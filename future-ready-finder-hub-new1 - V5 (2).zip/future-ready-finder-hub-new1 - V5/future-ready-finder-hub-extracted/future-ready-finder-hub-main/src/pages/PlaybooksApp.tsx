import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import PlaybookSidebar from "@/components/playbooks/PlaybookSidebar";
import PlaybookContent from "@/components/playbooks/PlaybookContent";
import { LogIn } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";

// Playbook structure array for scalable sidebar navigation (add more as needed)
const playbooks = [
  {
    id: "pb1",
    title: "Immediate Impact – Quick Wins for a Standout School",
    modules: [
      {
        id: "pb1m1",
        title: "Module 1: Powerful Positioning (Immediate Implementation)",
      },
      {
        id: "pb1m2",
        title: "Module 2: Initial Outreach Blitz",
      },
    ],
  },
  {
    id: "pb2",
    title: "Engaging Your Parent Community (Your Goldmine)",
    modules: [
      {
        id: "pb2m1",
        title: "Module 1: High-Value, Trust-Building Touchpoints",
      },
      {
        id: "pb2m2",
        title: "Module 2: Multiplied Outreach DFY (Tiny Budget)",
      },
    ],
  },
  // Explicitly add High Income Skills playbook for better visibility
  {
    id: "hi1",
    title: "High Income Skills Portfolio Building",
    modules: [
      {
        id: "hi1m1",
        title: "Module 1: Discovering Ourselves & New Opportunities",
      },
      {
        id: "hi1m2",
        title: "Module 2: Exploring Different Ways to Earn",
      },
      {
        id: "hi1m3",
        title: "Module 3: Learning How to Learn Effectively",
      },
      {
        id: "hi1m4",
        title: "Module 4: Building Your Skill Set",
      },
      {
        id: "hi1m5",
        title: "Module 5: Working Together & Sharing Ideas",
      },
      {
        id: "hi1m6",
        title: "Module 6: Organizing Your Portfolio & Planning Your Ongoing Journey",
      },
      {
        id: "hi1m7",
        title: "Module 7: Computer & Projector Enhanced Implementation",
      },
      {
        id: "hi1keywords",
        title: "Keyword & Prompt Library",
      },
    ],
  },
];

const PlaybooksApp = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedPlaybook, setSelectedPlaybook] = useState(playbooks[0].id);
  const [selectedModule, setSelectedModule] = useState(playbooks[0].modules[0].id);

  // Check authentication status on component mount
  useEffect(() => {
    const checkAuth = () => {
      // In a real app, we would validate JWT tokens or session cookies
      const loggedIn = localStorage.getItem("isLoggedIn") === "true";
      setIsLoggedIn(loggedIn);
      setIsLoading(false);
      
      if (!loggedIn) {
        toast({
          title: "Authentication Required",
          description: "Please log in to access the Playbooks App",
        });
      }
    };
    
    checkAuth();
  }, [toast]);

  // Use memo to prevent unnecessary re-renders
  const content = React.useMemo(() => {
    if (isLoading) {
      return (
        <div className="flex items-center justify-center min-h-screen">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      );
    }

    if (!isLoggedIn) {
      return (
        <main className="flex flex-col items-center justify-center min-h-[60vh] bg-gradient-to-br from-primary/10 via-accent/10 to-secondary/10">
          <div className="bg-white/70 rounded-2xl shadow-2xl p-10 flex flex-col items-center">
            <LogIn className="h-10 w-10 text-primary mb-4" />
            <h1 className="text-3xl font-bold mb-1">Please Log In</h1>
            <p className="text-gray-700 mb-6">This resource is exclusively for registered schools and management.</p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                onClick={() => navigate("/login")}
                className="bg-primary text-white px-6 py-2 rounded-md hover:bg-primary/90 transition-colors"
              >
                Log in
              </Button>
              <Button 
                onClick={() => navigate("/signup")}
                className="bg-secondary text-white px-6 py-2 rounded-md hover:bg-secondary/90 transition-colors"
              >
                Sign up
              </Button>
            </div>
            
            <div className="mt-8 border-t pt-6 text-center">
              <p className="text-gray-600">
                Students: Access helpful guides without logging in
              </p>
              <Button
                variant="link"
                className="text-accent"
                onClick={() => navigate("/student-guides")}
              >
                View Student Guides
              </Button>
            </div>
          </div>
        </main>
      );
    }

    return (
      <div className="flex min-h-screen bg-gradient-to-tr from-brand-50 to-accent-50 relative">
        <aside className="sticky top-0 h-screen z-20 w-72 bg-white/90 shadow-xl border-r border-gray-100 flex-shrink-0 hidden md:block animate-slide-in">
          <PlaybookSidebar
            playbooks={playbooks}
            selectedPlaybook={selectedPlaybook}
            setSelectedPlaybook={setSelectedPlaybook}
            selectedModule={selectedModule}
            setSelectedModule={setSelectedModule}
          />
        </aside>
        <main className="flex-1 flex flex-col items-center py-12 px-2 sm:px-8 overflow-y-auto z-10">
          <div className="w-full flex justify-end mb-4 px-4">
            <Button variant="outline" size="sm" onClick={() => navigate("/dashboard")}>
              Back to Dashboard
            </Button>
          </div>
          <div className="w-full max-w-4xl glass-morphism rounded-2xl overflow-hidden shadow-2xl border border-gray-100 animate-fade-in">
            <PlaybookContent
              playbookId={selectedPlaybook}
              moduleId={selectedModule}
              key={`${selectedPlaybook}-${selectedModule}`} // Add key to force re-render when module changes
            />
          </div>
        </main>
      </div>
    );
  }, [isLoading, isLoggedIn, navigate, selectedModule, selectedPlaybook, toast]);

  return content;
};

export default PlaybooksApp;
