
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Mail, MapPin, Phone, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { useIsMobile } from "@/hooks/use-mobile";

const Contact = () => {
  const isMobile = useIsMobile();
  
  return (
    <>
      <div className="bg-gradient-to-r from-primary to-secondary py-10 md:py-16">
        <div className="container px-4 md:px-6 mx-auto">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-4">Contact Us</h1>
          <p className="text-lg text-white/90 max-w-2xl">
            Have questions or ready to transform your institution? We're here to help.
          </p>
        </div>
      </div>
      
      <div className="container px-4 md:px-6 mx-auto py-12">
        <div className="max-w-3xl mx-auto">
          <div className="space-y-8">
            {/* Contact Information Section */}
            <div>
              <h2 className="text-2xl md:text-3xl font-bold mb-6">Get in Touch</h2>
              <p className="text-lg text-gray-600 mb-8">
                We're excited to hear from you. Reach out with your questions, feedback, or to learn more about how we can help your institution.
              </p>
              
              <div className="grid grid-cols-1 gap-6">
                <Card>
                  <CardContent className="flex items-start space-x-4 py-6">
                    <div className="bg-primary/10 p-3 rounded-full flex-shrink-0">
                      <Mail className="h-6 w-6 text-primary" />
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-bold text-lg">Email Us</h3>
                      <p className="text-gray-600 break-words">info@futurereadyschools.com</p>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="flex items-start space-x-4 py-6">
                    <div className="bg-primary/10 p-3 rounded-full flex-shrink-0">
                      <Phone className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-bold text-lg">Call Us</h3>
                      <p className="text-gray-600">+91 83745 07987</p>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="flex items-start space-x-4 py-6">
                    <div className="bg-primary/10 p-3 rounded-full flex-shrink-0">
                      <MapPin className="h-6 w-6 text-primary" />
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-bold text-lg">Visit Us</h3>
                      <p className="text-gray-600 break-words">
                        14-320, Durga nagar, opp police station,<br />
                        arilova, Visakhapatnam,<br />
                        Andhra Pradesh - 530040
                      </p>
                    </div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="flex items-start space-x-4 py-6">
                    <div className="bg-primary/10 p-3 rounded-full flex-shrink-0">
                      <Clock className="h-6 w-6 text-primary" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h3 className="font-bold text-lg">Office Hours</h3>
                      <div className={`grid ${!isMobile ? 'grid-cols-2' : 'grid-cols-1'} gap-4 mt-2`}>
                        <div>
                          <h4 className="font-medium text-gray-700">Weekdays</h4>
                          <p className="text-gray-600">Monday - Friday: 9:00 AM - 5:00 PM</p>
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-700">Weekends</h4>
                          <p className="text-gray-600">Saturday - Sunday: Closed</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
            
            <div>
              <h3 className="text-xl font-bold mb-4">How We Can Help</h3>
              <p className="text-gray-600 mb-6">
                Our team is ready to assist you with any questions about implementing future-ready education in your school. Whether you're looking for free resources or exploring our membership plans, we're here to support your journey.
              </p>
              <Button asChild className="w-full sm:w-auto">
                <Link to="/membership">
                  Explore Membership Plans
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Contact;
