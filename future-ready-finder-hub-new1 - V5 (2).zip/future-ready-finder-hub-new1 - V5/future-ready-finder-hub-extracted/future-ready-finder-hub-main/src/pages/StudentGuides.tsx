
import React, { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import StudentGuidesComponent from "@/components/guides/student";
import { useToast } from "@/components/ui/use-toast";
import { Book, ArrowLeft } from "lucide-react";

const StudentGuidesPage = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  
  // Check authentication
  useEffect(() => {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    
    if (!isLoggedIn) {
      toast({
        title: "Authentication Required",
        description: "Please log in to access student guides",
        variant: "destructive"
      });
      
      navigate('/login', { 
        state: { 
          from: '/student-guides' 
        }
      });
    }
  }, [navigate, toast]);
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-brand-50 to-accent-50">
      <div className="container mx-auto px-4 py-12">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-primary flex items-center">
            <Book className="mr-2 h-6 w-6" />
            Student Guides
          </h1>
          <Button variant="secondary" size="sm" onClick={() => navigate("/dashboard")} className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" /> Back to Dashboard
          </Button>
        </div>
        
        <div className="bg-white rounded-lg shadow-lg">
          <StudentGuidesComponent />
        </div>
      </div>
    </div>
  );
};

export default StudentGuidesPage;
