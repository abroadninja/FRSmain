
import React, { useState, useEffect } from "react";
import { 
  Building, Users, MessageSquare, UserPlus, 
  BookOpen, Download, Search, Filter, FileText, Database, X, File
} from "lucide-react";
import { resourceCategories, type ResourceCategory, type Resource } from "@/data/resources/downloadableResources";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";

const ResourcesHub = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [activeCategory, setActiveCategory] = useState<string>("all");
  const [filteredResources, setFilteredResources] = useState<Resource[]>([]);
  const { toast } = useToast();

  // Get icon component based on category icon name
  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case "building": return <Building className="h-5 w-5" />;
      case "users": return <Users className="h-5 w-5" />;
      case "message-square": return <MessageSquare className="h-5 w-5" />;
      case "user-plus": return <UserPlus className="h-5 w-5" />;
      case "book-open": return <BookOpen className="h-5 w-5" />;
      case "briefcase": return <BookOpen className="h-5 w-5" />;
      default: return <FileText className="h-5 w-5" />;
    }
  };

  // Get icon for resource type
  const getResourceTypeIcon = (type: string) => {
    switch (type) {
      case "pdf": return <File className="h-5 w-5 text-red-500" />;
      case "spreadsheet": return <Database className="h-5 w-5 text-green-500" />;
      case "document": return <FileText className="h-5 w-5 text-blue-500" />;
      default: return <File className="h-5 w-5 text-gray-500" />;
    }
  };

  // Filter resources based on search term and active category
  useEffect(() => {
    let results: Resource[] = [];
    
    if (activeCategory === "all") {
      // Combine all resources from all categories
      results = resourceCategories.flatMap(category => category.resources);
    } else {
      // Get resources from selected category
      const category = resourceCategories.find(cat => cat.id === activeCategory);
      results = category ? category.resources : [];
    }
    
    // Apply search filter if search term exists
    if (searchTerm.trim()) {
      const searchLower = searchTerm.toLowerCase();
      results = results.filter(resource => 
        resource.title.toLowerCase().includes(searchLower) || 
        (resource.description && resource.description.toLowerCase().includes(searchLower))
      );
    }
    
    setFilteredResources(results);
  }, [searchTerm, activeCategory]);

  // Handle resource download
  const handleResourceDownload = (resource: Resource) => {
    // Open the link in a new tab
    window.open(resource.link, "_blank");
    
    toast({
      title: "Resource opened",
      description: `${resource.title} has opened in a new tab.`,
      duration: 3000,
    });
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="flex flex-col space-y-6">
        <div>
          <h1 className="text-3xl font-bold">Resources Hub</h1>
          <p className="text-gray-600 mt-2">
            Access and download all ready-to-use resources for your school
          </p>
        </div>

        {/* Search and filter */}
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search resources..."
              className="pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          {searchTerm && (
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => setSearchTerm("")}
              aria-label="Clear search"
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>

        <Tabs defaultValue="grid" className="w-full">
          <div className="flex justify-between items-center">
            <TabsList>
              <TabsTrigger value="grid">Grid View</TabsTrigger>
              <TabsTrigger value="categories">Categories</TabsTrigger>
            </TabsList>
            
            <div className="text-sm text-gray-500">
              {filteredResources.length} resources found
            </div>
          </div>

          <TabsContent value="grid" className="mt-6">
            {filteredResources.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredResources.map((resource) => (
                  <Card key={resource.id} className="overflow-hidden hover:shadow-md transition-shadow">
                    <CardContent className="p-0">
                      <div className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-3">
                            {getResourceTypeIcon(resource.type)}
                            <div>
                              <h3 className="font-semibold">{resource.title}</h3>
                              {resource.description && (
                                <p className="text-sm text-gray-500 mt-1">{resource.description}</p>
                              )}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex justify-between items-center mt-4">
                          <Badge variant="outline" className="text-xs">
                            {resource.type === "pdf" ? "PDF Document" : 
                             resource.type === "spreadsheet" ? "Spreadsheet" : 
                             "Document"}
                          </Badge>
                          
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="text-primary"
                            onClick={() => handleResourceDownload(resource)}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Open
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <FileText className="h-12 w-12 mx-auto text-gray-400" />
                <h2 className="mt-4 text-xl font-semibold">No resources found</h2>
                <p className="text-gray-500 mt-2">
                  Try adjusting your search or filter criteria
                </p>
                {searchTerm && (
                  <Button 
                    variant="outline" 
                    className="mt-4"
                    onClick={() => setSearchTerm("")}
                  >
                    Clear search
                  </Button>
                )}
              </div>
            )}
          </TabsContent>

          <TabsContent value="categories" className="mt-6 space-y-8">
            {resourceCategories.map((category) => {
              // Filter resources in this category that match the search term
              const categoryResources = searchTerm.trim()
                ? category.resources.filter(
                    resource => resource.title.toLowerCase().includes(searchTerm.toLowerCase())
                  )
                : category.resources;
                
              // Skip rendering empty categories when searching
              if (searchTerm.trim() && categoryResources.length === 0) {
                return null;
              }
              
              return (
                <div key={category.id} className="space-y-4">
                  <div className="flex items-center gap-2">
                    <div className="bg-primary/10 p-2 rounded-lg">
                      {getCategoryIcon(category.icon)}
                    </div>
                    <h2 className="text-xl font-semibold">{category.title}</h2>
                    <Badge variant="outline">{categoryResources.length}</Badge>
                  </div>
                  
                  <p className="text-gray-600">{category.description}</p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {categoryResources.map((resource) => (
                      <Card key={resource.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex items-start gap-3">
                              {getResourceTypeIcon(resource.type)}
                              <div>
                                <h3 className="font-semibold">{resource.title}</h3>
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex justify-end mt-4">
                            <Button 
                              size="sm" 
                              variant="outline" 
                              className="text-primary"
                              onClick={() => handleResourceDownload(resource)}
                            >
                              <Download className="h-4 w-4 mr-2" />
                              Open
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              );
            })}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default ResourcesHub;
