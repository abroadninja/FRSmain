
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { 
  Award, 
  UserCheck, 
  TrendingUp, 
  CheckCircle, 
  Users 
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const About = () => {
  return (
    <>
      <Navbar />
      
      <div className="bg-gradient-to-r from-primary to-secondary py-12">
        <div className="container-custom">
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">About Future Ready Schools</h1>
          <p className="text-lg text-white/90 max-w-3xl">
            We're on a mission to transform education by preparing schools and students for the future.
          </p>
        </div>
      </div>
      
      <div className="container-custom py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Our Mission</h2>
            <p className="text-xl text-gray-600 mb-6">
              Future Ready Schools exists to empower educational institutions with the tools, resources, and strategies they need to thrive in a rapidly changing world.
            </p>
            <p className="text-lg text-gray-600 mb-6">
              We believe that every school deserves access to high-quality resources that help them increase enrollment, grow revenue, and provide future-ready education to their students.
            </p>
            <div className="space-y-4">
              <div className="flex items-start">
                <CheckCircle className="text-primary mr-3 mt-1 flex-shrink-0" />
                <p>
                  <strong>For Schools:</strong> We provide systems and strategies to boost enrollment and revenue.
                </p>
              </div>
              <div className="flex items-start">
                <CheckCircle className="text-primary mr-3 mt-1 flex-shrink-0" />
                <p>
                  <strong>For Students:</strong> We help develop high-income skills and future-ready education.
                </p>
              </div>
              <div className="flex items-start">
                <CheckCircle className="text-primary mr-3 mt-1 flex-shrink-0" />
                <p>
                  <strong>For Everyone:</strong> We make quality education more accessible and effective.
                </p>
              </div>
            </div>
          </div>
          <div>
            <img 
              src="https://images.unsplash.com/photo-1488590528505-98d2b5aba04b" 
              alt="Future Ready Schools team" 
              className="rounded-lg shadow-xl w-full"
            />
          </div>
        </div>
        
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Our Core Values</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-12">
            These principles guide everything we do and how we work with educational institutions.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-primary/10 p-4 rounded-full inline-flex mb-4">
                <Award size={32} className="text-primary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Excellence</h3>
              <p className="text-gray-600">
                We're committed to providing the highest quality tools, resources, and guidance to help schools succeed.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-secondary/10 p-4 rounded-full inline-flex mb-4">
                <UserCheck size={32} className="text-secondary" />
              </div>
              <h3 className="text-xl font-bold mb-3">Accessibility</h3>
              <p className="text-gray-600">
                We believe every school deserves access to quality resources, regardless of their budget or size.
              </p>
            </div>
            
            <div className="text-center">
              <div className="bg-accent/10 p-4 rounded-full inline-flex mb-4">
                <TrendingUp size={32} className="text-accent" />
              </div>
              <h3 className="text-xl font-bold mb-3">Innovation</h3>
              <p className="text-gray-600">
                We continuously evolve our approach to address the changing needs of education and the future of work.
              </p>
            </div>
          </div>
        </div>
        
        <div className="bg-gray-50 rounded-lg p-12 mb-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Our Story</h2>
              <p className="text-lg text-gray-600 mb-4">
                Future Ready Schools was founded by a team of educators, industry professionals, and technology experts who saw a growing gap between traditional education and the rapidly evolving needs of the modern workplace.
              </p>
              <p className="text-lg text-gray-600 mb-4">
                We recognized that many educational institutions were struggling with enrollment, revenue, and updating their curriculum to prepare students for future careers.
              </p>
              <p className="text-lg text-gray-600">
                Our solution was to create a platform that provides schools with the tools, resources, and strategies they need to thrive, while making much of it freely available to ensure accessibility for all.
              </p>
            </div>
            <div>
              <img 
                src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158" 
                alt="Our story" 
                className="rounded-lg shadow-xl w-full"
              />
            </div>
          </div>
        </div>
        
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Our Impact</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-12">
            We're proud of the difference we're making in education around the world.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="border rounded-lg p-6">
              <div className="text-4xl font-bold text-primary mb-2">500+</div>
              <div className="text-xl font-medium mb-2">Schools Supported</div>
              <p className="text-gray-600">
                Educational institutions using our tools and resources.
              </p>
            </div>
            
            <div className="border rounded-lg p-6">
              <div className="text-4xl font-bold text-primary mb-2">20,000+</div>
              <div className="text-xl font-medium mb-2">Students Reached</div>
              <p className="text-gray-600">
                Students benefiting from future-ready education.
              </p>
            </div>
            
            <div className="border rounded-lg p-6">
              <div className="text-4xl font-bold text-primary mb-2">30%</div>
              <div className="text-xl font-medium mb-2">Avg. Enrollment Increase</div>
              <p className="text-gray-600">
                Average enrollment growth for partner schools.
              </p>
            </div>
            
            <div className="border rounded-lg p-6">
              <div className="text-4xl font-bold text-primary mb-2">15+</div>
              <div className="text-xl font-medium mb-2">Countries</div>
              <p className="text-gray-600">
                Global reach of our educational solutions.
              </p>
            </div>
          </div>
        </div>
        
        <div className="text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Join Our Mission</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8">
            We're always looking for passionate individuals and organizations who share our vision for the future of education.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button size="lg" asChild>
              <Link to="/contact">Contact Us</Link>
            </Button>
            <Button variant="outline" size="lg" className="flex items-center gap-2" asChild>
              <Link to="/membership">
                <Users size={18} />
                View Membership Options
              </Link>
            </Button>
          </div>
        </div>
      </div>
      
      <Footer />
    </>
  );
};

export default About;
