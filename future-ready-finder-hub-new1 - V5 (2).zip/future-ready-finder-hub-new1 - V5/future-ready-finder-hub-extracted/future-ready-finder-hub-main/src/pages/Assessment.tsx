
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { 
  Activity, 
  ArrowRight, 
  BarChart, 
  Brain, 
  ClipboardList, 
  Lightbulb, 
  Puzzle, 
  Target,
  Rocket
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const Assessment = () => {
  return (
    <>
      <Navbar />
      
      <div className="bg-gradient-to-r from-secondary to-accent py-12">
        <div className="container-custom">
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">Psychometric Career Assessment</h1>
          <p className="text-lg text-white/90 max-w-3xl">
            Discover your strengths, interests, and ideal career paths through our comprehensive assessment.
          </p>
        </div>
      </div>
      
      <div className="container-custom py-16">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Brain size={48} className="mx-auto text-secondary mb-6" />
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Understand Your Career Potential</h2>
          <p className="text-lg text-gray-600">
            Our psychometric assessment helps students identify their natural aptitudes, interests, work styles, and personality traits to find career paths where they'll thrive.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <img 
              src="https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d" 
              alt="Person taking assessment" 
              className="rounded-lg shadow-lg w-full"
            />
          </div>
          
          <div className="space-y-6">
            <h3 className="text-2xl md:text-3xl font-bold">What Our Assessment Measures</h3>
            <p className="text-gray-600">
              Our comprehensive assessment evaluates multiple aspects of your personality, preferences, and aptitudes to provide personalized career guidance.
            </p>
            
            <div className="space-y-4">
              <div className="flex items-start">
                <div className="bg-primary/10 p-2 rounded-full mr-4 mt-1">
                  <Puzzle size={20} className="text-primary" />
                </div>
                <div>
                  <h4 className="font-bold mb-1">Cognitive Aptitudes</h4>
                  <p className="text-gray-600">Understand your natural abilities in areas like analytical thinking, creativity, and problem-solving.</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-secondary/10 p-2 rounded-full mr-4 mt-1">
                  <Lightbulb size={20} className="text-secondary" />
                </div>
                <div>
                  <h4 className="font-bold mb-1">Interests & Passions</h4>
                  <p className="text-gray-600">Identify what truly engages and motivates you for long-term career satisfaction.</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-accent/10 p-2 rounded-full mr-4 mt-1">
                  <Target size={20} className="text-accent" />
                </div>
                <div>
                  <h4 className="font-bold mb-1">Work Style Preferences</h4>
                  <p className="text-gray-600">Discover your ideal work environment and collaboration style.</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="bg-emerald-500/10 p-2 rounded-full mr-4 mt-1">
                  <BarChart size={20} className="text-emerald-500" />
                </div>
                <div>
                  <h4 className="font-bold mb-1">Skills Assessment</h4>
                  <p className="text-gray-600">Evaluate your current skill set and identify areas for development.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-gray-50 p-8 rounded-lg mb-16">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold mb-3">How the Assessment Works</h3>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Our assessment process is designed to be comprehensive yet user-friendly, providing valuable insights into your career potential.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center">
              <div className="bg-secondary/20 h-14 w-14 rounded-full flex items-center justify-center mb-4">
                <ClipboardList size={28} className="text-secondary" />
              </div>
              <h4 className="font-bold mb-2">Take the Assessment</h4>
              <p className="text-gray-600">
                Complete our comprehensive assessment (approximately 30-45 minutes) at your own pace.
              </p>
            </div>
            
            <div className="flex flex-col items-center text-center">
              <div className="bg-secondary/20 h-14 w-14 rounded-full flex items-center justify-center mb-4">
                <Activity size={28} className="text-secondary" />
              </div>
              <h4 className="font-bold mb-2">Get Personalized Results</h4>
              <p className="text-gray-600">
                Receive a detailed analysis of your aptitudes, interests, and recommended career paths.
              </p>
            </div>
            
            <div className="flex flex-col items-center text-center">
              <div className="bg-secondary/20 h-14 w-14 rounded-full flex items-center justify-center mb-4">
                <Rocket size={28} className="text-secondary" />
              </div>
              <h4 className="font-bold mb-2">Explore Matched Careers</h4>
              <p className="text-gray-600">
                Discover careers that align with your profile and explore educational pathways to achieve them.
              </p>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-xl font-bold mb-3">For Students</h3>
              <p className="text-gray-600 mb-4">
                Discover careers that align with your natural strengths and interests to make informed educational choices.
              </p>
              <ul className="space-y-2 mb-6">
                <li className="flex items-center">
                  <CheckItem />
                  <span>Personalized career matches</span>
                </li>
                <li className="flex items-center">
                  <CheckItem />
                  <span>Course recommendations</span>
                </li>
                <li className="flex items-center">
                  <CheckItem />
                  <span>Skills development roadmap</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button className="w-full" asChild>
                <Link to="#">Coming Soon</Link>
              </Button>
            </CardFooter>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-xl font-bold mb-3">For Schools</h3>
              <p className="text-gray-600 mb-4">
                Help your students make better career decisions and align your programs with their aspirations.
              </p>
              <ul className="space-y-2 mb-6">
                <li className="flex items-center">
                  <CheckItem />
                  <span>Bulk assessment access</span>
                </li>
                <li className="flex items-center">
                  <CheckItem />
                  <span>School-wide analytics</span>
                </li>
                <li className="flex items-center">
                  <CheckItem />
                  <span>Counselor tools & resources</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button className="w-full" variant="outline" asChild>
                <Link to="/contact">Request Information</Link>
              </Button>
            </CardFooter>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <h3 className="text-xl font-bold mb-3">For Institutions</h3>
              <p className="text-gray-600 mb-4">
                Attract students who are well-matched to your programs and improve retention rates.
              </p>
              <ul className="space-y-2 mb-6">
                <li className="flex items-center">
                  <CheckItem />
                  <span>Program-student matching</span>
                </li>
                <li className="flex items-center">
                  <CheckItem />
                  <span>Career pathway integration</span>
                </li>
                <li className="flex items-center">
                  <CheckItem />
                  <span>Customized assessment options</span>
                </li>
              </ul>
            </CardContent>
            <CardFooter>
              <Button className="w-full" variant="outline" asChild>
                <Link to="/contact">Partner With Us</Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
        
        <div className="bg-primary/5 rounded-lg p-8 text-center">
          <h3 className="text-2xl font-bold mb-4">Our Assessment Tool is Coming Soon!</h3>
          <p className="text-lg text-gray-600 mb-6 max-w-2xl mx-auto">
            We're currently developing a comprehensive psychometric assessment tool to help students discover their ideal career paths.
          </p>
          <Button asChild>
            <Link to="/contact">Get Notified When It Launches</Link>
          </Button>
        </div>
      </div>
      
      <Footer />
    </>
  );
};

// Helper component for check marks
const CheckItem = () => (
  <div className="h-5 w-5 rounded-full bg-green-100 flex items-center justify-center mr-3 flex-shrink-0">
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M10 3L4.5 8.5L2 6" stroke="#10B981" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  </div>
);

export default Assessment;
