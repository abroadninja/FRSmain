
import React from "react";
import { Helmet } from "react-helmet";
import { Button } from "@/components/ui/button";
import { ArrowRight, PanelTop } from "lucide-react";
import { useResponsive } from "@/hooks/use-responsive";

// Keeping the original dashboard in the codebase but not showing it
const Dashboard = () => {
  const { isMobile } = useResponsive();
  
  return (
    <>
      <Helmet>
        <title>Future Ready Dashboard</title>
      </Helmet>
      
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
        <div className="container mx-auto py-16 px-4 max-w-6xl">
          <div className="text-center mb-14">
            <span className="inline-block bg-blue-100 text-blue-800 text-sm font-semibold px-4 py-1 rounded-full mb-4">
              Future Ready Platform
            </span>
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-5 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600">
              Transform Your School's Future
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Unlock the full potential of your educational institution with our comprehensive suite of tools, resources, and frameworks designed to create future-ready learning environments.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
            {/* Interactive Demos Card */}
            <div className="group bg-white rounded-2xl shadow-xl border border-indigo-50 p-7 hover:shadow-2xl transition-all duration-300 hover:-translate-y-1">
              <div className="h-14 w-14 bg-indigo-100 rounded-xl flex items-center justify-center mb-5 group-hover:bg-indigo-200 transition-colors">
                <ArrowRight className="h-7 w-7 text-indigo-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-3">Explore Our Demo Library</h3>
              <p className="text-gray-600 mb-7 text-lg leading-relaxed">
                Browse our collection of interactive demos designed to showcase various aspects of our platform. Each demo provides a focused look at specific features and tools available to enhance your school's future readiness.
              </p>
              <Button 
                size={isMobile ? "default" : "lg"}
                className="bg-indigo-600 hover:bg-indigo-700 text-white w-full py-6 text-base font-medium transition-all duration-300 hover:shadow-lg" 
                asChild
              >
                <a 
                  href="https://alldemos.futurereadyschools.com/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-3"
                >
                  Explore All Demos
                  <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </a>
              </Button>
            </div>
            
            {/* School Growth Dashboard Card */}
            <div className="group bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl shadow-xl p-7 hover:shadow-2xl transition-all duration-300 hover:-translate-y-1 text-white">
              <div className="h-14 w-14 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center mb-5 group-hover:bg-white/30 transition-colors">
                <PanelTop className="h-7 w-7 text-white" />
              </div>
              <div className="mb-1 text-sm font-semibold text-blue-100">PREMIUM ACCESS</div>
              <h3 className="text-2xl font-bold mb-3">School Growth Dashboard</h3>
              <p className="text-blue-100 mb-7 text-lg leading-relaxed">
                Your all-in-one command center for school transformation. Access our comprehensive library of playbooks, tools, apps, and ready-to-use resources designed to drive meaningful educational outcomes.
              </p>
              <Button 
                size={isMobile ? "default" : "lg"}
                variant="secondary"
                className="bg-white text-blue-700 hover:bg-blue-50 w-full py-6 text-base font-medium transition-all duration-300 hover:shadow-lg group-hover:shadow-lg" 
                asChild
              >
                <a 
                  href="https://maindashboard.futurereadyschools.com/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-3"
                >
                  Launch Dashboard
                  <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
                </a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;
