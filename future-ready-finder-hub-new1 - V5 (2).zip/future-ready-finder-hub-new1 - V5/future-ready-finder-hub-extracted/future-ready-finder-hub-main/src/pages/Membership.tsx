
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { 
  CheckCircle, 
  XCircle, 
  MessageCircle, 
  Users, 
  Award, 
  Star, 
  FileText,
  BarChart,
  Heart
} from "lucide-react";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";

const Membership = () => {
  const { toast } = useToast();
  const [waitlistEmail, setWaitlistEmail] = useState("");
  const [waitlistPhone, setWaitlistPhone] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isAnnual, setIsAnnual] = useState(true);

  const handleJoinWaitlist = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Added to waitlist successfully!",
        description: "We'll notify you when Growth Accelerator spots become available.",
      });
      setIsSubmitting(false);
      setWaitlistEmail("");
      setWaitlistPhone("");
    }, 1000);
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-slate-50 pattern-bg">
      {/* Header with gradient background */}
      <div className="bg-gradient-to-r from-primary to-secondary py-12 md:py-20 px-4">
        <div className="container max-w-7xl mx-auto text-center">
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold text-white leading-none mb-6">
            The <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-orange-300">Unfair Advantage</span> Your School Needs
          </h1>
          <p className="text-lg md:text-xl lg:text-2xl text-white/90 max-w-4xl mx-auto mb-8 font-medium">
            Stop burning cash. We give you the <span className="font-bold text-white">COMPLETE, PROVEN SYSTEM</span> (worth lakhs!) to skyrocket enrollment, create raving fan parents, and build future-proof students. Starting at <span className="font-extrabold underline decoration-wavy">₹0.</span>
          </p>
          <p className="text-base md:text-lg lg:text-xl text-white/80 max-w-3xl mx-auto">
            Choose your path to market dominance.
          </p>
        </div>
      </div>
      
      <div className="container max-w-7xl mx-auto px-4 py-16" id="pricing">
        {/* Billing toggle */}
        <div className="flex items-center justify-center gap-3 mb-12">
          <Label htmlFor="billing-toggle" className={`text-sm md:text-base font-medium ${!isAnnual ? 'text-primary font-bold' : 'text-gray-500'}`}>
            Pay Monthly
          </Label>
          <div className="relative inline-block h-7 w-12 align-middle select-none transition duration-200 ease-in">
            <Switch 
              id="billing-toggle" 
              checked={isAnnual} 
              onCheckedChange={(checked) => setIsAnnual(checked)} 
              className="bg-gray-300 data-[state=checked]:bg-green-500"
            />
          </div>
          <Label htmlFor="billing-toggle" className={`text-sm md:text-base font-medium ${isAnnual ? 'text-primary font-bold' : 'text-gray-500'}`}>
            Pay Annually <span className="text-xs md:text-sm text-green-600 font-semibold">(Save 20%!)</span>
          </Label>
        </div>
        
        {/* Pricing cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {/* Free Plan */}
          <Card className="border-2 border-gray-200 border-t-4 border-t-blue-500 relative rounded-3xl shadow-xl transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl bg-white overflow-hidden">
            <CardHeader className="pb-2">
              <h3 className="text-2xl md:text-3xl font-bold mb-2 text-center">Zero-Cost <span className="text-blue-600">Dominance Engine</span></h3>
              <p className="text-gray-600 text-center text-base md:text-lg font-medium">The Entire Playbook. Absolutely FREE.</p>
              
              <div className="my-6 text-center">
                <span className="text-6xl md:text-7xl font-black text-gray-900">₹0</span>
                <span className="block text-lg md:text-xl font-semibold text-gray-600 mt-1">Forever. No Catch.</span>
              </div>
              
              <p className="text-sm text-gray-600 text-center italic font-medium">No trials, no hidden fees. Just pure value.</p>
            </CardHeader>
            
            <CardContent className="pt-4 pb-6">
              <ul className="space-y-4 text-gray-700 mb-6">
                <FeatureItem included>
                  <span className="font-semibold">Complete Growth & Positioning Toolkit</span>
                </FeatureItem>
                <FeatureItem included>
                  <span className="font-semibold">Parent Engagement & Community Arsenal</span>
                </FeatureItem>
                <FeatureItem included>
                  <span className="font-semibold">Student Future-Readiness Pack</span> (High Income Skill Building & Curriculum)
                </FeatureItem>
                <FeatureItem included>
                  <span className="font-semibold">Streamlined Admissions & Operations Systems</span>
                </FeatureItem>
                <FeatureItem included>
                  <span className="font-semibold">Teacher Empowerment Resources</span>
                </FeatureItem>
                <FeatureItem included>
                  <span className="font-semibold">Full Implementation Playbooks & Templates</span>
                </FeatureItem>
                <FeatureItem included>
                  Basic Implementation Community (WhatsApp)
                </FeatureItem>
                <FeatureItem included>
                  Exclusive Implementation Webapp Access
                </FeatureItem>
              </ul>
            </CardContent>
            
            <CardFooter className="pt-0 flex flex-col">
              <Button asChild className="w-full bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 text-lg font-bold py-6 rounded-xl shadow-lg transition-all duration-300 hover:scale-[1.03]">
                <Link to="/signup">GET FREE ACCESS</Link>
              </Button>
              <p className="text-xs text-gray-500 text-center mt-3">Start transforming your school now.</p>
            </CardFooter>
          </Card>
          
          {/* Growth Catalyst */}
          <Card className="border-2 border-t-4 border-t-amber-400 relative rounded-3xl shadow-xl transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl overflow-hidden bg-gradient-to-br from-gray-800 via-gray-900 to-black transform scale-105 z-10">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-gradient-to-r from-amber-400 to-yellow-400 text-gray-900 font-extrabold px-6 py-1 rounded-full text-sm shadow-lg border-2 border-white">
              ACCELERATE RESULTS
            </div>
            
            <CardHeader className="pb-2 pt-8">
              <h3 className="text-2xl md:text-3xl font-bold mb-2 text-center text-white">Growth Catalyst <span className="text-amber-400">Community</span></h3>
              <p className="text-gray-300 text-center text-base md:text-lg font-medium">The Shortcut: Expert Q&A to Implement Faster.</p>
              
              <div className="my-6 text-center">
                <span className="text-6xl md:text-7xl font-black text-white">
                  ₹{isAnnual ? '250' : '350'}
                </span>
                <span className="block text-lg md:text-xl font-semibold text-gray-400 mt-1">/ school / month</span>
                <p className="text-md text-amber-300 mt-3 font-semibold italic">
                  {isAnnual ? 'Billed Annually (₹3000). Insane Value.' : 'Billed Monthly. Flexibility first.'}
                </p>
                {isAnnual && (
                  <p className="text-xs text-gray-400 mt-1">(Less than ₹9/day for expert access!)</p>
                )}
              </div>
              
              <p className="text-sm text-gray-400 text-center italic font-medium">Stop guessing. Get direct answers weekly.</p>
            </CardHeader>
            
            <CardContent className="pt-4 pb-6">
              <ul className="space-y-4 text-gray-200 mb-6">
                <FeatureItem included variant="dark">
                  <span className="font-semibold">EVERYTHING in Zero-Cost Engine</span>
                </FeatureItem>
                <FeatureItem included variant="dark" icon="message">
                  <span className="font-extrabold text-amber-300">Weekly LIVE Q&A (WhatsApp):</span> Get implementation questions answered FAST.
                </FeatureItem>
                <FeatureItem included variant="dark" icon="users">
                  <span className="font-semibold">Exclusive Community Access:</span> Network & learn with driven school leaders.
                </FeatureItem>
                <FeatureItem included variant="dark">
                  Potential Early Updates on new strategies.
                </FeatureItem>
              </ul>
            </CardContent>
            
            <CardFooter className="pt-0 flex flex-col">
              <Button asChild className="w-full bg-gradient-to-r from-amber-400 to-yellow-400 hover:from-amber-500 hover:to-yellow-500 text-gray-900 text-lg font-bold py-6 rounded-xl shadow-lg transition-all duration-300 hover:scale-[1.03]">
                <Link to="/contact">JOIN INNER CIRCLE</Link>
              </Button>
              <p className="text-xs text-gray-400 text-center mt-3">Invest in speed & certainty.</p>
            </CardFooter>
          </Card>
          
          {/* Impact Accelerator */}
          <Card className="border-2 border-t-4 border-t-violet-400 relative rounded-3xl shadow-xl transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl overflow-hidden bg-gradient-to-br from-purple-600 via-indigo-700 to-blue-800">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-gradient-to-r from-violet-300 to-purple-400 text-gray-900 font-extrabold px-6 py-1 rounded-full text-sm shadow-lg border-2 border-white">
              PREMIUM COHORT
            </div>
            
            <CardHeader className="pb-2 pt-8">
              <h3 className="text-2xl md:text-3xl font-bold mb-2 text-center text-white">Impact Accelerator <span className="text-violet-300">Cohort</span></h3>
              <p className="text-indigo-200 text-center text-base md:text-lg font-medium">Done-With-You Implementation. Max Accountability.</p>
              
              <div className="my-6 text-center">
                <span className="text-6xl md:text-7xl font-black text-white">
                  ₹{isAnnual ? '2000' : '2500'}
                </span>
                <span className="block text-lg md:text-xl font-semibold text-indigo-300 mt-1">/ school / month</span>
                <p className="text-md text-violet-300 mt-3 font-semibold italic">
                  {isAnnual ? 'Billed Annually (₹24000). Limited Spots.' : 'Billed Monthly. Maximum Flexibility.'}
                </p>
                {isAnnual && (
                  <p className="text-xs text-indigo-300 mt-1">(Exclusive group guidance for ~₹65/day!)</p>
                )}
              </div>
              
              <p className="text-sm text-indigo-200 text-center italic font-medium">For schools committed to rapid, guided transformation.</p>
            </CardHeader>
            
            <CardContent className="pt-4 pb-6">
              <ul className="space-y-4 text-indigo-100 mb-6">
                <FeatureItem included variant="premium">
                  <span className="font-semibold">EVERYTHING in Growth Catalyst Community</span>
                </FeatureItem>
                <FeatureItem included variant="premium" icon="users-round">
                  <span className="font-extrabold text-violet-300">Done-With-You Implementation Sessions:</span> 3 dedicated group meetings per month.
                </FeatureItem>
                <FeatureItem included variant="premium" icon="user-round">
                  <span className="font-semibold">Exclusive Cohort:</span> Limited to only 8 schools for personalized attention.
                </FeatureItem>
                <FeatureItem included variant="premium" icon="target">
                  <span className="font-semibold">Accountability & Peer Support:</span> Structured progress with a motivated group.
                </FeatureItem>
              </ul>
            </CardContent>
            
            <CardFooter className="pt-0 flex flex-col">
              <form onSubmit={handleJoinWaitlist} className="w-full space-y-3">
                <Input 
                  type="email" 
                  placeholder="Your Email" 
                  value={waitlistEmail}
                  onChange={(e) => setWaitlistEmail(e.target.value)}
                  required
                  className="bg-white/10 text-white border-white/20 placeholder:text-white/60"
                />
                <Input 
                  type="tel" 
                  placeholder="WhatsApp Number" 
                  value={waitlistPhone}
                  onChange={(e) => setWaitlistPhone(e.target.value)}
                  required
                  className="bg-white/10 text-white border-white/20 placeholder:text-white/60"
                />
                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-violet-300 to-purple-400 hover:from-violet-400 hover:to-purple-500 text-gray-900 text-lg font-bold py-6 rounded-xl shadow-lg transition-all duration-300 hover:scale-[1.03]"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? "Processing..." : "APPLY FOR COHORT"}
                </Button>
              </form>
              <p className="text-xs text-indigo-300 text-center mt-3">Serious inquiries only. Spots are extremely limited.</p>
            </CardFooter>
          </Card>
        </div>
        
        {/* Custom Solutions Section */}
        <div className="mt-24 md:mt-32 pt-10 border-t border-gray-300 text-center">
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-gray-900 mb-6">
            Need Something <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-500 to-cyan-500">More Specific</span>?
          </h2>
          <p className="text-lg md:text-xl lg:text-2xl text-gray-700 max-w-4xl mx-auto mb-12 font-medium">
            We offer targeted solutions to solve your school's unique challenges and accelerate growth beyond our core plans.
          </p>
          
          <Card className="p-8 md:p-10 mb-12 max-w-4xl mx-auto text-left rounded-2xl shadow-xl border border-gray-200">
            <CardHeader className="pb-4">
              <h3 className="text-2xl md:text-3xl font-bold text-gray-800 flex items-center justify-center">
                <Star className="h-8 w-8 mr-3 text-teal-500" />
                Custom Solutions & Add-Ons
              </h3>
            </CardHeader>
            
            <CardContent className="pt-0">
              <p className="text-lg md:text-xl text-gray-700 mb-4">
                Our specialized services include:
              </p>
              <ul className="list-disc list-inside ml-4 space-y-2 text-gray-700 text-base md:text-lg">
                <li><span className="font-semibold">Affordable School Website Design:</span> Full positioning, built to convert parents.</li>
                <li><span className="font-semibold">Whitelabelled School Apps:</span> Your brand, our powerful app technology for seamless parent communication & engagement.</li>
              </ul>
              <p className="text-lg md:text-xl mt-6 text-center text-gray-700">
                Plus, explore other premium community tiers, bespoke consulting, and done-for-you services tailored to your exact needs and budget.
              </p>
            </CardContent>
            
            <CardFooter className="pt-4 flex justify-center">
              <Button asChild className="bg-gradient-to-r from-gray-800 to-black hover:from-gray-700 hover:to-gray-900 text-white text-lg font-bold py-6 px-8 rounded-xl shadow-lg transition-all duration-300 hover:scale-[1.03]">
                <Link to="/contact">Explore Custom Solutions</Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
        
        {/* Donate Button - Preserved from original */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-pink-100 to-purple-100 p-8 rounded-xl max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold mb-3">Support Our Mission</h3>
            <p className="text-gray-700 mb-6">
              We're committed to keeping our implementation resources free for all schools.
              If you find our resources valuable, consider supporting our mission with a donation.
            </p>
            <Button className="bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white font-medium" size="lg" asChild>
              <a href="#" className="flex items-center gap-2">
                <Heart className="h-5 w-5" />
                Donate and Support
              </a>
            </Button>
          </div>
        </div>
        
        {/* Value Proposition Cards - Preserved from original */}
        <div className="mt-20 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
          <Card className="border border-gray-100 hover:shadow-md transition-all">
            <CardHeader className="pb-2">
              <div className="bg-primary/10 p-2 w-12 h-12 flex items-center justify-center rounded-lg mb-4">
                <MessageCircle className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold">Expert-Led Community</h3>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Connect with school growth experts who understand the unique challenges of the Indian educational landscape.
              </p>
            </CardContent>
          </Card>
          
          <Card className="border border-gray-100 hover:shadow-md transition-all">
            <CardHeader className="pb-2">
              <div className="bg-primary/10 p-2 w-12 h-12 flex items-center justify-center rounded-lg mb-4">
                <Users className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold">Implementation Network</h3>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Build relationships with forward-thinking school leaders across India. Share challenges and celebrate wins together.
              </p>
            </CardContent>
          </Card>
          
          <Card className="border border-gray-100 hover:shadow-md transition-all">
            <CardHeader className="pb-2">
              <div className="bg-primary/10 p-2 w-12 h-12 flex items-center justify-center rounded-lg mb-4">
                <Award className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold">Growth Badge</h3>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Showcase your commitment to educational excellence with our official member badge. Stand out from competitors.
              </p>
            </CardContent>
          </Card>
          
          <Card className="border border-gray-100 hover:shadow-md transition-all">
            <CardHeader className="pb-2">
              <div className="bg-primary/10 p-2 w-12 h-12 flex items-center justify-center rounded-lg mb-4">
                <BarChart className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold">Proven Growth Systems</h3>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">
                Our playbooks are specifically designed for Indian schools, with strategies for significant enrollment growth.
              </p>
            </CardContent>
          </Card>
        </div>
        
        {/* FAQ Section - Preserved from original */}
        <div className="mt-24 max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
            <p className="text-gray-600">
              Get answers to common questions about our membership options
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="font-bold text-xl mb-2">What resources are included in the free plan?</h3>
              <p className="text-gray-600">
                The free plan includes complete access to our playbooks, implementation guides, marketing templates, parent communication scripts, high-income skill portfolio guidance, and all the practical tools you need for school growth.
              </p>
            </div>
            
            <div>
              <h3 className="font-bold text-xl mb-2">How is the Growth Network membership different?</h3>
              <p className="text-gray-600">
                Growth Network adds community support through our WhatsApp group, weekly expert Q&A sessions, and the official member badge for your school. It's about implementation support and networking.
              </p>
            </div>
            
            <div>
              <h3 className="font-bold text-xl mb-2">How many schools can join the Growth Accelerator?</h3>
              <p className="text-gray-600">
                Growth Accelerator is limited to 64 schools (eight groups of eight members). This ensures deep attention and personalized implementation support for each participating school.
              </p>
            </div>
            
            <div>
              <h3 className="font-bold text-xl mb-2">Are these strategies applicable to my school?</h3>
              <p className="text-gray-600">
                Yes, our systems are specifically designed for the Indian educational landscape, working for schools of all sizes across the country, from established institutions to newer schools looking to grow.
              </p>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <p className="text-gray-600 mb-4">Still have questions?</p>
            <Button asChild>
              <Link to="/contact">Contact Our Support Team</Link>
            </Button>
          </div>
        </div>
      </div>
      
      {/* Call to Action Banner */}
      <div className="bg-gradient-to-r from-primary to-secondary py-16 mt-16">
        <div className="container mx-auto text-center text-white px-4 max-w-4xl">
          <h2 className="text-2xl md:text-3xl font-bold mb-4">Ready to Transform Your School?</h2>
          <p className="text-xl mb-8">
            Join our community of forward-thinking schools implementing proven growth strategies
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button size="lg" className="bg-white text-primary hover:bg-white/90 font-semibold text-lg py-6" asChild>
              <Link to="/signup">Access Free Resources</Link>
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10 font-semibold text-lg py-6" asChild>
              <Link to="/contact">Join Growth Network</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

interface FeatureItemProps {
  included?: boolean;
  children: React.ReactNode;
  variant?: 'light' | 'dark' | 'premium';
  icon?: string;
}

const FeatureItem = ({ included = true, children, variant = 'light', icon = 'check' }: FeatureItemProps) => {
  const getIconColor = () => {
    if (variant === 'dark') return "text-amber-400";
    if (variant === 'premium') return "text-violet-300";
    return "text-green-500";
  };

  const renderIcon = () => {
    const iconColor = getIconColor();
    
    if (!included) {
      return <XCircle size={18} className="text-gray-300 mt-0.5 mr-2 flex-shrink-0" />;
    }
    
    switch (icon) {
      case 'message':
        return <MessageCircle size={18} className={`${iconColor} mt-0.5 mr-2 flex-shrink-0`} />;
      case 'users':
        return <Users size={18} className={`${iconColor} mt-0.5 mr-2 flex-shrink-0`} />;
      case 'users-round':
        return (
          <svg 
            className={`h-[18px] w-[18px] ${iconColor} mt-0.5 mr-2 flex-shrink-0`} 
            xmlns="http://www.w3.org/2000/svg" 
            fill="none" 
            viewBox="0 0 24 24" 
            strokeWidth="2" 
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-3.741-5.588M14.25 18.72a9.094 9.094 0 01-3.741-.479 3 3 0 01-3.741-5.588m-3.75 0a9.094 9.094 0 00-3.741.479 3 3 0 00-3.741-5.588" />
          </svg>
        );
      case 'user-round':
        return (
          <svg 
            className={`h-[18px] w-[18px] ${iconColor} mt-0.5 mr-2 flex-shrink-0`} 
            xmlns="http://www.w3.org/2000/svg" 
            fill="none" 
            viewBox="0 0 24 24" 
            strokeWidth="2" 
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A1.875 1.875 0 0118 22.5h-12a1.875 1.875 0 01-1.499-2.382z" />
          </svg>
        );
      case 'target':
        return (
          <svg 
            className={`h-[18px] w-[18px] ${iconColor} mt-0.5 mr-2 flex-shrink-0`} 
            xmlns="http://www.w3.org/2000/svg" 
            fill="none" 
            viewBox="0 0 24 24" 
            strokeWidth="2" 
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 18L9 11.25l4.306 4.307a11.95 11.95 0 015.814-5.519l2.74-1.22m0 0l-5.94-2.28m5.94 2.28l-2.28 5.941" />
          </svg>
        );
      default: // check
        return <CheckCircle size={18} className={`${iconColor} mt-0.5 mr-2 flex-shrink-0`} />;
    }
  };

  return (
    <li className={cn("flex items-start list-none", included ? "" : "opacity-60")}>
      {renderIcon()}
      <span className={cn("flex-1 leading-tight", included ? "" : "text-gray-400")}>{children}</span>
    </li>
  );
};

export default Membership;
