
import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";
import { Search, Filter, GraduationCap, MapPin, Users, Globe, DollarSign, BarChart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from "@/components/ui/tooltip";
import { collegesData } from "@/data/collegesData";
import { GlobalCollege } from "@/types/college.types";

const CollegeFinder = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredColleges, setFilteredColleges] = useState<GlobalCollege[]>(collegesData);
  const [showFilters, setShowFilters] = useState(false);
  
  const [selectedCountries, setSelectedCountries] = useState<string[]>([]);
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const [selectedDegrees, setSelectedDegrees] = useState<string[]>([]);
  const [tuitionRange, setTuitionRange] = useState<[number, number]>([0, 60000]);
  const [sortBy, setSortBy] = useState("ranking");
  
  const countries = Array.from(new Set(collegesData.map(college => college.country)));
  const types = Array.from(new Set(collegesData.map(college => college.type)));
  const allDegrees = Array.from(new Set(collegesData.flatMap(college => college.degrees)));
  
  useEffect(() => {
    let results = [...collegesData];
    
    if (searchTerm) {
      results = results.filter(
        college => 
          college.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          college.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
          college.programs.some(program => program.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }
    
    if (selectedCountries.length > 0) {
      results = results.filter(college => selectedCountries.includes(college.country));
    }
    
    if (selectedTypes.length > 0) {
      results = results.filter(college => selectedTypes.includes(college.type));
    }
    
    if (selectedDegrees.length > 0) {
      results = results.filter(college => 
        college.degrees.some(degree => selectedDegrees.includes(degree))
      );
    }
    
    results = results.filter(
      college => college.tuitionFee >= tuitionRange[0] && college.tuitionFee <= tuitionRange[1]
    );
    
    results = sortColleges(results, sortBy);
    
    setFilteredColleges(results);
  }, [searchTerm, selectedCountries, selectedTypes, selectedDegrees, tuitionRange, sortBy]);
  
  const sortColleges = (colleges: GlobalCollege[], sortMethod: string) => {
    switch (sortMethod) {
      case "name":
        return [...colleges].sort((a, b) => a.name.localeCompare(b.name));
      case "ranking":
        return [...colleges].sort((a, b) => a.ranking - b.ranking);
      case "tuition_low":
        return [...colleges].sort((a, b) => a.tuitionFee - b.tuitionFee);
      case "tuition_high":
        return [...colleges].sort((a, b) => b.tuitionFee - a.tuitionFee);
      default:
        return colleges;
    }
  };
  
  const toggleCountry = (country: string) => {
    setSelectedCountries(prev => 
      prev.includes(country)
        ? prev.filter(c => c !== country)
        : [...prev, country]
    );
  };
  
  const toggleType = (type: string) => {
    setSelectedTypes(prev => 
      prev.includes(type)
        ? prev.filter(t => t !== type)
        : [...prev, type]
    );
  };
  
  const toggleDegree = (degree: string) => {
    setSelectedDegrees(prev => 
      prev.includes(degree)
        ? prev.filter(d => d !== degree)
        : [...prev, degree]
    );
  };
  
  const resetFilters = () => {
    setSearchTerm("");
    setSelectedCountries([]);
    setSelectedTypes([]);
    setSelectedDegrees([]);
    setTuitionRange([0, 60000]);
    setSortBy("ranking");
  };

  return (
    <>
      <Helmet>
        <title>Global College Finder | Discover The Best International Universities</title>
        <meta name="description" content="Find top global universities and colleges by ranking, tuition, and program. Easily search, filter, and compare international colleges for your next academic journey." />
        <meta name="keywords" content="global colleges, international universities, study abroad, world university rankings, compare colleges, international education" />
      </Helmet>
      
      <div className="bg-gradient-to-r from-primary/90 to-secondary/90 py-12">
        <div className="container-custom">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-2">Global College Finder</h1>
              <p className="text-lg text-white/90 max-w-3xl">
                Discover the perfect international college or university that matches your academic goals, budget, and career aspirations.
              </p>
            </div>
            <div className="hidden lg:block">
              <Button variant="default" className="bg-white text-primary hover:bg-gray-100" asChild>
                <Link to="/india-colleges">Indian Colleges</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      <div className="container-custom py-8">
        <div className="mb-8 bg-white rounded-lg shadow-md p-6">
          <div className="flex flex-col md:flex-row md:items-center gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              <Input
                type="search"
                placeholder="Search by college name, location, or program..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="flex gap-3">
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ranking">Ranking: Best First</SelectItem>
                  <SelectItem value="name">Name: A-Z</SelectItem>
                  <SelectItem value="tuition_low">Tuition: Low to High</SelectItem>
                  <SelectItem value="tuition_high">Tuition: High to Low</SelectItem>
                </SelectContent>
              </Select>
              
              <Button 
                variant="outline" 
                className="flex items-center gap-2"
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter size={18} /> {showFilters ? "Hide Filters" : "Show Filters"}
              </Button>
            </div>
          </div>
          
          {showFilters && (
            <div className="border-t pt-6 mt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div>
                  <h3 className="font-medium mb-3">Country</h3>
                  <div className="h-60 overflow-y-auto pr-2 space-y-2">
                    {countries.sort().map(country => (
                      <div key={country} className="flex items-center">
                        <Checkbox 
                          id={`country-${country}`} 
                          checked={selectedCountries.includes(country)} 
                          onCheckedChange={() => toggleCountry(country)}
                        />
                        <label 
                          htmlFor={`country-${country}`}
                          className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {country}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium mb-3">Institution Type</h3>
                  <div className="space-y-2">
                    {types.map(type => (
                      <div key={type} className="flex items-center">
                        <Checkbox 
                          id={`type-${type}`}
                          checked={selectedTypes.includes(type)}
                          onCheckedChange={() => toggleType(type)}
                        />
                        <label
                          htmlFor={`type-${type}`}
                          className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {type}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium mb-3">Degree Level</h3>
                  <div className="space-y-2">
                    {allDegrees.map(degree => (
                      <div key={degree} className="flex items-center">
                        <Checkbox 
                          id={`degree-${degree}`} 
                          checked={selectedDegrees.includes(degree)}
                          onCheckedChange={() => toggleDegree(degree)}
                        />
                        <label
                          htmlFor={`degree-${degree}`}
                          className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {degree}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium mb-3">
                    Tuition Fee Range: ${tuitionRange[0].toLocaleString()} - ${tuitionRange[1].toLocaleString()}
                  </h3>
                  <Slider
                    defaultValue={[0, 60000]}
                    min={0}
                    max={60000}
                    step={1000}
                    value={tuitionRange}
                    onValueChange={(value) => setTuitionRange(value as [number, number])}
                    className="py-4"
                  />
                  
                  <div className="mt-6 flex justify-end">
                    <Button variant="outline" onClick={resetFilters}>
                      Reset Filters
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
        
        <div>
          <div className="flex justify-between items-center mb-6">
            <p className="text-gray-600">
              Showing {filteredColleges.length} {filteredColleges.length === 1 ? "college" : "colleges"}
            </p>
            <div className="flex items-center gap-3">
              <span className="text-sm text-gray-500">Looking for Indian colleges?</span>
              <Button size="sm" variant="outline" asChild>
                <Link to="/india-colleges">View Indian Colleges</Link>
              </Button>
            </div>
          </div>
          
          <TooltipProvider>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredColleges.length > 0 ? (
                filteredColleges.map((college) => (
                  <Card key={college.id} className="card-hover overflow-hidden">
                    <div className="aspect-video w-full overflow-hidden relative">
                      <img 
                        src={college.image} 
                        alt={college.name}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute top-3 right-3">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Badge variant="outline" className="bg-white/80 backdrop-blur-sm">
                              Rank #{college.ranking}
                            </Badge>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Global Ranking Position</p>
                          </TooltipContent>
                        </Tooltip>
                      </div>
                    </div>
                    <CardContent className="pt-6">
                      <div className="flex items-start justify-between">
                        <h3 className="font-bold text-xl">{college.name}</h3>
                      </div>
                      
                      <div className="flex items-center mt-2 text-gray-600">
                        <div className="flex items-center">
                          <MapPin size={16} className="mr-1" />
                          <span className="text-sm">{college.location}, {college.country}</span>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 mt-4">
                        <div className="flex items-center">
                          <GraduationCap size={16} className="mr-2 text-primary" />
                          <span className="text-sm">{college.type}</span>
                        </div>
                        <div className="flex items-center">
                          <Users size={16} className="mr-2 text-primary" />
                          <span className="text-sm">{college.studentsCount.toLocaleString()} students</span>
                        </div>
                        <div className="flex items-center">
                          <DollarSign size={16} className="mr-2 text-primary" />
                          <span className="text-sm">${college.tuitionFee.toLocaleString()}/year</span>
                        </div>
                        <div className="flex items-center">
                          <BarChart size={16} className="mr-2 text-primary" />
                          <span className="text-sm">{college.acceptanceRate}% acceptance</span>
                        </div>
                      </div>
                      
                      <div className="mt-4 border-t pt-4">
                        <h4 className="text-sm font-medium mb-2">Top Programs:</h4>
                        <div className="flex flex-wrap gap-2">
                          {college.programs.slice(0, 3).map((program, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {program}
                            </Badge>
                          ))}
                          {college.programs.length > 3 && (
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <Badge variant="outline" className="text-xs cursor-pointer">
                                  +{college.programs.length - 3} more
                                </Badge>
                              </TooltipTrigger>
                              <TooltipContent>
                                <div className="space-y-1">
                                  {college.programs.slice(3).map((program, index) => (
                                    <p key={index}>{program}</p>
                                  ))}
                                </div>
                              </TooltipContent>
                            </Tooltip>
                          )}
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="pt-0">
                      <Button variant="outline" className="w-full" asChild>
                        <Link to={`/colleges/${college.id}`}>View Details</Link>
                      </Button>
                    </CardFooter>
                  </Card>
                ))
              ) : (
                <div className="col-span-full text-center py-16">
                  <GraduationCap size={48} className="mx-auto text-gray-300 mb-4" />
                  <h3 className="text-xl font-bold mb-2">No colleges found</h3>
                  <p className="text-gray-600 mb-4">
                    Try adjusting your filters or search terms to find more results.
                  </p>
                  <Button onClick={resetFilters}>Reset Filters</Button>
                </div>
              )}
            </div>
          </TooltipProvider>
        </div>
      </div>
    </>
  );
};

export default CollegeFinder;
