
import React, { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PlaybookContent } from "@/components/implementation";
import { Book, ArrowLeft } from "lucide-react";
import { useResponsive } from "@/hooks/use-responsive";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

/**
 * Implementation Guides page shows resources for implementing strategies
 */
const ImplementationGuides = () => {
  const { isMobile } = useResponsive();

  return (
    <div className="container mx-auto py-6 lg:py-8 px-4 max-w-7xl">
      <div className="flex flex-col md:flex-row items-center justify-between mb-6">
        <Button variant="outline" size="sm" className="md:mb-0 mb-4 self-start" asChild>
          <Link to="/dashboard" className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" /> Back to Dashboard
          </Link>
        </Button>
        
        <div className="text-center md:text-right">
          <h1 className="text-2xl lg:text-3xl font-bold text-primary">Implementation Hub</h1>
          <p className="text-gray-600 text-sm lg:text-base">
            Resources to help implement future-ready strategies effectively
          </p>
        </div>
      </div>

      {/* Quick access shortcuts for mobile */}
      {isMobile && (
        <div className="mb-6 flex flex-wrap gap-2">
          <Button variant="outline" size="sm" className="text-indigo-600" asChild>
            <Link to="/implementation-guides?playbook=implementation-intro">Quick Start</Link>
          </Button>
          <Button variant="outline" size="sm" className="text-purple-600" asChild>
            <Link to="/implementation-guides?playbook=pen-paper">Simple Checklist</Link>
          </Button>
          <Button variant="outline" size="sm" className="text-green-600" asChild>
            <Link to="/implementation-guides?playbook=high-income">High Income Skills</Link>
          </Button>
        </div>
      )}

      <div className="bg-gray-50/80 rounded-lg p-3 lg:p-4">
        <PlaybookContent />
      </div>
      
      <div className="mt-8 flex flex-col sm:flex-row justify-center gap-4">
        <Button variant="outline" size="sm" asChild>
          <Link to="/playbooks" className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" /> Back to Playbooks
          </Link>
        </Button>
        <Button variant="outline" size="sm" asChild>
          <Link to="/dashboard" className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" /> Return to Dashboard
          </Link>
        </Button>
      </div>
    </div>
  );
};

export default ImplementationGuides;
