
import React from "react";
import { useParams } from "react-router-dom";
import { Helmet } from "react-helmet";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { getCollegeById, getRelatedColleges, generateCollegeSeoMetadata } from "@/utils/collegeUtils";
import { isIndianCollege, isGlobalCollege } from "@/types/college.types";
import CollegeHero from "@/components/colleges/CollegeHero";
import CollegeOverview from "@/components/colleges/CollegeOverview";
import CollegePrograms from "@/components/colleges/CollegePrograms";
import CollegeSpecializations from "@/components/colleges/CollegeSpecializations";
import CollegeFacilities from "@/components/colleges/CollegeFacilities";
import CollegeKeyInfo from "@/components/colleges/CollegeKeyInfo";
import CollegeAbout from "@/components/colleges/CollegeAbout";
import RelatedColleges from "@/components/colleges/RelatedColleges";
import CollegeMission from "@/components/colleges/CollegeMission";
import CollegeFaculty from "@/components/colleges/CollegeFaculty";
import CollegeRankings from "@/components/colleges/CollegeRankings";
import CollegeAlumni from "@/components/colleges/CollegeAlumni";
import CollegeFinancialAid from "@/components/colleges/CollegeFinancialAid";
import CollegeInternational from "@/components/colleges/CollegeInternational";
import CollegeGallery from "@/components/colleges/CollegeGallery";
import CollegeTestimonials from "@/components/colleges/CollegeTestimonials";
import CollegeFAQ from "@/components/colleges/CollegeFAQ";
import CollegeEvents from "@/components/colleges/CollegeEvents";
import CollegeApplicationProcess from "@/components/colleges/CollegeApplicationProcess";
import CollegeSocialLinks from "@/components/colleges/CollegeSocialLinks";
import CollegeAlternatives from "@/components/colleges/CollegeAlternatives";
import IndiaCollegeAlternatives from "@/components/colleges/IndiaCollegeAlternatives";
import IndianCollegeInsiderInfo from "@/components/colleges/IndianCollegeInsiderInfo";
import IndianCollegeCareerReality from "@/components/colleges/IndianCollegeCareerReality";
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbSeparator } from "@/components/ui/breadcrumb";

const CollegeDetail = () => {
  const { id } = useParams<{ id: string }>();
  const college = getCollegeById(id || "");
  
  if (!college) {
    return (
      <>
        <Navbar />
        <div className="container mx-auto py-16 px-4 text-center">
          <h1 className="text-2xl font-bold mb-4">College not found</h1>
          <p>The college you are looking for might have been removed or doesn't exist.</p>
        </div>
        <Footer />
      </>
    );
  }
  
  const relatedColleges = getRelatedColleges(college, 3);
  const seo = generateCollegeSeoMetadata(college);
  const isGlobal = isGlobalCollege(college);
  const isIndian = isIndianCollege(college);

  return (
    <>
      <Helmet>
        <title>{seo.title}</title>
        <meta name="description" content={seo.description} />
        <meta name="keywords" content={seo.keywords} />
        <meta property="og:title" content={`${college.name} - Complete College Profile & Alternative Paths to Success`} />
        <meta property="og:description" content={`Everything you need to know about ${college.name}, including costs, programs, rankings, AND practical alternatives for high-income skills without a degree.`} />
        <meta property="og:image" content={college.image} />
        <meta property="og:type" content="website" />
        <meta property="og:url" content={window.location.href} />
        <meta name="twitter:card" content="summary_large_image" />
        <meta name="twitter:title" content={`${college.name} - Complete College Profile & Alternative Paths`} />
        <meta name="twitter:description" content={`Everything about ${college.name} plus practical alternatives for high-income careers without a degree. Make an informed decision about your future.`} />
        <meta name="twitter:image" content={college.image} />
        <link rel="canonical" href={window.location.href} />
        {/* Schema.org markup for rich results */}
        <script type="application/ld+json">
          {`{
            "@context": "https://schema.org",
            "@type": "EducationalOrganization",
            "name": "${college.name}",
            "url": "${window.location.href}",
            "logo": "${college.image}",
            "address": {
              "@type": "PostalAddress",
              "addressLocality": "${college.location}",
              "addressCountry": "${isGlobal ? college.country : 'India'}"
            },
            "description": "${seo.description}",
            "sameAs": [
              ${isGlobal && college.socialLinks?.facebook ? `"${college.socialLinks.facebook}"` : ''},
              ${isGlobal && college.socialLinks?.twitter ? `"${college.socialLinks.twitter}"` : ''},
              ${isGlobal && college.socialLinks?.instagram ? `"${college.socialLinks.instagram}"` : ''},
              ${isGlobal && college.socialLinks?.linkedin ? `"${college.socialLinks.linkedin}"` : ''},
              ${isGlobal && college.socialLinks?.youtube ? `"${college.socialLinks.youtube}"` : ''}
            ]
          }`}
        </script>
      </Helmet>

      <Navbar />

      <div className="min-h-screen bg-gray-50">
        <CollegeHero college={college} />

        <div className="container mx-auto py-4 px-4">
          {/* Breadcrumbs */}
          <Breadcrumb className="mb-6 text-sm">
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink href="/">Home</BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbLink href={`/${isGlobal ? '' : 'india-'}colleges`}>
                  {isGlobal ? 'Global Colleges' : 'Indian Colleges'}
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbLink aria-current="page">{college.name}</BreadcrumbLink>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <CollegeOverview college={college} />
              
              {/* Alternatives - Different component based on college type */}
              {isGlobal && (
                <CollegeAlternatives college={college} />
              )}
              
              {isIndian && (
                <IndiaCollegeAlternatives college={college} />
              )}
              
              {/* Insider Info for Indian colleges */}
              {isIndian && college.longDescription && (
                <IndianCollegeInsiderInfo college={college} />
              )}
              
              {/* Career Reality for Indian colleges */}
              {isIndian && college.placementStats && (
                <IndianCollegeCareerReality college={college} />
              )}
              
              {isGlobal && college.longDescription && (
                <CollegeAbout college={college} />
              )}
              
              {isIndian && college.longDescription && (
                <CollegeAbout college={college} />
              )}
              
              {isGlobal && college.mission && (
                <CollegeMission college={college} />
              )}
              
              {isIndian && college.mission && (
                <CollegeMission college={college} />
              )}
              
              <CollegePrograms college={college} />
              
              {isIndian && (
                <>
                  <CollegeSpecializations college={college} />
                  <CollegeFacilities college={college} />
                </>
              )}
              
              {isGlobal && college.rankings && college.rankings.length > 0 && (
                <CollegeRankings college={college} />
              )}
              
              {isIndian && college.rankings && college.rankings.length > 0 && (
                <CollegeRankings college={college} />
              )}
              
              {isGlobal && college.facultyInfo?.notableFaculty && (
                <CollegeFaculty college={college} />
              )}
              
              {isIndian && college.facultyInfo?.notableFaculty && (
                <CollegeFaculty college={college} />
              )}
              
              {isGlobal && college.notableAlumni && (
                <CollegeAlumni college={college} />
              )}
              
              {isIndian && college.notableAlumni && (
                <CollegeAlumni college={college} />
              )}
              
              {isGlobal && college.financialAid && (
                <CollegeFinancialAid college={college} />
              )}
              
              {isIndian && college.financialAid && (
                <CollegeFinancialAid college={college} />
              )}
              
              {isGlobal && college.applicationProcess && (
                <CollegeApplicationProcess college={college} />
              )}
              
              {isGlobal && college.internationalStudents && (
                <CollegeInternational college={college} />
              )}
              
              {isGlobal && college.testimonials && (
                <CollegeTestimonials college={college} />
              )}
              
              {isIndian && college.testimonials && (
                <CollegeTestimonials college={college} />
              )}
            </div>

            <div className="space-y-6">
              <CollegeKeyInfo college={college} />
              
              {isGlobal && college.socialLinks && (
                <CollegeSocialLinks college={college} />
              )}
              
              {isIndian && college.socialLinks && (
                <CollegeSocialLinks college={college} />
              )}

              <CollegeFAQ college={college} />
              
              {isGlobal && college.upcomingEvents && college.upcomingEvents.length > 0 && (
                <CollegeEvents college={college} />
              )}
              
              {isIndian && college.upcomingEvents && college.upcomingEvents.length > 0 && (
                <CollegeEvents college={college} />
              )}
            </div>
          </div>
          
          {isGlobal && college.images && 
            Object.values(college.images).some(arr => arr && arr.length > 0) && (
            <div className="mt-8">
              <CollegeGallery college={college} />
            </div>
          )}
          
          {isIndian && college.images && 
            Object.values(college.images).some(arr => arr && arr.length > 0) && (
            <div className="mt-8">
              <CollegeGallery college={college} />
            </div>
          )}
          
          <RelatedColleges 
            colleges={relatedColleges} 
            title="Similar Colleges You Might Like"
          />
        </div>
      </div>

      <Footer />
    </>
  );
};

export default CollegeDetail;
