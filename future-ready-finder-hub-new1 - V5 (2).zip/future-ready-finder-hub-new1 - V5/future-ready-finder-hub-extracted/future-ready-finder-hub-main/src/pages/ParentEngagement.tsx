
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, MessageSquare } from "lucide-react";

const ParentEngagement = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 pb-12">
      <div className="container mx-auto px-4 py-8">
        {/* Header section */}
        <div className="mb-8 flex flex-col md:flex-row justify-between items-start md:items-center">
          <div>
            <h1 className="text-3xl font-bold text-primary mb-2">Parent Engagement Hub</h1>
            <p className="text-gray-600">
              Ready-to-use content and templates to engage with parents and build trust in your school community
            </p>
          </div>
          <Button variant="outline" size="sm" asChild className="mt-4 md:mt-0">
            <Link to="/dashboard" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" /> Back to Dashboard
            </Link>
          </Button>
        </div>

        {/* Introduction card */}
        <Card className="p-6 mb-8 bg-gradient-to-r from-brand-50 to-accent-50 border-0 shadow-sm">
          <div className="flex flex-col md:flex-row gap-6 items-center">
            <div className="bg-white p-4 rounded-full shadow-sm">
              <MessageSquare className="h-12 w-12 text-primary" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-primary mb-2">Engage, Connect, Build Trust</h2>
              <p className="text-gray-700">
                Effective parent communication is essential for building a thriving school community. This hub provides carefully crafted templates 
                and valuable content to engage both prospective parents considering your school and existing parents already part of your community.
              </p>
              <div className="mt-4">
                <h3 className="font-semibold text-primary">Key Benefits:</h3>
                <ul className="list-disc ml-5 text-gray-700">
                  <li>Build trust through consistent, valuable communication</li>
                  <li>Showcase your school's focus on future readiness</li>
                  <li>Convert prospective parents into enrolled families</li>
                  <li>Strengthen relationships with existing parents</li>
                  <li>Save time with ready-to-use professional templates and content</li>
                </ul>
              </div>
              
              <div className="mt-8">
                <Button size="lg" className="bg-primary hover:bg-primary/90" asChild>
                  <a href="http://parentcommunitycontent-index.futurereadyschools.com" target="_blank" rel="noopener noreferrer">
                    Access Parent Community Content
                  </a>
                </Button>
                <p className="text-sm text-gray-500 mt-2">
                  Get access to all free content that you can share with parents
                </p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};

export default ParentEngagement;
