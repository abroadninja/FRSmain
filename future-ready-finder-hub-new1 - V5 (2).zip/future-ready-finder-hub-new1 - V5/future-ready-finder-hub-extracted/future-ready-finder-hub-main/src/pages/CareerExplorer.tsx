
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Rocket, ArrowRight, Briefcase, School, LineChart, Award, Globe, Users } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const CareerExplorer = () => {
  return (
    <>
      <Navbar />
      
      <div className="bg-gradient-to-r from-primary to-accent py-12">
        <div className="container-custom">
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">Future Career Explorer</h1>
          <p className="text-lg text-white/90 max-w-3xl">
            Discover emerging careers, industries, and opportunities that will shape the future job market.
          </p>
        </div>
      </div>
      
      <div className="container-custom py-16">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Rocket size={48} className="mx-auto text-primary mb-6" />
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Explore Future-Ready Careers</h2>
          <p className="text-lg text-gray-600">
            Our Career Explorer tool helps students navigate the rapidly changing job landscape. Discover in-demand roles, future-proof skills, and educational pathways for tomorrow's careers.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          <Card className="feature-card">
            <CardContent className="pt-6 flex flex-col items-center text-center">
              <Briefcase size={32} className="text-primary mb-4" />
              <h3 className="text-xl font-bold mb-3">Emerging Careers</h3>
              <p className="text-gray-600 mb-4">
                Explore new and growing career paths across technology, healthcare, sustainability and more.
              </p>
              <Button variant="link" className="text-primary" asChild>
                <Link to="#" className="flex items-center">
                  Coming Soon <ArrowRight size={16} className="ml-2" />
                </Link>
              </Button>
            </CardContent>
          </Card>
          
          <Card className="feature-card">
            <CardContent className="pt-6 flex flex-col items-center text-center">
              <School size={32} className="text-secondary mb-4" />
              <h3 className="text-xl font-bold mb-3">Education Pathways</h3>
              <p className="text-gray-600 mb-4">
                Discover the best courses, degrees, and certifications needed for your desired career.
              </p>
              <Button variant="link" className="text-secondary" asChild>
                <Link to="#" className="flex items-center">
                  Coming Soon <ArrowRight size={16} className="ml-2" />
                </Link>
              </Button>
            </CardContent>
          </Card>
          
          <Card className="feature-card">
            <CardContent className="pt-6 flex flex-col items-center text-center">
              <LineChart size={32} className="text-accent mb-4" />
              <h3 className="text-xl font-bold mb-3">Industry Trends</h3>
              <p className="text-gray-600 mb-4">
                Stay updated on the latest industry trends, growth projections, and hiring demands.
              </p>
              <Button variant="link" className="text-accent" asChild>
                <Link to="#" className="flex items-center">
                  Coming Soon <ArrowRight size={16} className="ml-2" />
                </Link>
              </Button>
            </CardContent>
          </Card>
          
          <Card className="feature-card">
            <CardContent className="pt-6 flex flex-col items-center text-center">
              <Award size={32} className="text-emerald-500 mb-4" />
              <h3 className="text-xl font-bold mb-3">Skills Analysis</h3>
              <p className="text-gray-600 mb-4">
                Identify the most valuable skills for future careers and how to develop them.
              </p>
              <Button variant="link" className="text-emerald-500" asChild>
                <Link to="#" className="flex items-center">
                  Coming Soon <ArrowRight size={16} className="ml-2" />
                </Link>
              </Button>
            </CardContent>
          </Card>
          
          <Card className="feature-card">
            <CardContent className="pt-6 flex flex-col items-center text-center">
              <Globe size={32} className="text-blue-500 mb-4" />
              <h3 className="text-xl font-bold mb-3">Global Opportunities</h3>
              <p className="text-gray-600 mb-4">
                Explore career opportunities around the world and remote work possibilities.
              </p>
              <Button variant="link" className="text-blue-500" asChild>
                <Link to="#" className="flex items-center">
                  Coming Soon <ArrowRight size={16} className="ml-2" />
                </Link>
              </Button>
            </CardContent>
          </Card>
          
          <Card className="feature-card">
            <CardContent className="pt-6 flex flex-col items-center text-center">
              <Users size={32} className="text-purple-500 mb-4" />
              <h3 className="text-xl font-bold mb-3">Career Stories</h3>
              <p className="text-gray-600 mb-4">
                Learn from professionals who have successfully navigated changes in their industry.
              </p>
              <Button variant="link" className="text-purple-500" asChild>
                <Link to="#" className="flex items-center">
                  Coming Soon <ArrowRight size={16} className="ml-2" />
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
        
        <div className="bg-gray-50 rounded-lg p-8 text-center">
          <h3 className="text-2xl font-bold mb-4">Our Career Explorer Tool is Coming Soon!</h3>
          <p className="text-lg text-gray-600 mb-6 max-w-2xl mx-auto">
            We're currently developing a comprehensive career exploration tool that will help students discover and prepare for the careers of tomorrow.
          </p>
          <Button asChild>
            <Link to="/contact">Get Notified When It Launches</Link>
          </Button>
        </div>
      </div>
      
      <Footer />
    </>
  );
};

export default CareerExplorer;
