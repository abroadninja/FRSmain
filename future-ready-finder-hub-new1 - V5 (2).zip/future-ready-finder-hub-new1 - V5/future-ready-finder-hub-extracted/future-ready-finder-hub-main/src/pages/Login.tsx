
import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/components/ui/use-toast";
import { LogIn, Book, BookUser, AlertCircle, Copy } from "lucide-react";
import { useAuth } from "@/components/auth/AuthProvider";
import { Alert, AlertDescription } from "@/components/ui/alert";

// Keep the demo credentials in the code but not displayed on the UI
const DEMO_CREDENTIALS = {
  email: "demo@futurereadyschools.com",
  password: "demo123"
};

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const { toast } = useToast();
  const navigate = useNavigate();
  const { user, signIn } = useAuth();
  const [redirecting, setRedirecting] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleCopyCredentials = () => {
    setEmail(DEMO_CREDENTIALS.email);
    setPassword(DEMO_CREDENTIALS.password);
    setCopied(true);
    toast({
      title: "Demo credentials copied!",
      description: "The demo credentials have been filled in. Click 'Log In' to continue.",
    });
    
    // Reset the copied state after 3 seconds
    setTimeout(() => setCopied(false), 3000);
  };

  useEffect(() => {
    // If user is already logged in, redirect to dashboard once (not continuously)
    if (user && !redirecting) {
      setRedirecting(true);
      navigate("/dashboard");
    }
  }, [user, navigate, redirecting]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    if (!email || !password) {
      setError("Please fill in all fields");
      setLoading(false);
      return;
    }

    try {
      // Try to sign in with provided credentials
      await signIn(email, password);
      
      // The useEffect with user dependency will handle the redirect to dashboard
    } catch (error: any) {
      // If using the demo credentials for the first time, try signing up first
      if (email === DEMO_CREDENTIALS.email && password === DEMO_CREDENTIALS.password) {
        try {
          // Attempt to create the demo account if it doesn't exist
          const { data, error } = await fetch("https://tczyyycffnryjfkbatbt.supabase.co/auth/v1/signup", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "apikey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRjenl5eWNmZm5yeWpma2JhdGJ0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDUyMDYwNTcsImV4cCI6MjA2MDc4MjA1N30.XuQoEdRnKbkLMCYWbC-VqGQJyBthQ7skTvEX8Y6ZsJk"
            },
            body: JSON.stringify({
              email: DEMO_CREDENTIALS.email,
              password: DEMO_CREDENTIALS.password,
              data: {
                name: "Demo User"
              }
            })
          }).then(res => res.json());
          
          // Now try to sign in again
          await signIn(email, password);
        } catch (innerError) {
          // If this also fails, just show a generic error
          setError("Unable to log in with demo credentials. Please try again.");
        }
      } else {
        setError(error.message || "Invalid credentials. Please try again.");
      }
    } finally {
      setLoading(false);
    }
  };

  // Don't render anything while redirecting to prevent flash of login page
  if (user && redirecting) {
    return null; 
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-brand-50 to-accent-50 flex flex-col items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-lg shadow-md overflow-hidden">
        <div className="px-6 py-8">
          <div className="text-center mb-6">
            <h1 className="text-2xl font-bold text-primary mb-2">Log in to Your Account</h1>
            <p className="text-gray-600">
              Access exclusive features and resources
            </p>
          </div>
          
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                required
              />
            </div>
            
            <div>
              <div className="flex justify-between items-center mb-1">
                <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                  Password
                </label>
                <Link to="/forgot-password" className="text-xs text-primary hover:underline font-medium">
                  Forgot password?
                </Link>
              </div>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="•••••••••"
                required
              />
            </div>
            
            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-primary to-secondary hover:opacity-90"
              disabled={loading}
            >
              {loading ? (
                <span className="flex items-center">
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Logging in...
                </span>
              ) : (
                <span className="flex items-center">
                  <LogIn className="mr-2 h-4 w-4" /> Log In
                </span>
              )}
            </Button>
          </form>
          
          <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">Quick Access</span>
              </div>
            </div>
            
            <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg text-sm">
              <div className="flex items-start">
                <svg className="w-4 h-4 mr-2 mt-0.5 flex-shrink-0 text-blue-600" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h2a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                </svg>
                <div>
                  <p className="font-medium text-gray-800">Try the demo account</p>
                  <div className="mt-2 space-y-1">
                    <p className="text-sm text-gray-700">
                      <span className="font-medium">Email:</span>{' '}
                      <span className="font-mono bg-blue-100 px-2 py-0.5 rounded">{DEMO_CREDENTIALS.email}</span>
                    </p>
                    <p className="text-sm text-gray-700">
                      <span className="font-medium">Password:</span>{' '}
                      <span className="font-mono bg-blue-100 px-2 py-0.5 rounded">{DEMO_CREDENTIALS.password}</span>
                    </p>
                    <Button 
                      type="button" 
                      variant="outline" 
                      size="sm" 
                      className="mt-2 w-full text-xs"
                      onClick={handleCopyCredentials}
                    >
                      <Copy className="mr-2 h-3 w-3" />
                      {copied ? 'Copied!' : 'Copy & Fill Credentials'}
                    </Button>
                  </div>
                  <p className="mt-2 text-xs text-gray-600">
                    After logging in, please update your password in Account settings.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="relative mt-6">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">Login benefits</span>
              </div>
            </div>
            
            <div className="mt-6 grid grid-cols-1 gap-3">
              <div className="flex items-start">
                <div className="flex items-center h-5 mt-1">
                  <BookUser className="h-5 w-5 text-primary" />
                </div>
                <div className="ml-3 text-sm">
                  <label htmlFor="feature-1" className="font-medium text-gray-700">Complete Framework</label>
                  <p className="text-gray-500">Access our complete collection of implementation guides and resources</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="flex items-center h-5 mt-1">
                  <Book className="h-5 w-5 text-primary" />
                </div>
                <div className="ml-3 text-sm">
                  <label htmlFor="feature-2" className="font-medium text-gray-700">Implementation Dashboard</label>
                  <p className="text-gray-500">Track your progress and access all resources in one place</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="px-6 py-4 bg-gray-50 border-t border-gray-100">
          <div className="text-center text-sm">
            <span className="text-gray-600">Don't have an account? </span>
            <Link to="/signup" className="font-medium text-primary hover:underline">
              Sign up for free
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
