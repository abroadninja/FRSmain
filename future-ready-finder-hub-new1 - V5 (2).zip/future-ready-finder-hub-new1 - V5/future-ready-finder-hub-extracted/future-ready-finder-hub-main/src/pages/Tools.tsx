
import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, BookOpen, FileText, ListChecks, Star } from "lucide-react";

const Tools = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="container-custom py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-primary">Implementation Checklists</h1>
            <p className="text-gray-600 mt-1">Track your progress and stay on course</p>
          </div>
          <div className="flex gap-2 mt-4 md:mt-0">
            <Button variant="outline" onClick={() => navigate("/dashboard")}>
              <BookOpen className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Button>
            <Button variant="ghost" onClick={() => navigate("/")}>
              Home
            </Button>
          </div>
        </div>

        <Card className="border border-blue-100 mb-8">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Implementation Checklists</CardTitle>
              <div className="bg-primary/10 p-2 rounded-lg">
                <ListChecks className="h-6 w-6 text-primary" />
              </div>
            </div>
            <CardDescription>Stay on track with your school transformation</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-700 mb-5">
              Monitor your implementation progress with our comprehensive checklists for each playbook module.
              These checklists will help you ensure you're following all the important steps.
            </p>
            <div className="space-y-4">
              <div className="bg-white rounded-lg shadow-sm p-4 border border-gray-100">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-lg">Positioning Implementation</h3>
                  <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-medium">75% Complete</span>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    <span className="text-sm">Define your school's unique value proposition</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    <span className="text-sm">Create your school positioning statement</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-gray-300 mr-2" />
                    <span className="text-sm text-gray-500">Update all marketing materials with new positioning</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-sm p-4 border border-gray-100">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-lg">Community Building</h3>
                  <span className="bg-purple-100 text-purple-800 px-2 py-1 rounded text-xs font-medium">40% Complete</span>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    <span className="text-sm">Create parent engagement plan</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-gray-300 mr-2" />
                    <span className="text-sm text-gray-500">Establish parent ambassador program</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-gray-300 mr-2" />
                    <span className="text-sm text-gray-500">Set up regular parent feedback sessions</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-sm p-4 border border-gray-100">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-lg">Local Outreach</h3>
                  <span className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs font-medium">60% Complete</span>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    <span className="text-sm">Identify local partnership opportunities</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    <span className="text-sm">Create community involvement calendar</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-gray-300 mr-2" />
                    <span className="text-sm text-gray-500">Host community education event</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button className="w-full">View All Implementation Checklists</Button>
          </CardFooter>
        </Card>
        
        <Card className="border border-blue-100 mb-8">
          <CardHeader>
            <CardTitle>Need Help With Implementation?</CardTitle>
            <CardDescription>Get expert guidance from our school growth specialists</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 mb-4">
              Join our Growth Network to get weekly access to Q&A sessions with our experts and
              connect with other school leaders implementing the same strategies.
            </p>
            
            <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-sm font-medium flex items-start">
                <Star className="h-4 w-4 text-yellow-500 mr-2 mt-0.5" />
                Members implementing these systems see an average 30% increase in enrollment and inquiry conversion.
              </p>
            </div>
          </CardContent>
          <CardFooter>
            <Button asChild>
              <a href="/membership">Explore Membership Benefits</a>
            </Button>
          </CardFooter>
        </Card>
        
        <div className="text-center mt-8">
          <Button variant="outline" onClick={() => navigate("/dashboard")}>
            <FileText className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Tools;
