
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/components/ui/use-toast";
import { 
  Button,
  buttonVariants 
} from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { 
  Download, 
  FileText, 
  Image, 
  File, 
  BookOpen, 
  Home,
  Search,
  Eye
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";

// Resource types
type ResourceType = "worksheet" | "template" | "guide" | "examples" | "templates" | "toolkit" | "planner" | "spreadsheet" | "resource";

// Resource interface
interface Resource {
  id: string;
  title: string;
  description: string;
  type: ResourceType;
  filename: string;
  category: string;
  isViewable?: boolean;
  previewUrl?: string;
}

const Resources = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [userIsLoggedIn, setUserIsLoggedIn] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedResource, setSelectedResource] = useState<Resource | null>(null);
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);

  // Check authentication status on component mount
  useEffect(() => {
    const checkAuth = () => {
      const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
      setUserIsLoggedIn(isLoggedIn);
    };
    
    checkAuth();
  }, []);

  // All resources data
  const resources: Resource[] = [
    // Positioning resources
    {
      id: "isp-1", 
      title: "Ideal Student Profile Template", 
      description: "Define your target student characteristics",
      type: "worksheet",
      filename: "Ideal_Student_profile_template.pdf",
      category: "positioning",
      isViewable: true,
      previewUrl: "/resources/previews/ideal_student_profile.png"
    },
    {
      id: "usp-1", 
      title: "USP Worksheet", 
      description: "Create a powerful Unique Selling Proposition",
      type: "worksheet",
      filename: "Unique_selling_proposition_worksheet.pdf",
      category: "positioning",
      isViewable: true,
      previewUrl: "/resources/previews/usp_worksheet.png"
    },
    {
      id: "cvm-1", 
      title: "Core Values & Mission Guide", 
      description: "Align your mission with future-readiness",
      type: "guide",
      filename: "Core_Values_Mission_Statement_Guide.pdf",
      category: "positioning"
    },
    {
      id: "frs-1", 
      title: "Future-Ready Skills Curriculum", 
      description: "Template for curriculum development",
      type: "template",
      filename: "Future-Ready_Skills_Curriculum_Outline.pdf",
      category: "positioning",
      isViewable: true,
      previewUrl: "/resources/previews/future_ready_skills.png"
    },
    {
      id: "ppe-1", 
      title: "Parent Persona Examples", 
      description: "Understanding different parent types",
      type: "examples",
      filename: "Parent_Persona_Examples.pdf",
      category: "positioning"
    },
    {
      id: "caf-1", 
      title: "Competitive Analysis Framework", 
      description: "Stand out from other schools",
      type: "worksheet",
      filename: "Competitive_Analysis_Framework.pdf",
      category: "positioning"
    },
    
    // Marketing resources
    {
      id: "wt-1",
      title: "Website Templates", 
      description: "Professional school website designs",
      type: "templates",
      filename: "Website_Templates.zip",
      category: "marketing",
      isViewable: true,
      previewUrl: "/resources/previews/website_templates.png"
    },
    {
      id: "ft-1",
      title: "Flyer Templates", 
      description: "Professional marketing flyers",
      type: "templates",
      filename: "Flyer_Templates.zip",
      category: "marketing",
      isViewable: true,
      previewUrl: "/resources/previews/flyer_templates.png"
    },
    {
      id: "vhe-1",
      title: "Value Headlines Examples", 
      description: "Compelling headlines for marketing",
      type: "examples",
      filename: "Unbeatable_value_headlines.pdf",
      category: "marketing"
    },
    {
      id: "mtk-1",
      title: "Message Tool Kit", 
      description: "Ready-to-use marketing messages",
      type: "toolkit",
      filename: "Volume_message_tool_kit.pdf",
      category: "marketing"
    },
    {
      id: "epe-1",
      title: "Elevator Pitch Examples", 
      description: "Concise, compelling school pitches",
      type: "examples",
      filename: "Three_complete_elevator_pitch_examples.pdf",
      category: "marketing"
    },
    {
      id: "vpg-1",
      title: "Value Proposition Guide", 
      description: "Explain why your school is affordable",
      type: "guide",
      filename: "Why_are_we_so_good_and_affordable.pdf",
      category: "marketing"
    },
    
    // Community resources
    {
      id: "wci-1",
      title: "WhatsApp Community Invitation", 
      description: "Template to invite parents to community",
      type: "template",
      filename: "Whatsapp_community_invitation.pdf",
      category: "community",
      isViewable: true,
      previewUrl: "/resources/previews/whatsapp_invitation.png"
    },
    {
      id: "wmt-1",
      title: "Welcome Message Template", 
      description: "First message for new community members",
      type: "template",
      filename: "Parent_community_welcome_message.pdf",
      category: "community"
    },
    {
      id: "wft-1",
      title: "WhatsApp Follow-up Templates", 
      description: "Keep conversations going with parents",
      type: "templates",
      filename: "Follow_up_templates_for_whatsapp.pdf",
      category: "community"
    },
    {
      id: "ccg-1",
      title: "Community Champion Guide", 
      description: "Mobilize parent advocates",
      type: "guide",
      filename: "community_champion_mobilization.pdf",
      category: "community"
    },
    {
      id: "cct-1",
      title: "Content Calendar Template", 
      description: "Plan your community content",
      type: "template",
      filename: "Parent_Community_content_calendar.pdf",
      category: "community",
      isViewable: true,
      previewUrl: "/resources/previews/content_calendar.png"
    },
    {
      id: "tib-1",
      title: "Topic Idea Bank", 
      description: "Never run out of content ideas",
      type: "resource",
      filename: "Content_Theme_Topic_Idea_Bank.pdf",
      category: "community"
    },
    
    // Tracking resources
    {
      id: "lts-1",
      title: "Lead Tracking Spreadsheet", 
      description: "Comprehensive lead management",
      type: "spreadsheet",
      filename: "Lead_Enquiry_tracking_sheet.xlsx",
      category: "tracking",
      isViewable: true,
      previewUrl: "/resources/previews/lead_tracking.png"
    },
    {
      id: "otd-1",
      title: "Outreach Tracking Data", 
      description: "Measure marketing effectiveness",
      type: "spreadsheet",
      filename: "Outreach_tracking_data.xlsx",
      category: "tracking"
    },
    {
      id: "eap-1",
      title: "Event Activity Planner", 
      description: "Plan school outreach events",
      type: "planner",
      filename: "Outreach_event_Activity_planner.pdf",
      category: "tracking"
    }
  ];

  // Filter resources based on search query
  const filteredResources = searchQuery 
    ? resources.filter(resource => 
        resource.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
        resource.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        resource.type.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : resources;

  const handleDownload = (resource: Resource) => {
    // In a real app, this would initiate a download
    toast({
      title: "Download Started",
      description: `Downloading ${resource.filename}...`,
    });
  };

  const openPreview = (resource: Resource) => {
    setSelectedResource(resource);
    setIsPreviewOpen(true);
  };

  if (!userIsLoggedIn) {
    return null; // Don't render anything if not logged in - will redirect
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <div className="container-custom py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-primary">Resources Library</h1>
            <p className="text-gray-600 mt-1">Ready-to-use templates and materials for your school transformation</p>
          </div>
          <div className="flex gap-2 mt-4 md:mt-0">
            <Button variant="outline" onClick={() => navigate("/dashboard")}>
              <BookOpen className="mr-2 h-4 w-4" />
              Back to Dashboard
            </Button>
            <Button variant="ghost" onClick={() => navigate("/")}>
              <Home className="mr-2 h-4 w-4" />
              Home
            </Button>
          </div>
        </div>

        {/* Search bar */}
        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <Input
            type="text"
            placeholder="Search resources by title, description, or type..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 pr-4 py-2 rounded-md border border-gray-200"
          />
        </div>

        <Tabs defaultValue="positioning" className="mb-8">
          <TabsList className="mb-6 flex flex-wrap justify-start overflow-x-auto">
            <TabsTrigger value="all">All Resources</TabsTrigger>
            <TabsTrigger value="positioning">School Positioning</TabsTrigger>
            <TabsTrigger value="marketing">Marketing Materials</TabsTrigger>
            <TabsTrigger value="community">Parent Community</TabsTrigger>
            <TabsTrigger value="tracking">Lead Tracking</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredResources.map((resource) => (
                <ResourceCard 
                  key={resource.id}
                  resource={resource}
                  onDownload={() => handleDownload(resource)}
                  onPreview={resource.isViewable ? () => openPreview(resource) : undefined}
                />
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="positioning" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredResources
                .filter(resource => resource.category === "positioning")
                .map((resource) => (
                  <ResourceCard 
                    key={resource.id}
                    resource={resource}
                    onDownload={() => handleDownload(resource)}
                    onPreview={resource.isViewable ? () => openPreview(resource) : undefined}
                  />
                ))}
            </div>
          </TabsContent>
          
          <TabsContent value="marketing" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredResources
                .filter(resource => resource.category === "marketing")
                .map((resource) => (
                  <ResourceCard 
                    key={resource.id}
                    resource={resource}
                    onDownload={() => handleDownload(resource)}
                    onPreview={resource.isViewable ? () => openPreview(resource) : undefined}
                  />
                ))}
            </div>
          </TabsContent>
          
          <TabsContent value="community" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredResources
                .filter(resource => resource.category === "community")
                .map((resource) => (
                  <ResourceCard 
                    key={resource.id}
                    resource={resource}
                    onDownload={() => handleDownload(resource)}
                    onPreview={resource.isViewable ? () => openPreview(resource) : undefined}
                  />
                ))}
            </div>
          </TabsContent>
          
          <TabsContent value="tracking" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredResources
                .filter(resource => resource.category === "tracking")
                .map((resource) => (
                  <ResourceCard 
                    key={resource.id}
                    resource={resource}
                    onDownload={() => handleDownload(resource)}
                    onPreview={resource.isViewable ? () => openPreview(resource) : undefined}
                  />
                ))}
            </div>
          </TabsContent>
        </Tabs>

        <Card className="border border-blue-100 mb-8">
          <CardHeader>
            <CardTitle>Need Custom Resources?</CardTitle>
            <CardDescription>We can help customize these templates for your specific school needs</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700">Our team can assist with adapting these resources to your school's unique context, branding, and requirements.</p>
          </CardContent>
          <CardFooter>
            <Button>Request Customization Support</Button>
          </CardFooter>
        </Card>

        {/* Resource Preview Dialog */}
        <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
          <DialogContent className="max-w-3xl max-h-screen overflow-auto">
            <DialogHeader>
              <DialogTitle>{selectedResource?.title}</DialogTitle>
              <DialogDescription>{selectedResource?.description}</DialogDescription>
            </DialogHeader>
            <div className="flex justify-center p-4">
              {selectedResource?.previewUrl && (
                <img 
                  src={selectedResource.previewUrl} 
                  alt={selectedResource.title} 
                  className="max-h-[600px] object-contain border rounded-md shadow-sm" 
                />
              )}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsPreviewOpen(false)}>
                Close
              </Button>
              <Button onClick={() => handleDownload(selectedResource!)}>
                <Download className="mr-2 h-4 w-4" />
                Download Full Resource
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
};

interface ResourceCardProps {
  resource: Resource;
  onDownload: () => void;
  onPreview?: () => void;
}

const ResourceCard = ({ resource, onDownload, onPreview }: ResourceCardProps) => {
  const getIcon = () => {
    switch (resource.type) {
      case "worksheet":
      case "guide":
        return <FileText className="h-10 w-10 text-primary" />;
      case "template":
      case "templates":
        return <Image className="h-10 w-10 text-primary" />;
      default:
        return <File className="h-10 w-10 text-primary" />;
    }
  };

  return (
    <Card className="bg-white border border-blue-100 shadow-sm hover:shadow-md transition-shadow h-full flex flex-col">
      <CardContent className="pt-6 flex-grow">
        <div className="flex items-start mb-4">
          <div className="bg-primary/10 p-3 rounded-lg mr-4">
            {getIcon()}
          </div>
          <div>
            <h3 className="font-semibold text-lg">{resource.title}</h3>
            <p className="text-sm text-gray-600">{resource.description}</p>
            <div className="mt-2 flex flex-wrap gap-2">
              <Badge variant="outline" className="bg-blue-100 text-blue-800 hover:bg-blue-200">
                {resource.type}
              </Badge>
              {resource.isViewable && (
                <Badge variant="outline" className="bg-green-100 text-green-800 hover:bg-green-200">
                  Previewable
                </Badge>
              )}
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter className="pt-0 flex flex-col sm:flex-row gap-2 w-full">
        <Button 
          className="w-full" 
          variant="outline"
          onClick={onDownload}
        >
          <Download className="mr-2 h-4 w-4" />
          Download
        </Button>
        {onPreview && (
          <Button 
            className="w-full" 
            variant="secondary"
            onClick={onPreview}
          >
            <Eye className="mr-2 h-4 w-4" />
            Preview
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default Resources;
