
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Search, Filter, Book, Globe, Clock, Star, Tag, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { coursesData, Course } from "@/data/coursesData";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const CourseFinder = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredCourses, setFilteredCourses] = useState<Course[]>(coursesData);
  const [showFilters, setShowFilters] = useState(false);
  
  // Filter states
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const [selectedLevels, setSelectedLevels] = useState<string[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 1200]);
  const [onlyCertified, setOnlyCertified] = useState(false);
  const [onlyFree, setOnlyFree] = useState(false);
  const [sortBy, setSortBy] = useState("rating");
  
  // Get unique filters
  const types = Array.from(new Set(coursesData.map(course => course.type)));
  const levels = Array.from(new Set(coursesData.map(course => course.level)));
  const categories = Array.from(new Set(coursesData.map(course => course.category)));
  
  useEffect(() => {
    let results = [...coursesData];
    
    // Apply search filter
    if (searchTerm) {
      results = results.filter(
        course => 
          course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          course.provider.toLowerCase().includes(searchTerm.toLowerCase()) ||
          course.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
          course.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }
    
    // Apply type filter
    if (selectedTypes.length > 0) {
      results = results.filter(course => selectedTypes.includes(course.type));
    }
    
    // Apply level filter
    if (selectedLevels.length > 0) {
      results = results.filter(course => selectedLevels.includes(course.level));
    }
    
    // Apply category filter
    if (selectedCategories.length > 0) {
      results = results.filter(course => selectedCategories.includes(course.category));
    }
    
    // Apply price filter
    results = results.filter(
      course => course.price >= priceRange[0] && course.price <= priceRange[1]
    );
    
    // Apply certified filter
    if (onlyCertified) {
      results = results.filter(course => course.isCertified);
    }
    
    // Apply free filter
    if (onlyFree) {
      results = results.filter(course => !course.isPaid || course.price === 0);
    }
    
    // Apply sorting
    results = sortCourses(results, sortBy);
    
    setFilteredCourses(results);
  }, [
    searchTerm, 
    selectedTypes, 
    selectedLevels, 
    selectedCategories, 
    priceRange, 
    onlyCertified, 
    onlyFree, 
    sortBy
  ]);
  
  const sortCourses = (courses: Course[], sortMethod: string) => {
    switch (sortMethod) {
      case "title":
        return [...courses].sort((a, b) => a.title.localeCompare(b.title));
      case "rating":
        return [...courses].sort((a, b) => b.rating - a.rating);
      case "price_low":
        return [...courses].sort((a, b) => a.price - b.price);
      case "price_high":
        return [...courses].sort((a, b) => b.price - a.price);
      case "newest":
        return [...courses].sort((a, b) => new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime());
      default:
        return courses;
    }
  };
  
  const toggleType = (type: string) => {
    setSelectedTypes(prev => 
      prev.includes(type)
        ? prev.filter(t => t !== type)
        : [...prev, type]
    );
  };
  
  const toggleLevel = (level: string) => {
    setSelectedLevels(prev => 
      prev.includes(level)
        ? prev.filter(l => l !== level)
        : [...prev, level]
    );
  };
  
  const toggleCategory = (category: string) => {
    setSelectedCategories(prev => 
      prev.includes(category)
        ? prev.filter(c => c !== category)
        : [...prev, category]
    );
  };
  
  const resetFilters = () => {
    setSearchTerm("");
    setSelectedTypes([]);
    setSelectedLevels([]);
    setSelectedCategories([]);
    setPriceRange([0, 1200]);
    setOnlyCertified(false);
    setOnlyFree(false);
    setSortBy("rating");
  };

  // Function to render star rating
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    for (let i = 1; i <= 5; i++) {
      if (i <= fullStars) {
        stars.push(
          <Star key={i} size={16} className="fill-yellow-400 text-yellow-400" />
        );
      } else if (i === fullStars + 1 && hasHalfStar) {
        stars.push(
          <Star key={i} size={16} className="fill-yellow-400 text-yellow-400" fill="url(#half)" />
        );
      } else {
        stars.push(
          <Star key={i} size={16} className="text-gray-300" />
        );
      }
    }
    
    return (
      <div className="flex items-center">
        {stars}
        <span className="ml-2 text-sm font-medium">{rating.toFixed(1)}</span>
        <span className="ml-1 text-sm text-gray-500">({filteredCourses.find(c => c.rating === rating)?.reviewCount.toLocaleString()})</span>
      </div>
    );
  };

  return (
    <>
      <Navbar />
      
      <div className="bg-gradient-to-r from-secondary to-accent py-12">
        <div className="container-custom">
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4">Course Finder</h1>
          <p className="text-lg text-white/90 max-w-3xl">
            Discover online, offline, and university courses to enhance your skills and advance your career.
          </p>
        </div>
      </div>
      
      <div className="container-custom py-8">
        {/* Search and Filter Section */}
        <div className="mb-8 bg-white rounded-lg shadow-md p-6">
          <div className="flex flex-col md:flex-row md:items-center gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              <Input
                type="search"
                placeholder="Search by course title, provider, or skills..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="flex gap-3">
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rating">Best Rated</SelectItem>
                  <SelectItem value="newest">Newest First</SelectItem>
                  <SelectItem value="title">Title: A-Z</SelectItem>
                  <SelectItem value="price_low">Price: Low to High</SelectItem>
                  <SelectItem value="price_high">Price: High to Low</SelectItem>
                </SelectContent>
              </Select>
              
              <Button 
                variant="outline" 
                className="flex items-center gap-2"
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter size={18} /> {showFilters ? "Hide Filters" : "Show Filters"}
              </Button>
            </div>
          </div>
          
          {/* Expanded Filter Options */}
          {showFilters && (
            <div className="border-t pt-6 mt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {/* Course Type Filter */}
                <div>
                  <h3 className="font-medium mb-3">Course Type</h3>
                  <div className="space-y-2">
                    {types.map(type => (
                      <div key={type} className="flex items-center">
                        <Checkbox 
                          id={`type-${type}`} 
                          checked={selectedTypes.includes(type)} 
                          onCheckedChange={() => toggleType(type)}
                        />
                        <label 
                          htmlFor={`type-${type}`}
                          className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {type}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Level Filter */}
                <div>
                  <h3 className="font-medium mb-3">Level</h3>
                  <div className="space-y-2">
                    {levels.map(level => (
                      <div key={level} className="flex items-center">
                        <Checkbox 
                          id={`level-${level}`}
                          checked={selectedLevels.includes(level)}
                          onCheckedChange={() => toggleLevel(level)}
                        />
                        <label
                          htmlFor={`level-${level}`}
                          className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {level}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Category Filter */}
                <div>
                  <h3 className="font-medium mb-3">Category</h3>
                  <div className="space-y-2">
                    {categories.map(category => (
                      <div key={category} className="flex items-center">
                        <Checkbox 
                          id={`category-${category}`} 
                          checked={selectedCategories.includes(category)}
                          onCheckedChange={() => toggleCategory(category)}
                        />
                        <label
                          htmlFor={`category-${category}`}
                          className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {category}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                
                {/* Price Range Filter */}
                <div>
                  <h3 className="font-medium mb-3">
                    Price Range: ${priceRange[0].toLocaleString()} - ${priceRange[1].toLocaleString()}
                  </h3>
                  <Slider
                    defaultValue={[0, 1200]}
                    min={0}
                    max={1200}
                    step={10}
                    value={priceRange}
                    onValueChange={(value) => setPriceRange(value as [number, number])}
                    className="py-4"
                  />
                  
                  <div className="space-y-2 mt-4">
                    <div className="flex items-center">
                      <Checkbox 
                        id="certified" 
                        checked={onlyCertified}
                        onCheckedChange={() => setOnlyCertified(!onlyCertified)}
                      />
                      <label
                        htmlFor="certified"
                        className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Certificate Included
                      </label>
                    </div>
                    
                    <div className="flex items-center">
                      <Checkbox 
                        id="free" 
                        checked={onlyFree}
                        onCheckedChange={() => setOnlyFree(!onlyFree)}
                      />
                      <label
                        htmlFor="free"
                        className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Only Free Courses
                      </label>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 flex justify-end">
                <Button variant="outline" onClick={resetFilters}>
                  Reset Filters
                </Button>
              </div>
            </div>
          )}
        </div>
        
        {/* Results Section */}
        <div>
          <p className="text-gray-600 mb-6">
            Showing {filteredCourses.length} {filteredCourses.length === 1 ? "course" : "courses"}
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredCourses.length > 0 ? (
              filteredCourses.map((course) => (
                <Card key={course.id} className="card-hover">
                  <div className="aspect-video w-full overflow-hidden relative">
                    <img 
                      src={course.image} 
                      alt={course.title}
                      className="w-full h-full object-cover"
                    />
                    {course.price === 0 && (
                      <Badge className="absolute top-4 right-4 bg-green-500 text-white">
                        Free
                      </Badge>
                    )}
                  </div>
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="font-bold text-xl line-clamp-2">{course.title}</h3>
                    </div>
                    
                    <div className="flex items-center text-gray-600 mb-3">
                      <BookOpen size={16} className="mr-1" />
                      <span className="text-sm">{course.provider}</span>
                    </div>
                    
                    <div className="mb-3">
                      {renderStars(course.rating)}
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div className="flex items-center">
                        <Globe size={16} className="mr-2 text-secondary" />
                        <span className="text-sm">{course.type}</span>
                      </div>
                      <div className="flex items-center">
                        <Clock size={16} className="mr-2 text-secondary" />
                        <span className="text-sm">{course.duration}</span>
                      </div>
                      <div className="flex items-center">
                        <Book size={16} className="mr-2 text-secondary" />
                        <span className="text-sm">{course.level}</span>
                      </div>
                      <div className="flex items-center">
                        <Tag size={16} className="mr-2 text-secondary" />
                        <span className="text-sm">{course.category}</span>
                      </div>
                    </div>
                    
                    <div className="flex flex-wrap gap-2 mb-4">
                      {course.skills.slice(0, 3).map((skill, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                      {course.skills.length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{course.skills.length - 3} more
                        </Badge>
                      )}
                    </div>
                    
                    <div className="flex items-end justify-between">
                      {course.isCertified && (
                        <Badge variant="secondary" className="text-xs">
                          Certificate Included
                        </Badge>
                      )}
                      <div className="text-right">
                        <span className="font-bold text-lg">${course.price === 0 ? "Free" : course.price.toFixed(2)}</span>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="pt-0">
                    <Button variant="outline" className="w-full" asChild>
                      <Link to={`/courses/${course.id}`}>View Details</Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))
            ) : (
              <div className="col-span-full text-center py-16">
                <Book size={48} className="mx-auto text-gray-300 mb-4" />
                <h3 className="text-xl font-bold mb-2">No courses found</h3>
                <p className="text-gray-600 mb-4">
                  Try adjusting your filters or search terms to find more results.
                </p>
                <Button onClick={resetFilters}>Reset Filters</Button>
              </div>
            )}
          </div>
        </div>
      </div>
      
      <Footer />
    </>
  );
};

export default CourseFinder;
