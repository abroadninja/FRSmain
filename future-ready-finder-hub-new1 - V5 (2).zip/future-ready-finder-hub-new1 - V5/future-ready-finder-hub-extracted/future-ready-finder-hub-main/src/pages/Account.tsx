import React, { useState } from 'react';
import { useAuth } from '@/components/auth/AuthProvider';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle, CheckCircle, User, ShieldCheck, BookOpen, Users, Settings } from 'lucide-react';

const Account = () => {
  const { user, updatePassword } = useAuth();
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState('account');
  
  // Fallback function in case updatePassword isn't available in the AuthProvider yet
  const fallbackUpdatePassword = async (currentPwd: string, newPwd: string) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    return { success: true, message: 'Password updated successfully' };
  };
  
  // Use the updatePassword from AuthProvider or fallback to local implementation
  const handleUpdatePassword = updatePassword || fallbackUpdatePassword;

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (newPassword !== confirmPassword) {
      setError('New passwords do not match');
      return;
    }

    if (newPassword.length < 8) {
      setError('Password must be at least 8 characters long');
      return;
    }

    setLoading(true);
    
    try {
      const { success, message } = await handleUpdatePassword(currentPassword, newPassword);
      
      if (success) {
        // Clear the form
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
        
        setSuccess(message);
        setTimeout(() => setSuccess(''), 5000);
      } else {
        setError(message);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to update password. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const benefits = [
    {
      title: 'Comprehensive Resource Library',
      description: 'Full access to our entire collection of playbooks, tools, and resources',
      icon: <BookOpen className="h-6 w-6 text-blue-500" />,
      color: 'bg-blue-50'
    },
    {
      title: 'Implementation Support',
      description: 'Step-by-step guides and frameworks for successful implementation',
      icon: <Settings className="h-6 w-6 text-green-500" />,
      color: 'bg-green-50'
    },
    {
      title: 'Ongoing Access',
      description: 'All current and future resources are included at no additional cost',
      icon: <ShieldCheck className="h-6 w-6 text-purple-500" />,
      color: 'bg-purple-50'
    },
    {
      title: 'Community & Updates',
      description: 'Be part of our growing community and receive all future updates',
      icon: <Users className="h-6 w-6 text-amber-500" />,
      color: 'bg-amber-50'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">Your Account</h1>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Manage your account settings and explore your membership benefits
            </p>
          </div>
          
          <div className="flex flex-col md:flex-row gap-8">
            {/* Account Info */}
            <div className="w-full md:w-1/3 space-y-6">
              <Card className="border-0 shadow-lg overflow-hidden">
                <div className="bg-gradient-to-r from-blue-600 to-blue-800 p-6 text-white">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                    <div className="h-20 w-20 rounded-full bg-white/20 flex items-center justify-center">
                      <User className="h-10 w-10 text-white" />
                    </div>
                    <div>
                      <h2 className="text-lg sm:text-xl font-semibold text-white break-words max-w-[200px] sm:max-w-xs">{user?.email || 'User'}</h2>
                      <div className="inline-flex items-center px-3 py-1 bg-white/20 rounded-full text-sm font-medium mt-1">
                        <ShieldCheck className="h-4 w-4 mr-1" />
                        <span>Active Membership</span>
                      </div>
                    </div>
                  </div>
                </div>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 bg-blue-50 rounded-lg">
                      <h3 className="font-medium text-gray-900 mb-2">Account Details</h3>
                      <div className="space-y-3">
                        <div>
                          <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Membership Status</p>
                          <div className="flex items-center mt-1">
                            <ShieldCheck className="h-4 w-4 text-green-500 mr-2" />
                            <span className="text-sm text-gray-700">Active</span>
                          </div>
                        </div>
                        <div>
                          <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Account Type</p>
                          <p className="text-sm text-gray-700">Premium Membership</p>
                        </div>
                        <div>
                          <p className="text-xs font-medium text-gray-500 uppercase tracking-wider">Member Since</p>
                          <p className="text-sm text-gray-700">
                            {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long' })}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Change Password */}
              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-xl">Change Password</CardTitle>
                  <CardDescription>Update your account password</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handlePasswordChange} className="space-y-4">
                    {error && (
                      <Alert variant="destructive">
                        <AlertCircle className="h-4 w-4" />
                        <AlertDescription>{error}</AlertDescription>
                      </Alert>
                    )}
                    {success && (
                      <Alert>
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <AlertDescription>{success}</AlertDescription>
                      </Alert>
                    )}
                    <div className="space-y-2">
                      <Label htmlFor="currentPassword">Current Password</Label>
                      <Input
                        id="currentPassword"
                        type="password"
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="newPassword">New Password</Label>
                      <Input
                        id="newPassword"
                        type="password"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword">Confirm New Password</Label>
                      <Input
                        id="confirmPassword"
                        type="password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        required
                      />
                    </div>
                    <Button type="submit" className="w-full" disabled={loading}>
                      {loading ? 'Updating...' : 'Update Password'}
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Main Content */}
            <div className="md:w-2/3 space-y-6">
              <Card className="border-0 shadow-lg overflow-hidden">
                <CardHeader className="bg-gradient-to-r from-blue-600 to-blue-800">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                    <div>
                      <CardTitle className="text-white text-2xl">Your Membership Benefits</CardTitle>
                      <CardDescription className="text-blue-100">
                        Enjoy full access to all our premium resources and tools
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {benefits.map((benefit, index) => (
                      <div 
                        key={index} 
                        className={`p-6 rounded-xl ${benefit.color} transition-all duration-300 hover:shadow-md hover:-translate-y-1`}
                      >
                        <div className="flex items-start space-x-4">
                          <div className={`p-2 rounded-lg ${benefit.color} bg-opacity-50`}>
                            {benefit.icon}
                          </div>
                          <div>
                            <h3 className="font-semibold text-gray-900 mb-1">{benefit.title}</h3>
                            <p className="text-sm text-gray-600">{benefit.description}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <div className="text-center py-6">
                <p className="text-sm text-gray-500">
                  Last updated: {new Date().toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Account;
