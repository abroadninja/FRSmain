import React, { useState, useEffect } from "react";
import { Helmet } from "react-helmet";
import { Link } from "react-router-dom";
import { Search, Filter, GraduationCap, MapPin, Users, School, Percent, BookOpen, Building, BarChart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { indiaCollegesData } from "@/data/indiaCollegesData";
import { IndiaCollege } from "@/types/college.types";

const IndiaCollegeFinder = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredColleges, setFilteredColleges] = useState<IndiaCollege[]>(indiaCollegesData);
  const [showFilters, setShowFilters] = useState(false);
  
  const [selectedStates, setSelectedStates] = useState<string[]>([]);
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const [selectedOwnership, setSelectedOwnership] = useState<string[]>([]);
  const [selectedDegrees, setSelectedDegrees] = useState<string[]>([]);
  const [tuitionRange, setTuitionRange] = useState<[number, number]>([0, 500000]);
  const [nirfRange, setNirfRange] = useState<[number, number]>([1, 200]);
  const [sortBy, setSortBy] = useState("nirf");
  
  const states = Array.from(new Set(indiaCollegesData.map(college => college.state)));
  const types = Array.from(new Set(indiaCollegesData.map(college => college.type)));
  const ownerships = Array.from(new Set(indiaCollegesData.map(college => college.ownership)));
  const allDegrees = Array.from(new Set(indiaCollegesData.flatMap(college => college.degrees)));
  
  useEffect(() => {
    let results = [...indiaCollegesData];
    
    if (searchTerm) {
      results = results.filter(
        college => 
          college.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          college.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
          college.state.toLowerCase().includes(searchTerm.toLowerCase()) ||
          college.programs.some(program => program.toLowerCase().includes(searchTerm.toLowerCase())) ||
          college.specializations.some(spec => spec.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }
    
    if (selectedStates.length > 0) {
      results = results.filter(college => selectedStates.includes(college.state));
    }
    
    if (selectedTypes.length > 0) {
      results = results.filter(college => selectedTypes.includes(college.type));
    }
    
    if (selectedOwnership.length > 0) {
      results = results.filter(college => selectedOwnership.includes(college.ownership));
    }
    
    if (selectedDegrees.length > 0) {
      results = results.filter(college => 
        college.degrees.some(degree => selectedDegrees.includes(degree))
      );
    }
    
    results = results.filter(
      college => college.tuitionFee >= tuitionRange[0] && college.tuitionFee <= tuitionRange[1]
    );
    
    results = results.filter(
      college => college.nirf >= nirfRange[0] && college.nirf <= nirfRange[1]
    );
    
    results = sortColleges(results, sortBy);
    
    setFilteredColleges(results);
  }, [searchTerm, selectedStates, selectedTypes, selectedOwnership, selectedDegrees, tuitionRange, nirfRange, sortBy]);
  
  const sortColleges = (colleges: IndiaCollege[], sortMethod: string) => {
    switch (sortMethod) {
      case "name":
        return [...colleges].sort((a, b) => a.name.localeCompare(b.name));
      case "nirf":
        return [...colleges].sort((a, b) => a.nirf - b.nirf);
      case "ranking":
        return [...colleges].sort((a, b) => a.ranking - b.ranking);
      case "tuition_low":
        return [...colleges].sort((a, b) => a.tuitionFee - b.tuitionFee);
      case "tuition_high":
        return [...colleges].sort((a, b) => b.tuitionFee - a.tuitionFee);
      case "estYear":
        return [...colleges].sort((a, b) => b.estYear - a.estYear);
      default:
        return colleges;
    }
  };
  
  const toggleState = (state: string) => {
    setSelectedStates(prev => 
      prev.includes(state)
        ? prev.filter(c => c !== state)
        : [...prev, state]
    );
  };
  
  const toggleType = (type: string) => {
    setSelectedTypes(prev => 
      prev.includes(type)
        ? prev.filter(t => t !== type)
        : [...prev, type]
    );
  };
  
  const toggleOwnership = (ownership: string) => {
    setSelectedOwnership(prev => 
      prev.includes(ownership)
        ? prev.filter(o => o !== ownership)
        : [...prev, ownership]
    );
  };
  
  const toggleDegree = (degree: string) => {
    setSelectedDegrees(prev => 
      prev.includes(degree)
        ? prev.filter(d => d !== degree)
        : [...prev, degree]
    );
  };
  
  const resetFilters = () => {
    setSearchTerm("");
    setSelectedStates([]);
    setSelectedTypes([]);
    setSelectedOwnership([]);
    setSelectedDegrees([]);
    setTuitionRange([0, 500000]);
    setNirfRange([1, 200]);
    setSortBy("nirf");
  };

  return (
    <>
      <Helmet>
        <title>Indian College Finder | Top Universities & Colleges in India</title>
        <meta name="description" content="Explore top Indian universities, IITs, NITs, and colleges by NIRF, tuition, and program. Easily search, filter, and compare institutions as per your career goals." />
        <meta name="keywords" content="IIT, NIT, Indian colleges, best Indian universities, India rankings, NIRF, college search, higher education India" />
      </Helmet>
      
      <Navbar />
      
      <div className="bg-gradient-to-r from-primary/90 to-secondary/90 py-12">
        <div className="container-custom">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-2">Indian College Finder</h1>
              <p className="text-lg text-white/90 max-w-3xl">
                Find the perfect college or university in India that aligns with your academic goals, budget, and career aspirations.
              </p>
            </div>
            <div className="hidden lg:block">
              <Button variant="default" className="bg-white text-primary hover:bg-gray-100" asChild>
                <Link to="/colleges">Global Colleges</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
      
      <div className="container-custom py-8">
        <div className="mb-8 bg-white rounded-lg shadow-md p-6">
          <div className="flex flex-col md:flex-row md:items-center gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
              <Input
                type="search"
                placeholder="Search by college name, location, specialization, or program..."
                className="pl-10"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="flex gap-3">
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="nirf">NIRF Ranking</SelectItem>
                  <SelectItem value="ranking">Overall Ranking</SelectItem>
                  <SelectItem value="name">Name: A-Z</SelectItem>
                  <SelectItem value="tuition_low">Tuition: Low to High</SelectItem>
                  <SelectItem value="tuition_high">Tuition: High to Low</SelectItem>
                  <SelectItem value="estYear">Newest First</SelectItem>
                </SelectContent>
              </Select>
              
              <Button 
                variant="outline" 
                className="flex items-center gap-2"
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter size={18} /> {showFilters ? "Hide Filters" : "Show Filters"}
              </Button>
            </div>
          </div>
          
          {showFilters && (
            <div className="border-t pt-6 mt-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div>
                  <h3 className="font-medium mb-3">State</h3>
                  <div className="h-60 overflow-y-auto pr-2 space-y-2">
                    {states.sort().map(state => (
                      <div key={state} className="flex items-center">
                        <Checkbox 
                          id={`state-${state}`} 
                          checked={selectedStates.includes(state)} 
                          onCheckedChange={() => toggleState(state)}
                        />
                        <label 
                          htmlFor={`state-${state}`}
                          className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {state}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-6">
                  <div>
                    <h3 className="font-medium mb-3">Institution Type</h3>
                    <div className="space-y-2">
                      {types.map(type => (
                        <div key={type} className="flex items-center">
                          <Checkbox 
                            id={`type-${type}`}
                            checked={selectedTypes.includes(type)}
                            onCheckedChange={() => toggleType(type)}
                          />
                          <label
                            htmlFor={`type-${type}`}
                            className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                          >
                            {type}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="font-medium mb-3">Ownership</h3>
                    <div className="space-y-2">
                      {ownerships.map(ownership => (
                        <div key={ownership} className="flex items-center">
                          <Checkbox 
                            id={`ownership-${ownership}`}
                            checked={selectedOwnership.includes(ownership)}
                            onCheckedChange={() => toggleOwnership(ownership)}
                          />
                          <label
                            htmlFor={`ownership-${ownership}`}
                            className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                          >
                            {ownership}
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium mb-3">Degree Level</h3>
                  <div className="space-y-2">
                    {allDegrees.map(degree => (
                      <div key={degree} className="flex items-center">
                        <Checkbox 
                          id={`degree-${degree}`} 
                          checked={selectedDegrees.includes(degree)}
                          onCheckedChange={() => toggleDegree(degree)}
                        />
                        <label
                          htmlFor={`degree-${degree}`}
                          className="ml-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {degree}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium mb-3">
                    NIRF Rank Range: {nirfRange[0]} - {nirfRange[1]}
                  </h3>
                  <Slider
                    defaultValue={[1, 200]}
                    min={1}
                    max={200}
                    step={1}
                    value={nirfRange}
                    onValueChange={(value) => setNirfRange(value as [number, number])}
                    className="py-4"
                  />
                  <p className="text-xs text-gray-500 mt-2">*Lower is better</p>
                </div>
                
                <div>
                  <h3 className="font-medium mb-3">
                    Tuition Fee Range (₹): {tuitionRange[0].toLocaleString()} - {tuitionRange[1].toLocaleString()}
                  </h3>
                  <Slider
                    defaultValue={[0, 500000]}
                    min={0}
                    max={500000}
                    step={10000}
                    value={tuitionRange}
                    onValueChange={(value) => setTuitionRange(value as [number, number])}
                    className="py-4"
                  />
                </div>
                
                <div className="md:col-span-2 lg:col-span-3 flex justify-end">
                  <Button variant="outline" onClick={resetFilters}>
                    Reset All Filters
                  </Button>
                </div>
              </div>
            </div>
          )}
        </div>
        
        <div>
          <p className="text-gray-600 mb-6">
            Showing {filteredColleges.length} {filteredColleges.length === 1 ? "college" : "colleges"}
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredColleges.length > 0 ? (
              filteredColleges.map((college) => (
                <Card key={college.id} className="card-hover overflow-hidden">
                  <div className="aspect-video w-full overflow-hidden relative">
                    <img 
                      src={college.image} 
                      alt={college.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-3 left-3 flex gap-2">
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Badge variant="outline" className="bg-white/80 backdrop-blur-sm font-bold">
                            NIRF #{college.nirf}
                          </Badge>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>National Institutional Ranking Framework</p>
                        </TooltipContent>
                      </Tooltip>
                    </div>
                    <div className="absolute top-3 right-3">
                      <Badge variant={college.accreditation === "A++" ? "default" : "secondary"} className="font-bold">
                        {college.accreditation}
                      </Badge>
                    </div>
                  </div>
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between">
                      <h3 className="font-bold text-xl">{college.name}</h3>
                    </div>
                    
                    <div className="flex items-center mt-2 text-gray-600">
                      <MapPin size={16} className="mr-1" />
                      <span className="text-sm">{college.location}, {college.state}</span>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <div className="flex items-center">
                        <Building size={16} className="mr-2 text-primary" />
                        <span className="text-sm">{college.type}</span>
                      </div>
                      <div className="flex items-center">
                        <Users size={16} className="mr-2 text-primary" />
                        <span className="text-sm">{college.studentsCount.toLocaleString()} students</span>
                      </div>
                      <div className="flex items-center">
                        <School size={16} className="mr-2 text-primary" />
                        <span className="text-sm">Est. {college.estYear}</span>
                      </div>
                      <div className="flex items-center">
                        <Percent size={16} className="mr-2 text-primary" />
                        <span className="text-sm">{college.acceptanceRate}% acceptance</span>
                      </div>
                    </div>
                    
                    <div className="mt-4">
                      <div className="flex items-center justify-between">
                        <h4 className="text-sm font-medium">Annual Tuition:</h4>
                        <span className="text-primary font-semibold">₹{college.tuitionFee.toLocaleString()}</span>
                      </div>
                    </div>
                    
                    <div className="mt-4">
                      <h4 className="text-sm font-medium mb-2">Key Specializations:</h4>
                      <div className="flex flex-wrap gap-2">
                        {college.specializations.slice(0, 3).map((specialization, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {specialization}
                          </Badge>
                        ))}
                        {college.specializations.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{college.specializations.length - 3} more
                          </Badge>
                        )}
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="pt-0">
                    <Button variant="outline" className="w-full" asChild>
                      <Link to={`/india-colleges/${college.id}`}>View Details</Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))
            ) : (
              <div className="col-span-full text-center py-16">
                <GraduationCap size={48} className="mx-auto text-gray-300 mb-4" />
                <h3 className="text-xl font-bold mb-2">No colleges found</h3>
                <p className="text-gray-600 mb-4">
                  Try adjusting your filters or search terms to find more results.
                </p>
                <Button onClick={resetFilters}>Reset Filters</Button>
              </div>
            )}
          </div>
        </div>
      </div>
      
      <Footer />
    </>
  );
};

export default IndiaCollegeFinder;
