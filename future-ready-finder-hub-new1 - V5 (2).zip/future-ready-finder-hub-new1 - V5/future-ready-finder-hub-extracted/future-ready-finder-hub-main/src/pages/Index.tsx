
import React from "react";
import { useAuth } from "@/components/auth/AuthProvider";
import Hero from "@/components/home/Hero";
import SchoolChallenges from "@/components/home/SchoolChallenges";
import CoreSolutions from "@/components/home/CoreSolutions";
import ImplementationFramework from "@/components/home/ImplementationFramework";
import ResourcesHighlight from "@/components/homepage/ResourcesHighlight";
import ValueProposition from "@/components/home/ValueProposition";
import FAQ from "@/components/home/FAQ";
import FinalCTA from "@/components/home/FinalCTA";
import DemoSection from "@/components/home/DemoSection";
import ValueComparisonSection from "@/components/home/ValueComparisonSection";
import ComprehensiveResourcesSection from "@/components/home/ComprehensiveResourcesSection";

const Index = () => {
  const { user } = useAuth();
  
  return (
    <div className="min-h-screen bg-white">
      {/* Enhanced hero section with clear value proposition */}
      <Hero />
      
      {/* Demo Section - New addition */}
      <DemoSection />
      
      {/* School challenges section */}
      <SchoolChallenges />
      
      {/* Value Comparison Section - New addition */}
      <ValueComparisonSection />
      
      {/* Core solutions section */}
      <CoreSolutions />
      
      {/* Improved implementation framework section */}
      <ImplementationFramework />
      
      {/* Comprehensive Resources Section - Enhanced */}
      <ComprehensiveResourcesSection />
      
      {/* Resource showcase - updated with new content */}
      <ResourcesHighlight />
      
      {/* Updated value proposition highlighting thousands of hours saved */}
      <ValueProposition />
      
      {/* FAQ section */}
      <FAQ />
      
      {/* Redesigned final call to action */}
      <FinalCTA />
    </div>
  );
};

export default Index;
