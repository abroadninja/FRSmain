
import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { CheckCircle, School, GraduationCap, TrendingUp, Rocket, AlertCircle } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/components/auth/AuthProvider";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";

const formSchema = z.object({
  schoolName: z.string().min(2, "School name is required"),
  adminName: z.string().min(2, "Your name is required"),
  email: z.string().email("Please enter a valid email address"),
  phone: z.string().min(10, "Please enter a valid phone number"),
  password: z.string().min(8, "Password must be at least 8 characters")
});

type FormData = z.infer<typeof formSchema>;

const Signup = () => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const { user, signUp } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState("");

  // Form setup
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      schoolName: "",
      adminName: "",
      email: "",
      phone: "",
      password: ""
    }
  });

  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      navigate("/dashboard");
    }
  }, [user, navigate]);

  const onSubmit = async (data: FormData) => {
    setError("");
    setIsSubmitting(true);
    
    try {
      // Sign up with Supabase
      await signUp(data.email, data.password, {
        name: data.adminName,
        school_name: data.schoolName,
        phone: data.phone
      });
      
      // Success message handled in AuthProvider
      navigate("/login");
    } catch (error: any) {
      setError(error.message || "Registration failed. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-50 py-12 md:py-20">
      <div className="container mx-auto px-4 max-w-7xl">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
            Join The Future Ready Movement
          </h1>
          <p className="text-xl text-gray-600">
            Get immediate access to all our free tools, systems, and strategies
            that help schools thrive in the modern educational landscape.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-10 items-start">
          {/* Form Card */}
          <Card className="shadow-xl border-t-4 border-t-primary">
            <CardHeader>
              <CardTitle className="text-2xl">Register Your School</CardTitle>
              <CardDescription>
                Create your free account in less than 2 minutes
              </CardDescription>
            </CardHeader>
            <CardContent>
              {error && (
                <Alert variant="destructive" className="mb-4">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="schoolName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>School Name</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Enter your school's name" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="adminName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Your Name</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Enter your full name" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email Address</FormLabel>
                        <FormControl>
                          <Input 
                            type="email"
                            placeholder="Enter your email address" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone Number</FormLabel>
                        <FormControl>
                          <Input 
                            type="tel"
                            placeholder="Enter your phone number" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Password</FormLabel>
                        <FormControl>
                          <Input 
                            type="password"
                            placeholder="Create a secure password (min 8 characters)" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <Button 
                    type="submit" 
                    className="w-full py-6 text-lg mt-4 bg-primary" 
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? "Creating Account..." : "Create Free Account"}
                  </Button>
                </form>
              </Form>
            </CardContent>
            <CardFooter className="flex flex-col space-y-4 border-t pt-4">
              <div className="flex items-center justify-center gap-2 text-sm text-gray-500">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span>No credit card required</span>
              </div>
              <p className="text-sm text-center text-gray-500">
                Already a member? <Link to="/login" className="text-primary font-medium">Sign in</Link>
              </p>
            </CardFooter>
          </Card>

          {/* Benefits Column */}
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-primary/10 to-secondary/10 p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-3 flex items-center gap-2">
                <School className="text-primary" /> What You'll Get For Free
              </h3>
              <ul className="space-y-4">
                {[
                  "Complete educational transformation systems",
                  "Research-backed enrollment growth strategies",
                  "Revenue optimization frameworks & templates",
                  "Future-ready curriculum resources",
                  "In-demand skills programs & development guides",
                  "Regular updates on educational technology",
                  "Access to all platform tools & resources",
                  "Dedicated support for implementation"
                ].map((benefit, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-accent/10 p-4 rounded-lg flex flex-col items-center text-center">
                <GraduationCap className="h-10 w-10 text-accent mb-3" />
                <h4 className="font-bold">1000+</h4>
                <p className="text-sm text-gray-600">Schools Enrolled</p>
              </div>
              
              <div className="bg-primary/10 p-4 rounded-lg flex flex-col items-center text-center">
                <TrendingUp className="h-10 w-10 text-primary mb-3" />
                <h4 className="font-bold">35%</h4>
                <p className="text-sm text-gray-600">Average Growth</p>
              </div>
              
              <div className="bg-secondary/10 p-4 rounded-lg flex flex-col items-center text-center col-span-2">
                <Rocket className="h-10 w-10 text-secondary mb-3" />
                <h4 className="font-bold">100% Free Access</h4>
                <p className="text-sm text-gray-600">No hidden fees or limits</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Signup;
