
import { College, GlobalCollege, IndiaCollege, isIndianCollege, isGlobalCollege } from "@/types/college.types";
import { indiaCollegesData } from "@/data/indiaCollegesData";
import { collegesData } from "@/data/collegesData";

// Get all colleges (both Indian and global)
export const getAllColleges = (): College[] => {
  return [...indiaCollegesData, ...collegesData];
};

// Get a single college by ID
export const getCollegeById = (id: string): College | undefined => {
  return getAllColleges().find(college => college.id === id);
};

// Get suggested/related colleges
export const getRelatedColleges = (college: College, limit: number = 3): College[] => {
  const allColleges = getAllColleges();
  
  // If Indian college, suggest other colleges from same state or same type
  if (isIndianCollege(college)) {
    return allColleges
      .filter(c => 
        c.id !== college.id && 
        ((isIndianCollege(c) && c.state === college.state) || c.type === college.type)
      )
      .slice(0, limit);
  }
  
  // If global college, suggest other colleges from same country or similar ranking
  if (isGlobalCollege(college)) {
    return allColleges
      .filter(c => 
        c.id !== college.id && 
        ((isGlobalCollege(c) && c.country === college.country) || 
         Math.abs(c.ranking - college.ranking) < 10)
      )
      .slice(0, limit);
  }
  
  return [];
};

// Generate SEO metadata for a college
export const generateCollegeSeoMetadata = (college: College) => {
  let description = "";

  if (isGlobalCollege(college)) {
    description = college.longDescription || college.description;
  } else {
    description = college.shortDescription || 
      `${college.name} is a ${college.ownership} ${college.type} institution in ${college.location}, ${college.state}, India. ` +
      `Established in ${college.estYear}, it offers programs in ${college.programs.slice(0, 3).join(", ")}, and more. ` +
      `The college has a NIRF ranking of ${college.nirf} and an acceptance rate of ${college.acceptanceRate}%.`;
  }

  // Generate program list for keywords
  const programKeywords = college.programs
    .slice(0, 7)
    .join(", ");

  // Create location string
  const locationString = isIndianCollege(college)
    ? `${college.location}, ${college.state}, India`
    : `${college.location}, ${college.country}`;

  // Year established
  const yearString = isIndianCollege(college)
    ? `est. ${college.estYear}`
    : `est. ${college.foundedYear}`;

  // Combine SEO elements
  const keywords = [
    college.name,
    locationString,
    college.type,
    yearString,
    programKeywords,
    "college admission",
    "college ranking",
    "tuition fees",
    isIndianCollege(college) ? "NIRF ranking" : "university ranking"
  ].join(", ");
  
  return {
    title: `${college.name} | Complete College Profile and Information (${yearString})`,
    description: description.substring(0, 160), // Keep description to reasonable SEO length
    keywords,
  };
};

// Get colleges by filter criteria
export const getCollegesByFilters = (
  colleges: College[], 
  filters: {
    type?: string[],
    country?: string[],
    state?: string[],
    ownership?: string[],
    minRanking?: number,
    maxRanking?: number,
    minTuition?: number,
    maxTuition?: number,
    programs?: string[],
    degrees?: string[]
  }
) => {
  return colleges.filter(college => {
    // Filter by type
    if (filters.type && filters.type.length > 0 && !filters.type.includes(college.type)) {
      return false;
    }
    
    // Filter by country (for global colleges)
    if (filters.country && filters.country.length > 0 && isGlobalCollege(college) && 
        !filters.country.includes(college.country)) {
      return false;
    }
    
    // Filter by state (for Indian colleges)
    if (filters.state && filters.state.length > 0 && isIndianCollege(college) && 
        !filters.state.includes(college.state)) {
      return false;
    }
    
    // Filter by ownership (for Indian colleges)
    if (filters.ownership && filters.ownership.length > 0 && isIndianCollege(college) && 
        !filters.ownership.includes(college.ownership)) {
      return false;
    }
    
    // Filter by ranking
    if ((filters.minRanking !== undefined && college.ranking < filters.minRanking) ||
        (filters.maxRanking !== undefined && college.ranking > filters.maxRanking)) {
      return false;
    }
    
    // Filter by tuition
    if ((filters.minTuition !== undefined && college.tuitionFee < filters.minTuition) ||
        (filters.maxTuition !== undefined && college.tuitionFee > filters.maxTuition)) {
      return false;
    }
    
    // Filter by programs (match any)
    if (filters.programs && filters.programs.length > 0) {
      const hasMatchingProgram = college.programs.some(program => 
        filters.programs!.some(p => program.toLowerCase().includes(p.toLowerCase()))
      );
      if (!hasMatchingProgram) return false;
    }
    
    // Filter by degrees (match any)
    if (filters.degrees && filters.degrees.length > 0) {
      const hasMatchingDegree = college.degrees.some(degree => 
        filters.degrees!.includes(degree)
      );
      if (!hasMatchingDegree) return false;
    }
    
    return true;
  });
};

// Get unique values for filter options
export const getUniqueFilterOptions = <T extends College>(colleges: T[]) => {
  const types = new Set<string>();
  const countries = new Set<string>();
  const states = new Set<string>();
  const ownerships = new Set<string>();
  const programs = new Set<string>();
  const degrees = new Set<string>();
  
  colleges.forEach(college => {
    types.add(college.type);
    
    if (isGlobalCollege(college)) {
      countries.add(college.country);
    }
    
    if (isIndianCollege(college)) {
      states.add(college.state);
      ownerships.add(college.ownership);
    }
    
    college.programs.forEach(program => programs.add(program));
    college.degrees.forEach(degree => degrees.add(degree));
  });
  
  return {
    types: Array.from(types).sort(),
    countries: Array.from(countries).sort(),
    states: Array.from(states).sort(),
    ownerships: Array.from(ownerships).sort(),
    programs: Array.from(programs).sort(),
    degrees: Array.from(degrees).sort(),
  };
};

// Get min and max values for numerical filters
export const getMinMaxValues = <T extends College>(colleges: T[]) => {
  let minRanking = Infinity;
  let maxRanking = -Infinity;
  let minTuition = Infinity;
  let maxTuition = -Infinity;
  
  colleges.forEach(college => {
    minRanking = Math.min(minRanking, college.ranking);
    maxRanking = Math.max(maxRanking, college.ranking);
    minTuition = Math.min(minTuition, college.tuitionFee);
    maxTuition = Math.max(maxTuition, college.tuitionFee);
  });
  
  return {
    ranking: { min: minRanking, max: maxRanking },
    tuition: { min: minTuition, max: maxTuition },
  };
};
