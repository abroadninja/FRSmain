
import { College, GlobalCollege, IndiaCollege } from "@/types/college.types";
import { getCollegesByRegion } from "@/data/collegesData";
import { getIndianCollegesByType } from "@/data/indiaCollegesData";

// This utility helps with lazy loading college data when the dataset grows very large
// Instead of loading all colleges at once, we can strategically load them as needed

// Cache to store already loaded colleges by ID for quick access
const collegeCache: Record<string, College> = {};

// Load a single college by ID, with optimized lookup
export const loadCollegeById = async (id: string): Promise<College | undefined> => {
  // Return from cache if already loaded
  if (collegeCache[id]) {
    return collegeCache[id];
  }
  
  // In a real application, this would be an API call to fetch a specific college
  // For now, we're simulating this with a delayed return from our existing data
  
  // For demo purposes we'll determine if it's an Indian college by ID prefix
  // In a real app, this would be a proper API endpoint or database query
  if (id.startsWith('iit-') || id.startsWith('iim-')) {
    // It's likely an Indian college
    const type = id.startsWith('iit-') ? 'iit' : id.startsWith('iim-') ? 'iim' : 'other';
    const colleges = getIndianCollegesByType(type);
    const college = colleges.find(c => c.id === id);
    
    if (college) {
      collegeCache[id] = college;
      return college;
    }
  }
  
  // Try each region until we find the college
  const regions = ['usa', 'uk', 'canada', 'other'];
  
  for (const region of regions) {
    const colleges = getCollegesByRegion(region);
    const college = colleges.find(c => c.id === id);
    
    if (college) {
      collegeCache[id] = college;
      return college;
    }
  }
  
  return undefined;
};

// When we implement data pagination for thousands of colleges
// This would handle fetching a page of colleges with filters
export const loadColleges = async (
  page: number = 1,
  pageSize: number = 20,
  filters: {
    searchTerm?: string;
    country?: string[];
    type?: string[];
    ranking?: [number, number];
    tuition?: [number, number];
    degrees?: string[];
  } = {}
): Promise<{ colleges: College[]; totalCount: number }> => {
  // In a real app with thousands of colleges, this would be an API call
  // that handles pagination and filtering server-side
  
  // For now, we'll simulate pagination by slicing our existing data
  const allColleges = [...getCollegesByRegion('all')];
  
  // Apply filters (simplified version)
  let filtered = allColleges;
  
  if (filters.searchTerm) {
    const term = filters.searchTerm.toLowerCase();
    filtered = filtered.filter(college => 
      college.name.toLowerCase().includes(term) || 
      college.location.toLowerCase().includes(term)
    );
  }
  
  if (filters.country && filters.country.length > 0) {
    filtered = filtered.filter(college => 
      filters.country?.includes(college.country)
    );
  }
  
  // Calculate pagination
  const startIndex = (page - 1) * pageSize;
  const endIndex = startIndex + pageSize;
  const paginatedResults = filtered.slice(startIndex, endIndex);
  
  // In a real app, add these results to cache for quick access later
  paginatedResults.forEach(college => {
    collegeCache[college.id] = college;
  });
  
  return {
    colleges: paginatedResults,
    totalCount: filtered.length
  };
};
