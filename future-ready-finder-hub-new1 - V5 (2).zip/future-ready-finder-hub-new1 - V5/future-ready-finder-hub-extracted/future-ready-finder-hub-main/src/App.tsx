
import React from "react";
import "./App.css";
import { Routes, Route } from "react-router-dom";
import { Toaster } from "./components/ui/sonner";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import ScrollToTop from "./components/ScrollToTop";
import Index from "./pages/Index";
import Dashboard from "./pages/Dashboard";
import Tools from "./pages/Tools";
import Contact from "./pages/Contact";
import About from "./pages/About";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Account from "./pages/Account";
import ForgotPassword from "./pages/ForgotPassword";
import Membership from "./pages/Membership";
import ImplementationGuides from "./pages/ImplementationGuides";
import StudentGuides from "./pages/StudentGuides";
import PlaybooksApp from "./pages/PlaybooksApp";
import Resources from "./pages/Resources";
import Assessment from "./pages/Assessment";
import CareerExplorer from "./pages/CareerExplorer";
import CourseFinder from "./pages/CourseFinder";
import CollegeDetail from "./pages/CollegeDetail";
import NotFound from "./pages/NotFound";
import AuthGuard from "./components/AuthGuard";
import FutureReadyClassesApp from "./components/classes/FutureReadyClassesApp";
import ClassDetails from "./components/classes/ClassDetails";
import ParentEngagement from "./pages/ParentEngagement";
import ResourcesHub from "./pages/ResourcesHub";
import IndiaCollegeFinder from "./pages/IndiaCollegeFinder";
import { PublicRoute } from "./components/auth/PublicRoute";

function AppRoutes() {
  return (
    <>
      <Routes>
        <Route path="/" element={<PublicRoute><Index /></PublicRoute>} />
        <Route path="/dashboard" element={<AuthGuard><Dashboard /></AuthGuard>} />
        <Route path="/tools" element={<Tools />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/about" element={<About />} />
        <Route path="/login" element={<PublicRoute><Login /></PublicRoute>} />
        <Route path="/signup" element={<PublicRoute><Signup /></PublicRoute>} />
        <Route path="/forgot-password" element={<PublicRoute><ForgotPassword /></PublicRoute>} />
        <Route path="/account" element={<AuthGuard><Account /></AuthGuard>} />
        <Route path="/membership" element={<Membership />} />
        <Route path="/implementation-guides" element={<AuthGuard><ImplementationGuides /></AuthGuard>} />
        <Route path="/student-guides" element={<AuthGuard><StudentGuides /></AuthGuard>} />
        <Route path="/playbooks" element={<AuthGuard><PlaybooksApp /></AuthGuard>} />
        <Route path="/resources" element={<AuthGuard><ResourcesHub /></AuthGuard>} />
        <Route path="/assessment" element={<AuthGuard><Assessment /></AuthGuard>} />
        <Route path="/career-explorer" element={<AuthGuard><CareerExplorer /></AuthGuard>} />
        <Route path="/india-college-finder" element={<AuthGuard><IndiaCollegeFinder /></AuthGuard>} />
        <Route path="/courses" element={<AuthGuard><CourseFinder /></AuthGuard>} />
        <Route path="/college/:id" element={<AuthGuard><CollegeDetail /></AuthGuard>} />
        <Route path="/classes" element={<AuthGuard><FutureReadyClassesApp /></AuthGuard>} />
        <Route path="/classes/:groupId" element={<AuthGuard><ClassDetails /></AuthGuard>} />
        <Route path="/parent-engagement" element={<AuthGuard><ParentEngagement /></AuthGuard>} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </>
  );
}

function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex-grow">
        <ScrollToTop />
        <AppRoutes />
      </div>
      <Footer />
      <Toaster />
    </div>
  );
}

export default App;
