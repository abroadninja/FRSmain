
import { useState, useEffect } from 'react';

// Breakpoints matching Tailwind's default breakpoints
export type Breakpoint = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';

export const useResponsive = () => {
  const [breakpoint, setBreakpoint] = useState<Breakpoint>('xs');
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
    
    const calculateBreakpoint = () => {
      const width = window.innerWidth;
      if (width < 640) return 'xs';
      if (width < 768) return 'sm';
      if (width < 1024) return 'md';
      if (width < 1280) return 'lg';
      if (width < 1536) return 'xl';
      return '2xl';
    };

    const handleResize = () => {
      setBreakpoint(calculateBreakpoint());
    };

    // Initial calculation
    handleResize();

    // Add event listener
    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  return {
    breakpoint,
    isMobile: ['xs', 'sm'].includes(breakpoint),
    isTablet: breakpoint === 'md',
    isDesktop: ['lg', 'xl', '2xl'].includes(breakpoint),
    isSmallScreen: ['xs', 'sm', 'md'].includes(breakpoint),
    isLargeScreen: ['lg', 'xl', '2xl'].includes(breakpoint),
    isMounted
  };
};
