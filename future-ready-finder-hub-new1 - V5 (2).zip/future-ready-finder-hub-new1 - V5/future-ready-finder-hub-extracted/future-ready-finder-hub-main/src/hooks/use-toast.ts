
// Import from the ui toast component
import { useToast as useToastImpl, toast as toastImpl } from "@/components/ui/toast";

// Re-export for use in the rest of the app
export const useToast = useToastImpl;
export const toast = toastImpl;
