
// Define base type with common properties for all college types
export interface BaseCollege {
  id: string;
  name: string;
  location: string;
  type: string;
  ranking: number;
  studentsCount: number;
  acceptanceRate: number;
  tuitionFee: number;
  programs: string[];
  degrees: string[];
  image: string;
  kind: "india" | "global";
}

// Global college specific properties
export interface GlobalCollege extends BaseCollege {
  country: string;
  foundedYear: number;
  website: string;
  description: string;
  kind: "global";
  // Enhanced properties for better college pages
  shortDescription?: string;
  longDescription?: string;
  mission?: string;
  vision?: string;
  values?: string[];
  campusSize?: string;
  admissionDeadlines?: {
    early?: string;
    regular?: string;
    transfer?: string;
  };
  facultyInfo?: {
    totalCount: number;
    studentFacultyRatio: string;
    notableFaculty?: {
      name: string;
      position: string;
      achievement?: string;
      image?: string;
    }[];
  };
  accommodationOptions?: string[];
  researchAreas?: string[];
  notableAlumni?: {
    name: string;
    achievement: string;
    graduationYear?: number;
    image?: string;
  }[];
  rankings?: {
    source: string;
    rank: number;
    year: number;
    category?: string;
  }[];
  financialAid?: {
    availableAid: boolean;
    scholarships?: string[];
    averagePackage?: number;
    percentReceiving?: number;
  };
  virtualTour?: string;
  socialLinks?: {
    facebook?: string;
    twitter?: string;
    instagram?: string;
    linkedin?: string;
    youtube?: string;
  };
  faq?: {
    question: string;
    answer: string;
  }[];
  upcomingEvents?: {
    name: string;
    date: string;
    description: string;
    link?: string;
  }[];
  applicationProcess?: string[];
  images?: {
    campus?: string[];
    classrooms?: string[];
    labs?: string[];
    dormitories?: string[];
    facilities?: string[];
  };
  testimonials?: {
    quote: string;
    name: string;
    position: string;
    image?: string;
  }[];
  internationalStudents?: {
    percentage: number;
    countries: number;
    supportServices?: string[];
  };
}

// Indian college specific properties
export interface IndiaCollege extends BaseCollege {
  state: string;
  ownership: string;
  estYear: number;
  nirf: number;
  accreditation: string;
  facultyCount: number;
  specializations: string[];
  facilities: string[];
  kind: "india";
  // Enhanced properties for better college pages
  shortDescription?: string;
  longDescription?: string;
  mission?: string;
  vision?: string;
  values?: string[];
  campusSize?: string;
  admissionDeadlines?: {
    general?: string;
    reserved?: string;
    international?: string;
  };
  facultyInfo?: {
    professorCount: number;
    associateProfessorCount: number;
    assistantProfessorCount: number;
    studentFacultyRatio: string;
    notableFaculty?: {
      name: string;
      position: string;
      achievement?: string;
      image?: string;
    }[];
  };
  hostelFacilities?: {
    available: boolean;
    separateForGirls: boolean;
    accomodationFee?: number;
    capacity?: number;
    amenities?: string[];
  };
  researchCenters?: string[];
  notableAlumni?: {
    name: string;
    achievement: string;
    graduationYear?: number;
    image?: string;
  }[];
  rankings?: {
    source: string;
    rank: number;
    year: number;
    category?: string;
  }[];
  financialAid?: {
    availableAid: boolean;
    scholarships?: string[];
    feeWaivers?: string[];
  };
  virtualTour?: string;
  socialLinks?: {
    facebook?: string;
    twitter?: string;
    instagram?: string;
    linkedin?: string;
    youtube?: string;
  };
  faq?: {
    question: string;
    answer: string;
  }[];
  upcomingEvents?: {
    name: string;
    date: string;
    description: string;
    link?: string;
  }[];
  entranceExams?: string[];
  placementStats?: {
    year: number;
    averagePackage?: number;
    highestPackage?: number;
    placementPercentage?: number;
    topRecruiters?: string[];
  };
  images?: {
    campus?: string[];
    classrooms?: string[];
    labs?: string[];
    hostels?: string[];
    facilities?: string[];
  };
  testimonials?: {
    quote: string;
    name: string;
    batch: string;
    program: string;
    image?: string;
  }[];
}

// Union type for any college
export type College = IndiaCollege | GlobalCollege;

// Type guard functions
export const isIndianCollege = (college: College): college is IndiaCollege => 
  college.kind === "india";

export const isGlobalCollege = (college: College): college is GlobalCollege => 
  college.kind === "global";
