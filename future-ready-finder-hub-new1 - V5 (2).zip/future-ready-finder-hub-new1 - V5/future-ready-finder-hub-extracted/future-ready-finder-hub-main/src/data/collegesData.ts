
import { GlobalCollege } from "@/types/college.types";
import { usaCollegesData } from "./global/usaCollegesData";
import { ukCollegesData } from "./global/ukCollegesData";
import { canadaCollegesData } from "./global/canadaCollegesData";
import { globalOtherCollegesData } from "./global/globalOtherCollegesData";

// Merge all (soon: add more here as separate modules for each region!)
export const collegesData: GlobalCollege[] = [
  ...usaCollegesData,
  ...ukCollegesData,
  ...canadaCollegesData,
  ...globalOtherCollegesData,
];

// Export a function that will help with lazy loading college data
export const getCollegesByRegion = (region: string): GlobalCollege[] => {
  switch (region) {
    case 'usa':
      return usaCollegesData;
    case 'uk':
      return ukCollegesData;
    case 'canada':
      return canadaCollegesData;
    case 'other':
      return globalOtherCollegesData;
    default:
      return collegesData;
  }
};

export default collegesData;
