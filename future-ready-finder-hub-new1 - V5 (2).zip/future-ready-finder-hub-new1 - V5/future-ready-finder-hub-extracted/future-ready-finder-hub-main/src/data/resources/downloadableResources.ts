
export interface Resource {
  id: string;
  title: string;
  description?: string;
  link: string;
  type: 'pdf' | 'spreadsheet' | 'document';
  tags?: string[];
}

export interface ResourceCategory {
  id: string;
  title: string;
  description: string;
  icon: string;
  resources: Resource[];
}

export const resourceCategories: ResourceCategory[] = [
  {
    id: 'school-positioning',
    title: 'School Positioning',
    description: 'Resources to help position your school effectively in the market',
    icon: 'building',
    resources: [
      {
        id: 'website-12',
        title: 'Website 12',
        link: 'https://drive.google.com/open?id=1DasKHuNh5aCKA8guKe_8a-n5ElSjDk9c&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'website-11',
        title: 'Website 11',
        link: 'https://drive.google.com/open?id=1H0U0SentEB2YeJJze4j3_zcgNCYF7W_1&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'website-10',
        title: 'Website 10',
        link: 'https://drive.google.com/open?id=1J7-eY6moiBjPt8afFriZPMkOX37EoitV&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'website-9',
        title: 'Website 9',
        link: 'https://drive.google.com/open?id=1e9DTrASKnJICx29wwhcWVRWYQZEm3oTy&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'website-8',
        title: 'Website 8',
        link: 'https://drive.google.com/open?id=1OKvEk5HIpWpzOO5dZLGSgCIgSa-lcM_S&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'website-7',
        title: 'Website 7',
        link: 'https://drive.google.com/open?id=1apSin_dZJUphhuc-KLhx4jLgyXrGSwzH&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'website-6',
        title: 'Website 6',
        link: 'https://drive.google.com/open?id=1LsjelI20fRAcJlrb6jseotaPfH_btBOK&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'website-5',
        title: 'Website 5',
        link: 'https://drive.google.com/open?id=1MGDJWhd38656zxgp7JHxDn5NbSVTKevj&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'website-4',
        title: 'Website 4',
        link: 'https://drive.google.com/open?id=1CyX54v0u2Y9xDAs90VTgO6j6fgVtpabU&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'website-3',
        title: 'Website 3',
        link: 'https://drive.google.com/open?id=1odT5RT20N7tMiyjOJClZLsdRXaUMp2Mt&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'website-2',
        title: 'Website 2',
        link: 'https://drive.google.com/open?id=175O-gWd3rHnzEu39mKeJF-PQCq1AtZaI&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'website-1',
        title: 'Website 1',
        link: 'https://drive.google.com/open?id=1RVwfgenJViK2VnhWKDwAtc4ATXuOLHmK&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'flyer-6',
        title: 'Flyer 6',
        link: 'https://drive.google.com/open?id=1mZLUYzl4y_v_NLrDXGthbTPHjqABWItr&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'flyer-5',
        title: 'Flyer 5',
        link: 'https://drive.google.com/open?id=1CRX3birg-lw7QxQKCb5oGDL_jFB-zNS5&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'flyer-4',
        title: 'Flyer 4',
        link: 'https://drive.google.com/open?id=1vFrzihAbHlHC-FZYp2yHXD7fxhklTyRm&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'flyer-3',
        title: 'Flyer 3',
        link: 'https://drive.google.com/open?id=1FzRNLtCCKCgby3lE8Oca-m0vBbiJ9mOs&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'flyer-2',
        title: 'Flyer 2',
        link: 'https://drive.google.com/open?id=1PCZqV-DVNNWP-xBQEaVNqBjb4Ci-qvqI&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'flyer-1',
        title: 'Flyer 1',
        link: 'https://drive.google.com/open?id=1OcoGpe5x0sJqSKh_7WpLDbh7mpGvg342&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'elevator-pitch-template',
        title: 'Elevator Pitch Template',
        link: 'https://drive.google.com/file/d/1OVmn-aG7qG5SXk4P6xu4DEt9raaBq1UO/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'volume-message-toolkit',
        title: 'Volume Message Tool Kit',
        link: 'https://drive.google.com/file/d/1TIv5Tq9PQ2mJiF_QcOPyEgbwSCYL1Byc/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'elevator-pitch-examples',
        title: 'Three Elevator Pitch Examples',
        link: 'https://drive.google.com/file/d/1RcGOfNgLIiC4NWEsDfWsZhP3ucsxyJLu/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'unbeatable-value-headline-examples',
        title: 'Unbeatable Value Headline Examples',
        link: 'https://docs.google.com/document/d/1mWoKePZbfQ4ih6KSXVHIfTOGNKk7eR2sUoHIIGYX9rU/edit?tab=t.fkvzbhv6tdq8',
        type: 'document'
      },
      {
        id: 'why-good-affordable',
        title: 'Why Are We So Good and Affordable',
        link: 'https://drive.google.com/file/d/1BcuqWagf0A17ZAe1RQ3AHQ_yxGCKHgWb/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'immediate-positioning-updates',
        title: 'Immediate Positioning Updates Checklist',
        link: 'https://docs.google.com/spreadsheets/d/1rLS3UrdUOPdRfhCDLYlQWbm_WYrO_OaWm-InxeJyEuI/edit?usp=sharing',
        type: 'spreadsheet'
      },
      {
        id: 'growth-ignition-checklist',
        title: 'Growth Ignition Checklist',
        link: 'https://docs.google.com/spreadsheets/d/1N2iTp-k7XDhcMJn3QxqcwZKKg2spfsqxSzhes-it1xw/edit?usp=sharing',
        type: 'spreadsheet'
      },
      {
        id: 'first-100-members',
        title: 'First 100 Members Launch Plan',
        link: 'https://drive.google.com/file/d/1UyZlJkW9XHvfNVc9oSL4lNXutZ5ZGL-l/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'unique-selling-proposition',
        title: 'Unique Selling Proposition Worksheet',
        link: 'https://drive.google.com/open?id=1o5hVkv9o_VstWPcu7zkzTpQ8peFKqm_G&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'value-first-communication',
        title: 'Value-First Communication Checklist',
        link: 'https://drive.google.com/file/d/1SfaMig_w6rtT-BSdvqb14iTVc-cmHgip/view?usp=sharing',
        type: 'pdf'
      },
      {
        id: 'driving-school-growth',
        title: 'Driving School Growth and Community Building',
        link: 'https://docs.google.com/document/d/1BMOoeaQyHJIXYs5ah7T8vvcn-tenauCHvRD9U08d3c0/edit?tab=t.bg9g6w1sl21g',
        type: 'document'
      }
    ]
  },
  {
    id: 'parent-management',
    title: 'Parent Community Management',
    description: 'Resources for managing parent communities effectively',
    icon: 'users',
    resources: [
      {
        id: 'ice-breakers',
        title: 'Ice Breakers',
        link: 'https://drive.google.com/open?id=1N6bLEYo7ICq-hg1RoWK0ojNJYdRzlGs7&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'polls-2',
        title: 'Polls - 2',
        link: 'https://drive.google.com/open?id=1M6G886OqG40VYuZwBSJYXtjn1jqmATOK&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'polls-1',
        title: 'Polls - 1',
        link: 'https://drive.google.com/open?id=1vWu55cAqCRoWoDLCIX2ZSEZoDnqFUs6C&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'questions-2',
        title: 'Questions - 2',
        link: 'https://drive.google.com/open?id=1-xOZwfajpMndP5KIGSR3C5kJhqrdOPR6&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'questions-1',
        title: 'Questions - 1',
        link: 'https://drive.google.com/open?id=1-xOZwfajpMndP5KIGSR3C5kJhqrdOPR6&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'ice-breaker-3',
        title: 'Ice Breaker - 3',
        link: 'https://drive.google.com/open?id=1cPJrkRCP44jl4n_4XGpLG7KGgi0uwUdz&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'ice-breaker-2',
        title: 'Ice Breaker - 2',
        link: 'https://drive.google.com/open?id=1wctbe4NzdQ6y3Nykg_OyhMmqTYc_yguk&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'ice-breaker-1',
        title: 'Ice Breaker - 1',
        link: 'https://drive.google.com/open?id=1MSMtvGjb9T_YvBWVDiJt9a78d8hgjbjM&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'ice-breakers-alt',
        title: 'Ice Breakers',
        link: 'https://drive.google.com/open?id=1xPe9y4uaPt0ojO0S5vqNoSddyy-DmOsF&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'curriculum-update-3',
        title: 'Curriculum Update - 3',
        link: 'https://drive.google.com/open?id=1YCmjVAWsRlqnsQCRUOgh436HY1yjZuWX&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'curriculum-update-2',
        title: 'Curriculum Update - 2',
        link: 'https://drive.google.com/open?id=1Pr0zt7wCWhU9PomeKCzVzJeLQ5DQp_Bb&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'curriculum-update-1',
        title: 'Curriculum Update - 1',
        link: 'https://drive.google.com/open?id=1cGxl40c8tVzsRrtc7sqmEF_og9odFufQ&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'parent-community-announcement',
        title: 'Parent Community Announcement',
        link: 'https://drive.google.com/open?id=1FYRWW4ThJWxAvilr4gDKgT6E-k6sRBNq&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'parent-community-invitation-1',
        title: 'Parent Community Invitation',
        link: 'https://drive.google.com/open?id=1JKkiAfS8eMuaYyKhOrzvI_NGFExfc1XM&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'parent-community-invitation-2',
        title: 'Parent Community Invitation',
        link: 'https://drive.google.com/open?id=1pTTjYmGPPpdhLIayxo_7pcfUuG7P015E&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'parent-community-welcome',
        title: 'Parent Community Welcome Message Template',
        link: 'https://drive.google.com/file/d/1nmU7QQ5B8tZ_qO6WM8ir6tIABTsqQURn/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'monthly-parent-newsletter',
        title: 'Monthly Parent Newsletter Template',
        link: 'https://drive.google.com/file/d/1nmU7QQ5B8tZ_qO6WM8ir6tIABTsqQURn/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'whatsapp-follow-up',
        title: 'Follow Up Templates for WhatsApp',
        link: 'https://drive.google.com/file/d/1nmU7QQ5B8tZ_qO6WM8ir6tIABTsqQURn/view?usp=drive_link',
        type: 'pdf'
      }
    ]
  },
  {
    id: 'parent-engagement',
    title: 'Parent Engagement Resources',
    description: 'Resources for engaging with parents effectively',
    icon: 'message-square',
    resources: [
      {
        id: 'initial-value-drop',
        title: 'Initial Value Drop Content Starters',
        link: 'https://drive.google.com/file/d/14d4YfX4tj_CspSheI8258w8A84TyXGTi/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'parent-content-calendar',
        title: 'Parent Community Content Calendar and Ideas',
        link: 'https://drive.google.com/file/d/1BZl951_zUD_B7sSCmSSp-PqDd3PxysyV/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'content-theme-topic',
        title: 'Content Theme & Topic Idea Bank for Parents',
        link: 'https://drive.google.com/file/d/1OgnPNwd_PlZYeCcxBoHuyw_Dc9gJhNr1/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'extra-attention-new-parents',
        title: 'Importance of Extra Attention for New Parents',
        link: 'https://docs.google.com/document/d/1BMOoeaQyHJIXYs5ah7T8vvcn-tenauCHvRD9U08d3c0/edit?tab=t.nbxz6ens9xqa',
        type: 'document'
      },
      {
        id: 'parent-community-promotion',
        title: 'Parent Community Promotion',
        link: 'https://drive.google.com/file/d/1704geQ-KPQFbw6a_fG02BtVaA1yC44Vv/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'community-initiative-launch',
        title: 'Community Initiative Launch Blueprint',
        link: 'https://drive.google.com/file/d/1Y7v9NYB4RrHplMK1rufABqLvxwo5y58O/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'content-calendar-spreadsheet',
        title: 'Parent Community Content Calendar',
        link: 'https://docs.google.com/spreadsheets/d/1IQ3kChjDE8_CkpVBg2dKTJR5dRbGpIJXf_YYayw9zt0/edit?usp=sharing',
        type: 'spreadsheet'
      },
      {
        id: 'community-growth-tracking',
        title: 'Basic Community Growth Tracking',
        link: 'https://drive.google.com/file/d/1Vrnz-U1HM0FKvmdctfiXcVr1oxe_vc2b/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'new-parents-vicinity',
        title: 'Engaging New Parents in the Vicinity',
        link: 'https://docs.google.com/document/d/1BMOoeaQyHJIXYs5ah7T8vvcn-tenauCHvRD9U08d3c0/edit?tab=t.no4fkymtxx66',
        type: 'document'
      },
      {
        id: 'outreach-event-planner',
        title: 'Outreach Event Activity Planner',
        link: 'https://drive.google.com/file/d/1_mGd7xmGdIGURV957cTg53iT7TK5XBdv/view?usp=drive_link',
        type: 'pdf'
      }
    ]
  },
  {
    id: 'lead-management',
    title: 'Lead Generation & Management',
    description: 'Resources for generating and managing leads',
    icon: 'user-plus',
    resources: [
      {
        id: 'lead-tracking',
        title: 'Lead Generation Activity Tracker',
        link: 'https://docs.google.com/spreadsheets/d/18hJ03aO6t6gSc4e3LZ4rPUUeTwaYy0S4rGnyjzdAbeM/edit?usp=sharing',
        type: 'spreadsheet'
      },
      {
        id: 'outreach-tracking',
        title: 'Outreach Tracking Data',
        link: 'https://docs.google.com/spreadsheets/d/1lzZGHiKKDmhCwqYVviN0k6z6NXwKcg2h9KqbbjOa',
        type: 'spreadsheet'
      },
      {
        id: 'lead-scoring',
        title: 'Lead Scoring & Categorization Guide',
        link: 'https://drive.google.com/file/d/1S3emSShRLeUHhdxRC7rIvFrR0OwlIbgJ/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'lead-tracking-sheet',
        title: 'Lead Enquiry Tracking Sheet',
        link: 'https://drive.google.com/file/d/1b7NWY4AgD969pOZks1-61Msyd0XJezYt/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'conversion-tracking',
        title: 'Lead Conversion Tracking Dashboard',
        link: 'https://docs.google.com/spreadsheets/d/1miMq1P9DNGAFn9sz5JBggt1f512Te5uxWEihPzSpeLQ/edit?usp=sharing',
        type: 'spreadsheet'
      },
      {
        id: 'welcome-wagon',
        title: 'Welcome Wagon Parent Onboarding Flowchart',
        link: 'https://drive.google.com/file/d/1gnuDwpiibGO-XpBfLbqhvXv79k0MnVEE/view?usp=drive_link',
        type: 'pdf'
      }
    ]
  },
  {
    id: 'referral-programs',
    title: 'Referral & Ambassador Programs',
    description: 'Resources for creating and managing referral programs',
    icon: 'users',
    resources: [
      {
        id: 'parent-referral',
        title: 'Parent Referral Program',
        link: 'https://drive.google.com/file/d/1jnD0rj0ILxBrAxlOQ2aL_BuSLxyzLYrD/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'referral-incentive',
        title: 'Referral Incentive Program Announcement Templates',
        link: 'https://drive.google.com/file/d/14Wz8LQZHeNV6DjaE-T1u-HeXIb4qnw-J/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'ambassador-recruitment',
        title: 'Admission Ambassador Recruitment Email/WhatsApp',
        link: 'https://drive.google.com/file/d/1ka-RsDS9qhOEL8dUwAvuAEcgf7jiZv2h/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'parent-referral-rocket',
        title: 'Parent Referral Rocket',
        link: 'https://drive.google.com/file/d/1-3TZtcajrsg3k0lvPaI7SW1AVr5veeK0/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'testimonial-trigger',
        title: 'Parent Testimonial Trigger Flowchart',
        link: 'https://drive.google.com/file/d/1JrO5eqF1L6XPDBrK-uTUr-VjZYvFGMxp/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'affiliate-amplifier',
        title: 'Affiliate Amplifier Chart',
        link: 'https://drive.google.com/open?id=1bEu5My8NBg0dCyMDv32N7KA-d27Our0n&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'referral-tracking',
        title: 'Referral Tracking System',
        link: 'https://drive.google.com/file/d/1458C3AaOfQZcsX3xAAQY1N81gXgnRjpD/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'rave-review',
        title: 'Rave Review Amplification Tracker',
        link: 'https://docs.google.com/spreadsheets/d/1Vf9TsNKCVhTlgLUte99u8WxdZZG5CIJiMyXiNzvAoa4/edit?usp=sharing',
        type: 'spreadsheet'
      },
      {
        id: 'referral-optimization',
        title: 'Referral Program Optimization Dashboard Layout',
        link: 'https://docs.google.com/document/d/1Fqo1foAsJvDLb3AqasY8Uirx6kYm5AG12mM0x7DkCMA/edit?tab=t.bcfuy9y2qrvy',
        type: 'document'
      }
    ]
  },
  {
    id: 'admission-counselors',
    title: 'Admission Counselor Resources',
    description: 'Resources for admission counselors',
    icon: 'briefcase',
    resources: [
      {
        id: 'objection-handling',
        title: 'Objection Handling Guide & Script Snippets',
        link: 'https://drive.google.com/file/d/1NKKd88XiYxzitf_axwc2qejJXnYlAWek/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'ambassador-recruitment',
        title: 'Admission Ambassador Recruitment Email/WhatsApp',
        link: 'https://drive.google.com/file/d/1ka-RsDS9qhOEL8dUwAvuAEcgf7jiZv2h/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'inquiry-handling',
        title: 'Admission Inquiry Handling Email/WhatsApp',
        link: 'https://drive.google.com/file/d/1ka-RsDS9qhOEL8dUwAvuAEcgf7jiZv2h/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'training-outline',
        title: 'Training Outline for Admission Counselors',
        link: 'https://drive.google.com/file/d/1ka-RsDS9qhOEL8dUwAvuAEcgf7jiZv2h/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'unbeatable-value-arsenal',
        title: 'The Unbeatable Value Admission Counselor Sales Arsenal',
        link: 'https://drive.google.com/file/d/1ka-RsDS9qhOEL8dUwAvuAEcgf7jiZv2h/view?usp=drive_link',
        type: 'pdf'
      },
      {
        id: 'powerful-script',
        title: 'Powerful Admission Counselor Script',
        link: 'https://drive.google.com/file/d/1ka-RsDS9qhOEL8dUwAvuAEcgf7jiZv2h/view?usp=drive_link',
        type: 'pdf'
      }
    ]
  },
  {
    id: 'teacher-resources',
    title: 'Teacher Resources',
    description: 'Resources for teachers',
    icon: 'book-open',
    resources: [
      {
        id: 'future-readiness-management',
        title: 'Future Readiness Class Management',
        link: 'https://docs.google.com/spreadsheets/d/1NhuF3hq2_EV9fTr9tlB8FjFeF7br-iEV6LyFTvDl2DI/edit?usp=sharing',
        type: 'spreadsheet'
      },
      {
        id: 'high-income-skill-management',
        title: 'High-Income Skill Building Guidance Management',
        link: 'https://docs.google.com/spreadsheets/d/1NhuF3hq2_EV9fTr9tlB8FjFeF7br-iEV6LyFTvDl2DI/edit?usp=sharing',
        type: 'spreadsheet'
      },
      {
        id: 'financial-freedom-framework',
        title: 'Financial Freedom Framework',
        link: 'https://docs.google.com/spreadsheets/d/1cl89aq3q2F7fTgdCnG91koMvI_aGDgB3nbVUve1rVtU/edit?usp=sharing',
        type: 'spreadsheet'
      },
      {
        id: 'skill-roadmap',
        title: 'Skill Acquisition Roadmap',
        link: 'https://docs.google.com/spreadsheets/d/1m7fEu_IG416Kqrp1gE9VWRTRjjOyRLE7Xm6cvD3zVyA/edit?usp=sharing',
        type: 'spreadsheet'
      },
      {
        id: 'alignment-prep',
        title: 'Kickstarting Alignment: Teacher, Student & Parent Prep',
        link: 'https://docs.google.com/document/d/1BMOoeaQyHJIXYs5ah7T8vvcn-tenauCHvRD9U08d3c0/edit?tab=t.91svuk970u8z',
        type: 'document'
      },
      {
        id: 'discussion-driver',
        title: 'Discussion Driver Flowchart',
        link: 'https://drive.google.com/open?id=1bIC8H4YnISzhVS5TWB7-ywcUfSr8qWxU&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'critical-thinking',
        title: 'Critical Thinking Skill Builder Toolkit',
        link: 'https://docs.google.com/document/d/1Fqo1foAsJvDLb3AqasY8Uirx6kYm5AG12mM0x7DkCMA/edit?tab=t.n940nl6xya4r',
        type: 'document'
      },
      {
        id: 'future-ready-outline',
        title: 'Future-Ready Skills Curriculum Outline Template',
        link: 'https://drive.google.com/open?id=1OSNeoB8LpmJ424YysrQdh7o0yzMz2EI6&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'high-income-skill-building',
        title: 'High-Income Skill Building & Future Readiness',
        link: 'https://docs.google.com/document/d/1BMOoeaQyHJIXYs5ah7T8vvcn-tenauCHvRD9U08d3c0/edit?tab=t.37wyh9q4s27p',
        type: 'document'
      },
      {
        id: 'career-compass',
        title: 'Career Compass Flowchart',
        link: 'https://drive.google.com/file/d/1XJDIA9b0nqx4GVfZOhpSHU1W_yoISH_5/view?usp=drive_link',
        type: 'pdf'
      }
    ]
  },
  {
    id: 'student-resources',
    title: 'Student Resources',
    description: 'Resources for students',
    icon: 'users',
    resources: [
      {
        id: 'career-switch',
        title: 'Career Switch Flow Chart',
        link: 'https://drive.google.com/open?id=1FFXpstRzQzGs42gTKmnNpcDcg6I3adNb&usp=drive_copy',
        type: 'pdf'
      },
      {
        id: 'career-assessment',
        title: 'Student Career Assessment Tracker',
        link: 'https://docs.google.com/spreadsheets/d/1uQckiwMI8eGL91b53sQgt8z4HeXLntQ67XnNyXTFMKk/edit?usp=sharing',
        type: 'spreadsheet'
      },
      {
        id: 'success-tracker',
        title: 'Student Success Tracker',
        link: 'https://docs.google.com/spreadsheets/d/1Lt3Hic4Yddas9PCLCTm8L3VndoX-n3hPvQOvN4__v9g/edit?usp=sharing',
        type: 'spreadsheet'
      },
      {
        id: 'independence-framework',
        title: 'Student Independence Empowerment Framework',
        link: 'https://docs.google.com/document/d/1Fqo1foAsJvDLb3AqasY8Uirx6kYm5AG12mM0x7DkCMA/edit?tab=t.za9hp5z7xq2c',
        type: 'document'
      },
      {
        id: 'project-planner',
        title: 'Independent Learning Project Planner',
        link: 'https://drive.google.com/file/d/1eFYFdGqREJAzfzmbQy6mqjWC8fbSxZSN/view?usp=sharing',
        type: 'pdf'
      },
      {
        id: 'self-learning',
        title: 'Self-Learning Readiness Assessment',
        link: 'https://drive.google.com/file/d/1OsQgR51RTl6F2Oywf5RXALj95e0OZWtr/view?usp=sharing',
        type: 'pdf'
      }
    ]
  }
];
