
import { IndiaCollege } from "@/types/college.types";
import { iitCollegesData } from "./india/iitCollegesData";
import { iimCollegesData } from "./india/iimCollegesData";
import { otherTopIndiaCollegesData } from "./india/otherTopIndiaCollegesData";

export const indiaCollegesData: IndiaCollege[] = [
  ...iitCollegesData,
  ...iimCollegesData,
  ...otherTopIndiaCollegesData,
];

// Export a function that will help with lazy loading college data
export const getIndianCollegesByType = (type: string): IndiaCollege[] => {
  switch (type) {
    case 'iit':
      return iitCollegesData;
    case 'iim':
      return iimCollegesData;
    case 'other':
      return otherTopIndiaCollegesData;
    default:
      return indiaCollegesData;
  }
};

export default indiaCollegesData;
