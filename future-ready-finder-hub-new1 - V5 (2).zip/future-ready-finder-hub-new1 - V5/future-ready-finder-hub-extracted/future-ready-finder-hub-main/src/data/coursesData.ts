
export interface Course {
  id: string;
  title: string;
  provider: string;
  type: 'Online' | 'Offline' | 'University';
  duration: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced' | 'All Levels';
  category: string;
  subcategory: string;
  price: number;
  rating: number;
  reviewCount: number;
  image: string;
  isCertified: boolean;
  isPaid: boolean;
  language: string;
  description: string;
  skills: string[];
  lastUpdated: string;
}

export const coursesData: Course[] = [
  {
    id: "cr1",
    title: "The Complete Web Development Bootcamp",
    provider: "TechAcademy",
    type: "Online",
    duration: "12 weeks",
    level: "All Levels",
    category: "Technology",
    subcategory: "Web Development",
    price: 59.99,
    rating: 4.8,
    reviewCount: 12500,
    image: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6",
    isCertified: true,
    isPaid: true,
    language: "English",
    description: "A comprehensive bootcamp covering HTML, CSS, JavaScript, React, Node.js, and more to help you become a full-stack web developer.",
    skills: ["HTML", "CSS", "JavaScript", "React", "Node.js", "MongoDB"],
    lastUpdated: "2023-10-15"
  },
  {
    id: "cr2",
    title: "Data Science Masterclass",
    provider: "DataExperts",
    type: "Online",
    duration: "16 weeks",
    level: "Intermediate",
    category: "Technology",
    subcategory: "Data Science",
    price: 79.99,
    rating: 4.7,
    reviewCount: 8300,
    image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085",
    isCertified: true,
    isPaid: true,
    language: "English",
    description: "Master the skills of a data scientist including Python, statistics, machine learning, and data visualization.",
    skills: ["Python", "Statistics", "Machine Learning", "Data Visualization", "SQL", "Tableau"],
    lastUpdated: "2023-11-20"
  },
  {
    id: "cr3",
    title: "Digital Marketing Fundamentals",
    provider: "Marketing Pros",
    type: "Online",
    duration: "8 weeks",
    level: "Beginner",
    category: "Business",
    subcategory: "Digital Marketing",
    price: 49.99,
    rating: 4.5,
    reviewCount: 9100,
    image: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d",
    isCertified: true,
    isPaid: true,
    language: "English",
    description: "Learn the fundamentals of digital marketing including SEO, social media, content marketing, and analytics.",
    skills: ["SEO", "Social Media Marketing", "Content Marketing", "Google Analytics", "Email Marketing"],
    lastUpdated: "2023-09-05"
  },
  {
    id: "cr4",
    title: "AI and Machine Learning Specialization",
    provider: "TechUniversity",
    type: "University",
    duration: "6 months",
    level: "Advanced",
    category: "Technology",
    subcategory: "Artificial Intelligence",
    price: 1200,
    rating: 4.9,
    reviewCount: 3200,
    image: "https://images.unsplash.com/photo-1605810230434-7631ac76ec81",
    isCertified: true,
    isPaid: true,
    language: "English",
    description: "An in-depth specialization in artificial intelligence and machine learning with hands-on projects and industry case studies.",
    skills: ["Python", "TensorFlow", "Deep Learning", "Natural Language Processing", "Computer Vision"],
    lastUpdated: "2023-12-10"
  },
  {
    id: "cr5",
    title: "Introduction to Project Management",
    provider: "BusinessSchool",
    type: "Online",
    duration: "4 weeks",
    level: "Beginner",
    category: "Business",
    subcategory: "Project Management",
    price: 0,
    rating: 4.3,
    reviewCount: 15600,
    image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158",
    isCertified: false,
    isPaid: false,
    language: "English",
    description: "Learn the basics of project management including planning, execution, monitoring, and closure.",
    skills: ["Project Planning", "Team Management", "Risk Assessment", "Task Prioritization", "Reporting"],
    lastUpdated: "2023-08-15"
  },
  {
    id: "cr6",
    title: "UI/UX Design Principles",
    provider: "DesignAcademy",
    type: "Offline",
    duration: "10 weeks",
    level: "Intermediate",
    category: "Design",
    subcategory: "User Interface Design",
    price: 850,
    rating: 4.6,
    reviewCount: 2800,
    image: "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b",
    isCertified: true,
    isPaid: true,
    language: "English",
    description: "An in-person workshop series covering user interface and user experience design principles with hands-on projects.",
    skills: ["UI Design", "UX Research", "Wireframing", "Prototyping", "User Testing", "Figma"],
    lastUpdated: "2023-10-28"
  },
  {
    id: "cr7",
    title: "Cybersecurity Essentials",
    provider: "SecurityInstitute",
    type: "Online",
    duration: "8 weeks",
    level: "All Levels",
    category: "Technology",
    subcategory: "Cybersecurity",
    price: 69.99,
    rating: 4.7,
    reviewCount: 5600,
    image: "https://images.unsplash.com/photo-1559581958-df379578606a",
    isCertified: true,
    isPaid: true,
    language: "English",
    description: "Learn the fundamentals of cybersecurity including threat detection, prevention, and security best practices.",
    skills: ["Network Security", "Cryptography", "Risk Management", "Security Protocols", "Ethical Hacking"],
    lastUpdated: "2023-11-15"
  },
  {
    id: "cr8",
    title: "Cloud Computing Fundamentals",
    provider: "CloudAcademy",
    type: "Online",
    duration: "6 weeks",
    level: "Beginner",
    category: "Technology",
    subcategory: "Cloud Computing",
    price: 59.99,
    rating: 4.6,
    reviewCount: 4800,
    image: "https://images.unsplash.com/photo-1649972904349-6e44c42644a7",
    isCertified: true,
    isPaid: true,
    language: "English",
    description: "An introduction to cloud computing concepts, services, and platforms including AWS, Azure, and Google Cloud.",
    skills: ["AWS", "Azure", "Google Cloud", "Cloud Architecture", "Serverless Computing", "DevOps"],
    lastUpdated: "2023-09-28"
  }
];
