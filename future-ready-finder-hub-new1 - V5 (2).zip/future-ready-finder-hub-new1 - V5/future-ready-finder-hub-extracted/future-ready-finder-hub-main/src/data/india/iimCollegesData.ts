
import { IndiaCollege } from "@/types/college.types";

export const iimCollegesData: IndiaCollege[] = [
  {
    id: "iim-ahmedabad",
    name: "Indian Institute of Management Ahmedabad",
    location: "Ahmedabad",
    state: "Gujarat",
    type: "Management",
    ownership: "Public",
    estYear: 1961,
    ranking: 4,
    nirf: 1,
    accreditation: "A++",
    studentsCount: 1200,
    facultyCount: 118,
    tuitionFee: 2375000,
    acceptanceRate: 0.25,
    programs: ["MBA", "PhD", "Executive MBA", "PGPX"],
    specializations: ["Finance", "Marketing", "Operations", "Human Resources", "Strategy", "Entrepreneurship"],
    degrees: ["Master's", "Doctorate"],
    facilities: ["Harvard Style Classrooms", "Library", "Sports Complex", "Hostels", "Computer Center", "Auditorium"],
    image: "https://images.unsplash.com/photo-1576439108456-0d49a6702398?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3",
    kind: "india"
  }
  // Add more IIMs following this pattern!
];
