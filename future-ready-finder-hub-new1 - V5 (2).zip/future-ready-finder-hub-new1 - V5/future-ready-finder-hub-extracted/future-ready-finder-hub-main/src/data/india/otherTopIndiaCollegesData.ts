import { IndiaCollege } from "@/types/college.types";

export const otherTopIndiaCollegesData: IndiaCollege[] = [
  {
    id: "aiims-delhi",
    name: "All India Institute of Medical Sciences Delhi",
    location: "New Delhi",
    state: "Delhi",
    type: "Medical",
    ownership: "Public",
    estYear: 1956,
    ranking: 5,
    nirf: 1,
    accreditation: "A++",
    studentsCount: 2500,
    facultyCount: 750,
    tuitionFee: 6810,
    acceptanceRate: 0.1,
    programs: ["MBBS", "MD", "MS", "M.Ch", "DM", "Ph.D", "B.Sc Nursing"],
    specializations: ["Cardiology", "Neurology", "Oncology", "Pediatrics", "Surgery", "Gynecology"],
    degrees: ["Bachelor's", "Master's", "Doctorate", "Super Specialty"],
    facilities: ["Hospital", "Research Labs", "Library", "Hostels", "Auditorium", "Sports Facilities"],
    image: "https://images.unsplash.com/photo-1504439468489-c8920d796a29?q=80&w=2071&auto=format&fit=crop&ixlib=rb-4.0.3",
    kind: "india"
  }
  // Add more top Indian colleges, NITs, medical, law, etc following this pattern!
];
