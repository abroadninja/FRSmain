
import { IndiaCollege } from "@/types/college.types";

export const iitCollegesData: IndiaCollege[] = [
  {
    id: "iit-delhi",
    name: "Indian Institute of Technology Delhi",
    location: "New Delhi",
    state: "Delhi",
    type: "Engineering and Technology",
    ownership: "Public",
    estYear: 1961,
    ranking: 1,
    nirf: 2,
    accreditation: "A++",
    studentsCount: 10500,
    facultyCount: 642,
    tuitionFee: 225000,
    acceptanceRate: 2,
    programs: ["B.Tech", "M.Tech", "Ph.D", "MBA", "M.Sc", "M.Des"],
    specializations: ["Computer Science", "Electrical Engineering", "Mechanical Engineering", "Civil Engineering", "Biotechnology", "Textile Engineering"],
    degrees: ["Bachelor's", "Master's", "Doctorate"],
    facilities: ["Smart Classrooms", "Central Library", "Sports Complex", "Incubation Center", "Research Labs", "Hostels"],
    image: "https://images.unsplash.com/photo-1562774053-701939374585?q=80&w=2072&auto=format&fit=crop&ixlib=rb-4.0.3",
    kind: "india"
  },
  {
    id: "iit-bombay",
    name: "Indian Institute of Technology Bombay",
    location: "Mumbai",
    state: "Maharashtra",
    type: "Engineering and Technology",
    ownership: "Public",
    estYear: 1958,
    ranking: 2,
    nirf: 3,
    accreditation: "A++",
    studentsCount: 11000,
    facultyCount: 650,
    tuitionFee: 225000,
    acceptanceRate: 1.8,
    programs: ["B.Tech", "M.Tech", "Ph.D", "MBA", "M.Sc", "M.Des"],
    specializations: ["Computer Science", "Electrical Engineering", "Mechanical Engineering", "Aerospace Engineering", "Chemical Engineering", "Metallurgical Engineering"],
    degrees: ["Bachelor's", "Master's", "Doctorate"],
    facilities: ["Central Library", "Computer Center", "Sports Facilities", "Auditorium", "Hostels", "Swimming Pool"],
    image: "https://images.unsplash.com/photo-1554467728-b9025a8723a1?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3",
    kind: "india"
  },
  {
    id: "iit-madras",
    name: "Indian Institute of Technology Madras",
    location: "Chennai",
    state: "Tamil Nadu",
    type: "Engineering and Technology",
    ownership: "Public",
    estYear: 1959,
    ranking: 3,
    nirf: 1,
    accreditation: "A++",
    studentsCount: 12000,
    facultyCount: 670,
    tuitionFee: 225000,
    acceptanceRate: 1.5,
    programs: ["B.Tech", "M.Tech", "Ph.D", "MBA", "M.Sc", "Dual Degree"],
    specializations: ["Computer Science", "Electrical Engineering", "Mechanical Engineering", "Data Science", "Biotechnology", "Aerospace Engineering"],
    degrees: ["Bachelor's", "Master's", "Doctorate"],
    facilities: ["Research Park", "Central Library", "Sports Complex", "Innovation Hub", "Incubation Cell", "Hostels"],
    shortDescription: "IIT Madras is India's top engineering institute known for cutting-edge research and industry connections. But here's the truth: admission is brutally competitive, accepting only 1.5% of applicants.",
    longDescription: "IIT Madras, established in 1959 with assistance from the German government, has consistently ranked #1 in the NIRF rankings. While renowned for world-class engineering education and research, the institute's 1.5% acceptance rate makes it more selective than many Ivy League schools. The campus spans 620 acres of urban forest, housing advanced research facilities, innovation ecosystems, and India's first university-based research park. However, the brutal truth is that for 98.5% of aspirants, admission remains an impossible dream. Fortunately, in today's digital economy, alternative paths to high-income technical careers exist without requiring an IIT degree.",
    mission: "To be an academic institution in dynamic equilibrium with its social, ecological and economic environment, striving continuously for excellence in education, research and technological service to the nation.",
    vision: "To be recognized globally for academic and research excellence in science, engineering and humanities, and to become a preferred destination for undergraduate and graduate education.",
    values: ["Academic integrity and accountability", "Respect and tolerance for the views of every individual", "Attention to issues of national relevance", "Depth, innοvation and quality in teaching and research", "Industry and society as stakeholders"],
    campusSize: "620 acres",
    admissionDeadlines: {
      general: "April-May (through JEE Advanced)",
      reserved: "April-May (through JEE Advanced)",
      international: "March-April (DASA scheme)"
    },
    facultyInfo: {
      professorCount: 250,
      associateProfessorCount: 195,
      assistantProfessorCount: 225,
      studentFacultyRatio: "18:1",
      notableFaculty: [
        {
          name: "Dr. Ashok Jhunjhunwala",
          position: "Professor, Department of Electrical Engineering",
          achievement: "Padma Shri recipient, pioneered telecom and rural technology innovations"
        },
        {
          name: "Dr. V. Kamakoti",
          position: "Director, IIT Madras",
          achievement: "Led development of India's first indigenous processor 'Shakti'"
        },
        {
          name: "Dr. Prathap Haridoss",
          position: "Professor, Department of Metallurgical and Materials Engineering",
          achievement: "Known for groundbreaking work in nanomaterials and corrosion science"
        }
      ]
    },
    hostelFacilities: {
      available: true,
      separateForGirls: true,
      accomodationFee: 20000,
      capacity: 8500,
      amenities: ["Wi-Fi", "Gym", "Recreation rooms", "Dining halls", "Reading rooms"]
    },
    researchCenters: [
      "Centre for Industrial Consultancy and Sponsored Research",
      "National Centre for Combustion Research and Development",
      "Centre for Innovation",
      "Healthcare Technology Innovation Centre",
      "Robert Bosch Centre for Data Science and AI"
    ],
    notableAlumni: [
      {
        name: "Kris Gopalakrishnan",
        achievement: "Co-founder of Infosys",
        graduationYear: 1977
      },
      {
        name: "Ramanathan V. Guha",
        achievement: "Inventor of RSS and Google Custom Search, creator of Schema.org",
        graduationYear: 1986
      },
      {
        name: "Krishna Bharat",
        achievement: "Creator of Google News, Principal Scientist at Google",
        graduationYear: 1991
      },
      {
        name: "Anand Rajaraman",
        achievement: "Founder of Junglee, Founding Partner of Cambrian Ventures, early investor in Facebook",
        graduationYear: 1989
      },
      {
        name: "D. Uday Kumar",
        achievement: "Designer of the Indian Rupee symbol",
        graduationYear: 2001
      }
    ],
    rankings: [
      {
        source: "NIRF",
        rank: 1,
        year: 2023,
        category: "Overall"
      },
      {
        source: "QS World University Rankings",
        rank: 250,
        year: 2023,
        category: "Global"
      },
      {
        source: "THE World University Rankings",
        rank: 301,
        year: 2023,
        category: "Engineering & Technology"
      }
    ],
    financialAid: {
      availableAid: true,
      scholarships: ["Merit-cum-Means Scholarship", "SC/ST Top Class Education Scheme", "Institute Free Studentship", "Siemens Scholarship Program", "Aditya Birla Scholarship"],
      feeWaivers: ["Full tuition fee waiver for SC/ST/PH students", "Full tuition fee waiver for students whose family income is less than Rs. 1 lakh per annum", "Two-thirds tuition fee waiver for students whose family income is between Rs. 1 lakh and Rs. 5 lakh per annum"]
    },
    entranceExams: ["JEE Advanced", "GATE", "JAM", "CAT (for MBA)"],
    placementStats: {
      year: 2023,
      averagePackage: 2100000,
      highestPackage: 9500000,
      placementPercentage: 92,
      topRecruiters: ["Microsoft", "Google", "Apple", "Amazon", "Qualcomm", "Intel", "Goldman Sachs", "Morgan Stanley", "McKinsey", "Boston Consulting Group"]
    },
    images: {
      campus: [
        "https://images.unsplash.com/photo-1562774053-701939374585?q=80&w=2072&auto=format&fit=crop&ixlib=rb-4.0.3",
        "https://images.unsplash.com/photo-1509316975850-ff9c5deb0cd9?q=80&w=2072&auto=format&fit=crop&ixlib=rb-4.0.3"
      ],
      classrooms: [
        "https://images.unsplash.com/photo-1544531586-fde5298cdd40?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3"
      ],
      labs: [
        "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=7952&auto=format&fit=crop&ixlib=rb-4.0.3"
      ],
      hostels: [
        "https://images.unsplash.com/photo-1555854877-bab0e564b8d5?q=80&w=2069&auto=format&fit=crop&ixlib=rb-4.0.3"
      ]
    },
    testimonials: [
      {
        quote: "IIT Madras pushes you beyond what you think is possible, but what helped me succeed wasn't just the degree—it was the self-directed projects and internships I pursued alongside my coursework.",
        name: "Raj Sharma",
        batch: "2018",
        program: "B.Tech Computer Science"
      },
      {
        quote: "The competitive environment at IITM can be overwhelming. What most don't tell you is that your network and practical projects matter far more than your CGPA for landing good opportunities.",
        name: "Anitha K",
        batch: "2019",
        program: "Dual Degree Electrical Engineering"
      },
      {
        quote: "IIT Madras gave me a strong foundation, but I had to learn most industry-relevant skills on my own through online courses and open source contributions. The degree opened doors, but my self-taught skills sealed the deals.",
        name: "Vikram Menon",
        batch: "2020",
        program: "M.Tech Data Science"
      }
    ],
    faq: [
      {
        question: "How difficult is it to get into IIT Madras?",
        answer: "Extremely difficult. With an acceptance rate of just 1.5%, IIT Madras is more selective than most Ivy League schools. You need to rank in the top 1-2% of JEE Advanced, which itself requires qualifying through JEE Mains (top 2.5%). Only about 150-200 students get admitted to B.Tech CS each year out of hundreds of thousands who attempt. The brutal reality: for 98.5% of aspirants, admission is mathematically impossible."
      },
      {
        question: "Is an IIT Madras degree worth the cost and effort?",
        answer: "It depends on your goals. For certain specialized fields in engineering and research, an IIT degree provides exceptional value through its prestige, network, and rigorous training. However, the ROI calculation has changed dramatically in the age of AI and digital learning. For many tech careers, self-taught skills and portfolio projects can provide similar or better outcomes at a fraction of the time and cost. The degree's primary value now is often the initial door-opening rather than the education itself."
      },
      {
        question: "What don't they tell you about IIT Madras?",
        answer: "The curriculum often lags behind industry trends by 2-3 years. Many graduates report learning more practical skills through online courses, internships, and personal projects than through formal coursework. Mental health challenges are widespread but rarely discussed openly. The intense pressure results in burnout for many students. While placement statistics look impressive, they don't reflect the significant self-learning many students undertake outside the curriculum to become job-ready."
      },
      {
        question: "How can I get an IIT-quality education if I don't get admitted?",
        answer: "The internet has democratized knowledge. You can access MIT OpenCourseWare, Stanford Online, and NPTEL (created by IITs themselves) for free. Platforms like Coursera offer courses taught by the same professors. For practical skills, focus on building projects and contributing to open source. Join communities like Stack Overflow, GitHub, and specialized Discord servers. Many successful tech professionals never attended elite institutions but built impressive careers through self-education and proving their skills through real-world projects."
      },
      {
        question: "What high-income skills should I focus on whether or not I get into IIT?",
        answer: "Focus on skills with high market demand and low supply: AI/ML engineering, especially prompt engineering and fine-tuning LLMs, cloud architecture (AWS/Azure/GCP), cybersecurity, data engineering, blockchain development, and AR/VR development. Non-technical high-income skills include digital marketing (especially paid acquisition), UX/UI design, technical sales, and content creation. The highest earners typically combine technical expertise with business acumen or creative skills. Build a portfolio showcasing these skills rather than just collecting certifications."
      },
      {
        question: "How relevant is the IIT Madras curriculum to actual industry needs?",
        answer: "There's often a significant gap. The theoretical foundation is strong, but many graduates report needing to learn practical tools, frameworks, and methodologies on their own. For example, while students learn programming fundamentals, they may not learn modern frameworks like React, TensorFlow, or cloud services that employers demand. The curriculum emphasizes theory over practice, which provides depth but requires supplementing with practical, self-directed learning to be job-ready."
      }
    ],
    upcomingEvents: [
      {
        name: "Shaastra 2025",
        date: "January 3-6, 2025",
        description: "Asia's largest completely student-run technical festival featuring competitions, shows, workshops, and exhibitions.",
        link: "https://www.shaastra.org/"
      },
      {
        name: "Open House for Prospective Students",
        date: "December 10, 2024",
        description: "Virtual campus tour and information session for prospective JEE aspirants and their parents.",
        link: "https://www.iitm.ac.in/events"
      }
    ],
    image: "https://images.unsplash.com/photo-1562774053-701939374585?q=80&w=2072&auto=format&fit=crop&ixlib=rb-4.0.3",
    kind: "india"
  },
  {
    id: "iit-kanpur",
    name: "Indian Institute of Technology Kanpur",
    location: "Kanpur",
    state: "Uttar Pradesh",
    type: "Engineering and Technology",
    ownership: "Public",
    estYear: 1959,
    ranking: 4,
    nirf: 4,
    accreditation: "A++",
    studentsCount: 8500,
    facultyCount: 420,
    tuitionFee: 225000,
    acceptanceRate: 2.5,
    programs: ["B.Tech", "M.Tech", "Ph.D", "MBA", "M.Sc", "M.Des"],
    specializations: ["Computer Science", "Aerospace Engineering", "Materials Science", "Nuclear Engineering", "Environmental Engineering"],
    degrees: ["Bachelor's", "Master's", "Doctorate"],
    facilities: ["Flight Laboratory", "Advanced Center for Materials", "Computer Center", "Sports Complex", "Health Centre"],
    image: "https://images.unsplash.com/photo-1562774053-701939374585?q=80&w=2072&auto=format&fit=crop&ixlib=rb-4.0.3",
    kind: "india"
  }
];
