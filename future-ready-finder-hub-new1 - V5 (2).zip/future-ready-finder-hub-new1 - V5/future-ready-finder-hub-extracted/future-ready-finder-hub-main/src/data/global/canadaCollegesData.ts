
import type { GlobalCollege } from "@/types/college.types";

export const canadaCollegesData: GlobalCollege[] = [
  {
    id: "toronto",
    name: "University of Toronto",
    location: "Toronto",
    country: "Canada",
    type: "Public",
    ranking: 13,
    foundedYear: 1827,
    studentsCount: 63000,
    acceptanceRate: 43,
    tuitionFee: 54000,
    programs: [
      "Computer Science", "Law", "Philosophy", "Medicine", "Engineering"
    ],
    degrees: ["Bachelor", "Master", "Doctorate"],
    image: "https://images.unsplash.com/photo-1536601290628-c91d3897f2a2",
    website: "https://www.utoronto.ca/",
    description: "UofT is Canada's top university known for global impact and research.",
    kind: "global"
  },
  {
    id: "mcgill",
    name: "McGill University",
    location: "Montreal",
    country: "Canada",
    type: "Public",
    ranking: 31,
    foundedYear: 1821,
    studentsCount: 40000,
    acceptanceRate: 46,
    tuitionFee: 45000,
    programs: [
      "Medicine", "Law", "Engineering", "Business", "Arts", "Science"
    ],
    degrees: ["Bachelor", "Master", "Doctorate"],
    image: "https://images.unsplash.com/photo-1560015534-d250f038e31c",
    website: "https://www.mcgill.ca/",
    description: "McGill is one of Canada's best-known institutions of higher learning and one of the leading universities in the world.",
    kind: "global"
  },
  {
    id: "ubc",
    name: "University of British Columbia",
    location: "Vancouver",
    country: "Canada",
    type: "Public",
    ranking: 37,
    foundedYear: 1908,
    studentsCount: 66000,
    acceptanceRate: 52,
    tuitionFee: 42000,
    programs: [
      "Computer Science", "Engineering", "Medicine", "Business", "Forestry"
    ],
    degrees: ["Bachelor", "Master", "Doctorate"],
    image: "https://images.unsplash.com/photo-1589798312824-ca9225afb70e",
    website: "https://www.ubc.ca/",
    description: "UBC is a global center for research and teaching, consistently ranked among the top 20 public universities in the world.",
    kind: "global"
  },
  {
    id: "waterloo",
    name: "University of Waterloo",
    location: "Waterloo",
    country: "Canada",
    type: "Public",
    ranking: 47,
    foundedYear: 1957,
    studentsCount: 42000,
    acceptanceRate: 53,
    tuitionFee: 41000,
    programs: [
      "Computer Science", "Engineering", "Mathematics", "Science", "Arts"
    ],
    degrees: ["Bachelor", "Master", "Doctorate"],
    image: "https://images.unsplash.com/photo-1562774053-701939374585",
    website: "https://uwaterloo.ca/",
    description: "The University of Waterloo is a leading research institution known for its co-operative education programs and strong STEM focus.",
    kind: "global"
  },
  {
    id: "western",
    name: "Western University",
    location: "London, ON",
    country: "Canada",
    type: "Public",
    ranking: 68,
    foundedYear: 1878,
    studentsCount: 31000,
    acceptanceRate: 58,
    tuitionFee: 36000,
    programs: [
      "Medicine", "Business", "Engineering", "Law", "Media Studies"
    ],
    degrees: ["Bachelor", "Master", "Doctorate"],
    image: "https://images.unsplash.com/photo-1541339907198-e08756dedf3f",
    website: "https://www.uwo.ca/",
    description: "Western University delivers an academic experience second to none with a full complement of rich academic choices.",
    kind: "global"
  }
];
