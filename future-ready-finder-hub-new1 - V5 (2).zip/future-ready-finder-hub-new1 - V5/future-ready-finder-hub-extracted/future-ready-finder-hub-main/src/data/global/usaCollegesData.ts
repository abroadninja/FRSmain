
import { GlobalCollege } from "@/types/college.types";

export const usaCollegesData: GlobalCollege[] = [
  {
    id: "mit",
    name: "Massachusetts Institute of Technology",
    location: "Cambridge, MA",
    country: "USA",
    type: "Private",
    ranking: 1,
    foundedYear: 1861,
    studentsCount: 11500,
    acceptanceRate: 7,
    tuitionFee: 57790,
    programs: [
      "Computer Science", "Electrical Engineering", "Aerospace Engineering",
      "Physics", "Chemistry", "Economics", "Mathematics", "Mechanical Engineering",
      "Biology", "Architecture", "Urban Planning", "Business Analytics", 
      "Data Science", "Artificial Intelligence", "Nuclear Science"
    ],
    degrees: ["Bachelor", "Master", "Doctorate"],
    image: "https://images.unsplash.com/photo-1576439108456-0d49a6702398?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3",
    website: "https://web.mit.edu/",
    description: "MIT is a world leader in science, technology, and engineering education and research.",
    shortDescription: "The Massachusetts Institute of Technology (MIT) is a private land-grant research university in Cambridge, Massachusetts.",
    longDescription: "Founded in 1861, MIT has played a key role in the development of modern technology and science, and has been ranked among the top academic institutions in the world. The Institute is traditionally known for its research and education in the physical sciences, engineering, and more recently biology, economics, linguistics, and management. MIT is a member of the Association of American Universities (AAU) and has a strong entrepreneurial culture, with many alumni founding successful companies and organizations.",
    mission: "The mission of MIT is to advance knowledge and educate students in science, technology, and other areas of scholarship that will best serve the nation and the world in the 21st century.",
    vision: "To bring knowledge to bear on the world's great challenges. MIT faculty and students extend this ethos through learning, research, and innovation focused on solving global issues.",
    values: [
      "Excellence and innovation in education and research",
      "Integrity and intellectual honesty",
      "Diversity and respect for the value and dignity of each individual",
      "Serving the nation and the world",
      "Promoting the welfare of the MIT community"
    ],
    campusSize: "168 acres (0.68 km²)",
    admissionDeadlines: {
      early: "November 1",
      regular: "January 5",
      transfer: "March 15"
    },
    facultyInfo: {
      totalCount: 1073,
      studentFacultyRatio: "3:1",
      notableFaculty: [
        {
          name: "Tim Berners-Lee",
          position: "Professor of Computer Science",
          achievement: "Inventor of the World Wide Web",
          image: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=1000&auto=format&fit=crop"
        },
        {
          name: "Esther Duflo",
          position: "Professor of Poverty Alleviation and Development Economics",
          achievement: "Nobel Prize in Economics (2019)",
          image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=1000&auto=format&fit=crop"
        },
        {
          name: "Robert Langer",
          position: "Institute Professor",
          achievement: "Pioneering researcher in biotechnology and drug delivery systems",
          image: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5?q=80&w=1000&auto=format&fit=crop"
        }
      ]
    },
    accommodationOptions: [
      "Undergraduate residence halls",
      "Graduate dormitories",
      "Family housing",
      "Fraternities, sororities, and independent living groups"
    ],
    researchAreas: [
      "Artificial Intelligence",
      "Biotechnology",
      "Climate Change",
      "Computer Science",
      "Cybersecurity",
      "Economics",
      "Energy",
      "Engineering Systems",
      "Health Sciences",
      "Materials Science",
      "Nanotechnology",
      "Quantum Computing",
      "Robotics",
      "Space Exploration",
      "Sustainable Development"
    ],
    notableAlumni: [
      {
        name: "Buzz Aldrin",
        achievement: "Astronaut, second person to walk on the Moon",
        graduationYear: 1963,
        image: "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?q=80&w=1000&auto=format&fit=crop"
      },
      {
        name: "Kofi Annan",
        achievement: "Former Secretary-General of the United Nations, Nobel Peace Prize laureate",
        graduationYear: 1972,
        image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1000&auto=format&fit=crop"
      },
      {
        name: "Richard Feynman",
        achievement: "Theoretical physicist, Nobel Prize winner in Physics",
        graduationYear: 1939,
        image: "https://images.unsplash.com/photo-1564564321837-a57b7070ac4f?q=80&w=1000&auto=format&fit=crop"
      },
      {
        name: "Katharine McCormick",
        achievement: "Biologist, philanthropist, women's rights activist",
        graduationYear: 1904,
        image: "https://images.unsplash.com/photo-1553267751-1c148a7280a1?q=80&w=1000&auto=format&fit=crop"
      }
    ],
    rankings: [
      {
        source: "QS World University Rankings",
        rank: 1,
        year: 2024,
        category: "Overall"
      },
      {
        source: "Times Higher Education",
        rank: 5,
        year: 2024,
        category: "Overall"
      },
      {
        source: "U.S. News & World Report",
        rank: 2,
        year: 2024,
        category: "National Universities"
      },
      {
        source: "QS World University Rankings",
        rank: 1,
        year: 2024,
        category: "Engineering & Technology"
      }
    ],
    financialAid: {
      availableAid: true,
      scholarships: ["MIT Scholarship", "Pell Grants", "Federal Work-Study", "Outside Scholarships"],
      averagePackage: 53500,
      percentReceiving: 59
    },
    virtualTour: "https://www.youvisit.com/tour/mit",
    socialLinks: {
      facebook: "https://www.facebook.com/MITnews",
      twitter: "https://twitter.com/MIT",
      instagram: "https://www.instagram.com/mitpics/",
      linkedin: "https://www.linkedin.com/school/mit/",
      youtube: "https://www.youtube.com/user/MITNewsOffice"
    },
    faq: [
      {
        question: "What is MIT's acceptance rate?",
        answer: "MIT's undergraduate acceptance rate is approximately 7%, making it one of the most selective universities in the world."
      },
      {
        question: "Does MIT offer financial aid?",
        answer: "Yes, MIT is committed to meeting 100% of demonstrated financial need for all admitted students through a combination of scholarships, grants, and work opportunities. About 59% of MIT undergraduates receive need-based financial aid."
      },
      {
        question: "What is MIT known for academically?",
        answer: "MIT is renowned for its programs in engineering, computer science, physics, mathematics, economics, and business. The university is particularly known for its innovative research in areas such as artificial intelligence, robotics, energy, and biotechnology."
      },
      {
        question: "Does MIT have a strong entrepreneurial culture?",
        answer: "Yes, MIT has a very strong entrepreneurial ecosystem. MIT alumni have founded thousands of companies including Dropbox, Bose, Koch Industries, Intel, and many others. The Martin Trust Center for MIT Entrepreneurship supports students in turning their ideas into viable businesses."
      },
      {
        question: "What sports and extracurricular activities are available at MIT?",
        answer: "MIT offers 33 varsity sports, numerous club and intramural sports, and over 500 student organizations covering a wide range of interests including arts, community service, cultural groups, media and publications, and governance."
      }
    ],
    upcomingEvents: [
      {
        name: "MIT Sloan Tech Conference",
        date: "April 30, 2025",
        description: "Annual technology conference bringing together business leaders, innovators, and academics to discuss the impact of technology on business and society.",
        link: "https://www.mitsloantech.com/"
      },
      {
        name: "MIT Energy Conference",
        date: "May 15, 2025",
        description: "A student-led conference that brings together leaders in industry, government, academia, and finance to discuss and explore solutions to pressing global energy challenges.",
        link: "https://www.mitenergyconference.org/"
      }
    ],
    applicationProcess: [
      "Complete the Coalition or Common Application",
      "Submit SAT or ACT scores (optional for 2024-2025)",
      "Submit two teacher evaluations",
      "Interview with an MIT alumni (if available)",
      "Submit maker portfolio (optional)",
      "Complete financial aid application if needed"
    ],
    images: {
      campus: [
        "https://images.unsplash.com/photo-1564540583246-934409427776?q=80&w=2070&auto=format&fit=crop",
        "https://images.unsplash.com/photo-1576439139176-4b49a76275a0?q=80&w=2070&auto=format&fit=crop"
      ],
      classrooms: [
        "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=2070&auto=format&fit=crop"
      ],
      labs: [
        "https://images.unsplash.com/photo-1581091007718-0c50d599bfd0?q=80&w=2070&auto=format&fit=crop"
      ],
      facilities: [
        "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=2070&auto=format&fit=crop"
      ]
    },
    testimonials: [
      {
        quote: "The collaborative atmosphere at MIT pushed me to think beyond boundaries. The rigorous curriculum and support from faculty helped me develop skills that have been invaluable in my career.",
        name: "Sarah Chen",
        position: "Computer Science '21, Software Engineer at Google",
        image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=1000&auto=format&fit=crop"
      },
      {
        quote: "MIT doesn't just teach you knowledge; it teaches you how to think. The problem-solving approach I learned here has been applicable to every challenge I've faced in my professional life.",
        name: "Michael Rodriguez",
        position: "Mechanical Engineering '19, Aerospace Engineer at SpaceX",
        image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=1000&auto=format&fit=crop"
      }
    ],
    internationalStudents: {
      percentage: 29,
      countries: 118,
      supportServices: [
        "International Students Office",
        "English Language Support",
        "Global Education & Career Development",
        "Cross-Cultural Connection Programs",
        "International Student Orientation"
      ]
    },
    kind: "global"
  },
  {
    id: "harvard",
    name: "Harvard University",
    location: "Cambridge, MA",
    country: "USA",
    type: "Private",
    ranking: 2,
    foundedYear: 1636,
    studentsCount: 20000,
    acceptanceRate: 5,
    tuitionFee: 59011,
    programs: [
      "Law", "Business Administration", "Medicine", "Computer Science", "Physics",
      "Government", "Psychology"
    ],
    degrees: ["Bachelor", "Master", "Doctorate"],
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=1000&auto=format&fit=crop",
    website: "https://www.harvard.edu/",
    description: "Harvard is one of the world's most prestigious universities, renowned for leadership in teaching, research, and innovation.",
    kind: "global"
  }
  // More USA colleges can be added here
];
