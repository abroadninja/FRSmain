
import { GlobalCollege } from "@/types/college.types";

export const globalOtherCollegesData: GlobalCollege[] = [
  {
    id: "nus",
    name: "National University of Singapore",
    location: "Singapore",
    country: "Singapore",
    type: "Public",
    ranking: 8,
    foundedYear: 1905,
    studentsCount: 38000,
    acceptanceRate: 7,
    tuitionFee: 30000,
    programs: [
      "Engineering", "Medicine", "Law", "Business Administration", "Architecture"
    ],
    degrees: ["Bachelor", "Master", "Doctorate"],
    image: "https://images.unsplash.com/photo-1501854140801-50d01698950b",
    website: "https://www.nus.edu.sg/",
    description: "NUS is Asia’s leading comprehensive research university.",
    kind: "global"
  },
  {
    id: "unimelb",
    name: "University of Melbourne",
    location: "Melbourne",
    country: "Australia",
    type: "Public",
    ranking: 10,
    foundedYear: 1853,
    studentsCount: 54000,
    acceptanceRate: 35,
    tuitionFee: 38000,
    programs: [
      "Medicine", "Law", "Engineering", "Arts", "Business"
    ],
    degrees: ["Bachelor", "Master", "Doctorate"],
    image: "https://images.unsplash.com/photo-1606761568499-6d2451b23c66",
    website: "https://www.unimelb.edu.au/",
    description: "Australia's top university, focused on research, innovation, and teaching.",
    kind: "global"
  }
  // Add more for other regions/continents!
];
