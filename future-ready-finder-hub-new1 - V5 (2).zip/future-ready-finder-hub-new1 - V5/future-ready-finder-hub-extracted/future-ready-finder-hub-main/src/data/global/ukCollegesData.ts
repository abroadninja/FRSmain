
import { GlobalCollege } from "@/types/college.types";

export const ukCollegesData: GlobalCollege[] = [
  {
    id: "oxford",
    name: "University of Oxford",
    location: "Oxford",
    country: "UK",
    type: "Public",
    ranking: 4,
    foundedYear: 1096,
    studentsCount: 24750,
    acceptanceRate: 17,
    tuitionFee: 47500,
    programs: [
      "Philosophy", "Medicine", "Law", "Engineering Science", "History", "Mathematics"
    ],
    degrees: ["Bachelor", "Master", "Doctorate"],
    image: "https://images.unsplash.com/photo-1541339907198-e08756dedf3f",
    website: "https://www.ox.ac.uk/",
    description: "Oxford combines centuries-old tradition with cutting-edge research.",
    kind: "global"
  },
  {
    id: "cambridge",
    name: "University of Cambridge",
    location: "Cambridge",
    country: "UK",
    type: "Public",
    ranking: 5,
    foundedYear: 1209,
    studentsCount: 21000,
    acceptanceRate: 21,
    tuitionFee: 44000,
    programs: [
      "Engineering", "Medicine", "Economics", "History", "Computer Science"
    ],
    degrees: ["Bachelor", "Master", "Doctorate"],
    image: "https://images.unsplash.com/photo-1519452575417-564c1401ecc0",
    website: "https://www.cam.ac.uk/",
    description: "A global leader in education and research, Cambridge has influenced the world for over 800 years.",
    kind: "global"
  }
  // More UK colleges can be added here
];
