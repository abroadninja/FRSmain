
export interface TemplateItem {
  id: string;
  title: string;
  preview: string;
  content: string;
  type: string;
  category: string;
}

export const prospectiveParentTemplates: TemplateItem[] = [
  // Short-form templates
  {
    id: "short-social-1",
    title: "Join Our Community (Short Social)",
    preview: "A concise invitation for social media to join the prospective parent community",
    content: "Considering the best future for your child? Join our free community for prospective parents! Connect with other families, gain insights into our future-focused approach to education, and get general parenting tips. It's a great way to learn more about our school and how we think about preparing students for tomorrow's world. Click the link below to join!\n\n#FutureReadyKids #ProspectiveParents #ParentCommunity #SchoolEnrolment",
    type: "Social Media",
    category: "short-form"
  },
  {
    id: "short-social-2",
    title: "Future Skills Focus (Short)",
    preview: "Brief social media post highlighting future skills preparation",
    content: "Thinking about your child's future? Join our free parent community for prospective families! Connect with others and learn about our focus on skills like critical thinking and adaptability. Let's explore your child's potential together! [Link to join] #FutureReadyKids #ProspectiveParents #ParentCommunity",
    type: "Social Media",
    category: "short-form"
  },
  {
    id: "short-engaging-1",
    title: "Considering Your Child's Future? (Short & Engaging)",
    preview: "A brief but engaging invitation to join the parent community",
    content: "Considering Your Child's Future? Join Our Community for Prospective Parents!\n\nConnect with other families exploring future-focused education and gain insights into how we help children develop essential skills for tomorrow's world. This is a space for prospective parents to share ideas and learn more about our school's approach to nurturing lifelong learners. Join our free community today and take the first step in partnering for your child's bright future! [Link to join]",
    type: "Email/WhatsApp",
    category: "short-form"
  },
  {
    id: "short-connection-1",
    title: "Connect with Other Families (Short)",
    preview: "Brief message focused on family connections and shared experiences",
    content: "Connect with Other Families Exploring Future-Focused Education!\n\nAre you a prospective parent interested in a school that prioritises future readiness? Our free parent community for prospective families offers a supportive space to connect with others on the same journey. Share your questions, learn about our school's vision for preparing students for tomorrow, and exchange general parenting insights. Click here to join our community today!",
    type: "Email/WhatsApp",
    category: "short-form"
  },
  
  // Detailed templates
  {
    id: "detailed-website-1",
    title: "Website/Flyer Snippet (Detailed)",
    preview: "Longer copy for your website or printed materials",
    content: "Thinking About Your Child's Education? Join Our Free Prospective Parent Community!\n\nIf you're exploring school options and thinking about how to best prepare your child for the future, we invite you to join our dedicated online community for prospective parents.\n\nThis free group offers a space to connect with other families considering our school, gain a broader understanding of our educational philosophy (particularly our commitment to future readiness), and receive general tips on supporting your child's development. Please note that specific details about our Future Readiness Classes and High Income Skill Portfolio Building Guidance are for our currently enrolled students. However, this community provides valuable insights as you consider our school for your child's educational journey. Join us today to start the conversation! [Link to join]",
    type: "Website/Flyer",
    category: "detailed"
  },
  {
    id: "detailed-email-1",
    title: "Email Invitation with Subject Line",
    preview: "Complete email template with subject line and opening paragraph",
    content: "Subject: Explore Your Child's Future: Join Our Prospective Parent Community\n\nDear Prospective Parent,\n\nAs you consider educational options for your child, we understand you're looking for a school that not only provides excellent academics but also prepares students for the future landscape. We'd like to invite you to join our free online community specifically for prospective parents like you.\n\nThis community offers a space to connect with other families who are at the same stage of the school selection process, providing mutual support and shared insights. You'll also gain valuable information about our educational approach, particularly our focus on future readiness skills that prepare children for a rapidly changing world.\n\nBy joining, you'll receive:\n• Insights into how we develop critical skills like adaptability, problem-solving, and digital literacy\n• General parenting tips on supporting your child's growth and learning\n• Opportunities to connect with other parents exploring educational options\n• A glimpse into our school's community and values\n\nPlease note that detailed curriculum information and specific program content are reserved for enrolled families, but this community will help you understand our overall approach and philosophy.\n\nTo join, simply [instructions for joining - e.g., click the link below, scan this QR code, etc.].\n\nWe look forward to connecting with you!\n\nWarm regards,\n[Your Name]\n[School Name]",
    type: "Email",
    category: "detailed"
  },
  {
    id: "detailed-discovery-1",
    title: "Discover Our Approach (Detailed)",
    preview: "In-depth look at the school's approach to future readiness",
    content: "Discover Our Approach to Future Readiness and Connect with Other Prospective Families\n\nAt our school, we believe in equipping students with crucial skills such as critical thinking, adaptability, creativity, and collaboration. We understand that choosing the right educational environment is a significant decision. Our community for prospective parents offers a valuable opportunity to connect with other families who are also considering how to best prepare their children for the future.\n\nIn this community, you can:\n• Share your thoughts and questions with other prospective parents\n• Gain a broader understanding of our school's philosophy, which emphasises the development of future-ready skills\n• Learn about the importance of fostering qualities like curiosity and a growth mindset in your child\n\nPlease note that specific details about our curriculum and programs for enrolled students will be shared at a later stage. This community is designed to support you as you explore your options and consider our school for your child's educational journey. We look forward to welcoming you! [Link to join]",
    type: "Website/Email",
    category: "detailed"
  },
  
  // Community-focused templates
  {
    id: "community-partnership-1",
    title: "Partnership for Success (Community-Focused)",
    preview: "Message emphasizing school-parent partnership and shared values",
    content: "Partner with Us for Your Child's Success: Join Our Prospective Parent Community\n\nChoosing the right school is about finding a partner who shares your commitment to your child's growth and future well-being. Our community for prospective parents provides a supportive space where you can connect with other families and learn more about how we foster holistic development in our students.\n\nWe believe in nurturing not just academic achievement, but also essential life skills such as communication, teamwork, and problem-solving. By joining our community, you can engage with other prospective parents and gain insights into our values and our commitment to preparing students to thrive in a complex and evolving world.\n\nWe encourage you to join this free community to start building connections and learning more about our vision for future-ready education. [Link to join]",
    type: "Email/Website",
    category: "community-focused"
  },
  {
    id: "community-connect-1",
    title: "Building Future-Ready Community (Connection)",
    preview: "Focus on building a community of forward-thinking families",
    content: "Join Our Future-Ready Family Network: Where Education Meets Tomorrow's Opportunities\n\nDear Prospective Parent,\n\nEvery child deserves an education that prepares them not just for exams, but for life. At [School Name], we're building a community of forward-thinking families who understand that tomorrow's success requires more than traditional academics.\n\nOur Prospective Parent Community is your first step into this network. Here, you'll connect with other families who share your values about education and future preparation. Together, you'll explore how our approach develops critical skills like problem-solving, adaptability, and digital literacy – all within a supportive community that values every child's unique potential.\n\nWhat makes our community different:\n• Focus on practical future skills, not just theory\n• Regular insights from experienced educators\n• Connection with like-minded families\n• A practical understanding of how education and future success connect\n\nJoin us today to see if our educational philosophy aligns with your family's vision for your child's future.\n\n[Link to join]\n\nWarmly,\n[School Principal/Representative]",
    type: "Email",
    category: "community-focused"
  },
  {
    id: "community-journey-1",
    title: "Education Journey Together (Community)",
    preview: "Invitation emphasizing shared educational journey and values",
    content: "Begin Your Child's Educational Journey with Us\n\nDear Family,\n\nChoosing a school isn't just a decision—it's the beginning of a journey. We invite you to join our Prospective Parent Community, where families like yours are exploring how education can truly prepare children for the future.\n\nThis free online group allows you to:\n• Connect with other parents navigating school choices\n• Discover how our curriculum develops future-ready skills\n• Learn practical ways to support your child's development at home\n• Ask questions in a supportive, no-pressure environment\n\nWhether you're just starting to explore options or actively comparing schools, our community provides valuable perspectives from both educators and other parents.\n\nJoin us today at [link] and take the first step in discovering if our approach to education aligns with your family's values and your child's needs.\n\nWe look forward to welcoming you,\n[School Name] Admissions Team",
    type: "Email/WhatsApp",
    category: "community-focused"
  },
  
  // Social media templates
  {
    id: "social-carousel-1",
    title: "Instagram Carousel Copy (5 Slides)",
    preview: "Copy for a 5-slide Instagram carousel about future readiness",
    content: "Instagram Carousel Copy (5 Slides)\n\nSlide 1: Parents ask us: \"How will your school prepare my child for the future?\" Swipe to see what makes our approach different →\n\nSlide 2: We focus on FUTURE READINESS skills, not just academics. Critical thinking, adaptability, creativity, and digital literacy are built into everything we do.\n\nSlide 3: Our students learn HIGH-INCOME SKILLS that will remain valuable regardless of how the job market evolves. They build portfolios of actual work, not just grades.\n\nSlide 4: Parents are PARTNERS in education. Our parent community receives regular insights on supporting skills development at home, creating a powerful learning ecosystem.\n\nSlide 5: Want to learn more? Join our FREE prospective parent community where you can connect with other families and discover our approach to future-ready education. Link in bio!\n\nCaption: What educational approach will truly prepare your child for tomorrow's world? At [School Name], we're focused on skills that matter for the future, not just test scores. Join our free parent community to learn more! #FutureReadyEducation #ParentCommunity #SchoolChoice",
    type: "Social Media",
    category: "social-media"
  },
  {
    id: "social-video-1",
    title: "Social Media Video Script",
    preview: "Script for a short video to attract prospective parents",
    content: "Social Media Video Script (60-90 seconds)\n\nOPENING (0:00-0:10)\n[Visual: Students engaged in creative problem-solving or collaborative activity]\nVoiceover: \"What if school could prepare your child not just for exams, but for life?\"\n\nMAIN POINTS (0:10-0:50)\n[Visual: Split screen showing traditional learning vs. future-ready approach]\nVoiceover: \"At [School Name], we focus on the skills that will matter most in your child's future: critical thinking, adaptability, creativity, and digital literacy.\"\n\n[Visual: Students working on projects/portfolios]\nVoiceover: \"Our students don't just learn theory—they build actual skills and create portfolios that showcase their abilities.\"\n\n[Visual: Parent and teacher interaction]\nVoiceover: \"And we partner with parents through our dedicated community, providing insights and strategies to support your child's development at home.\"\n\nCALL TO ACTION (0:50-1:00)\n[Visual: School logo with contact information]\nVoiceover: \"Join our free prospective parent community to learn more about our approach and connect with other forward-thinking families.\"\n\nOn-Screen Text: \"Join our Prospective Parent Community at [link]\"",
    type: "Social Media",
    category: "social-media"
  },
  {
    id: "social-facebook-1",
    title: "Facebook Ad Copy",
    preview: "Copy for a Facebook ad campaign targeting prospective parents",
    content: "Facebook Ad Copy\n\nHeadline: Prepare Your Child for Tomorrow's World, Not Yesterday's\n\nMain Text: Is your child learning the skills they'll actually need in the future?\n\nAt [School Name], we focus on developing:\n✅ Critical thinking & problem-solving\n✅ Creativity & innovation\n✅ Digital literacy & adaptability\n✅ Communication & collaboration\n\nAll while maintaining academic excellence.\n\nJoin our FREE prospective parent community to discover how our approach differs from traditional schools and connect with other families looking for future-focused education.\n\nCTA Button: Learn More\n\n[Note: Include an image of students engaged in collaborative, technology-enhanced learning or creative problem-solving]",
    type: "Social Media",
    category: "social-media"
  }
];
