
export interface CommunityContentItem {
  id: string;
  title: string;
  description: string;
  content: string;
  format: string;
  category: string;
  ageGroup: string;
}

export const parentCommunityContent: CommunityContentItem[] = [
  // Content for ages 7-9
  {
    id: "beyond-grades-7-9",
    title: "Beyond Grades: 5 Foundational Skills Your Child Needs",
    description: "What matters most for future success beyond academics",
    content: "Beyond Grades: 5 Foundational Skills Your Child Needs for the Future\n\nGrades are important, but the future demands MORE. Are you preparing your child for tomorrow's world?\n\n1. CRITICAL THINKING: The ability to analyze, not just memorize.\nWhy it matters: In an age of information overload, children need to evaluate what they see and hear.\nTry this: Instead of providing answers, ask \"Why do you think that happens?\" Encourage questioning.\n\n2. ADAPTABILITY: Embracing change confidently.\nWhy it matters: The only constant in their future will be change itself.\nTry this: Introduce small changes to routines occasionally. Praise flexible thinking and trying new approaches.\n\n3. COLLABORATION: Working effectively with others.\nWhy it matters: Complex problems require teamwork and diverse perspectives.\nTry this: Family projects, board games, and shared responsibilities build this skill naturally.\n\n4. CREATIVITY: Generating and developing ideas.\nWhy it matters: Automation will handle routine tasks; human creativity remains invaluable.\nTry this: Provide open-ended materials and time for unstructured play.\n\n5. COMMUNICATION: Expressing ideas clearly and listening effectively.\nWhy it matters: Even brilliant ideas are useless if they can't be shared.\nTry this: Regular family discussions where everyone gets heard. Encourage storytelling.\n\nOur school focuses on building these skills alongside strong academics. You can reinforce them at home through everyday interactions and activities.\n\nRemember: These skills develop gradually through practice and encouragement. Celebrate progress rather than perfection.\n\nWhat skill do you think is most important for your child's future? We'd love to hear your thoughts!",
    format: "Educational Article",
    category: "essential-skills",
    ageGroup: "ages-7-9"
  },
  {
    id: "curiosity-sparking-7-9", 
    title: "Is Your Child Curious Enough?",
    description: "How to spark and protect natural curiosity in young children",
    content: "Is Your Child Curious Enough? How to Spark Lifelong Learning\n\nCuriosity isn't just a trait - it's a MUSCLE that needs regular exercise. Research shows curious children become better learners and more successful adults. Here's how to keep that natural wonder alive:\n\n1. WELCOME ALL QUESTIONS\nEven the hundredth \"why?\" deserves acknowledgment. Questions show your child is thinking! Set aside \"question time\" if needed, but never discourage their inquiries.\n\n2. RESPOND WITH EXPLORATION\nInstead of quick answers, say \"Let's find out together!\" Use books, nature, safe online resources, or experts in your community. The journey to the answer is often more valuable than the answer itself.\n\n3. MODEL CURIOSITY YOURSELF\nWonder aloud: \"I'm curious why the sky changes color at sunset\" or \"I wonder how they build bridges over water.\" Show that learning continues throughout life.\n\n4. FOLLOW THEIR INTERESTS DEEPLY\nWhether it's dinosaurs, outer space, cooking, or insects - dive into topics they love. Visit related museums, find books, watch documentaries, try hands-on projects.\n\n5. CREATE A \"WONDER WALL\"\nDesignate a space where family members post questions they're curious about. Research answers together weekly.\n\nWARNING SIGNS OF FADING CURIOSITY:\n• Reduced questioning\n• Lack of enthusiasm for new experiences\n• \"I don't know\" as a default response\n• Boredom with non-screen activities\n\nRemember: A curious mind is a future-ready mind. In a world where information and technology are constantly changing, the ability to wonder, question, and explore may be your child's greatest asset.\n\nWant to assess your child's curiosity? Ask them what they're wondering about today!",
    format: "Educational Article",
    category: "mindset",
    ageGroup: "ages-7-9"
  },
  // Add more items as needed with the correct structure
  {
    id: "adaptability-7-9",
    title: "Adaptability 101: Preparing Your Child for a Changing World",
    description: "Simple steps to build flexibility and resilience in young children",
    content: "Adaptability 101: Preparing Your Child for a Changing World\n\nIf there's one certainty about your child's future, it's uncertainty. The world is changing faster than ever, and adaptability may be their greatest asset. Here's how to build this essential skill:\n\n1. NORMALIZE SMALL CHANGES\nOccasionally alter routines in positive ways: breakfast for dinner, furniture rearrangement, or trying a new route to familiar places. Talk about how you adjust.\n\n2. USE POSITIVE LANGUAGE ABOUT CHANGE\nInstead of \"Sorry for the disruption,\" try \"Here's an opportunity to be flexible!\" How you frame change shapes their perception of it.\n\n3. TEACH COPING STRATEGIES\nSimple techniques like deep breathing, counting to ten, or naming emotions help children manage the discomfort that sometimes comes with change.\n\n4. CELEBRATE FLEXIBILITY\nNotice and praise when your child handles unexpected situations well: \"I'm impressed by how you adjusted when our plans changed!\"\n\n5. SHARE AGE-APPROPRIATE STORIES\nTalk about times you've adapted to changes, making sure to highlight both the challenge and how you overcame it.\n\n6. ENCOURAGE NEW EXPERIENCES\nRegularly expose children to new foods, activities, people, and environments within their comfort zone, gradually expanding what's familiar.\n\nWHAT TO AVOID:\n• Excessive routine without variation\n• Always rescuing them from minor challenges\n• Catastrophizing when things don't go as planned\n• Rigidly sticking to plans when flexibility would work better\n\nActivity Idea: \"The Change Game\" - Once weekly, introduce a small, manageable change to a family routine. Afterward, discuss: What was different? How did it feel? What did we learn?\n\nRemember: The goal isn't to create chaos, but to build confidence that change is manageable. Children who learn \"I can adjust\" rather than \"I can't handle change\" develop resilience that serves them throughout life.",
    format: "Educational Article",
    category: "essential-skills",
    ageGroup: "ages-7-9"
  }
];
