
export interface TemplateItem {
  id: string;
  title: string;
  preview: string;
  content: string;
  type: string;
  category: string;
}

export const existingParentTemplates: TemplateItem[] = [
  // Announcements
  {
    id: "announce-future-ready-1",
    title: "Future Readiness Program Announcement",
    preview: "Announce the enhanced Future Readiness program to current parents",
    content: "Dear Parents,\n\nWe are excited to announce the rollout of our enhanced Future Readiness program designed to equip your child with essential skills for a successful future. This program will be integrated into the curriculum for all age groups, from our youngest learners to those preparing to transition after school.\n\nFor our 7-9 year olds, the focus will be on foundational skills such as curiosity, adaptability, problem-solving, creativity, and collaboration, laying the groundwork for lifelong learning. Lessons will also cover understanding feelings, trying new things, basic financial concepts, and simple problem-solving.\n\nFor our 10-12 year olds, the program will build upon these foundations, focusing on developing critical thinking, digital discernment, effective collaboration, adaptability, and strong communication skills. They will also be introduced to more complex problem-solving, basic financial literacy, and understanding different perspectives.\n\nFor our 13-15 year olds, the emphasis will shift towards high-leverage skills for future career success, including complex problem-solving, critical thinking and analysis, effective communication, adaptability, and digital literacy. They will also learn about advanced goal setting, financial literacy including compound interest, and digital citizenship.\n\nFor our 16-18 year olds, the program will focus on the essential pillars for a successful transition after school: a clear path (or exploration strategy), marketable skills (and a portfolio), financial literacy in action, professionalism, and their network. They will delve into topics like post-secondary ROI, building a skill-based resume, interview strategies, networking, and investment basics.\n\nIn class, teachers will guide discussions, introduce concepts, and explain how students can utilize their smartphones and the internet for self-learning. Outside of class, students will be encouraged to explore skills, practice, and collaborate in small groups, with teachers sharing helpful resources via platforms like WhatsApp.\n\nWe believe this comprehensive approach, which also incorporates lessons on self-awareness, health and well-being, and community responsibility, will ensure your child is truly future-ready. We encourage you to support their learning journey by showing interest in what they are exploring and praising their efforts.\n\nSincerely,\n[School Name]",
    type: "Email/Letter",
    category: "announcements"
  },
  {
    id: "announce-skill-portfolio-1",
    title: "Skill Portfolio Building Announcement",
    preview: "Introduce the skill portfolio initiative to parents",
    content: "Dear Parents,\n\nAs part of our commitment to future readiness, we are guiding our students in building Skill Portfolio Notebooks to document their developing abilities and create a tangible record of their progress. This portfolio approach is particularly relevant for demonstrating high-income skills and showcasing their capabilities to future employers or higher education institutions.\n\nFor students in the 13-15 and 16-18 year old ranges, we are emphasizing the importance of identifying and developing skills that are in demand, such as complex problem-solving, critical thinking, effective communication, digital literacy, and adaptability. The Skill Portfolio Notebook will serve as a place to record learning plans, document projects, and gather feedback, providing evidence of their growing competence.\n\nWe are encouraging students to choose skills based on their interests and future aspirations, and to actively learn using free online resources, including Google Search, YouTube, and AI tools. They are also being guided on how to research career paths and identify the types of work samples that would be valuable to include in their portfolios.\n\nParents can support this process by encouraging their child to maintain their Skill Portfolio Notebook regularly, discussing their learning plans and future options, and supporting their practice of chosen skills. This practical approach to skill development and portfolio building will be invaluable as they prepare for their next steps after school, providing \"proof of work\" that can often be more impactful than traditional resumes alone.\n\nWe will continue to provide guidance in class and through online communication to help students effectively build their Skill Portfolio Notebooks. We encourage you to discuss this exciting initiative with your child and support their efforts in showcasing their developing talents.\n\nSincerely,\n[School Name]",
    type: "Email/Letter",
    category: "announcements"
  },
  {
    id: "announce-new-initiatives-1",
    title: "New Future Readiness Initiatives",
    preview: "Comprehensive announcement of all new future readiness initiatives",
    content: "Subject: Exciting New Initiatives for Your Child's Future Readiness!\n\nDear Parents,\n\nWe are thrilled to announce some exciting new developments at school designed to further equip your child with the essential skills and knowledge they need to thrive in the future. Based on the latest insights and educational best practices, we are introducing enhanced initiatives focusing on future readiness.\n\nIntroducing 'The Future Ready Family Network':\n\nWe recognize the crucial role parents play in their child's development and future success. To foster a stronger partnership between home and school, we are launching 'The Future Ready Family Network'. This initiative will provide you with:\n\n• Regular updates and insights on key skills for the future, drawn from resources designed for parents like yourselves.\n• Practical tips and conversation starters to support your child's learning and skill development at home. For example, we will be sharing content related to sparking curiosity, building adaptability, fostering problem-solving skills, nurturing self-awareness, and introducing financial literacy.\n• Information on how the school's programs align with these future-ready skills.\n• Guidance on how you can encourage your child's exploration of interests and development of a growth mindset.\n• Occasional notes and messages from teachers via platforms like WhatsApp with simple ways you can support your child's learning journey. We will encourage you to talk to your child about what they are learning, praise their effort, and support their curiosity.\n\nWe believe that by working together, we can create a powerful support system for your child's future.\n\nEnhanced Future Readiness Classes:\n\nWe are further integrating future readiness skills into our curriculum for all age groups. These classes will focus on developing crucial transferable skills that are valuable across many different jobs and life situations, such as:\n\n• Critical Thinking: Learning to analyze information, question assumptions, and solve problems effectively.\n• Adaptability: Preparing students to navigate change and learn quickly in new situations.\n• Collaboration: Building teamwork and communication skills essential for working with others.\n• Creativity: Encouraging innovation and the ability to think outside the box.\n• Digital Literacy: Teaching responsible and effective use of technology and navigating the online world safely.\n• Goal Setting and Time Management: Helping students plan and organize themselves for success.\n• Self-Awareness and Emotional Intelligence: Developing an understanding of their strengths, weaknesses, and emotions.\n\nFor our younger students (e.g., ages 10-12), lessons will cover topics like understanding strengths and weaknesses, basic budgeting, problem-solving, digital citizenship, and exploring different careers. As students progress (e.g., ages 13-15), the focus will shift to more advanced goal setting, critical thinking, adaptability, digital responsibility, and exploring skills needed for future careers.\n\nGuidance on High Income Skill Building:\n\nFor our older students, we will be providing specific guidance on high income skill building. This will involve:\n\n• Introducing students to in-demand skills that have strong future career prospects.\n• Guiding them on how to explore and learn these skills using available resources, including smartphones and free online tools.\n• Encouraging self-learning and collaborative learning in small groups.\n• Facilitating the creation of simple work samples and portfolios to showcase their developing skills.\n• Providing resources and guidance on learning paths and career steps related to these skills.\n\nFor our oldest students (ages 16-18), this will also include information on building a skill-based resume, exploring earning potential through their skills, and understanding the importance of a professional online presence.\n\nWe are confident that these integrated initiatives will provide your child with a well-rounded preparation for the future, equipping them with not only academic knowledge but also the essential skills, mindset, and financial literacy to thrive in an ever-evolving world.\n\nWe look forward to your active participation in 'The Future Ready Family Network' and working together to empower your child's journey. More details about specific activities and resources will be shared in due course.\n\nSincerely,\n[School Name] Administration",
    type: "Email/Letter",
    category: "announcements"
  },
  {
    id: "announce-cultivating-skills-1",
    title: "Cultivating Essential Skills Announcement",
    preview: "Focus on the key skills being developed and how parents can support",
    content: "Announcement: Cultivating Essential Skills for Your Child's Future Success\n\nDear Parents,\n\nWe continue to partner with you in preparing your child for a rapidly evolving future. Beyond academic knowledge, certain essential skills are increasingly vital for success in all aspects of life. We are actively fostering these skills in our students, and your support at home is invaluable in reinforcing this learning.\n\nHere are some key areas we are focusing on and how you can encourage them:\n\nFueling Curiosity: Remember that every child is born curious. Encourage their questions, and instead of always providing instant answers, try asking \"What do you think?\" or \"How can we find out?\". Stop saying \"Because I said so\" and start saying \"Let's find out!\". Protect their curiosity; it fuels learning and critical thinking.\n\nEmbracing Adaptability: Life wobbles, so teach them to adapt, not fear the shake. Praise them when they handle changes well or try new things bravely. Encourage them to step outside their comfort zone, as growth happens when you try new things.\n\nBuilding Problem-Solving Skills: Knowing they can figure things out reduces fear of unexpected challenges. Don't jump in too fast; let them work through small challenges to build their belief in their own ability to find solutions. Every problem solved builds confidence.\n\nDeveloping Digital Literacy: Screens are on, but brains must be on too. Teach them to think critically online, question information, recognize ads, and stay safe. Remind them that online doesn't always equal true.\n\nValuing Effort Over Outcome: Praise the process, not just the prize. Effort is what they control. Focus praise on hard work and persistence, which teaches a growth mindset. Remember, mistakes are stepping stones to learning.\n\nYour mindset matters: model curiosity, resilience, and a growth mindset – they're watching! By partnering with us, we can create an unbeatable combination for your child's future readiness.\n\nSincerely,\n[School Name]",
    type: "Email/Newsletter",
    category: "announcements"
  },
  
  // Updates section (shorter versions)
  {
    id: "update-family-engagement-1",
    title: "Future Ready Family Network Launch (Short)",
    preview: "Brief announcement of the new parent network",
    content: "Subject: Join Our 'Future Ready Family Network'!\n\nDear Parents,\n\nWe're launching the 'Future Ready Family Network' to partner with you in preparing your child for the future. You'll receive updates and tips on essential future skills, helping you support their development at home alongside our enhanced future readiness classes and high income skill building guidance for older students. More info to come!\n\nSincerely,\n[School Name] Administration",
    type: "Email/WhatsApp",
    category: "updates"
  },
  {
    id: "update-classes-1",
    title: "Enhanced Future Readiness Classes (Short)",
    preview: "Brief announcement focusing on the new classes",
    content: "Subject: Exciting Enhancements to Prepare Your Child for the Future!\n\nDear Parents,\n\nGet ready for our enhanced future readiness classes across all age groups! Your child will develop crucial skills like critical thinking, adaptability, and collaboration. For older students, we're also introducing guidance on high income skill building, complementing our new 'Future Ready Family Network' for parents.\n\nSincerely,\n[School Name] Administration",
    type: "Email/WhatsApp",
    category: "updates"
  },
  {
    id: "update-skills-1",
    title: "Investing in Future Skills (Short)",
    preview: "Brief announcement emphasizing skill development",
    content: "Subject: Investing in Your Child's Future Skills\n\nDear Parents,\n\nWe're boosting our focus on future readiness skills! Through enhanced classes (covering areas like creativity and digital literacy) and specific high income skill building guidance for older students (using online tools), we're preparing your child for a changing world. We're also launching the 'Future Ready Family Network' to keep you informed and involved.\n\nSincerely,\n[School Name] Administration",
    type: "Email/WhatsApp",
    category: "updates"
  },
  {
    id: "update-partnership-1",
    title: "Partnership for Future Readiness (Short)",
    preview: "Brief message focusing on school-parent partnership",
    content: "Subject: Partnering for Your Child's Future Readiness\n\nDear Parents,\n\nWe believe in working together to prepare your child for a successful future. That's why we're introducing the 'Future Ready Family Network' to support you, alongside enhanced future readiness classes developing key skills (like problem-solving and adaptability) and high income skill building guidance for our older students (using readily available resources). We're excited about this partnership!\n\nSincerely,\n[School Name] Administration",
    type: "Email/WhatsApp",
    category: "updates"
  },
  
  // Family Network
  {
    id: "network-welcome-1",
    title: "Welcome to Future Ready Family Network",
    preview: "Welcome message for parents joining the network",
    content: "Subject: Welcome to the Future Ready Family Network! Let's Partner for Success\n\nDear Parent,\n\nWelcome to our Future Ready Family Network! We're thrilled to have you join this community dedicated to supporting your child's development of essential future skills.\n\nAs part of this network, you'll receive:\n\n• Weekly tips on fostering key skills at home\n• Insights into what your child is learning in our future readiness program\n• Simple activities you can do together to reinforce learning\n• Opportunities to connect with other parents\n• Advance notice of parent workshops and events\n\nOur first topic focuses on curiosity - the foundation of lifelong learning. Look for our message later this week with practical ways to nurture your child's natural curiosity.\n\nTo make the most of this network:\n• Save this number to your contacts\n• Check our messages at least once a week\n• Try implementing at least one suggestion per month\n• Share your experiences and questions\n\nWe believe that when schools and families work together, children thrive. Thank you for partnering with us in preparing your child for a bright future!\n\nWarmly,\n[Name]\nFuture Ready Coordinator\n[School Name]",
    type: "Email/WhatsApp",
    category: "network"
  },
  {
    id: "network-monthly-theme-1",
    title: "Monthly Theme Announcement",
    preview: "Introducing the monthly skill focus to parents",
    content: "Subject: February Skill Focus: Building Problem-Solving Confidence\n\nDear Future Ready Families,\n\nThis month, we're focusing on a skill that's essential for future success: Problem-Solving.\n\nIn our rapidly changing world, the ability to tackle challenges with confidence is more valuable than ever. Our students are exploring problem-solving techniques in class this month, and you can reinforce this learning at home.\n\nHow you can support at home:\n\n1️⃣ When your child faces a challenge, resist solving it immediately. Instead ask: \"What have you tried so far?\" or \"What could be your first step?\"\n\n2️⃣ Normalize setbacks by sharing age-appropriate challenges you've faced and how you worked through them.\n\n3️⃣ Play games that build problem-solving skills, like puzzles, strategy games, or even \"what would you do if...\" scenarios during dinner conversations.\n\n4️⃣ Praise their process, not just results: \"I like how you tried different approaches\" or \"You didn't give up when it got difficult!\"\n\nLook for our weekly tips this month with more specific activities for your child's age group. We'll also be hosting a parent workshop on \"Raising Problem Solvers\" on February 15th at 6 PM - save the date!\n\nWorking together,\nThe Future Ready Team\n[School Name]",
    type: "Email/WhatsApp",
    category: "network"
  },
  {
    id: "network-weekly-tip-1",
    title: "Weekly Skill Tip for Parents",
    preview: "Practical weekly tip for supporting skill development at home",
    content: "📱 FUTURE READY TIP OF THE WEEK 📱\n\n🔍 CRITICAL THINKING SPOTLIGHT 🔍\n\nCritical thinking isn't just for academics—it's an essential life skill that helps your child evaluate information and make sound decisions.\n\nQuick Activity (takes just 5 minutes):\n\nNext time you're watching TV/online content together, play \"Fact or Opinion?\"\n\n1. Identify statements being made (in ads, shows, or news)\n2. Ask your child: \"Is that a fact we can prove, or someone's opinion?\"\n3. Follow up with: \"How could we verify if that's true?\"\n\nThis simple habit builds media literacy and helps your child become a more discerning consumer of information—a crucial skill in today's information-saturated world.\n\nTry it this week and let us know how it goes!\n\n💡 TIP: Make it fun, not a test. Share your own thoughts too!\n\n#FutureReadySkills #CriticalThinking #ParentingTip",
    type: "WhatsApp",
    category: "network"
  },
  {
    id: "network-event-invite-1",
    title: "Parent Workshop Invitation",
    preview: "Invitation to a skill-building workshop for parents",
    content: "Subject: Invitation: \"Future-Proofing Your Child\" Workshop for Parents\n\nDear Future Ready Families,\n\nYou're invited to our upcoming parent workshop:\n\n🌟 FUTURE-PROOFING YOUR CHILD: SKILLS THAT MATTER 🌟\n\n📅 Date: [Insert date]\n⏰ Time: 6:00 PM - 7:30 PM\n📍 Location: School Auditorium [or Virtual Link for online]\n\nIn this interactive session, you'll discover:\n\n• Why traditional education alone isn't enough for tomorrow's world\n• The 5 most important skills your child needs to develop now\n• Practical strategies to support these skills at home (without adding to your busy schedule)\n• How our school's future readiness program is preparing your child\n\nThe workshop includes hands-on activities, a Q&A session, and take-home resources you can implement immediately.\n\nThis workshop is designed for parents of all students, regardless of age group, as these skills develop across the entire educational journey.\n\nPlease RSVP by [date] by [method]. Limited seats available!\n\nWe look forward to partnering with you in preparing your child for a rapidly changing future.\n\nWarmly,\n[Name]\nFuture Ready Coordinator\n[School Name]\n\n*Refreshments will be provided*",
    type: "Email",
    category: "network"
  },
  
  // Skills Development
  {
    id: "skills-curiosity-1",
    title: "Nurturing Curiosity at Home",
    preview: "Guidance for parents on encouraging curiosity",
    content: "🧠 FUTURE READY FAMILY TIP: NURTURING CURIOSITY 🧠\n\nDid you know? Curiosity is the foundation of lifelong learning and a predictor of academic success.\n\n💡 HOW TO FUEL YOUR CHILD'S CURIOSITY 💡\n\n1️⃣ When your child asks questions, resist giving immediate answers. Instead try:\n   \"What do you think?\" or \"How could we find out?\"\n\n2️⃣ Wonder aloud: \"I wonder why the sky changes color at sunset\" or \"I wonder how they build bridges over water.\"\n\n3️⃣ Create a \"Question Wall\" at home: a space where family members can post questions they're curious about, then research answers together.\n\n4️⃣ Follow their interests: Whether it's dinosaurs, space, or cooking, dive deeper into topics they're naturally drawn to.\n\n5️⃣ Replace \"Because I said so\" with \"Let's find out why\" when possible.\n\nTRY THIS WEEKEND: Pick one ordinary object in your home and challenge everyone to come up with unusual questions about it. Example: \"How is a pencil made?\" or \"Why are most refrigerators white?\"\n\nPraising curiosity is as important as praising achievement! When your child asks thoughtful questions, let them know you value their inquisitive mind.\n\n#FutureReadySkills #Curiosity #ParentingTips",
    type: "WhatsApp/Email",
    category: "skills"
  },
  {
    id: "skills-adaptability-1",
    title: "Building Adaptability in Children",
    preview: "Tips for helping children develop adaptability",
    content: "🌈 FUTURE READY SKILL SPOTLIGHT: ADAPTABILITY 🌈\n\nIn a world changing faster than ever, adaptability may be our children's greatest asset.\n\n\"The ability to adapt to change will be more valuable than expertise in a single area.\"\n\nHow to nurture adaptability at home:\n\n1️⃣ Embrace small changes in routines occasionally. Having breakfast for dinner or rearranging furniture builds flexibility.\n\n2️⃣ Respond positively to unexpected situations: \"This is a surprise! Let's figure out how to adapt our plans.\"\n\n3️⃣ Encourage trying new things—foods, activities, routes to familiar places. Celebrate the attempt, not just success.\n\n4️⃣ Share age-appropriate stories of how you've adapted to changes in your own life.\n\n5️⃣ When plans change, model positive adaptation rather than frustration.\n\nQuick Activity: This weekend, introduce a small, unexpected change to a family routine. Afterward, discuss how everyone felt and adapted.\n\nRemember: Children who learn to say \"I can adjust\" rather than \"I can't handle change\" develop resilience that serves them throughout life.\n\nWhat small change might you introduce this week to build this muscle?\n\n#FutureReadySkills #Adaptability #RaisingResilientKids",
    type: "WhatsApp/Email",
    category: "skills"
  },
  {
    id: "skills-digital-1",
    title: "Digital Literacy for Parents",
    preview: "Guide to help parents support healthy digital skills",
    content: "📱 FUTURE READY FOCUS: DIGITAL LITERACY 📱\n\nDear Parents,\n\nDigital literacy isn't just about using technology—it's about using it wisely, critically, and safely. Here's how you can guide your child:\n\n𝟭. 𝗠𝗼𝗱𝗲𝗹 𝗚𝗼𝗼𝗱 𝗗𝗶𝗴𝗶𝘁𝗮𝗹 𝗛𝗮𝗯𝗶𝘁𝘀\n• Show how you verify information before believing or sharing it\n• Demonstrate healthy breaks from screens\n• Let them see you learning new skills online\n\n𝟮. 𝗕𝘂𝗶𝗹𝗱 𝗖𝗿𝗶𝘁𝗶𝗰𝗮𝗹 𝗧𝗵𝗶𝗻𝗸𝗶𝗻𝗴\n• When they find information online, ask: \"How do we know this is reliable?\"\n• Help them recognize ads, sponsored content, and potential bias\n• Encourage comparing multiple sources\n\n𝟯. 𝗦𝘁𝗿𝗲𝗻𝗴𝘁𝗵𝗲𝗻 𝗦𝗮𝗳𝗲𝘁𝘆 𝗦𝗸𝗶𝗹𝗹𝘀\n• Discuss privacy settings together\n• Create clear family guidelines about what's appropriate to share\n• Maintain open communication about online interactions\n\n𝟰. 𝗘𝗻𝗰𝗼𝘂𝗿𝗮𝗴𝗲 𝗖𝗿𝗲𝗮𝘁𝗶𝘃𝗲 𝗨𝘀𝗲𝘀\n• Digital tools aren't just for consuming content—they're for creating\n• Support using technology for projects, learning, and creative expression\n• Help them find age-appropriate online learning resources\n\nRemember: The goal isn't to limit technology but to build thoughtful digital citizens who can navigate online spaces safely and productively.\n\nQuick Activity: Choose an interesting news story and search for it together on different websites. Compare how it's presented and discuss any differences you notice.\n\n#DigitalLiteracy #FutureReadySkills #ParentingTips",
    type: "Email/Newsletter",
    category: "skills"
  },
  {
    id: "skills-financial-1",
    title: "Age-Appropriate Financial Literacy",
    preview: "Guidelines for teaching financial literacy by age group",
    content: "💰 BUILDING FINANCIAL LITERACY AT HOME 💰\n\nDear Parents,\n\nFinancial literacy is a critical life skill that's best developed early. Here are age-appropriate strategies for different stages:\n\n𝗔𝗴𝗲𝘀 𝟱-𝟴:\n• Use a clear piggy bank so they can see money accumulating\n• Play store at home to practice simple transactions\n• Introduce the concept of saving for something special\n• Use everyday shopping trips to discuss basic choices and trade-offs\n\n𝗔𝗴𝗲𝘀 𝟵-𝟭𝟮:\n• Consider providing a small regular allowance with guidelines for saving, spending, and sharing\n• Help them open a savings account and track balances\n• Introduce comparison shopping and finding better deals\n• Discuss the difference between needs and wants\n• Begin explaining what bills your family pays regularly\n\n𝗔𝗴𝗲𝘀 𝟭𝟯-𝟭𝟱:\n• Involve them in some family financial discussions (e.g., planning a vacation budget)\n• Discuss how advertising tries to influence spending decisions\n• Introduce the concept of compound interest and why starting to save early matters\n• Help them set and work toward medium-term financial goals\n\n𝗔𝗴𝗲𝘀 𝟭𝟲+:\n• Discuss education costs and how to evaluate ROI (return on investment)\n• Explain credit, debt, and interest rates before they encounter credit card offers\n• Involve them in researching large purchases\n• Discuss how income connects to lifestyle choices and long-term planning\n• Share age-appropriate information about family financial decisions and planning\n\nWeekend Challenge: Have a conversation about money that's appropriate for your child's age. Normalize talking about financial concepts in a positive, educational way.\n\nRemember, our goal is to raise financially confident children who understand money as a tool, not a taboo subject.\n\n#FinancialLiteracy #FutureReadySkills #ParentingTips",
    type: "Email/Newsletter",
    category: "skills"
  }
];
