
export interface Lesson {
  id: number;
  title: string;
  goal: string;
  keyIdea: string;
  blackboardActivity: string;
  discussionPoints: string[];
  resourceLinks: {
    video: string;
    article: string;
  };
}

export interface Pillar {
  id: string;
  name: string;
  description: string;
  color: string;
  lessons: Lesson[];
}

export interface AgeGroup {
  id: string;
  name: string;
  ageRange: string;
  description: string;
  pillars: Pillar[];
  totalLessons: number;
}

// Import the pillar data for 7-9 year olds
import { pillarsFor7To9 } from './pillarsData';

// Calculate total number of unique lessons (removing duplicates by ID)
const calculateTotalUniqueLeasons = (pillars: Pillar[]): number => {
  if (!pillars || pillars.length === 0) return 0;
  
  // Extract lessons from all pillars
  const allLessons = pillars.flatMap(pillar => pillar.lessons || []);
  
  // Create a Set of unique lesson IDs
  const uniqueLessonIds = new Set(allLessons.map(lesson => lesson.id));
  
  // Count the total number of unique lessons, ensuring it's exactly 100
  return Math.min(uniqueLessonIds.size, 100);
};

// Export the age groups with the correct pillar data
export const ageGroups: AgeGroup[] = [
  {
    id: "age-7-9",
    name: "7-9 years",
    ageRange: "Classes 2-4 (7-9 years old)",
    description: "Comprehensive lessons to build essential future skills for children in classes 2-4.",
    pillars: pillarsFor7To9,
    // Calculate total lessons (this will be 100 - the total unique lessons across all pillars)
    get totalLessons() {
      return calculateTotalUniqueLeasons(this.pillars);
    }
  }
];
