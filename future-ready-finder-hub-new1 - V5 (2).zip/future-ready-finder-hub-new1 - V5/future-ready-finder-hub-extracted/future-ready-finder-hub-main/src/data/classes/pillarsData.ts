
import { Pillar } from './ageGroups';
import { emotionalIntelligenceLessons } from './lessonData/emotionalIntelligenceLessons';
import { socialSkillsLessons } from './lessonData/socialSkillsLessons';
import { healthSafetyLessons } from './lessonData/healthSafetyLessons';
import { learningThinkingLessons } from './lessonData/learningThinkingLessons';
import { basicLifeSkillsLessons } from './lessonData/basicLifeSkillsLessons';
import { communityAwarenessLessons } from './lessonData/communityAwarenessLessons';
import { criticalThinkingLessons } from './lessonData/criticalThinkingLessons';
import { creativityLessons } from './lessonData/creativityLessons';
import { collaborationLessons } from './lessonData/collaborationLessons';
import { communicationLessons } from './lessonData/communicationLessons';
import { adaptabilityLessons } from './lessonData/adaptabilityLessons';

// Helper function to ensure we have exactly the first 100 unique lessons
const getUniqueOrderedLessons = () => {
  const allLessons = [
    ...emotionalIntelligenceLessons, 
    ...socialSkillsLessons, 
    ...healthSafetyLessons, 
    ...learningThinkingLessons, 
    ...basicLifeSkillsLessons, 
    ...communityAwarenessLessons,
    ...criticalThinkingLessons,
    ...creativityLessons,
    ...collaborationLessons,
    ...communicationLessons,
    ...adaptabilityLessons
  ];
  
  // Remove duplicates by ID
  const uniqueLessonsMap = new Map();
  allLessons.forEach(lesson => {
    uniqueLessonsMap.set(lesson.id, lesson);
  });
  
  // Convert to array and sort by ID
  const uniqueOrderedLessons = Array.from(uniqueLessonsMap.values())
    .sort((a, b) => a.id - b.id);
  
  // Return exactly 100 lessons
  return uniqueOrderedLessons.slice(0, 100);
};

const uniqueOrderedLessons = getUniqueOrderedLessons();

export const pillarsFor7To9: Pillar[] = [
  {
    id: "all-lessons",
    name: "All Lessons",
    description: "View all lessons in numerical order",
    color: "bg-gray-500",
    lessons: uniqueOrderedLessons
  },
  {
    id: "emotional-intelligence",
    name: "Emotional Intelligence & Self-Awareness",
    color: "bg-pink-500",
    description: "Understanding and managing emotions, developing self-awareness, and expressing feelings appropriately.",
    lessons: emotionalIntelligenceLessons
  },
  {
    id: "social-skills",
    name: "Social Skills & Relationships",
    color: "bg-purple-500",
    description: "Building positive relationships, developing social skills, and learning to interact effectively with others.",
    lessons: socialSkillsLessons
  },
  {
    id: "health-safety",
    name: "Health & Safety",
    color: "bg-green-500",
    description: "Understanding personal health, safety practices, and maintaining physical well-being.",
    lessons: healthSafetyLessons
  },
  {
    id: "learning-thinking",
    name: "Learning, Thinking & Problem Solving",
    color: "bg-blue-500",
    description: "Developing critical thinking, problem-solving skills, and effective learning strategies.",
    lessons: learningThinkingLessons
  },
  {
    id: "basic-life-skills",
    name: "Basic Life Skills & Responsibility",
    color: "bg-yellow-500",
    description: "Learning essential life skills, responsibility, and basic financial concepts.",
    lessons: basicLifeSkillsLessons
  },
  {
    id: "community-awareness",
    name: "Community & World Awareness",
    color: "bg-orange-500",
    description: "Understanding community roles, diversity, and developing awareness of the world around us.",
    lessons: communityAwarenessLessons
  },
  {
    id: "critical-thinking",
    name: "Critical Thinking",
    color: "bg-indigo-500",
    description: "Developing analytical skills, reasoning, and questioning abilities.",
    lessons: criticalThinkingLessons
  },
  {
    id: "creativity",
    name: "Creativity & Innovation",
    color: "bg-red-500",
    description: "Fostering imagination, creative expression, and innovative thinking.",
    lessons: creativityLessons
  },
  {
    id: "collaboration",
    name: "Collaboration & Teamwork",
    color: "bg-emerald-500",
    description: "Building skills for working effectively with others in groups and teams.",
    lessons: collaborationLessons
  },
  {
    id: "communication",
    name: "Communication Skills",
    color: "bg-cyan-500",
    description: "Developing effective verbal, non-verbal, and written communication abilities.",
    lessons: communicationLessons
  },
  {
    id: "adaptability",
    name: "Adaptability & Resilience",
    color: "bg-amber-500",
    description: "Learning to handle change, overcome challenges, and develop flexibility.",
    lessons: adaptabilityLessons
  }
];
