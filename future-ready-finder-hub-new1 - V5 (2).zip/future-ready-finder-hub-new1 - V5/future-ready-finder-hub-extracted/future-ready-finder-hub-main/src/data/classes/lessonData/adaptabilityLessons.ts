
import { Lesson } from '../ageGroups';

export const adaptabilityLessons: Lesson[] = [
  {
    id: 36,
    title: "Embracing Change",
    goal: "Students will develop a positive attitude toward change and transitions.",
    keyIdea: "Changes are a normal part of life. Looking for opportunities in changes helps us adapt and grow.",
    blackboardActivity: "Create a 'Changes in My Life' timeline where students identify past changes and how they adapted. Discuss upcoming changes and strategies to handle them.",
    discussionPoints: [
      "What are some changes you've experienced? How did you feel?",
      "Why do changes sometimes feel scary or difficult?",
      "What helps you adjust to new situations?",
      "How can changes help us learn and grow?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Dealing with change for kids\"",
      article: "Search for \"Helping elementary students cope with change\""
    }
  },
  {
    id: 37,
    title: "Plan B Thinking",
    goal: "Students will practice flexibility when plans change and develop alternative solutions.",
    keyIdea: "Things don't always go as planned, and that's okay! Having backup plans and being able to adjust helps us handle surprises.",
    blackboardActivity: "Present scenarios where original plans can't work (rain cancels outdoor activity, material for project unavailable, etc.). Have students develop Plan B solutions.",
    discussionPoints: [
      "What happens when plans change unexpectedly?",
      "How does it feel when things don't go as planned?",
      "Why is it helpful to have backup plans?",
      "What's a time when you had to change plans but things still turned out well?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Flexibility for kids\" or \"Adapting to change\"",
      article: "Search for \"Teaching flexible thinking to children\""
    }
  },
  {
    id: 38,
    title: "Trying New Things",
    goal: "Students will develop courage to step outside their comfort zones and try new experiences.",
    keyIdea: "Trying new things can feel scary, but it helps us discover talents, interests, and friends we might otherwise miss.",
    blackboardActivity: "Create a class 'New Things We've Tried' chart with columns for the activity, feelings before, feelings after, and what was learned.",
    discussionPoints: [
      "Why can trying new things feel scary?",
      "What new thing have you tried that you ended up enjoying?",
      "How can we build courage to try something unfamiliar?",
      "Why is it worth trying things even if we might not be good at them at first?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Growth mindset for kids\" or \"Trying new things\"",
      article: "Search for \"Encouraging risk-taking in elementary students\""
    }
  },
  {
    id: 39,
    title: "Bouncing Back",
    goal: "Students will develop resilience and strategies to recover from setbacks.",
    keyIdea: "Everyone faces disappointments and failures. Resilient people find ways to bounce back and keep going.",
    blackboardActivity: "Share age-appropriate examples of famous failures that led to eventual success. Create a 'Bounce Back Plan' template for responding to setbacks.",
    discussionPoints: [
      "What does it mean to be resilient?",
      "How does it feel when something doesn't work out the way you hoped?",
      "What helps you feel better after a disappointment?",
      "Why is it important to try again after making a mistake or facing a setback?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Resilience for kids\" or \"Bouncing back from failure\"",
      article: "Search for \"Building resilience in elementary students\""
    }
  },
  {
    id: 40,
    title: "Different Ways to Learn",
    goal: "Students will explore various learning styles and strategies to adapt their approach when one method isn't working.",
    keyIdea: "People learn in different ways. When one approach doesn't work, trying another way can help us understand.",
    blackboardActivity: "Teach a simple concept using multiple methods (visual, auditory, hands-on). Have students identify which approach works best for them and try using a different approach than usual.",
    discussionPoints: [
      "What helps you learn best? Seeing, hearing, doing, or a combination?",
      "Why might different people learn better in different ways?",
      "What can you do if you're having trouble understanding something?",
      "Why is it helpful to try different ways of learning?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Learning styles for kids\"",
      article: "Search for \"Multiple intelligences elementary classroom\""
    }
  },
  {
    id: 41,
    title: "Problem-Solving Toolkit",
    goal: "Students will develop a variety of strategies for approaching problems.",
    keyIdea: "Having different strategies for solving problems is like having a toolkit. If one tool doesn't work, you can try another.",
    blackboardActivity: "Create a class 'Problem-Solving Toolkit' with different strategies (break it down, look for patterns, work backward, etc.). Apply different strategies to sample problems.",
    discussionPoints: [
      "What are different ways to approach a problem?",
      "How do you know when to try a different strategy?",
      "Why is having multiple strategies helpful?",
      "What problem-solving strategies work best for you?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Problem-solving strategies for kids\"",
      article: "Search for \"Teaching multiple problem-solving approaches elementary\""
    }
  },
  {
    id: 42,
    title: "Working with Different People",
    goal: "Students will develop skills for adapting to different personalities, working styles, and expectations.",
    keyIdea: "Throughout life, we need to work with many different people. Adapting our communication and approach helps build successful relationships.",
    blackboardActivity: "Role-play scenarios working with different types of partners/teachers with varying styles. Discuss strategies for adapting approach.",
    discussionPoints: [
      "How can you work well with someone who has a very different personality from yours?",
      "Why might some people prefer different ways of doing things?",
      "How can understanding someone else's preferences help you work better together?",
      "What skills help you adapt to working with new people?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Getting along with different people kids\"",
      article: "Search for \"Teaching interpersonal adaptability elementary\""
    }
  }
];
