
import { Lesson } from '../ageGroups';

export const criticalThinkingLessons: Lesson[] = [
  {
    id: 8,
    title: "Question Everything",
    goal: "Students will develop the habit of asking thoughtful questions to deepen understanding.",
    keyIdea: "Good thinkers ask questions. Questions help us learn more and understand better.",
    blackboardActivity: "Show an unusual object and model different types of questions: what, why, how, what if. Have students practice generating their own questions.",
    discussionPoints: [
      "What makes a question good or helpful?",
      "Why is it important to ask questions?",
      "What kinds of questions help us learn the most?",
      "What should you do when you don't understand something?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Asking questions for kids\" or \"Inquiry-based learning\"",
      article: "Search for \"Developing questioning skills in children\""
    }
  },
  {
    id: 9,
    title: "Spot the Difference",
    goal: "Students will strengthen observation skills and learn to notice details.",
    keyIdea: "Careful observers notice small details that others might miss. This helps solve problems and understand the world better.",
    blackboardActivity: "Show pairs of similar images and challenge students to find the differences. Progress to more complex observation tasks.",
    discussionPoints: [
      "Why is it important to pay attention to details?",
      "What helps you notice things that others might miss?",
      "How can being observant help you in school and life?",
      "When is a time that noticing a detail helped you solve a problem?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Observation skills for kids\"",
      article: "Search for \"Developing observational skills in children\""
    }
  },
  {
    id: 12,
    title: "Fact or Opinion?",
    goal: "Students will distinguish between facts (which can be proven) and opinions (personal beliefs).",
    keyIdea: "Facts can be proven true or false, while opinions are what someone thinks or feels. Both are important but different.",
    blackboardActivity: "Create a T-chart labeled 'Facts' and 'Opinions'. Present statements and have students decide where each belongs.",
    discussionPoints: [
      "What's the difference between a fact and an opinion?",
      "Why is it important to know when something is a fact or an opinion?",
      "Can facts change over time? How?",
      "Is it okay for people to have different opinions?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Fact vs opinion for kids\"",
      article: "Search for \"Teaching fact and opinion in elementary\""
    }
  },
  {
    id: 13,
    title: "Solving Mysteries",
    goal: "Students will gather and analyze clues to solve problems.",
    keyIdea: "Detectives solve mysteries by gathering clues, thinking carefully, and testing their ideas.",
    blackboardActivity: "Present a classroom 'mystery' with clues for students to solve. Guide them through gathering evidence, eliminating possibilities, and drawing conclusions.",
    discussionPoints: [
      "What makes a good detective?",
      "How can we use clues to solve problems?",
      "Why is it important to consider all the evidence?",
      "When have you had to solve a problem like a detective?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Mystery solving for kids\"",
      article: "Search for \"Problem-solving activities for elementary\""
    }
  },
  {
    id: 14,
    title: "Cause and Effect",
    goal: "Students will identify relationships between events and understand how one action can lead to another.",
    keyIdea: "When something happens (cause), it makes other things happen (effect). Understanding these connections helps us make better choices.",
    blackboardActivity: "Draw a simple cause-effect chart. Provide scenarios and have students identify causes and resulting effects.",
    discussionPoints: [
      "What happens when you forget to water a plant?",
      "How can one person's actions affect others?",
      "Why is it important to think about what might happen before we make decisions?",
      "Can you think of a time when something you did caused an unexpected effect?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Cause and effect for kids\"",
      article: "Search for \"Teaching cause and effect to elementary students\""
    }
  },
  {
    id: 19,
    title: "Solving Simple Problems",
    goal: "Students will learn very simple steps to think about solving a problem.",
    keyIdea: "Sometimes things don't go right – maybe two friends want the same toy, or you can't reach something. That's a problem! Solving a problem is like being a detective. First, you have to figure out: What is the problem? (Step 1: Stop and Think). Then, you brainstorm ideas: What are some things I could do? (Step 2: Think of Ideas). Next, you choose the best idea and try it! (Step 3: Try an Idea). Thinking step-by-step helps find good solutions.",
    blackboardActivity: "Draw three boxes labeled: 1. STOP & THINK (What's the problem?), 2. IDEAS (What can I do?), 3. TRY IT! Present a simple problem: \"Two kids want the same red crayon.\" Ask: Step 1? (Problem: Both want red crayon). Step 2? (Ideas: Take turns, find another red crayon, use a different color, draw together). Step 3? (Choose one idea, e.g., taking turns).",
    discussionPoints: [
      "Can you think of a small problem you solved recently?",
      "Why is it good to stop and think before acting when there's a problem?",
      "Is it okay if your first idea doesn't work? What can you do? (Try another idea!).",
      "When might you need help from a grown-up to solve a problem? (If it's big, unsafe, or involves hurt feelings)."
    ],
    resourceLinks: {
      video: "Search YouTube for \"Problem solving steps for kids video\" or \"Sesame Street problem solving scenarios\".",
      article: "Search for \"Teaching problem solving skills to young children\" or \"Simple problem solving activities kids\"."
    }
  },
  {
    id: 84,
    title: "Thinking Skill - Sequencing Events (First, Next, Last)",
    goal: "Students will practice putting simple events or steps in the correct order.",
    keyIdea: "Lots of things happen in a certain order, like steps in a recipe or events in a story. Sequencing means putting things in the right order – what happened first, what came next, and what was last. Understanding the sequence helps us understand stories, follow instructions, and know how things work. Let's practice putting things in order!",
    blackboardActivity: "Write \"SEQUENCING - First, Next, Last\". Draw three simple pictures out of order for a common activity (e.g., Brushing teeth: 1. Toothbrush with paste, 2. Rinsing mouth, 3. Brushing teeth). Ask students: \"What do you do first?\" (Put paste on brush). \"What do you do next?\" (Brush). \"What do you do last?\" (Rinse). Number the pictures 1, 2, 3 in the correct sequence. Try another sequence (e.g., Getting dressed: Socks, Shoes, Tying laces).",
    discussionPoints: [
      "Why is the order important when following instructions or telling a story? (Makes sense, leads to the right result).",
      "Can you think of a story? What happened first, next, last? (Use a very familiar simple story).",
      "What sequence of events happens in the morning to get ready for school? (Wake up, brush teeth, eat breakfast, get dressed, etc.)."
    ],
    resourceLinks: {
      video: "Search YouTube for \"Sequencing events song for kids\" or \"First next last story sequencing video\".",
      article: "Search for \"Sequencing activities for kids printable\" or \"Picture sequencing worksheets\"."
    }
  },
  {
    id: 94,
    title: "Thinking Skill - Cause and Effect",
    goal: "Students will practice identifying simple cause-and-effect relationships.",
    keyIdea: "Cause and effect is like asking 'What happened?' (the effect) and 'Why did it happen?' (the cause). One thing makes another thing happen. For example: The CAUSE is 'It started raining heavily.' The EFFECT is 'We got wet' or 'We used an umbrella.' Understanding cause and effect helps us figure out how things work and predict what might happen next.",
    blackboardActivity: "Write 'CAUSE (Why it happened)' -> 'EFFECT (What happened)'. Give simple examples and ask students to identify cause and effect: 'I studied hard (Cause) -> I did well on the test (Effect).' 'The plant didn't get water (Cause) -> The plant wilted (Effect).' 'I dropped the glass (Cause) -> The glass broke (Effect).' 'I was kind to my friend (Cause) -> My friend smiled (Effect).'",
    discussionPoints: [
      "Can one cause have more than one effect? (Yes, rain -> get wet AND plants grow)",
      "Can one effect have more than one cause? (Yes, glass broke -> dropped it OR threw it)",
      "How does thinking about cause and effect help us make good choices? (We think about what might happen because of our actions)"
    ],
    resourceLinks: {
      video: "Search YouTube for 'Cause and effect song for kids' or 'Simple cause and effect examples kids video'",
      article: "Search for 'Cause and effect worksheets elementary' or 'Simple cause effect matching games'"
    }
  }
];
