
import { Lesson } from '../ageGroups';

export const emotionalIntelligenceLessons: Lesson[] = [
  {
    id: 1,
    title: "Understanding Feelings - Happy",
    goal: "Students will understand what the feeling 'happy' means and identify things that make them feel happy.",
    keyIdea: "Feelings are like visitors that come inside us. Sometimes a visitor named 'Happy' comes! Imagine Happy is like sunshine inside you. It makes you feel warm, light, and smiley. It visits when something good happens, like when you play your favorite game, get a hug from someone you love, eat yummy food, or learn something new and exciting. Feeling happy makes you want to smile, laugh, or even jump around! It's a wonderful feeling, and everyone feels happy sometimes.",
    blackboardActivity: "Draw a large smiley face :) on the board. Write \"HAPPY\" above it. Ask students: \"What things make YOU feel happy?\" As students share ideas (e.g., playing with friends, getting a gift, seeing a puppy, eating ice cream, a sunny day), write simple words or draw small pictures representing their answers inside the big smiley face circle.",
    discussionPoints: [
      "What does your face look like when you are happy? (Ask students to show their happy faces).",
      "What does your body feel like when you are happy? (Light? Bouncy? Warm?)",
      "What can you do to help someone else feel happy? (Share a toy? Give a smile? Say something kind?)"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Sesame Street: Name That Emotion Game\" or \"Simple feelings song for kids happy\".",
      article: "Search for \"PBS Kids What is happiness for kids\" or \"Simple happiness activity printable kids\"."
    }
  },
  {
    id: 2,
    title: "Understanding Feelings - Sad",
    goal: "Students will understand what the feeling 'sad' means and learn it's okay to feel sad sometimes.",
    keyIdea: "Sometimes, a different visitor named 'Sad' comes to see us. Feeling sad is like having a little rain cloud inside you. It might make you feel heavy, quiet, or like you want to cry. Sadness often visits when something upsetting happens, like if you miss someone, lose a toy, or get hurt. It's okay to feel sad; everyone does sometimes. It's just another feeling passing through.",
    blackboardActivity: "Draw a large sad face :( on the board. Write \"SAD\" above it. Ask students: \"What things can make someone feel sad?\" (e.g., falling down, losing a game, friend moving away, not feeling well). Write or draw simple representations inside the sad face circle.",
    discussionPoints: [
      "What does your face look like when you are sad?",
      "What does your body feel like when you are sad? (Heavy? Tired? Watery eyes?)",
      "What can make you feel a little better when you are sad? (A hug? Talking to someone? Drawing? Resting?)",
      "Is it okay to cry when you feel sad? (Yes, it's a way our body lets the sadness out)."
    ],
    resourceLinks: {
      video: "Search YouTube for \"Daniel Tiger feeling sad song\" or \"Sesame Street it's okay to be sad\".",
      article: "Search for \"Helping kids cope with sadness PBS Kids\" or \"Activities for kids feeling sad\"."
    }
  },
  {
    id: 3,
    title: "Trying New Things (Curiosity)",
    goal: "Students will understand that trying new things can be fun and helps them learn.",
    keyIdea: "Trying something new is like opening a surprise box! You don't know exactly what's inside – maybe a new game, a new food, or learning a new skill. It might feel a little scary at first, like standing at the edge of a puddle before jumping in. But being curious and trying it anyway is how we discover new things we like and learn cool stuff about the world and ourselves. It's like going on a mini-adventure!",
    blackboardActivity: "Draw a large question mark (?) and next to it, an open box with stars and sparkles coming out. Write \"TRYING NEW THINGS\" above. Ask students: \"What's something new you tried recently?\" (e.g., a new food, a different game, talking to a new classmate). Write simple answers around the box. Ask: \"What's something new you might like to try?\"",
    discussionPoints: [
      "How does it feel before you try something new? (Excited? Nervous? Curious?)",
      "How does it feel after you try something new, even if it was tricky? (Proud? Happy you tried?)",
      "What new things can we try at school or at home?",
      "Is it okay if you try something new and don't like it? (Yes! Trying is the important part)."
    ],
    resourceLinks: {
      video: "Search YouTube for \"Curiosity song for kids\" or \"Daniel Tiger trying new food\".",
      article: "Search for \"Encouraging curiosity in children activities\" or \"Benefits of trying new things for kids\"."
    }
  },
  {
    id: 11,
    title: "Understanding Feelings - Angry",
    goal: "Students will understand what the feeling 'angry' means and learn simple ways to handle it.",
    keyIdea: "Sometimes a visitor named 'Angry' comes. Feeling angry is like having a hot fire or a volcano inside you. It might make you feel tense, want to shout, or stomp your feet. Anger often visits when things feel unfair, someone breaks your things, or you can't do something you want. It's okay to feel angry, but it's not okay to hurt others or break things. We need to learn safe ways to let the anger out, like taking deep breaths or talking about it.",
    blackboardActivity: "Draw a face with furrowed brows and a tight mouth >:-(. Write \"ANGRY\" above it. Ask students: \"What things can make someone feel angry?\" (e.g., someone taking their toy, not being allowed to play, losing a game unfairly). Write or draw simple representations. Draw a 'Stop' sign (octagon). Ask: \"What should we NOT do when angry?\" (Hit, kick, yell mean things, break things). Draw a 'Go' sign (circle). Ask: \"What CAN we do?\" (Take deep breaths, count to 10, walk away, talk to a grown-up, squeeze a pillow).",
    discussionPoints: [
      "What does your body feel like when you are angry? (Hot? Tight fists? Fast heartbeat?)",
      "Is it okay to feel angry? (Yes). Is it okay to hurt someone when angry? (No).",
      "Let's practice taking 3 deep breaths together.",
      "Who can you talk to when you feel angry?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Daniel Tiger when you feel so mad song\" or \"Sesame Street managing anger kids\".",
      article: "Search for \"Helping kids manage anger PBS Kids\" or \"Calm down strategies for kids printable\"."
    }
  },
  {
    id: 18,
    title: "Understanding Feelings - Scared",
    goal: "Students will understand what the feeling 'scared' or 'afraid' means and that it's okay to feel scared.",
    keyIdea: "Feeling scared is like having an alarm bell go off inside you. It happens when something seems dangerous, unknown, or startling, like a loud noise, the dark, or trying something high up. Your body might feel shaky, your heart might beat fast, or you might want to hide. Feeling scared is your body's way of saying 'Be careful!' It's okay to be scared sometimes; everyone feels it. Talking about your fears can help.",
    blackboardActivity: "Draw a face with wide eyes and an open mouth :O. Write \"SCARED / AFRAID\" above it. Ask students: \"What things can make someone feel scared?\" (e.g., loud thunder, dark room, big dog barking, nightmares, trying something new and high). Write or draw simple ideas.",
    discussionPoints: [
      "What does your body feel like when you are scared? (Shaky, fast heartbeat, butterflies in tummy?).",
      "Is it okay to feel scared? (Yes, it's a normal feeling).",
      "What can you do when you feel scared? (Take deep breaths, hold someone's hand, talk to a grown-up, turn on a light, think brave thoughts).",
      "Who can help you when you feel scared?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Daniel Tiger feeling scared song\" or \"Sesame Street coping with fears kids\".",
      article: "Search for \"Helping children overcome fears PBS Kids\" or \"What to do when your child is scared article\"."
    }
  }
];
