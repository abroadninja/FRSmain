
import { Lesson } from '../ageGroups';

export const communicationLessons: Lesson[] = [
  {
    id: 29,
    title: "Speak Up, Speak Clear",
    goal: "Students will practice expressing their ideas clearly and confidently.",
    keyIdea: "Clear communication helps others understand our ideas and needs. Speaking clearly and confidently helps get our message across.",
    blackboardActivity: "Play 'Describe and Draw' where one student describes an image while others try to draw it based on the description.",
    discussionPoints: [
      "What makes instructions easy or hard to follow?",
      "Why is it important to speak clearly and loudly enough?",
      "How can you check if someone understands what you're saying?",
      "What can make it difficult to share your ideas, and how can you overcome that?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Public speaking for kids\" or \"Clear communication skills\"",
      article: "Search for \"Building speaking confidence in elementary students\""
    }
  },
  {
    id: 30,
    title: "Body Language Basics",
    goal: "Students will understand and use non-verbal communication effectively.",
    keyIdea: "We communicate with our whole bodies, not just our words. Facial expressions, gestures, and posture send important messages.",
    blackboardActivity: "Play charades or emotion guessing games where students communicate without words.",
    discussionPoints: [
      "What messages can we send without using words?",
      "How can you tell how someone is feeling by looking at them?",
      "Why might body language and words sometimes tell different stories?",
      "How can paying attention to body language help us be better friends?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Body language for kids\" or \"Non-verbal communication\"",
      article: "Search for \"Teaching non-verbal communication elementary\""
    }
  },
  {
    id: 31,
    title: "The Art of Questions",
    goal: "Students will learn to ask effective questions to gather information and understand others better.",
    keyIdea: "Good questions help us learn new things and understand other people's ideas and feelings.",
    blackboardActivity: "Sort questions into different types (yes/no, open-ended, clarifying). Practice turning simple questions into more thoughtful ones.",
    discussionPoints: [
      "What makes a question effective or helpful?",
      "What's the difference between closed and open-ended questions?",
      "How can asking questions show that you're interested in someone?",
      "What questions could help you understand a complicated topic?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Asking good questions for kids\"",
      article: "Search for \"Teaching questioning skills to elementary students\""
    }
  },
  {
    id: 32,
    title: "Tell Me a Story",
    goal: "Students will develop narrative skills and learn to organize their thoughts in a logical sequence.",
    keyIdea: "Stories help us share experiences and ideas in interesting ways. Good stories have a clear beginning, middle, and end.",
    blackboardActivity: "Create a story sequence chart. Practice telling personal stories or creating fictional ones with clear structure.",
    discussionPoints: [
      "What makes a story interesting to listen to?",
      "Why is the order of events important in a story?",
      "How do storytellers keep their audience engaged?",
      "What are different types of stories people tell?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Storytelling for kids\"",
      article: "Search for \"Developing narrative skills in elementary\""
    }
  },
  {
    id: 33,
    title: "Just the Right Words",
    goal: "Students will expand their vocabulary and learn to choose precise words to express their ideas.",
    keyIdea: "Using specific, descriptive words helps others picture exactly what we mean and makes communication more interesting.",
    blackboardActivity: "Replace simple, overused words (nice, good, bad) with more specific alternatives. Create word banks for different topics.",
    discussionPoints: [
      "Why is it helpful to use specific words instead of general ones?",
      "How can having a bigger vocabulary help you express yourself?",
      "When might simpler words be better than complicated ones?",
      "How can you learn new words and remember them?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Vocabulary building for kids\"",
      article: "Search for \"Expanding elementary students' vocabulary\""
    }
  },
  {
    id: 34,
    title: "Persuasive Power",
    goal: "Students will learn basic techniques for persuasive communication.",
    keyIdea: "Persuasion means trying to convince others of your ideas using reasons and evidence, not just saying 'please'.",
    blackboardActivity: "Analyze simple advertisements to identify persuasive techniques. Practice making persuasive arguments for/against topics relevant to students.",
    discussionPoints: [
      "What makes an argument convincing?",
      "Why are reasons and examples important when trying to persuade someone?",
      "How can persuasion be used in positive ways?",
      "How can you tell when someone is trying to persuade you?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Persuasive speaking for kids\"",
      article: "Search for \"Teaching persuasive skills elementary\""
    }
  },
  {
    id: 35,
    title: "Digital Communication",
    goal: "Students will understand appropriate and effective ways to communicate using digital tools.",
    keyIdea: "Digital communication is different from face-to-face. We need special skills and rules to communicate clearly and safely online.",
    blackboardActivity: "Compare face-to-face and digital communication. Create a list of digital communication do's and don'ts.",
    discussionPoints: [
      "How is communicating online different from talking in person?",
      "Why is it sometimes hard to understand someone's tone in written messages?",
      "What information should you never share online?",
      "How can emoji and punctuation change the meaning of a message?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Digital citizenship for kids\" or \"Online communication safety\"",
      article: "Search for \"Teaching digital communication to elementary students\""
    }
  }
];
