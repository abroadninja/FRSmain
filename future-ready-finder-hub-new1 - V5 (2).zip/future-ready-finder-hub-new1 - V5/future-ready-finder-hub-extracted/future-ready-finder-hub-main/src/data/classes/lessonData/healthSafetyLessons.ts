
import { Lesson } from '../ageGroups';

export const healthSafetyLessons: Lesson[] = [
  {
    id: 7,
    title: "Healthy Habits - Washing Hands",
    goal: "Students will understand why and how to wash their hands properly to stay healthy.",
    keyIdea: "Our hands touch everything all day long, and sometimes they pick up tiny, invisible things called germs. Germs are like sneaky little troublemakers that can get inside our bodies and make us sick. Washing our hands with soap and water is like using superhero soap bubbles to fight off these germs! It washes them away down the drain, so they can't make us unwell. It's a super important way to keep ourselves and others healthy.",
    blackboardActivity: "Draw two hands under a running tap with lots of soap bubbles. Write \"WASH YOUR HANDS!\" Ask students: \"When should we wash our hands?\" (e.g., before eating, after using the toilet, after playing outside, after sneezing/coughing, after touching pets). List key times. Briefly draw/list steps: Wet -> Soap -> Rub (front, back, fingers, 20 secs - sing 'Happy Birthday' twice) -> Rinse -> Dry.",
    discussionPoints: [
      "Why can't we see germs? (They are too tiny).",
      "What happens if germs get inside us? (We might get a cold, tummy ache, etc.).",
      "Can we practice the handwashing steps together (using actions, no water)?",
      "What other things help us stay healthy? (Eating good food, sleeping, exercise)."
    ],
    resourceLinks: {
      video: "Search YouTube for \"Hand washing song for kids\" or \"Germs explained for kids video\".",
      article: "Search for \"Germ experiment for kids simple\" or \"Hand washing steps printable for kids\"."
    }
  },
  {
    id: 13,
    title: "Healthy Habits - Eating Vegetables",
    goal: "Students will understand that eating vegetables helps their bodies grow strong and stay healthy.",
    keyIdea: "Vegetables are like colorful superheroes for your body! Think of carrots helping your eyes see well, spinach making your muscles strong, and broccoli helping you fight off sickness. Eating different colored vegetables gives your body lots of special powers (vitamins and minerals) it needs to grow big, run fast, play hard, and stay healthy. They help keep your tummy happy and give you energy!",
    blackboardActivity: "Draw different simple, colorful vegetables (e.g., a green broccoli, an orange carrot, a red tomato, purple eggplant). Write \"EAT YOUR VEGGIES!\" Ask students: \"What vegetables do you know?\" or \"What vegetables do you like?\" List some names. Draw a stick figure with muscles 💪 next to the vegetables. Draw another stick figure looking energetic and happy.",
    discussionPoints: [
      "What colors of vegetables can you name?",
      "Why are vegetables good for our bodies? (Help us grow, give energy, keep us healthy).",
      "What's a vegetable you tried recently or would like to try?",
      "How can we make eating vegetables fun? (Dip them in something yummy? Cut into shapes?)"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Vegetable song for kids\" or \"Why are vegetables healthy for kids video\".",
      article: "Search for \"Fun ways to get kids to eat vegetables\" or \"Healthy eating activities for kids printable\"."
    }
  },
  {
    id: 17,
    title: "Healthy Habits - Getting Enough Sleep",
    goal: "Students will understand that getting enough sleep is important for their body and brain.",
    keyIdea: "Sleeping is like plugging your body and brain into a charger overnight! Just like a toy car needs charging to run well, you need sleep to have energy for the next day. When you sleep, your body rests, heals, and grows. Your brain sorts out all the things you learned and helps you remember them. Getting enough sleep helps you feel happy, think clearly, learn better at school, and have energy to play.",
    blackboardActivity: "Draw a moon and stars on one side, and a sun on the other. Draw a child sleeping peacefully under the moon/stars. Write \"SLEEP IS IMPORTANT\". Draw arrows pointing from the sleeping child to pictures representing benefits: a brain with a lightbulb (thinking), a running figure (energy), a smiling face (happy mood), a book (learning).",
    discussionPoints: [
      "How do you feel when you don't get enough sleep? (Tired, grumpy, hard to think).",
      "How do you feel after a good night's sleep? (Rested, energetic, happy).",
      "What helps you get ready for sleep? (Quiet time, reading a book, brushing teeth, dim lights).",
      "Why is it important to have a regular bedtime?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Importance of sleep for kids video\" or \"Bedtime routine song for kids\".",
      article: "Search for \"Why kids need sleep article\" or \"Healthy sleep habits for children tips\"."
    }
  }
];
