
import { Lesson } from '../ageGroups';

export const socialSkillsLessons: Lesson[] = [
  {
    id: 4,
    title: "Being Kind",
    goal: "Students will understand what kindness means and identify simple ways to be kind to others.",
    keyIdea: "Kindness is like giving someone a warm, invisible hug with your words or actions. It's about being friendly, caring, and helpful towards others. When you share your toys, say something nice, help someone who dropped their books, or even just give a smile, you're being kind. Kindness makes others feel good, and it makes you feel good inside too, like spreading sunshine.",
    blackboardActivity: "Draw a large heart ♡ on the board. Write \"KINDNESS\" inside it. Ask students: \"What are some ways we can show kindness?\" As students share ideas (e.g., sharing, helping, saying please/thank you, smiling, listening, including others), write these kind actions inside or around the heart.",
    discussionPoints: [
      "How does it feel when someone is kind to you?",
      "How does it feel when you are kind to someone else?",
      "Can you be kind to animals? How?",
      "Can you be kind to yourself? How? (e.g., resting when tired, thinking nice thoughts about yourself)."
    ],
    resourceLinks: {
      video: "Search YouTube for \"Kindness is a muscle song\" or \"Sesame Street kindness song\".",
      article: "Search for \"Kindness activities for young children\" or \"Teaching empathy and kindness kids\"."
    }
  },
  {
    id: 8,
    title: "Working Together (Teamwork)",
    goal: "Students will understand the benefits of working together as a team.",
    keyIdea: "Working together, or teamwork, is like building something cool with friends. Imagine building a big tower with blocks – if one person does it, it might be small. But if many friends work together, adding blocks carefully, you can build a huge, amazing tower! Teamwork means sharing ideas, helping each other, listening to everyone, and working towards the same goal. It makes big tasks easier and often more fun!",
    blackboardActivity: "Draw several stick figures holding hands or working together to build something (like a block tower or drawing a picture). Write \"TEAMWORK\" above. Ask students: \"When do we work together in class or during play?\" (e.g., group projects, playing team games, cleaning up together). List examples.",
    discussionPoints: [
      "Why is teamwork sometimes better than working alone? (Share ideas, faster, more fun, help each other).",
      "What makes a good team player? (Sharing, listening, helping, being kind, doing your part).",
      "What can be tricky about teamwork? (Disagreeing, someone not helping). How can we solve that? (Talk about it, find a compromise)."
    ],
    resourceLinks: {
      video: "Search YouTube for \"Teamwork song for kids\" or \"Sesame Street teamwork compilation\".",
      article: "Search for \"Simple teamwork activities for classroom\" or \"Benefits of teamwork for children\"."
    }
  },
  {
    id: 9,
    title: "Asking for Help",
    goal: "Students will understand that it's okay and important to ask for help when needed.",
    keyIdea: "Sometimes, we get stuck on something, like trying to tie shoelaces, understanding a tricky word, or reaching something high up. Trying to figure it out alone is good, but if you're really stuck, asking for help is like using a special key to unlock the problem! It's not a sign of being weak; it's actually very smart! Grown-ups and friends are often happy to help. Asking for help lets you learn and get unstuck faster.",
    blackboardActivity: "Draw a stick figure with a raised hand and a question mark (?) above its head. Write \"ASKING FOR HELP IS OKAY!\" Ask students: \"Who can you ask for help at school?\" (Teacher, friends, other staff). \"Who can you ask for help at home?\" (Parents, older siblings, relatives). List the people.",
    discussionPoints: [
      "When might you need to ask for help? (Can't do something, don't understand, feel unsafe, hurt yourself).",
      "How does it feel to ask for help? (Sometimes shy, but usually good afterwards).",
      "How can you ask politely? (\"Excuse me, can you please help me with...\" or \"I don't understand, can you explain?\").",
      "Is it okay if the person you ask can't help right away? (Yes, they might be busy, you can ask again later or ask someone else)."
    ],
    resourceLinks: {
      video: "Search YouTube for \"It's okay to ask for help song kids\" or \"Daniel Tiger asking for help\".",
      article: "Search for \"Teaching kids how to ask for help article\" or \"Role playing asking for help scenarios kids\"."
    }
  },
  {
    id: 12,
    title: "Sharing and Taking Turns",
    goal: "Students will understand why sharing and taking turns is important for playing well with others.",
    keyIdea: "Sharing is like letting someone else have a little bit of fun with something you have, like a toy or crayons. Taking turns is like saying, 'My turn now, your turn next!' Imagine playing on a swing – only one person can swing at a time. Taking turns means everyone gets a chance. Sharing and taking turns helps everyone feel included, makes playtime more fun, and shows kindness and fairness.",
    blackboardActivity: "Draw two stick figures. One has a ball, the other looks sad. Then draw an arrow showing the ball being passed. Now both figures are smiling. Write \"SHARING\". Draw a simple game board (like snakes and ladders) with two game pieces, one ahead of the other. Write \"TAKING TURNS\". Ask: \"Why is sharing good?\" (Makes friends happy, more fun together). \"Why is taking turns important?\" (Fair, everyone gets a chance).",
    discussionPoints: [
      "How does it feel when someone shares with you?",
      "How does it feel when you share with someone?",
      "Is it always easy to share or take turns? Why or why not?",
      "What can you say to ask for a turn politely? (\"Can I have a turn please?\")",
      "What can you say when you are ready to give a turn? (\"Your turn now!\")"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Sharing song for kids\" or \"Daniel Tiger sharing and taking turns\".",
      article: "Search for \"Teaching kids about sharing activities\" or \"Importance of taking turns social skills\"."
    }
  },
  {
    id: 20,
    title: "Respecting Others",
    goal: "Students will understand what it means to treat others with respect.",
    keyIdea: "Respect is like treating others the way you want to be treated. It means thinking about their feelings, listening when they talk (even if you disagree), using kind words ('please', 'thank you'), not interrupting, and being careful with their things. Respecting others means valuing them, even if they are different from you. It helps everyone feel safe, happy, and important.",
    blackboardActivity: "Draw two stick figures smiling and shaking hands politely. Write \"RESPECT\" above them. Ask students: \"How can we show respect to others?\" (e.g., Listen when they talk, use kind words, wait your turn, don't grab things, knock before entering, be polite to grown-ups and friends). List key actions.",
    discussionPoints: [
      "How does it feel when someone respects you? (Good, valued, heard).",
      "How does it feel when someone does not respect you? (Bad, ignored, unimportant).",
      "Do we need to respect people even if we don't agree with them? (Yes).",
      "How can we show respect for school property or others' belongings? (Use gently, ask before borrowing, put things back)."
    ],
    resourceLinks: {
      video: "Search YouTube for \"Respect song for kids\" or \"Teaching respect social story video\".",
      article: "Search for \"Activities to teach children respect\" or \"Importance of respect for kids article\"."
    }
  }
];
