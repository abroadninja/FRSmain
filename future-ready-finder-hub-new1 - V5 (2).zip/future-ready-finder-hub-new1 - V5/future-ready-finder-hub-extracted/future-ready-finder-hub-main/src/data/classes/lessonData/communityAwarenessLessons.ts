
import { Lesson } from '../ageGroups';

export const communityAwarenessLessons: Lesson[] = [
  {
    id: 33,
    title: "Community Helpers - Police Officers",
    goal: "Students will understand the role of police officers in keeping the community safe.",
    keyIdea: "Police officers are helpers in our community who work to keep people safe and help when there's trouble.",
    blackboardActivity: "Draw a simple police officer figure. Write 'POLICE OFFICERS HELP US' above. List duties of police officers as students share ideas.",
    discussionPoints: [
      "What do police officers do to help our community?",
      "When might you need a police officer's help?",
      "How can you recognize a police officer?",
      "What number can we call in an emergency to reach help?"
    ],
    resourceLinks: {
      video: "Search YouTube for 'Community helpers police officer for kids' or 'Police officers explained for kids'",
      article: "Search for 'Teaching children about police officers' or 'Community helpers activities police'"
    }
  },
  {
    id: 40,
    title: "Celebrating Differences (Diversity)",
    goal: "Students will understand that people have different backgrounds, abilities, and appearances, and these differences make our world interesting.",
    keyIdea: "People are like colorful flowers in a garden - we come in different colors, shapes, and sizes, and together we make a beautiful, interesting world!",
    blackboardActivity: "Draw different types of flowers or people figures in different colors. Write 'WE ARE ALL DIFFERENT AND SPECIAL' above.",
    discussionPoints: [
      "What are some ways people can be different from each other?",
      "Is it okay to be different?",
      "How would the world be if everyone was exactly the same?",
      "How can we show respect for people who are different from us?"
    ],
    resourceLinks: {
      video: "Search YouTube for 'Diversity explained for kids' or 'Sesame Street celebrating differences'",
      article: "Search for 'Teaching children about diversity activities' or 'Celebrating differences classroom ideas'"
    }
  },
  {
    id: 41,
    title: "Community Helpers - Firefighters",
    goal: "Students will understand the role of firefighters as important helpers in emergencies.",
    keyIdea: "Firefighters are brave community helpers who rescue people from fires and other dangerous situations. Think of them like safety superheroes!",
    blackboardActivity: "Draw a simple firefighter hat and a fire truck with a ladder and hose. Write 'FIREFIGHTERS HELP!'",
    discussionPoints: [
      "What special equipment do firefighters use?",
      "What sound does a fire truck make? Why is it loud?",
      "What should you do if you see a fire?",
      "What is the emergency number to call for help?"
    ],
    resourceLinks: {
      video: "Search YouTube for 'Firefighter song for kids' or 'What does a firefighter do kids video'",
      article: "Search for 'Teaching kids about firefighters' or 'Fire safety tips for kids printable'"
    }
  },
  {
    id: 51,
    title: "Community Helpers - Doctors & Nurses",
    goal: "Students will understand the role of doctors and nurses in helping people stay healthy and get better when sick.",
    keyIdea: "Doctors and nurses are like health detectives and fix-it helpers! Their job is to help us keep our bodies healthy and figure out what's wrong when we feel sick or get hurt.",
    blackboardActivity: "Draw a simple stethoscope and maybe a bandage with a plus sign (+). Write 'DOCTORS & NURSES HELP US STAY HEALTHY'.",
    discussionPoints: [
      "Where do doctors and nurses work?",
      "Have you visited a doctor or nurse? What did they do?",
      "Why is it important to go for check-ups even when you're not sick?",
      "Are doctors/nurses strangers?"
    ],
    resourceLinks: {
      video: "Search YouTube for 'Doctor song for kids' or 'What does a nurse do kids video'",
      article: "Search for 'Teaching kids about doctors visits' or 'Community helpers doctor nurse printable'"
    }
  },
  {
    id: 61,
    title: "Community Helpers - Teachers",
    goal: "Students will understand the role of teachers as helpers who guide learning.",
    keyIdea: "Teachers are special guides in our learning adventure! Their job is to help us discover and understand new things.",
    blackboardActivity: "Draw a simple figure next to a blackboard/book with 'ABC' or '123'. Write 'TEACHERS HELP US LEARN'.",
    discussionPoints: [
      "How do teachers help you when you don't understand something?",
      "What different subjects or topics do teachers teach?",
      "Besides teaching subjects, what else do teachers help us with at school?",
      "How can we show respect and appreciation for our teachers?"
    ],
    resourceLinks: {
      video: "Search YouTube for 'Teacher song for kids' or 'What does a teacher do kids video'",
      article: "Search for 'Appreciating teachers activities for kids' or 'Role of a teacher explained simply'"
    }
  },
  {
    id: 72,
    title: "Community Helpers - Farmers",
    goal: "Students will understand the important role farmers play in growing food for the community.",
    keyIdea: "Where does our food like rice, vegetables, and fruits come from? Often, it comes from farmers!",
    blackboardActivity: "Draw a simple farmer figure (maybe with a hat) next to some growing plants (like rice stalks or vegetable plants).",
    discussionPoints: [
      "Why is a farmer's job important?",
      "What tools might a farmer use?",
      "Is farming hard work? Why?",
      "How does the food get from the farm to our homes?"
    ],
    resourceLinks: {
      video: "Search YouTube for 'Farmer song for kids' or 'Where does food come from kids video farm'",
      article: "Search for 'Teaching kids about farming' or 'Farm to table activity kids'"
    }
  },
  {
    id: 82,
    title: "Community Helpers - Sanitation Workers / Cleaners",
    goal: "Students will understand the important role of sanitation workers and cleaners in keeping the community clean and healthy.",
    keyIdea: "Special community helpers called sanitation workers collect trash and keep our streets and neighbourhoods clean.",
    blackboardActivity: "Draw a simple garbage truck and a figure putting trash bags into it. Draw another figure sweeping a floor.",
    discussionPoints: [
      "What would happen if no one collected the trash?",
      "How can we help make their job easier?",
      "Is their job easy or hard? Why?",
      "How can we show respect for cleaners and sanitation workers?"
    ],
    resourceLinks: {
      video: "Search YouTube for 'Sanitation worker song for kids' or 'Community helpers keeping community clean video'",
      article: "Search for 'Teaching kids respect for sanitation workers' or 'Importance of cleanliness community helpers'"
    }
  },
  {
    id: 95,
    title: "Community Helper - Shopkeeper / Vendor",
    goal: "Students will understand the role of shopkeepers and vendors in providing goods to the community.",
    keyIdea: "When we need to buy things like soap, pencils, snacks, or vegetables, where do we go? Often to a shop or a street vendor!",
    blackboardActivity: "Draw a simple shop front with items on shelves. Draw a figure behind a counter.",
    discussionPoints: [
      "How do shopkeepers help the community?",
      "What skills might a shopkeeper need?",
      "How do we interact politely with shopkeepers?"
    ],
    resourceLinks: {
      video: "Search YouTube for 'Community helpers shopkeeper song' or 'Going to the shop social story kids'",
      article: "Search for 'Teaching kids about local shops' or 'Role play shopping activity kids'"
    }
  },
  {
    id: 96,
    title: "Different Ways of Celebrating (Festivals/Traditions)",
    goal: "Students will appreciate that different families and communities have different ways of celebrating special occasions.",
    keyIdea: "Remember we learned everyone is different and special? That includes how families and communities celebrate!",
    blackboardActivity: "Draw simple symbols for a few different local festivals/celebrations. Write 'DIFFERENT CELEBRATIONS!'",
    discussionPoints: [
      "Why do people have celebrations and festivals?",
      "Is one way of celebrating 'better' than another?",
      "How can we show respect for others' celebrations, even if they are different from ours?"
    ],
    resourceLinks: {
      video: "Search YouTube for 'Festivals of India for kids simple' or 'Celebrating diversity traditions kids video'",
      article: "Search for 'Teaching kids about different cultures festivals' or 'Respecting diversity celebrations activities'"
    }
  },
  {
    id: 83, 
    title: "Basic Needs of Animals (Food, Water, Shelter)",
    goal: "Students will understand that animals, like humans and plants, have basic needs for survival.",
    keyIdea: "Just like we need food, water, and a home, animals need these things too! All animals need food to give them energy – some eat plants, some eat other animals. They all need water to drink to keep their bodies working. And they need shelter – a safe place to rest, hide from danger, and maybe raise their babies. This shelter could be a nest, a burrow, a den, or even just a safe spot under a bush. Food, water, and shelter help animals live and grow.",
    blackboardActivity: "Draw a simple animal (e.g., a bird). Draw arrows pointing to it from simple icons: Food (seeds/worm), Water (water drops/bowl), Shelter (a nest in a tree). Write \"ANIMALS NEED FOOD, WATER, SHELTER\". Repeat with another animal (e.g., a dog - Food bowl, Water bowl, Doghouse/Bed).",
    discussionPoints: [
      "What kind of food do different animals eat? (e.g., Cow eats grass, cat eats fish/mice, bird eats seeds).",
      "Where do animals find water? (Rivers, lakes, puddles, bowls if pets).",
      "What kind of shelters do different animals use? (Bird-nest, Rabbit-burrow, Bear-cave, Fish-under rocks/plants in water).",
      "How do pets get their needs met? (Owners provide food, water, shelter)."
    ],
    resourceLinks: {
      video: "Search YouTube for \"Animal needs song for kids\" or \"What do animals need to survive kids science\".",
      article: "Search for \"Basic needs of animals worksheet kids\" or \"Animal habitats and needs activity\"."
    }
  }
];
