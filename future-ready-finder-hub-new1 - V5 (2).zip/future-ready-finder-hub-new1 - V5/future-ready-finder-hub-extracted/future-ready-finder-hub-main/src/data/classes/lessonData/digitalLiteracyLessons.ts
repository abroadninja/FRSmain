
import { Lesson } from '../ageGroups';

export const digitalLiteracyLessons: Lesson[] = [
  {
    id: 43,
    title: "Digital Citizens",
    goal: "Students will understand the concept of digital citizenship and responsibilities online.",
    keyIdea: "Being a good digital citizen means being respectful, safe, and responsible when using technology—just like being a good citizen in the physical world.",
    blackboardActivity: "Create a 'Digital Citizenship Pledge' with class-generated guidelines for responsible technology use.",
    discussionPoints: [
      "What does it mean to be a good citizen in the real world?",
      "How can we be good citizens online?",
      "Why are rules important when using technology?",
      "How can our online actions affect others?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Digital citizenship for kids\"",
      article: "Search for \"Teaching digital citizenship elementary\""
    }
  },
  {
    id: 44,
    title: "Digital Safety First",
    goal: "Students will learn basic safety practices for online activities.",
    keyIdea: "Just like we have safety rules in the physical world, we need rules to stay safe online. Protecting personal information is especially important.",
    blackboardActivity: "Sort information into 'Safe to Share' and 'Not Safe to Share' categories. Practice scenarios for handling unsafe situations online.",
    discussionPoints: [
      "What information should you never share online?",
      "Who are trusted adults you can talk to about online safety?",
      "What should you do if something online makes you uncomfortable?",
      "Why is it important to get permission before going to new websites or downloading apps?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Internet safety for kids\"",
      article: "Search for \"Online safety lessons elementary\""
    }
  },
  {
    id: 45,
    title: "Digital Detective",
    goal: "Students will develop basic skills for evaluating online information.",
    keyIdea: "Not everything online is true or trustworthy. Good digital users know how to spot clues about whether information is reliable.",
    blackboardActivity: "Present age-appropriate examples of reliable and unreliable online content. Create a simple checklist for evaluating websites.",
    discussionPoints: [
      "How can you tell if information online is true?",
      "Why might some online information be incorrect or misleading?",
      "Who creates the information we find online?",
      "What should you do if you're not sure if online information is accurate?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Evaluating websites for kids\"",
      article: "Search for \"Media literacy elementary level\""
    }
  },
  {
    id: 46,
    title: "Digital Balance",
    goal: "Students will understand the importance of balancing screen time with other activities.",
    keyIdea: "Technology is a tool that can be helpful and fun, but it's important to make time for other activities that keep our bodies and minds healthy.",
    blackboardActivity: "Create a 'Balanced Day' chart showing a healthy mix of screen and non-screen activities.",
    discussionPoints: [
      "What are good ways to use technology?",
      "Why is it important to take breaks from screens?",
      "What activities do you enjoy that don't involve technology?",
      "How do you feel when you spend too much time on screens?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Screen time balance for kids\"",
      article: "Search for \"Teaching healthy technology habits elementary\""
    }
  },
  {
    id: 47,
    title: "Digital Creation Tools",
    goal: "Students will explore digital tools for creative expression and learning.",
    keyIdea: "Digital tools can help us create, learn, and share ideas in exciting ways.",
    blackboardActivity: "Demonstrate age-appropriate digital creation tools (drawing apps, simple coding platforms, digital storytelling). Allow students to experiment with available tools.",
    discussionPoints: [
      "What are different ways technology helps us create things?",
      "How can digital tools help us learn new things?",
      "What would you like to create using technology?",
      "How is creating digitally different from using traditional materials?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Digital creativity tools for kids\"",
      article: "Search for \"Digital creation apps elementary classroom\""
    }
  },
  {
    id: 48,
    title: "Finding Information Online",
    goal: "Students will develop basic research skills using digital resources.",
    keyIdea: "Digital tools can help us find information quickly, but we need to learn how to search effectively and select reliable sources.",
    blackboardActivity: "Practice formulating search questions. Demonstrate kid-friendly search tools and strategies for finding information efficiently.",
    discussionPoints: [
      "What words help you find the information you want when searching?",
      "How can you narrow down search results when you get too many?",
      "What are good websites for kids to use for research?",
      "Why is it important to look at multiple sources of information?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Research skills for kids\"",
      article: "Search for \"Teaching search skills elementary\""
    }
  },
  {
    id: 49,
    title: "Digital Footprints",
    goal: "Students will understand that online actions leave traces that can last a long time.",
    keyIdea: "Everything we do online leaves a 'footprint' that can be seen by others and might last for a very long time.",
    blackboardActivity: "Create a visual representation of a digital footprint. Discuss scenarios and whether they create positive or negative digital footprints.",
    discussionPoints: [
      "What is a digital footprint?",
      "Who might see the things you post or share online?",
      "Why is it important to think before posting something online?",
      "How can you create a positive digital footprint?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Digital footprint for kids\"",
      article: "Search for \"Teaching digital footprint elementary\""
    }
  }
];
