
import { Lesson } from '../ageGroups';

export const collaborationLessons: Lesson[] = [
  {
    id: 22,
    title: "Better Together",
    goal: "Students will understand the value of collaboration and working together.",
    keyIdea: "Working together can help us solve problems faster, come up with better ideas, and make tasks more fun.",
    blackboardActivity: "Give students a task to complete first individually, then in pairs or groups. Compare the results and discuss the benefits of collaboration.",
    discussionPoints: [
      "When is working together better than working alone?",
      "What can a group do that one person might find difficult?",
      "How does sharing ideas help create better solutions?",
      "What are some examples of collaboration in the real world?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Benefits of teamwork for kids\"",
      article: "Search for \"Teaching collaboration skills in elementary\""
    }
  },
  {
    id: 23,
    title: "Everyone Has Something to Offer",
    goal: "Students will recognize and value diverse strengths and perspectives in a team.",
    keyIdea: "Each person has unique talents, ideas, and experiences that can help the group. Diversity makes teams stronger.",
    blackboardActivity: "Create a 'Team Strengths' chart where students identify and share their own strengths and those of their classmates.",
    discussionPoints: [
      "What special strengths or talents do you bring to a group?",
      "Why is it helpful to have people with different skills on a team?",
      "How can someone who thinks differently from you help the group?",
      "How can we make sure everyone's ideas are heard?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Diversity and inclusion for kids\"",
      article: "Search for \"Appreciating differences in elementary classroom\""
    }
  },
  {
    id: 24,
    title: "Active Listening",
    goal: "Students will practice listening attentively to others and demonstrate understanding.",
    keyIdea: "Good listeners pay attention, ask questions, and show they understand. Listening well shows respect and helps collaboration.",
    blackboardActivity: "Practice active listening skills through paired activities where one student speaks and the other must summarize what they heard.",
    discussionPoints: [
      "What does a good listener do with their body and face?",
      "How can you show someone you're really listening?",
      "Why is listening just as important as speaking in a conversation?",
      "What makes it hard to listen sometimes, and how can we overcome those challenges?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Active listening for kids\"",
      article: "Search for \"Teaching listening skills in elementary\""
    }
  },
  {
    id: 25,
    title: "Roles and Responsibilities",
    goal: "Students will learn to share work fairly and take responsibility for their contributions to a group.",
    keyIdea: "In effective teams, everyone has important jobs and takes responsibility for their part of the work.",
    blackboardActivity: "Create a group project where each student has a specific, essential role. Discuss how each role contributes to the whole.",
    discussionPoints: [
      "Why is it important to share work in a group?",
      "How can we make sure everyone has an important role?",
      "What happens when someone doesn't do their part in a team?",
      "How does taking responsibility for your job show respect for the team?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Teamwork roles for kids\"",
      article: "Search for \"Teaching responsibility in group work elementary\""
    }
  },
  {
    id: 26,
    title: "Working Through Disagreements",
    goal: "Students will develop strategies for resolving conflicts and disagreements constructively.",
    keyIdea: "Disagreements are normal in teams, but we can work through them respectfully to find solutions everyone can accept.",
    blackboardActivity: "Role-play common group work conflicts and practice conflict resolution strategies like compromise and taking turns.",
    discussionPoints: [
      "Why do disagreements happen when people work together?",
      "What are some respectful ways to tell someone you disagree?",
      "How can compromise help resolve disagreements?",
      "Why is it important to stay calm when there's a conflict?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Conflict resolution for kids\"",
      article: "Search for \"Teaching compromise skills elementary\""
    }
  },
  {
    id: 27,
    title: "Giving and Receiving Feedback",
    goal: "Students will learn to give helpful feedback and use feedback to improve their work.",
    keyIdea: "Feedback helps us grow and improve. Good feedback is specific, kind, and focused on the work, not the person.",
    blackboardActivity: "Practice giving 'sandwich' feedback (something positive, a suggestion for improvement, something positive) on classmates' work.",
    discussionPoints: [
      "What makes feedback helpful rather than hurtful?",
      "How should we respond when we receive feedback?",
      "Why is it important to mention positive things along with suggestions?",
      "How has feedback helped you improve something you've done?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Giving feedback for kids\"",
      article: "Search for \"Teaching peer feedback in elementary\""
    }
  },
  {
    id: 28,
    title: "Achieving Goals Together",
    goal: "Students will set and work toward shared goals as a team.",
    keyIdea: "Teams need clear goals that everyone understands and agrees on. Planning and tracking progress helps teams succeed.",
    blackboardActivity: "Guide students through setting a class goal, breaking it into steps, assigning responsibilities, and tracking progress.",
    discussionPoints: [
      "Why do teams need goals?",
      "How can we make sure everyone understands and agrees with the goal?",
      "What steps help a team reach their goal?",
      "How does it feel when a team achieves something together?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Goal setting for kids\" or \"Team goals\"",
      article: "Search for \"Collaborative goal setting elementary classroom\""
    }
  }
];
