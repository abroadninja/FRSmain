
import { Lesson } from '../ageGroups';

export const basicLifeSkillsLessons: Lesson[] = [
  {
    id: 6,
    title: "What is Money? (Basic Introduction)",
    goal: "Students will get a basic idea of what money is and what it's used for.",
    keyIdea: "Money is like special paper notes or metal coins that grown-ups (and sometimes kids!) use to swap for things they need or want. Think of it like trading tokens. You need food? You trade money for it at the store. You want a toy? You trade money for it. People get money usually by working at jobs. It helps us get the things we need to live, like food and a home, and sometimes things we just enjoy, like books or going to the movies.",
    blackboardActivity: "Draw simple shapes of coins (circles) and notes (rectangles). Write \"MONEY\" above them. Ask students: \"What do people use money for?\" (e.g., food, clothes, house, toys, bus fare, electricity). Write or draw simple pictures of these items around the money drawings.",
    discussionPoints: [
      "Where have you seen money being used?",
      "Do you get pocket money? What do you use it for? (If applicable).",
      "Why do people need to work to get money?",
      "Can money buy everything? (No, it can't buy things like friendship, love, or happiness)."
    ],
    resourceLinks: {
      video: "Search YouTube for \"What is money for kids video\" or \"Learning about money for kids cartoon\".",
      article: "Search for \"Introduction to money worksheets for kids\" or \"Teaching kids about money basics\"."
    }
  },
  {
    id: 10,
    title: "Making Mistakes is Okay (Learning)",
    goal: "Students will understand that making mistakes is a normal part of learning.",
    keyIdea: "Imagine you are learning to ride a bicycle. Do you ride perfectly the first time? No! You might wobble, or even fall down. Falling down is like making a mistake. Is it bad? No! It just teaches you what not to do next time – maybe lean differently or pedal faster. Mistakes are like little signposts showing us we need to try a different way. Everyone makes mistakes – kids, grown-ups, everyone! They help our brains grow stronger and teach us how to do things better.",
    blackboardActivity: "Draw a simple path with a 'wrong turn' that has an 'X' on it, and then show the path continuing correctly. Write \"MISTAKES HELP US LEARN!\" Ask students: \"Can you think of a time you made a mistake while learning something?\" (e.g., spelling a word wrong, drawing something incorrectly, missing a ball). Ask: \"What did you learn from that mistake?\"",
    discussionPoints: [
      "How does it feel when you make a mistake? (Sometimes upset, frustrated, embarrassed).",
      "What can you say to yourself when you make a mistake? (\"It's okay,\" \"I can try again,\" \"What can I learn?\").",
      "What's more important: never making mistakes, or trying your best and learning? (Trying and learning!).",
      "How can we be kind to friends when they make a mistake? (Don't laugh, say \"That's okay, try again!\")."
    ],
    resourceLinks: {
      video: "Search YouTube for \"Mistakes are okay song for kids\" or \"Growth mindset for kids mistakes video\".",
      article: "Search for \"Growth mindset activities for kids mistakes\" or \"Teaching children it's okay to make mistakes\"."
    }
  },
  {
    id: 15,
    title: "Saving Money (Simple Idea)",
    goal: "Students will get a very basic idea that saving money means not spending it right away, so you can buy something bigger later.",
    keyIdea: "Remember how money helps us buy things? Saving money is like collecting little bits of money over time instead of spending it all at once. Imagine you get a little bit of money each week. If you spend it all on small candies right away, it's gone. But if you put some aside each week in a special jar (a piggy bank!), soon you'll have enough collected to buy a bigger thing you really want, like a special toy or a book. Saving helps you reach bigger goals!",
    blackboardActivity: "Draw a simple piggy bank (a pig shape with a coin slot). Draw several coins going into it over time (maybe show arrows with 'Week 1', 'Week 2'). Draw an arrow from the full piggy bank to a picture of a slightly bigger item (e.g., a storybook or a small toy car). Write \"SAVING MONEY\". Ask: \"What small things can we buy with a little money?\" (Candy, sticker). \"What bigger things might we need to save up for?\" (Toy, book, game).",
    discussionPoints: [
      "Why is it sometimes good to save money instead of spending it right away?",
      "Have you ever saved up for something? How did it feel when you finally got it?",
      "Where can people keep the money they are saving? (Piggy bank, jar, wallet).",
      "Does saving take time? (Yes, usually)."
    ],
    resourceLinks: {
      video: "Search YouTube for \"Saving money for kids cartoon\" or \"Sesame Street saving money explained\".",
      article: "Search for \"Teaching kids about saving money activities\" or \"Needs vs wants worksheet for kids\"."
    }
  },
  {
    id: 16,
    title: "Being Honest (Telling the Truth)",
    goal: "Students will understand the importance of telling the truth, even when it's difficult.",
    keyIdea: "Being honest means telling the truth, saying what really happened. Imagine truth is like a straight, clear path. Telling a lie is like taking a crooked, confusing path that can get you lost. Even if you made a mistake or did something wrong, telling the truth is usually the best choice. It helps people trust you. It might be hard sometimes, but honesty builds strong friendships and makes you feel good inside in the long run.",
    blackboardActivity: "Draw a straight line labeled \"TRUTH / HONESTY\". Draw a wiggly, tangled line labeled \"LIE\". Draw a stick figure with a 'halo' or a smiling face next to \"TRUTH\". Draw a stick figure looking worried or tangled up next to \"LIE\". Ask: \"Why is telling the truth important?\" (People trust you, it's the right thing, avoids bigger problems later).",
    discussionPoints: [
      "How does it feel when someone tells you the truth? (Good, you can trust them).",
      "How does it feel when you think someone is not telling the truth? (Confused, sad, mistrusting).",
      "Is it sometimes hard to tell the truth? Why? (Afraid of getting in trouble).",
      "What might happen if you tell the truth about a mistake? (Might still face consequences, but people will respect your honesty)."
    ],
    resourceLinks: {
      video: "Search YouTube for \"Honesty song for kids\" or \"Telling the truth story for kids\".",
      article: "Search for \"Teaching kids about honesty activities\" or \"Importance of telling the truth children\"."
    }
  },
  {
    id: 54,
    title: "Simple Choices: Spending vs. Saving",
    goal: "Students will practice making simple choices between spending money now or saving for something slightly bigger.",
    keyIdea: "Remember saving money means keeping it for later? Let's think about choices. Imagine you have a small amount of pocket money. You could spend it right now on a small candy. Or, you could save it. If you save it this week, and maybe next week too, you might have enough to buy that slightly bigger thing you wanted, like a small storybook or a special pencil. Spending now gives instant fun, but saving lets you get something bigger later. It's about choosing what's more important to you right now.",
    blackboardActivity: "Draw a coin. Draw two arrows pointing from it. Arrow 1 points to a small candy. Write 'SPEND NOW (Small Treat)'. Arrow 2 points to a piggy bank, which then points to a slightly bigger item (e.g., a book). Write 'SAVE NOW -> BUY LATER (Bigger Treat)'. Ask: 'If you had 10 rupees, would you buy a 10 rupee chocolate now, or save it towards a 50 rupee comic book?' (Discuss choices).",
    discussionPoints: [
      "Is one choice (spend or save) always right or wrong? (No, it depends on what you want/need)",
      "How does it feel to save up and finally buy something you wanted? (Proud, happy, worth the wait)",
      "How does it feel to spend money right away on something small? (Good for a moment)",
      "Why is it sometimes hard to save? (We want things now!)"
    ],
    resourceLinks: {
      video: "Search YouTube for 'Spending or saving money kids choices' or 'Simple budgeting for kids cartoon'",
      article: "Search for 'Teaching kids spend save choices activities' or 'Money choices worksheet for kids'"
    }
  }
];
