
import { Lesson } from '../ageGroups';

export const learningThinkingLessons: Lesson[] = [
  {
    id: 5,
    title: "Using Listening Ears",
    goal: "Students will understand the importance of listening carefully to others.",
    keyIdea: "Listening is like using special superpowers in your ears! It's not just hearing sounds; it's about catching the words someone says and trying to understand what they mean. Imagine words are like little balls being thrown – good listening is catching them! When we listen well, we learn things, understand instructions, show others we care, and avoid misunderstandings. It means looking at the person talking, keeping our body calm, and thinking about their words.",
    blackboardActivity: "Draw two large ears on the board. Write \"LISTENING EARS\" between them. Ask students: \"When is it important to use your listening ears?\" (e.g., when the teacher talks, when a friend tells a story, when parents give instructions, during a game). Write simple answers around the ears.",
    discussionPoints: [
      "What does good listening look like? (Eyes on speaker, quiet mouth, still body).",
      "Why is it hard to listen sometimes? (Distractions, feeling wiggly, not interested).",
      "What happens when we don't listen carefully? (Miss information, misunderstand, hurt feelings).",
      "How does it feel when someone really listens to you? (Respected, understood, important)."
    ],
    resourceLinks: {
      video: "Search YouTube for \"Listening skills song for kids\" or \"Good listening habits for students video\".",
      article: "Search for \"Listening games for elementary students\" or \"Teaching active listening skills to children\"."
    }
  },
  {
    id: 14,
    title: "Saying Sorry",
    goal: "Students will understand why and how to apologize sincerely when they make a mistake or hurt someone.",
    keyIdea: "Saying 'sorry' is like using magic words to help fix things when you've accidentally bumped into someone, hurt their feelings, or broken something. It shows the other person that you know you did something wrong and you feel bad about it. A good sorry means you really mean it. Sometimes you also need to ask, 'How can I make it better?' Saying sorry helps mend friendships and shows you care.",
    blackboardActivity: "Draw two stick figures. One looks sad/angry, the other looks sorry and is saying \"SORRY\". Draw a 'broken heart' between them, then draw a 'mended heart' after the apology. Ask: \"When should we say sorry?\" (When we hurt someone's feelings, break a rule, make a mistake that affects others, bump into someone).",
    discussionPoints: [
      "Why is it important to say sorry? (Shows respect, helps fix feelings, takes responsibility).",
      "What makes a good apology? (Saying \"I'm sorry for...\", meaning it, maybe offering to help fix it).",
      "Is it easy or hard to say sorry sometimes? Why?",
      "What should you do if someone says sorry to you? (Listen, maybe say \"Thank you\" or \"It's okay\")."
    ],
    resourceLinks: {
      video: "Search YouTube for \"Saying sorry song for kids\" or \"Daniel Tiger saying I'm sorry\".",
      article: "Search for \"Teaching kids how to apologize effectively\" or \"Role playing apology scenarios kids\"."
    }
  }
];
