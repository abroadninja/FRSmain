
import { Lesson } from '../ageGroups';

export const creativityLessons: Lesson[] = [
  {
    id: 15,
    title: "The Power of Imagination",
    goal: "Students will exercise their imagination and understand its value in generating new ideas.",
    keyIdea: "Imagination helps us think of new possibilities and solve problems in creative ways.",
    blackboardActivity: "Show an ordinary object (like a paper clip) and challenge students to come up with as many unusual uses for it as possible.",
    discussionPoints: [
      "How do we use our imagination every day?",
      "Why is imagination important for inventors and artists?",
      "Can imagination help solve real problems? How?",
      "What's something amazing you've imagined?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Imagination activities for kids\"",
      article: "Search for \"Developing imagination in elementary students\""
    }
  },
  {
    id: 16,
    title: "Think Outside the Box",
    goal: "Students will practice divergent thinking and overcome mental blocks to creativity.",
    keyIdea: "Sometimes the best ideas come when we think differently from everyone else and break old patterns.",
    blackboardActivity: "Present puzzles that require creative thinking beyond the obvious solution, like the 9-dot problem or lateral thinking puzzles appropriate for the age group.",
    discussionPoints: [
      "What does 'thinking outside the box' mean?",
      "Why is it sometimes hard to think of new ideas?",
      "How can we train ourselves to think more creatively?",
      "When was a time you solved a problem in an unusual way?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Creative thinking for kids\"",
      article: "Search for \"Lateral thinking activities for elementary\""
    }
  },
  {
    id: 17,
    title: "From Problems to Solutions",
    goal: "Students will use creative thinking to identify solutions to everyday problems.",
    keyIdea: "Creative thinking helps us find new and better ways to solve problems we face.",
    blackboardActivity: "Present age-appropriate problems (e.g., forgotten lunch, rainy day recess, lost library book) and brainstorm multiple creative solutions.",
    discussionPoints: [
      "What makes a solution creative?",
      "Why is it helpful to think of many possible solutions?",
      "How do inventors solve problems?",
      "What's a problem you solved in a creative way?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Problem-solving for kids\" or \"Kid inventors\"",
      article: "Search for \"Teaching creative problem-solving to children\""
    }
  },
  {
    id: 18,
    title: "The Art of Making Mistakes",
    goal: "Students will understand that mistakes are an important part of creativity and learning.",
    keyIdea: "Mistakes are not failures—they're opportunities to learn, improve, and sometimes discover something new!",
    blackboardActivity: "Share stories of famous mistakes that led to great discoveries (like penicillin or Post-it notes). Have students transform 'mistakes' (like spilled paint) into something new.",
    discussionPoints: [
      "How do you usually feel when you make a mistake?",
      "Why are mistakes important for learning and creativity?",
      "What can we learn from our mistakes?",
      "How can we be brave about trying new things even if we might make mistakes?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Growth mindset for kids\" or \"Famous mistakes that led to inventions\"",
      article: "Search for \"Teaching children to embrace mistakes\""
    }
  },
  {
    id: 19,
    title: "Combining Ideas",
    goal: "Students will practice combining different concepts to create something new.",
    keyIdea: "Many creative inventions come from combining things that don't usually go together.",
    blackboardActivity: "Create a 'random combination' activity where students pick two unrelated objects or ideas and combine them to create something new.",
    discussionPoints: [
      "What are some things that were created by combining different ideas?",
      "How does combining ideas help us be more creative?",
      "What unusual combinations might solve a problem in your life?",
      "Why is it helpful to get ideas from different people when creating something new?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Creative combinations for kids\"",
      article: "Search for \"Fusion thinking activities for elementary\""
    }
  },
  {
    id: 20,
    title: "Express Yourself",
    goal: "Students will explore different forms of creative expression.",
    keyIdea: "There are many ways to express ideas and feelings creatively, through art, music, movement, writing, and more.",
    blackboardActivity: "Provide the same concept (e.g., 'happiness' or 'adventure') and have students express it in different ways—drawing, writing, acting, etc.",
    discussionPoints: [
      "What are different ways people express themselves creatively?",
      "How does creative expression help us share our thoughts and feelings?",
      "Which forms of creative expression do you enjoy most? Why?",
      "Why is it important that people can express themselves in different ways?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Creative expression for kids\"",
      article: "Search for \"Multimodal expression activities for children\""
    }
  },
  {
    id: 21,
    title: "From Draft to Masterpiece",
    goal: "Students will understand the creative process of revising and improving ideas.",
    keyIdea: "Creative work usually gets better with revision and feedback. First attempts are just the beginning!",
    blackboardActivity: "Show examples of famous artwork or writing in early draft form and final form. Have students work through multiple drafts of their own creative project.",
    discussionPoints: [
      "Why do creative people make multiple drafts of their work?",
      "How does getting feedback help make our work better?",
      "What's the difference between giving up and deciding something is finished?",
      "How can we overcome frustration when our work isn't turning out the way we want?"
    ],
    resourceLinks: {
      video: "Search YouTube for \"Revision process for kids\" or \"Growth mindset and creativity\"",
      article: "Search for \"Teaching revision to elementary students\""
    }
  }
];
