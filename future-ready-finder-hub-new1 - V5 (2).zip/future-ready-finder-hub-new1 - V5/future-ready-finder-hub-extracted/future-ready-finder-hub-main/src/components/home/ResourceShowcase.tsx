
import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { 
  BookOpen, 
  FileText, 
  Users, 
  CheckCircle,
  Layout
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { useIsMobile } from "@/hooks/use-mobile";

const ResourceShowcase = () => {
  const isMobile = useIsMobile();
  
  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <Badge variant="outline" className="mb-4">Free Resources</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Complete Toolkit for School Transformation
          </h2>
          <p className="text-lg text-gray-600">
            Access our comprehensive collection of resources designed to transform your school's approach to education.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {resources.map((resource, index) => (
            <ResourceCard
              key={index}
              icon={resource.icon}
              title={resource.title}
              description={resource.description}
              features={resource.features}
              color={resource.color}
            />
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <p className="text-gray-600 mb-6">
            All resources are completely free, with no hidden costs or time limits.
          </p>
          
          <Button size="lg" className="bg-blue-700 hover:bg-blue-800 text-white shadow-md" asChild>
            <Link to="/signup">
              Access All Resources
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

interface ResourceCardProps {
  icon: React.FC<{ className?: string }>;
  title: string;
  description: string;
  features: string[];
  color: "blue" | "violet" | "amber" | "emerald" | "indigo" | "rose";
}

const ResourceCard = ({ icon: Icon, title, description, features, color }: ResourceCardProps) => {
  const colorClasses = {
    blue: "bg-blue-100 text-blue-700 border-blue-200",
    violet: "bg-violet-100 text-violet-700 border-violet-200",
    amber: "bg-amber-100 text-amber-700 border-amber-200",
    emerald: "bg-emerald-100 text-emerald-700 border-emerald-200",
    indigo: "bg-indigo-100 text-indigo-700 border-indigo-200",
    rose: "bg-rose-100 text-rose-700 border-rose-200"
  };
  
  return (
    <Card className={`border hover:shadow-md transition-all border-l-4 ${colorClasses[color].split(' ')[2]}`}>
      <CardContent className="p-6 pt-6">
        <div className={`${colorClasses[color].split(' ')[0]} ${colorClasses[color].split(' ')[1]} w-12 h-12 rounded-full flex items-center justify-center mb-4`}>
          <Icon className="h-6 w-6" />
        </div>
        
        <h3 className="font-bold text-xl mb-2">{title}</h3>
        <p className="text-gray-600 mb-4">{description}</p>
        
        <ul className="space-y-2">
          {features.map((feature, idx) => (
            <li key={idx} className="flex items-start gap-2">
              <CheckCircle className={`h-4 w-4 mt-1 ${colorClasses[color].split(' ')[1]}`} />
              <span className="text-gray-700 text-sm">{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
};

const resources = [
  {
    icon: BookOpen,
    title: "Educational Frameworks",
    description: "Complete curriculum frameworks for developing future-ready skills",
    features: [
      "Age-appropriate skill development guides",
      "Project-based learning templates",
      "Implementation checklists",
      "Assessment frameworks"
    ],
    color: "blue" as const
  },
  {
    icon: Users,
    title: "Parent Engagement System",
    description: "Tools to build a thriving community of engaged parents",
    features: [
      "Communication templates",
      "Parent meeting frameworks",
      "Feedback collection tools",
      "Event planning guides"
    ],
    color: "violet" as const
  },
  {
    icon: Layout,
    title: "School Positioning Kit",
    description: "Materials to effectively differentiate your school",
    features: [
      "Value proposition templates",
      "Marketing frameworks",
      "School branding guides",
      "Differentiation strategies"
    ],
    color: "emerald" as const
  },
  {
    icon: FileText,
    title: "Implementation Playbooks",
    description: "Step-by-step guides for transforming your school",
    features: [
      "Resource optimization plans",
      "Implementation timelines",
      "Progress tracking tools",
      "Success metrics"
    ],
    color: "amber" as const
  },
  {
    icon: Users,
    title: "Teacher Support",
    description: "Resources to help teachers succeed with the new framework",
    features: [
      "Professional development guides",
      "Classroom activities",
      "Teaching resources",
      "Assessment tools"
    ],
    color: "indigo" as const
  },
  {
    icon: Layout,
    title: "Enrollment Growth",
    description: "Systems to increase enrollment and retention",
    features: [
      "Admissions process optimization",
      "Parent satisfaction frameworks",
      "Word-of-mouth generation",
      "Retention strategies"
    ],
    color: "rose" as const
  }
];

export default ResourceShowcase;
