
import React from "react";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const FAQ = () => {
  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <Badge variant="outline" className="mb-4">FAQ</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Common Questions
          </h2>
          <p className="text-lg text-gray-600">
            Find answers to frequently asked questions about our free school transformation system.
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border border-gray-200 rounded-lg px-6">
                <AccordionTrigger className="text-left font-semibold text-lg py-4">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="pt-2 pb-4 text-gray-600">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
};

const faqs = [
  {
    question: "Is this really completely free?",
    answer: "Yes, all our resources, frameworks, and implementation guides are 100% free. There are no hidden costs, subscription fees, or time limits. We believe in removing financial barriers to quality education."
  },
  {
    question: "How long does implementation take?",
    answer: "Most schools see initial results within 30-90 days. The implementation timeline depends on which components you choose to implement first and your school's existing resources and systems."
  },
  {
    question: "Will this work for our school's limited budget?",
    answer: "Absolutely. Our system is specifically designed to work with limited resources. We focus on optimizing what you already have rather than requiring significant new investments."
  },
  {
    question: "Do we need special technical skills?",
    answer: "No technical expertise is required. Our implementation guides are designed to be user-friendly and accessible for all school administrators, regardless of technical background."
  },
  {
    question: "Can we customize the system for our specific needs?",
    answer: "Yes, the entire system is designed to be adaptable to your school's unique context, resources, and student population. You can implement the components that make the most sense for your specific situation."
  },
  {
    question: "What ongoing support is available?",
    answer: "We provide comprehensive documentation, guides, and resources to support your implementation. While we don't currently offer personalized consulting, our resources are designed to be self-guided."
  }
];

export default FAQ;
