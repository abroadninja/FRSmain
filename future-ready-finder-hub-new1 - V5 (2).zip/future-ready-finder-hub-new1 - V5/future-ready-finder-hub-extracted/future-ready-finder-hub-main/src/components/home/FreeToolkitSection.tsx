
import React, { useState } from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  GraduationCap, 
  Users, 
  BookOpen,
  Star,
  ArrowRight
} from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const FreeToolkitSection = () => {
  const isMobile = useIsMobile();

  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container-custom">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <Badge variant="outline" className="mb-4">Free Resources</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Your FREE Toolkit for School Transformation
          </h2>
          <p className="text-lg text-gray-600">
            We give you everything: ready-to-use plans, templates, guides, and even apps! 
            All 100% FREE to help your school shine.
          </p>
        </div>

        <Tabs defaultValue="positioning" className="w-full">
          <TabsList className="grid grid-cols-3 md:grid-cols-6 h-auto p-1 bg-muted/20 mb-8">
            <TabsTrigger value="positioning" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground py-2">
              Positioning
            </TabsTrigger>
            <TabsTrigger value="parents" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground py-2">
              Parents
            </TabsTrigger>
            <TabsTrigger value="admissions" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground py-2">
              Admissions
            </TabsTrigger>
            <TabsTrigger value="teachers" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground py-2">
              Teachers
            </TabsTrigger>
            <TabsTrigger value="students" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground py-2">
              Students
            </TabsTrigger>
            <TabsTrigger value="growth" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground py-2">
              Growth
            </TabsTrigger>
          </TabsList>

          <TabsContent value="positioning" className="mt-0">
            <ToolkitTab
              title="School Positioning & Websites"
              description="Stand out in your market with professionally designed materials to showcase your school's unique value."
              items={[
                "Example websites & templates",
                "Value proposition frameworks",
                "Digital marketing guides",
                "School branding materials"
              ]}
              image="https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80"
            />
          </TabsContent>

          <TabsContent value="parents" className="mt-0">
            <ToolkitTab
              title="Parent Engagement Kits"
              description="Build stronger relationships with parents and create a community that champions your school."
              items={[
                "Ice breakers & poll templates",
                "Curriculum update templates",
                "Community invitations",
                "Referral program guides"
              ]}
              image="https://images.unsplash.com/photo-1573497019236-61f323342eb4?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80"
            />
          </TabsContent>

          <TabsContent value="admissions" className="mt-0">
            <ToolkitTab
              title="Admission Counselor Resources"
              description="Convert more inquiries into enrollments with professional sales and communication tools."
              items={[
                "Objection handling guides",
                "Inquiry response templates",
                "'Unbeatable Value' sales scripts",
                "Follow-up systems"
              ]}
              image="https://images.unsplash.com/photo-1551836022-d5d88e9218df?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80"
            />
          </TabsContent>

          <TabsContent value="teachers" className="mt-0">
            <ToolkitTab
              title="Teacher Support Materials"
              description="Equip your teachers with resources to deliver high-value education that prepares students for the future."
              items={[
                "High-income skill building trackers",
                "Financial literacy frameworks",
                "Discussion drivers",
                "Critical thinking toolkits"
              ]}
              image="https://images.unsplash.com/photo-1509062522246-3755977927d7?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80"
            />
          </TabsContent>

          <TabsContent value="students" className="mt-0">
            <ToolkitTab
              title="Student Success Tools & Apps"
              description="Give your students resources to plan their future and develop valuable skills."
              items={[
                "Career compass flowcharts",
                "Planning templates",
                "Skill Spark Journal",
                "Student Success Kit"
              ]}
              image="https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80"
            />
          </TabsContent>

          <TabsContent value="growth" className="mt-0">
            <ToolkitTab
              title="Growth & Management Systems"
              description="Implement proven systems to increase enrollment and efficiently manage your school's growth."
              items={[
                "Lead generation trackers",
                "USP worksheets",
                "Website optimization flowcharts",
                "Curriculum outline templates"
              ]}
              image="https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80"
            />
          </TabsContent>
        </Tabs>

        <div className="text-center mt-8 md:mt-12">
          <p className="text-lg font-medium mb-6">
            All these practical resources are yours to use, completely FREE, forever! 
            <span className="text-primary"> Fully customizable to your school's needs.</span>
          </p>
          
          <Button 
            size={isMobile ? "default" : "lg"}
            className="bg-primary hover:bg-primary/90 text-white shadow-lg"
            asChild
          >
            <Link to="/signup">
              Get Your FREE Access <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

interface ToolkitTabProps {
  title: string;
  description: string;
  items: string[];
  image: string;
}

const ToolkitTab = ({ title, description, items, image }: ToolkitTabProps) => {
  return (
    <div className="grid md:grid-cols-2 gap-8 items-center bg-gray-50 rounded-lg p-6 md:p-10 border border-gray-200">
      <div className="space-y-6">
        <h3 className="text-2xl font-bold">{title}</h3>
        <p className="text-gray-600">{description}</p>
        
        <ul className="space-y-3">
          {items.map((item, index) => (
            <li key={index} className="flex items-start gap-3">
              <div className="bg-green-100 p-1 rounded-full mt-0.5">
                <Star className="h-4 w-4 text-green-600" />
              </div>
              <span>{item}</span>
            </li>
          ))}
        </ul>
        
        <Button variant="outline" className="border-primary text-primary hover:bg-primary/5" asChild>
          <Link to="/resources">
            View All Resources
          </Link>
        </Button>
      </div>
      
      <div className="hidden md:block">
        <img 
          src={image} 
          alt={title}
          className="rounded-lg object-cover w-full h-[300px]"
        />
      </div>
    </div>
  );
};

export default FreeToolkitSection;
