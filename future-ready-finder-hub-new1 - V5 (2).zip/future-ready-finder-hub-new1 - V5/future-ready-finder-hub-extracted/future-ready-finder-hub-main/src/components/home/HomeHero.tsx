
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle, GraduationCap, BookOpen, Calendar, Star } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useIsMobile } from "@/hooks/use-mobile";

const HomeHero = () => {
  const isMobile = useIsMobile();

  return (
    <section className="relative overflow-hidden">
      {/* Background with gradient and pattern */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/90 via-secondary/80 to-accent/90 z-0">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yLjIgMS44LTQgNC00czQgMS44IDQgNC0xLjggNC00IDQtNC0xLjgtNC00eiIvPjwvZz48L2c+PC9zdmc+')] opacity-20"></div>
      </div>

      <div className="container-custom relative z-10 py-16 sm:py-20 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Column: Main Content */}
          <div className="space-y-6 md:space-y-8 max-w-2xl">
            {/* Brand & Logo */}
            <div className="flex items-center gap-3 animate-fade-in">
              <div className="bg-white p-3 rounded-xl shadow-lg">
                <GraduationCap size={isMobile ? 28 : 40} className="text-primary" />
              </div>
              <div>
                <h2 className="text-2xl md:text-3xl font-bold text-white leading-tight">
                  Future Ready Schools
                </h2>
                <div className="flex items-center mt-1">
                  <Badge variant="outline" className="bg-white/20 text-white border-white/30 text-xs">No-Cost School Growth System</Badge>
                </div>
              </div>
            </div>

            {/* Main Headline */}
            <div className="space-y-4">
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold text-white leading-tight tracking-tight animate-fade-in">
                Give Your Students What They Actually Need
              </h1>
              
              <p className="text-lg md:text-xl text-white/95 max-w-xl font-medium leading-relaxed">
                <span className="relative inline-block">
                  <span className="absolute -bottom-1 left-0 right-0 h-1 bg-yellow-300/50 rounded-full"></span>
                  A complete system to transform your school
                </span> with future-ready education, increased enrollment, and skills that prepare students for tomorrow's economy — all at <span className="font-bold">zero cost</span>.
              </p>
            </div>

            {/* Benefits */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-3 gap-x-4 pb-2">
              {[
                { icon: CheckCircle, text: "Complete Implementation System" },
                { icon: CheckCircle, text: "Career-Ready Skills Development" },
                { icon: CheckCircle, text: "Parent Engagement Framework" },
                { icon: CheckCircle, text: "Enrollment & Growth Strategy" }
              ].map((benefit, idx) => (
                <div key={idx} className="flex items-center gap-2 text-white/90">
                  <benefit.icon className="h-5 w-5 text-yellow-300 flex-shrink-0" />
                  <span className="text-sm md:text-base">{benefit.text}</span>
                </div>
              ))}
            </div>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button 
                size={isMobile ? "default" : "lg"} 
                className="bg-white text-primary hover:bg-white/90 transition-all font-bold shadow-lg py-6 text-base sm:text-lg relative overflow-hidden group"
                asChild
              >
                <Link to="/signup">
                  <span className="absolute inset-0 w-1/2 bg-gradient-to-r from-transparent via-white/30 to-transparent skew-x-15 -translate-x-full group-hover:animate-shimmer"></span>
                  Get Free Access Now <ArrowRight className="ml-2" />
                </Link>
              </Button>
              <Button 
                size={isMobile ? "default" : "lg"} 
                variant="secondary" 
                className="bg-white/20 text-white hover:bg-white/30 border-white border-2 font-medium py-6 text-base sm:text-lg"
                asChild
              >
                <Link to="/login">
                  <BookOpen className="mr-2 h-5 w-5" />
                  Browse Resources
                </Link>
              </Button>
            </div>
            
            {/* Trust Elements */}
            <div className="flex flex-wrap items-center gap-2 md:gap-4 bg-white/10 backdrop-blur-md px-4 py-3 rounded-lg border border-white/20 max-w-lg">
              <Badge className="bg-green-500 text-white border-none">Easy Implementation</Badge>
              <div className="w-0.5 h-5 bg-white/20"></div>
              <span className="text-white/90 text-xs md:text-sm">Comprehensive education system for future-ready schools</span>
              <div className="w-0.5 h-5 bg-white/20"></div>
              <span className="text-white/90 text-xs md:text-sm">No credit card required</span>
            </div>
          </div>

          {/* Right Column: Featured Image/Card */}
          <div className="relative hidden lg:block">
            <div className="absolute -top-8 -left-8 w-64 h-64 bg-accent/20 rounded-full blur-3xl"></div>
            <div className="absolute -bottom-8 -right-8 w-64 h-64 bg-primary/20 rounded-full blur-3xl"></div>
            
            {/* Main Feature Card */}
            <div className="relative bg-white p-6 rounded-xl shadow-2xl transform rotate-1 z-20">
              <div className="absolute -top-4 -right-4 bg-primary text-white p-3 rounded-full shadow-lg flex flex-col items-center justify-center">
                <p className="font-bold text-lg leading-none">100%</p>
                <p className="text-xs">Free</p>
              </div>
              
              <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                <GraduationCap className="h-5 w-5 text-primary" />
                Future Ready Implementation System
              </h3>
              
              <div className="space-y-3 mb-5">
                <div className="flex items-start gap-2">
                  <div className="bg-green-100 p-1 rounded-full mt-0.5">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  </div>
                  <p className="text-sm text-gray-700">Step-by-step playbooks with implementation checklists</p>
                </div>
                <div className="flex items-start gap-2">
                  <div className="bg-green-100 p-1 rounded-full mt-0.5">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  </div>
                  <p className="text-sm text-gray-700">Ready-to-use templates for parent communication</p>
                </div>
                <div className="flex items-start gap-2">
                  <div className="bg-green-100 p-1 rounded-full mt-0.5">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  </div>
                  <p className="text-sm text-gray-700">Fully customizable to your school's needs</p>
                </div>
                <div className="flex items-start gap-2">
                  <div className="bg-green-100 p-1 rounded-full mt-0.5">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  </div>
                  <p className="text-sm text-gray-700">Works with limited budgets and resources</p>
                </div>
              </div>
              
              <img 
                src="https://images.unsplash.com/photo-1509062522246-3755977927d7?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80" 
                alt="Educational resources for schools" 
                className="rounded-lg w-full h-[200px] object-cover mb-4"
              />
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-primary" />
                  <span className="text-sm text-gray-600">Implement in 30 days</span>
                </div>
                <Button size="sm" className="bg-primary" asChild>
                  <Link to="/signup">
                    Get Access <ArrowRight className="ml-1 h-3 w-3" />
                  </Link>
                </Button>
              </div>
            </div>
          </div>
          
          {/* Mobile cards */}
          {isMobile && (
            <div className="grid grid-cols-3 gap-2">
              <div className="bg-white p-3 rounded-lg shadow-sm text-center">
                <p className="text-primary text-lg font-bold">100%</p>
                <p className="text-xs text-gray-600 truncate">Free Access</p>
              </div>
              <div className="bg-white p-3 rounded-lg shadow-sm text-center">
                <p className="text-primary text-lg font-bold">Comprehensive</p>
                <p className="text-xs text-gray-600 truncate">Frameworks</p>
              </div>
              <div className="bg-white p-3 rounded-lg shadow-sm text-center">
                <p className="text-primary text-lg font-bold">Complete</p>
                <p className="text-xs text-gray-600 truncate">Resources</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom Wave */}
      <div className="absolute bottom-0 left-0 right-0 h-16 bg-white">
        <svg 
          className="absolute bottom-0 w-full h-16 text-white transform translate-y-1" 
          viewBox="0 0 1440 100" 
          fill="currentColor" 
          preserveAspectRatio="none"
        >
          <path d="M0,50 C240,100 480,0 720,50 C960,100 1200,0 1440,50 L1440,100 L0,100 Z"></path>
        </svg>
      </div>
    </section>
  );
};

export default HomeHero;
