
import React from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Quote } from "lucide-react";

const SuccessStorySection = () => {
  return (
    <section className="py-16 md:py-24 bg-white relative overflow-hidden">
      <div className="absolute top-0 right-0 w-80 h-80 bg-primary/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-accent/5 rounded-full blur-3xl"></div>
      
      <div className="container-custom relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <Badge variant="outline" className="mb-4">Success Story</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            REAL SCHOOL STORY
          </h2>
          <h3 className="text-xl md:text-2xl font-semibold text-primary mb-4">
            From Falling Enrollment to a Waiting List!
          </h3>
          <p className="text-lg text-gray-600">
            "Competition was tough, and student numbers were down. We used the Future Ready positioning, Skills Portfolio for Classes 9-12, 
            and the parent engagement system. The change was amazing! We now have a waiting list for admissions."
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <StatsCard 
            title="More Inquiries"
            value="42%"
          />
          
          <StatsCard
            title="To Start"
            value="<30 Days"
          />
          
          <StatsCard
            title="Extra Cost"
            value="₹0"
          />
        </div>
        
        <Card className="border border-gray-200 bg-gray-50 max-w-3xl mx-auto">
          <CardContent className="p-6 md:p-8">
            <div className="flex items-start gap-4">
              <Quote className="h-10 w-10 text-primary/30 mt-1 flex-shrink-0" />
              <div>
                <p className="text-lg italic text-gray-700 mb-6">
                  "We now have clarity and a system that produces predictable, positive results. Our students are genuinely excited about their future prospects, 
                  and parents are our strongest advocates."
                </p>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-primary/20 text-primary rounded-full flex items-center justify-center font-bold">
                    RS
                  </div>
                  <div>
                    <p className="font-bold">Dr. R. Sharma</p>
                    <p className="text-sm text-gray-600">Principal, Early Adopter School</p>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};

interface StatsCardProps {
  title: string;
  value: string;
}

const StatsCard = ({ title, value }: StatsCardProps) => {
  return (
    <Card className="border border-gray-200 hover:shadow-md transition-all text-center">
      <CardContent className="p-6 pt-6">
        <h3 className="text-3xl md:text-4xl font-bold text-primary mb-2">{value}</h3>
        <p className="text-gray-600">{title}</p>
      </CardContent>
    </Card>
  );
};

export default SuccessStorySection;
