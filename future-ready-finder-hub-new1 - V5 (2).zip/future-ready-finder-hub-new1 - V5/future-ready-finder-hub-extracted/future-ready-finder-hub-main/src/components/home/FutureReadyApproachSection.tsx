
import React from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { GraduationCap, Briefcase, ArrowUpRight, LineChart } from "lucide-react";

const FutureReadyApproachSection = () => {
  return (
    <section className="py-16 bg-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-1/3 h-1/3 bg-gradient-to-bl from-accent/10 to-transparent rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-1/3 h-1/3 bg-gradient-to-tr from-primary/10 to-transparent rounded-full blur-3xl"></div>
      
      <div className="container-custom relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <Badge variant="outline" className="mb-4">Our Solution</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Our Future-Ready Approach: Simple, Powerful, FREE
          </h2>
          <p className="text-lg text-gray-600">
            We don't just talk about problems. We give you a complete, easy-to-use system to prepare your students 
            for success, from Class 2 to Class 12.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          <div className="hidden md:block">
            <img 
              src="https://images.unsplash.com/photo-1509062522246-3755977927d7?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80" 
              alt="Students using technology in a classroom" 
              className="rounded-xl object-cover w-full h-full max-h-[600px] shadow-lg"
            />
          </div>
          
          <div className="space-y-6">
            <ApproachCard 
              icon={GraduationCap}
              title="Holistic Framework (Classes 2-12)"
              description="A comprehensive curriculum integration developing essential 21st-century skills across all age groups."
              badge="Classes 2-12"
              iconBg="bg-blue-100 text-blue-600"
            />
            
            <ApproachCard 
              icon={Briefcase}
              title="High-Income Skill Portfolio"
              description="Step-by-step guidance for students to build impressive portfolios showcasing in-demand skills employers value."
              badge="Classes 8-12"
              iconBg="bg-amber-100 text-amber-600"
            />
            
            <ApproachCard 
              icon={ArrowUpRight}
              title="Financial Freedom Through Skills"
              description="Strategic pathways to achieve financial independence through targeted skill development, not pressuring early income."
              iconBg="bg-emerald-100 text-emerald-600"
            />
            
            <ApproachCard 
              icon={LineChart}
              title="Future-Proofed Career Paths"
              description="Guidance toward careers that will thrive in 20+ years, building entrepreneurial mindsets that create opportunities."
              iconBg="bg-purple-100 text-purple-600"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

interface ApproachCardProps {
  icon: React.FC<{ className?: string }>;
  title: string;
  description: string;
  badge?: string;
  iconBg: string;
}

const ApproachCard = ({ icon: Icon, title, description, badge, iconBg }: ApproachCardProps) => {
  return (
    <Card className="border border-gray-200 hover:shadow-lg transition-all group">
      <CardContent className="p-6 flex gap-4">
        <div className={`${iconBg} w-12 h-12 rounded-full flex items-center justify-center shrink-0`}>
          <Icon className="h-6 w-6" />
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-xl">{title}</h3>
            {badge && (
              <Badge className="bg-gray-200 text-gray-800 hover:bg-gray-300">
                {badge}
              </Badge>
            )}
          </div>
          <p className="text-gray-600">{description}</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default FutureReadyApproachSection;
