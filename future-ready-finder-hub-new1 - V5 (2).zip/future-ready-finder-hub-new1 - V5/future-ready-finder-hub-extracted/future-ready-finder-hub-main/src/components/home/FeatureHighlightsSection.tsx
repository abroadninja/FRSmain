
import React from "react";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, FileText, BookOpen, Users, Star, Layout } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const FeatureHighlightsSection = () => {
  return (
    <section className="py-20 bg-white relative">
      <div className="container-custom">
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-2">Available Resources</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Free Resources For <span className="text-primary">School Improvement</span>
          </h2>
          <p className="text-gray-600 max-w-3xl mx-auto text-lg">
            Access our collection of educational resources designed to help schools enhance 
            their teaching approach and create more engaging learning environments.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredItems.map((item, index) => (
            <FeatureCard key={index} {...item} />
          ))}
        </div>

        <div className="mt-12 text-center">
          <Button size="lg" className="bg-primary hover:bg-primary/90 text-white" asChild>
            <Link to="/signup">Get Free Access</Link>
          </Button>
          <p className="mt-3 text-sm text-gray-500">No credit card required. Access our free resources immediately.</p>
        </div>
      </div>
      
      {/* Decorative elements */}
      <div className="absolute -bottom-10 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl"></div>
      <div className="absolute top-20 -left-10 w-72 h-72 bg-accent/5 rounded-full blur-3xl"></div>
    </section>
  );
};

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  highlights: string[];
  bgColor: string;
  linkUrl: string;
}

const FeatureCard = ({ icon, title, description, highlights, bgColor, linkUrl }: FeatureCardProps) => {
  return (
    <div className="bg-white border border-gray-100 rounded-xl shadow-sm hover:shadow-md transition-all p-6 group">
      <div className={`${bgColor} rounded-full p-3 inline-flex mb-5 group-hover:scale-110 transition-transform`}>
        {icon}
      </div>
      
      <h3 className="text-xl font-bold mb-3">{title}</h3>
      <p className="text-gray-600 mb-5">{description}</p>
      
      <ul className="space-y-2 mb-4">
        {highlights.map((highlight, idx) => (
          <li key={idx} className="flex items-start">
            <span className="mr-2 mt-1 text-primary">
              <CheckCircle className="h-4 w-4" />
            </span>
            <span className="text-gray-700 text-sm">{highlight}</span>
          </li>
        ))}
      </ul>
      
      <Link to={linkUrl} className="text-primary hover:underline text-sm font-medium inline-flex items-center">
        Explore Resources
        <svg className="w-4 h-4 ml-1" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
        </svg>
      </Link>
    </div>
  );
};

const featuredItems = [
  {
    icon: <BookOpen className="w-6 h-6 text-primary" />,
    title: "Educational Guides",
    description: "Access helpful guides to enhance your educational approach",
    highlights: [
      "Teaching strategy resources",
      "Classroom management tips",
      "Educational templates",
      "Lesson planning guides"
    ],
    bgColor: "bg-primary/10",
    linkUrl: "/implementation-guides"
  },
  {
    icon: <Users className="w-6 h-6 text-secondary" />,
    title: "Community Resources",
    description: "Materials to help engage parents and create a supportive community",
    highlights: [
      "Parent communication templates",
      "Community event ideas",
      "Home-school connection guides",
      "Parent involvement strategies"
    ],
    bgColor: "bg-secondary/10",
    linkUrl: "/resources?type=community"
  },
  {
    icon: <FileText className="w-6 h-6 text-accent" />,
    title: "Teacher Materials",
    description: "Practical resources to support teachers in the classroom",
    highlights: [
      "Classroom activities",
      "Assessment frameworks",
      "Professional development guides",
      "Teaching aids"
    ],
    bgColor: "bg-accent/10",
    linkUrl: "/resources?type=teacher"
  },
  {
    icon: <Layout className="w-6 h-6 text-emerald-600" />,
    title: "Curriculum Resources",
    description: "Materials to enhance your school's curriculum approach",
    highlights: [
      "Grade-specific resources",
      "Subject-focused materials",
      "Curriculum planning tools",
      "Assessment guides"
    ],
    bgColor: "bg-emerald-100",
    linkUrl: "/resources?type=curriculum"
  },
  {
    icon: <Star className="w-6 h-6 text-amber-600" />,
    title: "School Improvement Ideas",
    description: "Practical suggestions to enhance your school environment",
    highlights: [
      "School culture resources",
      "Administrative tools",
      "Improvement planning guides",
      "Success measurement tools"
    ],
    bgColor: "bg-amber-100",
    linkUrl: "/resources?type=improvement"
  },
  {
    icon: <Users className="w-6 h-6 text-blue-600" />,
    title: "Community Building",
    description: "Create a positive school culture with these resources",
    highlights: [
      "Event planning ideas",
      "Community engagement strategies",
      "Collaborative projects",
      "School culture builders"
    ],
    bgColor: "bg-blue-100",
    linkUrl: "/resources?type=culture"
  }
];

export default FeatureHighlightsSection;
