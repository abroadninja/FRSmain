
import React from "react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { useIsMobile } from "@/hooks/use-mobile";
import { ArrowRight, CheckCircle, GraduationCap, Star } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const Hero = () => {
  const isMobile = useIsMobile();
  
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-blue-700 to-indigo-800 text-white">
      {/* Background pattern */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDM0YzAtMi4yIDEuOC00IDQtNHM0IDEuOCA0IDQtMS44IDQtNCA0LTQtMS44LTQtNHoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-50"></div>
      
      <div className="container mx-auto px-4 py-16 md:py-24 lg:py-32 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          {/* Left column: Content */}
          <div className="w-full lg:w-1/2 text-center lg:text-left">
            <Badge variant="outline" className="border-white/30 text-white mb-4 bg-white/10">Proven School Growth System</Badge>
            
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6 text-white">
              Make Your School Stand Out With Future-Ready Students — At Zero Cost
            </h1>
            
            <p className="text-lg md:text-xl text-white/90 mb-8 max-w-2xl mx-auto lg:mx-0">
              Our proven framework equips schools with the tools to develop future-ready students, 
              increase enrollment, and build thriving school communities — 
              designed to work with the resources you already have.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8 text-left max-w-xl mx-auto lg:mx-0">
              {[
                "Complete implementation playbooks",
                "Future-ready skills development framework",
                "Parent engagement strategies that work",
                "Enrollment growth without expensive marketing"
              ].map((feature, index) => (
                <div key={index} className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-yellow-300 flex-shrink-0 mt-0.5" />
                  <span className="text-white/90">{feature}</span>
                </div>
              ))}
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button 
                size={isMobile ? "default" : "lg"} 
                className="bg-white text-blue-700 hover:bg-white/90 font-semibold shadow-lg px-6 py-6"
                asChild
              >
                <Link to="/signup">
                  Get Free Access <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              
              <Button 
                size={isMobile ? "default" : "lg"} 
                variant="outline"
                className="border-white/40 bg-transparent text-white hover:bg-white/10 px-6 py-6"
                asChild
              >
                <a href="http://www.membership-page1.futurereadyschools.com" target="_blank" rel="noopener noreferrer">
                  Membership Plans
                </a>
              </Button>
            </div>
            
            <div className="mt-8 flex items-center gap-2 justify-center lg:justify-start text-white/80">
              <div className="flex">
                {[1, 2, 3, 4, 5].map((_, index) => (
                  <Star key={index} className="h-4 w-4 fill-yellow-300 text-yellow-300" />
                ))}
              </div>
              <span className="text-sm">Comprehensive education system for future-ready schools — No credit card needed</span>
            </div>
          </div>
          
          {/* Right column: Image */}
          {!isMobile && (
            <div className="w-full lg:w-1/2 relative">
              <div className="absolute -top-6 -right-6 w-full h-full bg-blue-500 rounded-xl transform rotate-3 opacity-50"></div>
              <div className="relative z-10 rounded-xl overflow-hidden shadow-2xl border-4 border-white/20">
                <img 
                  src="https://images.unsplash.com/photo-1577896851231-70ef18881754?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80" 
                  alt="Students in an engaging learning environment" 
                  className="w-full h-auto"
                />
                
                {/* Overlay gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-blue-900/70 via-transparent to-transparent"></div>
                
                {/* Stats overlay */}
                <div className="absolute bottom-0 left-0 w-full p-6">
                  <div className="grid grid-cols-3 gap-3">
                    <div className="text-center bg-white/90 backdrop-blur-sm rounded-lg p-2 shadow-lg">
                      <p className="text-lg font-bold text-blue-800">100%</p>
                      <p className="text-xs text-blue-700">Free Access</p>
                    </div>
                    <div className="text-center bg-white/90 backdrop-blur-sm rounded-lg p-2 shadow-lg">
                      <p className="text-lg font-bold text-blue-800">Complete</p>
                      <p className="text-xs text-blue-700">Resources</p>
                    </div>
                    <div className="text-center bg-white/90 backdrop-blur-sm rounded-lg p-2 shadow-lg">
                      <p className="text-lg font-bold text-blue-800">Comprehensive</p>
                      <p className="text-xs text-blue-700">Frameworks</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Completely removing mobile cards to prevent overflow */}
        </div>
      </div>
    </section>
  );
};

export default Hero;
