
import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, GraduationCap, Rocket, Users, Award, CheckCircle } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

const TransformationSection = () => {
  const isMobile = useIsMobile();
  
  return (
    <section className="py-16 md:py-20 bg-gray-50 relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-72 h-72 bg-accent/5 rounded-full blur-3xl"></div>
      
      <div className="container-custom relative z-10">
        <div className="text-center mb-10 md:mb-16 max-w-3xl mx-auto">
          <Badge variant="outline" className="mb-3 md:mb-4">The Triple-Threat Approach</Badge>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-3 md:mb-4">Triple Your School's Value & Double Enrollment</h2>
          <p className="text-base md:text-xl text-gray-600">
            While other schools struggle with outdated methods, our step-by-step implementation systems 
            help you build future-ready education, increase enrollment, and create thriving parent-teacher communities.
          </p>
        </div>
        
        {/* Main transformation cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
          <TransformationCard
            icon={<GraduationCap size={isMobile ? 24 : 28} className="text-primary" />}
            title="Future-Ready Curriculum"
            color="primary"
            description="Implement our proven framework that prepares students for the evolving future workplace – not yesterday's economy."
            features={[
              "Future-Skills Integration",
              "Step-by-Step Implementation",
              "Class 2-12 Framework"
            ]}
          />
          
          <TransformationCard
            icon={<Rocket size={isMobile ? 24 : 28} className="text-secondary" />}
            title="Enrollment Growth"
            color="secondary"
            description="Deploy our immediate-impact positioning system that turns your school's hidden strengths into inquiry magnets."
            features={[
              "Proven Positioning Strategies",
              "Parent Engagement Systems",
              "Frictionless Enrollment Process"
            ]}
          />
          
          <TransformationCard
            icon={<Users size={isMobile ? 24 : 28} className="text-accent" />}
            title="Community Building"
            color="accent"
            description="Create thriving ecosystems that connect parents, teachers and students – boosting retention and referrals."
            features={[
              "Parent Loyalty Programs",
              "Communication Templates",
              "Community Event Frameworks"
            ]}
          />
        </div>
        
        {/* Value multiplier section */}
        <div className="mt-12 md:mt-16 bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
          <h3 className="text-xl md:text-2xl font-bold text-center mb-6">The "Value Multiplier" Implementation System</h3>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <ValueStep 
              number="1"
              title="Complete Playbooks" 
              description="Step-by-step implementation guides requiring minimal effort"
            />
            <ValueStep 
              number="2"
              title="Ready Templates" 
              description="Plug-and-play documents, forms, and materials"
            />
            <ValueStep 
              number="3"
              title="Future Skills" 
              description="High-income skill portfolio building for classes 8-12"
            />
            <ValueStep 
              number="4"
              title="Community Systems" 
              description="Create thriving parent-teacher-student ecosystems"
            />
          </div>
        </div>
        
        <div className="mt-10 md:mt-16 text-center">
          <Button 
            size={isMobile ? "default" : "lg"} 
            className="bg-gradient-to-r from-primary to-secondary text-white hover:opacity-90 shadow-md"
            asChild
          >
            <Link to="/signup">
              Get Free Access To All Resources <ArrowRight className="ml-2" />
            </Link>
          </Button>
          <p className="text-gray-500 text-xs sm:text-sm mt-3 md:mt-4">No credit card required. Lifetime free access to core systems.</p>
        </div>
      </div>
    </section>
  );
};

const TransformationCard = ({ 
  icon, 
  title, 
  color, 
  description, 
  features 
}: { 
  icon: React.ReactNode;
  title: string;
  color: "primary" | "secondary" | "accent" | "emerald";
  description: string;
  features: string[];
}) => {
  const colorClasses = {
    primary: {
      border: "hover:border-primary/50",
      bg: "bg-primary/10",
      stripe: "bg-primary"
    },
    secondary: {
      border: "hover:border-secondary/50",
      bg: "bg-secondary/10", 
      stripe: "bg-secondary"
    },
    accent: {
      border: "hover:border-accent/50",
      bg: "bg-accent/10",
      stripe: "bg-accent"
    },
    emerald: {
      border: "hover:border-emerald-500/50",
      bg: "bg-emerald-500/10",
      stripe: "bg-emerald-500"
    }
  };
  
  return (
    <div className={`rounded-xl border border-gray-200 ${colorClasses[color].border} bg-white shadow-sm transition-all duration-300 overflow-hidden hover:shadow-md hover:-translate-y-1 group h-full`}>
      <div className={`h-1.5 w-full ${colorClasses[color].stripe}`}></div>
      <div className="p-5 md:p-6">
        <div className={`${colorClasses[color].bg} p-3 md:p-4 rounded-full w-12 h-12 md:w-14 md:h-14 flex items-center justify-center mb-4 md:mb-6 group-hover:scale-110 transition-transform`}>
          {icon}
        </div>
        <h3 className="text-lg md:text-xl font-bold mb-2 md:mb-3">{title}</h3>
        <p className="text-gray-600 text-sm md:text-base mb-4 md:mb-5">
          {description}
        </p>
        <ul className="space-y-1 md:space-y-2">
          {features.map((feature, idx) => (
            <li key={idx} className="flex items-center text-xs md:text-sm text-gray-600">
              <CheckCircle size={14} className="mr-2 text-gray-400 flex-shrink-0" />
              {feature}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

const ValueStep = ({ number, title, description }: { number: string; title: string; description: string }) => {
  return (
    <div className="flex items-start gap-3">
      <div className="flex-shrink-0 bg-primary/10 text-primary font-bold rounded-full w-8 h-8 flex items-center justify-center">
        {number}
      </div>
      <div>
        <h4 className="font-semibold text-gray-900">{title}</h4>
        <p className="text-xs md:text-sm text-gray-600">{description}</p>
      </div>
    </div>
  );
};

export default TransformationSection;
