
import React from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { Info } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

const StatsBanner = () => {
  const isMobile = useIsMobile();
  
  return (
    <div className="bg-white py-4 md:py-6 border-b border-gray-100">
      <div className="container-custom">
        <div className={`grid ${isMobile ? 'grid-cols-2 gap-3 text-center' : 'grid-cols-4 gap-4'}`}>
          <StatItem 
            text="Practical Implementation Framework" 
            tooltip="Our step-by-step system for school transformation"
            highlight={true}
          />
          <StatItem 
            text="Works with Limited Budgets" 
            tooltip="All implementation guides and resources are completely free"
          />
          <StatItem 
            text="Customizable to Your School" 
            tooltip="Adaptable for schools of any size and resource level"
            highlight={true}
          />
          <StatItem 
            text="Future-Ready Skills Development" 
            tooltip="Preparing students with tomorrow's essential skills"
            highlight={true}
          />
        </div>
      </div>
    </div>
  );
};

interface StatItemProps {
  text: string;
  tooltip?: string;
  highlight?: boolean;
}

const StatItem = ({ text, tooltip, highlight = false }: StatItemProps) => {
  return (
    <TooltipProvider>
      <div className="flex flex-col items-center justify-center">
        <div className="flex items-center gap-1 justify-center">
          <p className={`text-sm sm:text-base font-bold ${highlight ? 'text-primary' : 'text-gray-900'}`}>
            {text}
          </p>
          {tooltip && (
            <Tooltip>
              <TooltipTrigger asChild>
                <Info className="h-3 w-3 text-gray-400 cursor-help" />
              </TooltipTrigger>
              <TooltipContent className="max-w-xs">
                <p>{tooltip}</p>
              </TooltipContent>
            </Tooltip>
          )}
        </div>
      </div>
    </TooltipProvider>
  );
};

export default StatsBanner;
