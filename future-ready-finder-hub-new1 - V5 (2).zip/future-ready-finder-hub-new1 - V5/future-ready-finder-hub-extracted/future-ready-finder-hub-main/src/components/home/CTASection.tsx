
import React from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, Check } from "lucide-react";

const CTASection = () => {
  const isMobile = useIsMobile();
  
  return (
    <section className="py-16 md:py-24 bg-gradient-to-br from-primary via-secondary to-accent text-white relative overflow-hidden">
      {/* Background patterns */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRjMC0yLjIgMS44LTQgNC00czQgMS44IDQgNC0xLjggNC00IDQtNC0xLjgtNC00eiIvPjwvZz48L2c+PC9zdmc+')] opacity-20"></div>
      
      <div className="container-custom relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Transform Your School? It's Easy & FREE!
          </h2>
          <p className="text-xl md:text-2xl mb-8 text-white/90">
            Don't let your school fall behind. Build a brighter future for your students with our comprehensive system.
          </p>
          
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white/10 backdrop-blur-sm p-5 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Check className="h-5 w-5 text-yellow-300" />
                <h3 className="font-bold text-lg">100% FREE Access</h3>
              </div>
              <p className="text-white/80">No hidden charges. Ever.</p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm p-5 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Check className="h-5 w-5 text-yellow-300" />
                <h3 className="font-bold text-lg">Fast, Visible Results</h3>
              </div>
              <p className="text-white/80">See improvements quickly.</p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm p-5 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Check className="h-5 w-5 text-yellow-300" />
                <h3 className="font-bold text-lg">Zero Risk, All Reward</h3>
              </div>
              <p className="text-white/80">Only positive changes for your school.</p>
            </div>
          </div>
          
          <Button
            size={isMobile ? "default" : "lg"}
            className="bg-white text-primary hover:bg-white/90 transition-all font-bold shadow-lg py-6 px-8 text-lg relative overflow-hidden group"
            asChild
          >
            <Link to="/signup">
              <span className="absolute inset-0 w-1/2 bg-gradient-to-r from-transparent via-white/30 to-transparent skew-x-15 -translate-x-full group-hover:animate-shimmer"></span>
              CLICK HERE FOR YOUR FREE SYSTEM! <ArrowRight className="ml-2" />
            </Link>
          </Button>
          
          <p className="mt-6 text-white/80">
            Start today. Give your students the future they deserve.
          </p>
          
          <p className="text-sm mt-10 text-white/70">
            Fully customizable to adapt to your school's specific needs and budget constraints.
          </p>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
