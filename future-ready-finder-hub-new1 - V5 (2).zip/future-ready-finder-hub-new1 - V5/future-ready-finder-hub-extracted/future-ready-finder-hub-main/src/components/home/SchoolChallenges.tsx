
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BookOpen, DollarSign, Users, GraduationCap } from "lucide-react";

const SchoolChallenges = () => {
  return (
    <section className="py-16 md:py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <Badge variant="outline" className="mb-4">Common Challenges</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Today's Schools Face Real Challenges
          </h2>
          <p className="text-lg text-gray-600">
            Schools today must navigate multiple challenges while preparing students for a rapidly changing future.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          <ChallengeCard 
            icon={BookOpen}
            title="Skills Gap"
            description="Traditional curriculum doesn't align with rapidly evolving workplace demands."
            iconColor="text-blue-600"
            iconBg="bg-blue-100"
          />
          
          <ChallengeCard 
            icon={Users}
            title="Enrollment Pressure"
            description="Schools struggle to differentiate in competitive education markets."
            iconColor="text-violet-600"
            iconBg="bg-violet-100"
          />
          
          <ChallengeCard 
            icon={DollarSign}
            title="Resource Constraints"
            description="Limited budgets hinder implementation of forward-thinking programs."
            iconColor="text-amber-600"
            iconBg="bg-amber-100"
          />
          
          <ChallengeCard 
            icon={GraduationCap}
            title="Future Unprepared"
            description="Students graduate lacking critical skills for tomorrow's economy."
            iconColor="text-emerald-600"
            iconBg="bg-emerald-100"
          />
        </div>
      </div>
    </section>
  );
};

interface ChallengeCardProps {
  icon: React.FC<{ className?: string }>;
  title: string;
  description: string;
  iconColor: string;
  iconBg: string;
}

const ChallengeCard = ({ icon: Icon, title, description, iconColor, iconBg }: ChallengeCardProps) => {
  return (
    <Card className="border border-gray-200 hover:shadow-md transition-all duration-300">
      <CardContent className="p-6 pt-6">
        <div className={`${iconBg} w-12 h-12 rounded-full flex items-center justify-center mb-4`}>
          <Icon className={`h-6 w-6 ${iconColor}`} />
        </div>
        <h3 className="font-bold text-xl mb-2">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </CardContent>
    </Card>
  );
};

export default SchoolChallenges;
