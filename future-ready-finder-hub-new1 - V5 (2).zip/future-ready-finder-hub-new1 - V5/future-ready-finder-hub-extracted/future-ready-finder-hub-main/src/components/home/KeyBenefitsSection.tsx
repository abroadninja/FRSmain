
import React from "react";
import { TrendingUp, Users, Check, BarChart2, Award, Star, Clock } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useIsMobile } from "@/hooks/use-mobile";

const KeyBenefitsSection = () => {
  const isMobile = useIsMobile();
  
  return (
    <section className="py-16 md:py-24 bg-gray-50">
      <div className="container-custom">
        <div className="text-center mb-12">
          <Badge variant="outline" className="mb-3">THE BENEFITS</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">The Three Core Benefits For Your School</h2>
          <p className="text-base md:text-lg text-gray-600 max-w-3xl mx-auto">
            Our system delivers three key outcomes that transform your school from the inside out 
            while requiring minimal resources and implementation effort.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-10">
          <BenefitCard 
            icon={<TrendingUp className="h-6 w-6 text-white" />}
            title="Enrollment Growth"
            description="Transform your school's positioning to stand out in a crowded market and attract more quality applications"
            metrics={[
              { value: "22%", label: "Average inquiry increase" },
              { value: "90", label: "Days to see results" }
            ]}
            features={[
              "Differentiation strategy",
              "Streamlined admissions",
              "Word-of-mouth system"
            ]}
            color="primary"
          />
          
          <BenefitCard 
            icon={<Users className="h-6 w-6 text-white" />}
            title="Parent Satisfaction"
            description="Build a thriving community of engaged parents who become your best advocates and referral sources"
            metrics={[
              { value: "35%", label: "Increase in engagement" },
              { value: "87%", label: "Parent satisfaction" }
            ]}
            features={[
              "Communication framework",
              "Community-building system",
              "Parent education resources"
            ]}
            color="secondary"
          />
          
          <BenefitCard 
            icon={<Award className="h-6 w-6 text-white" />}
            title="Student Readiness"
            description="Prepare your students for the future economy with practical skills development and career preparation"
            metrics={[
              { value: "76%", label: "Career path confidence" },
              { value: "12+", label: "High-income skills" }
            ]}
            features={[
              "Future skills portfolio",
              "Project-based learning",
              "Career exploration system"
            ]}
            color="accent"
          />
        </div>
        
        <div className="mt-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 max-w-5xl mx-auto text-center">
          <ImplementationStat 
            icon={<Clock />}
            value="30 Days"
            label="Typical implementation time"
          />
          <ImplementationStat 
            icon={<Check />}
            value="Zero Cost"
            label="No budget required to start"
          />
          <ImplementationStat 
            icon={<BarChart2 />}
            value="90 Days"
            label="Average time to see results"
          />
          <ImplementationStat 
            icon={<Star />}
            value="100%"
            label="Success rate for implementation"
          />
        </div>
      </div>
    </section>
  );
};

interface BenefitCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  metrics: Array<{value: string, label: string}>;
  features: string[];
  color: "primary" | "secondary" | "accent";
}

const BenefitCard = ({ icon, title, description, metrics, features, color }: BenefitCardProps) => {
  const colorClasses = {
    primary: {
      bg: "bg-primary",
      light: "bg-primary/10",
      text: "text-primary"
    },
    secondary: {
      bg: "bg-secondary",
      light: "bg-secondary/10",
      text: "text-secondary"
    },
    accent: {
      bg: "bg-accent",
      light: "bg-accent/10",
      text: "text-accent"
    }
  };
  
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-all h-full flex flex-col">
      <div className="p-6 pb-4">
        <div className={`${colorClasses[color].bg} w-12 h-12 rounded-lg flex items-center justify-center mb-4`}>
          {icon}
        </div>
        <h3 className="text-xl font-bold mb-2">{title}</h3>
        <p className="text-gray-600 mb-4">{description}</p>
        
        <div className="grid grid-cols-2 gap-3 mb-5">
          {metrics.map((metric, idx) => (
            <div key={idx} className={`${colorClasses[color].light} p-3 rounded-lg text-center`}>
              <div className={`text-2xl font-bold ${colorClasses[color].text}`}>{metric.value}</div>
              <div className="text-sm text-gray-600">{metric.label}</div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="mt-auto border-t border-gray-100 p-5">
        <h4 className="font-medium text-gray-900 mb-3">Key Components:</h4>
        <ul className="space-y-2">
          {features.map((feature, idx) => (
            <li key={idx} className="flex items-center text-sm">
              <Check className={`h-4 w-4 mr-2 ${colorClasses[color].text}`} />
              <span className="text-gray-700">{feature}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

interface ImplementationStatProps {
  icon: React.ReactNode;
  value: string;
  label: string;
}

const ImplementationStat = ({ icon, value, label }: ImplementationStatProps) => {
  return (
    <div className="bg-white p-4 rounded-lg border border-gray-200">
      <div className="bg-primary/10 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3">
        <div className="text-primary">
          {icon}
        </div>
      </div>
      <div className="text-xl font-bold text-gray-900">{value}</div>
      <div className="text-sm text-gray-600">{label}</div>
    </div>
  );
};

export default KeyBenefitsSection;
