
import React from "react";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Star, Settings, BookOpen, Wallet } from "lucide-react";

const BenefitsSection = () => {
  return (
    <section className="py-24 bg-white relative">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent"></div>
      
      <div className="container-custom relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="order-2 lg:order-1">
            <div className="relative">
              <div className="relative z-10 rounded-2xl overflow-hidden shadow-2xl">
                <img 
                  src="https://images.unsplash.com/photo-1522071820081-009f0129c71c" 
                  alt="Thriving school community" 
                  className="w-full h-auto"
                />
                
                {/* Overlay gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                
                {/* Testimonial overlay */}
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <p className="text-white text-lg font-medium">
                    "The transformation in our school has been remarkable. Our students are now truly future-ready."
                  </p>
                  <div className="flex items-center mt-2">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                    <span className="text-white/90 text-sm ml-2">- Principal, Delhi Public School</span>
                  </div>
                </div>
              </div>
              
              {/* Decorative elements */}
              <div className="absolute -bottom-6 -right-6 bg-accent p-4 rounded-lg shadow-lg text-white z-20">
                <div className="flex items-center">
                  <CheckCircle className="w-5 h-5 mr-2" />
                  <div>
                    <p className="text-sm font-medium">School-Tested System</p>
                    <p className="text-xs">Proven Results</p>
                  </div>
                </div>
              </div>
              
              <div className="absolute -z-10 -bottom-8 -right-8 w-64 h-64 bg-primary/20 rounded-full blur-3xl"></div>
              <div className="absolute -z-10 -top-8 -left-8 w-64 h-64 bg-accent/20 rounded-full blur-3xl"></div>
            </div>
          </div>
          
          <div className="space-y-6 order-1 lg:order-2">
            <Badge variant="outline" className="mb-2">Member Benefits</Badge>
            <h2 className="text-3xl md:text-4xl font-bold">Everything You Need, <span className="text-primary">Completely Free</span></h2>
            <p className="text-xl text-gray-600">
              Our free membership provides your school with everything needed to implement future-ready education and build thriving communities that prepare students for real-world success.
            </p>
            
            <div className="bg-yellow-50 border border-yellow-100 p-4 rounded-lg">
              <p className="text-sm text-yellow-800">
                <span className="font-semibold">🔹 Easy Implementation:</span> All our resources work with limited budgets and can be customized to fit your school's unique needs and resources.
              </p>
            </div>
            
            <div className="grid grid-cols-1 gap-4 mt-8">
              <BenefitItem 
                title="Complete Implementation Framework" 
                description="Step-by-step playbooks for transforming your curriculum, teaching methods, and community engagement with measurable outcomes."
                icon={Settings}
              />
              
              <BenefitItem 
                title="8th-12th Grade Skill-Building Programs" 
                description="Ready-to-implement programs that develop high-income skills starting from middle school years — skills employers actually pay for."
                icon={BookOpen}
              />
              
              <BenefitItem 
                title="Community Building Tools" 
                description="Systems to create synergy between parents, teachers, students, and alumni for holistic growth and lasting impact."
              />
              
              <BenefitItem 
                title="Weekly EdTech Updates" 
                description="Stay informed about the latest education technology trends and implement them in your school with guided assistance."
              />
              
              <BenefitItem 
                title="Custom Implementation Webapp" 
                description="Access our exclusive webapp with all playbooks, resources, and tools in one place — designed for busy educators."
                icon={Wallet}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

interface BenefitItemProps {
  title: string;
  description: string;
  icon?: React.ElementType;
}

const BenefitItem = ({ title, description, icon: Icon = CheckCircle }: BenefitItemProps) => {
  return (
    <div className="flex items-start p-4 rounded-lg border border-gray-100 hover:border-primary/30 bg-white shadow-sm hover:shadow-md transition-all">
      <div className="bg-primary/10 p-2 rounded-full mr-4">
        <Icon className="h-5 w-5 text-primary" />
      </div>
      <div>
        <h3 className="font-bold text-gray-900">{title}</h3>
        <p className="text-gray-600 text-sm mt-1">{description}</p>
      </div>
    </div>
  );
};

export default BenefitsSection;
