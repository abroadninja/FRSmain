
import React from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowUpRight, GraduationCap, Star, BookOpen } from "lucide-react";

const BeyondTraditionalSection = () => {
  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container-custom">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <Badge className="mb-4">Beyond Traditional Education</Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              We Go Beyond Regular School Programs
            </h2>
            <p className="text-lg text-gray-600 mb-8">
              Regular schools provide things like career counseling, IIT/NEET foundations, arts, and dance classes. 
              We help your school go a step further by actually preparing students for a secure, successful, and 
              financially independent future.
            </p>
            
            <div className="space-y-6">
              <ComparisonItem 
                title="Traditional Approach"
                items={[
                  "Standard career counseling limited to conventional paths",
                  "Fixed curriculum with limited real-world application",
                  "Focus on academic achievements alone",
                  "Competitive exam preparation only"
                ]}
                cardClass="border-gray-200"
                iconBg="bg-gray-100"
                iconColor="text-gray-600"
              />
              
              <ComparisonItem 
                title="Our Future Ready Approach"
                items={[
                  "High income skill portfolio building guidance",
                  "Achieving early financial independence through strategic skill development",
                  "Guidance on discovering and planning for high-income generating paths",
                  "Future-proof career exploration with entrepreneurial mindset development"
                ]}
                cardClass="border-primary/20 bg-primary/5"
                iconBg="bg-primary/20"
                iconColor="text-primary"
                highlight={true}
              />
            </div>
          </div>
          
          <div className="space-y-6">
            <BenefitCard 
              icon={GraduationCap}
              title="Beyond Standard Curriculum"
              description="While other schools focus on conventional education, we provide frameworks that develop future-relevant skills alongside academics."
              iconBg="bg-blue-100 text-blue-600"
            />
            
            <BenefitCard 
              icon={ArrowUpRight}
              title="Long-term Financial Success"
              description="Instead of just preparing for the next exam, we help students build skillsets that lead to long-term financial independence and success."
              iconBg="bg-amber-100 text-amber-600"
            />
            
            <BenefitCard 
              icon={BookOpen}
              title="Practical Implementation"
              description="Easy to implement with your existing resources and budget constraints. Our system works for schools of any size."
              iconBg="bg-emerald-100 text-emerald-600"
            />
            
            <BenefitCard 
              icon={Star}
              title="Fully Customizable"
              description="All resources can be adapted to fit your school's unique needs, existing programs, and available resources."
              iconBg="bg-purple-100 text-purple-600"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

interface ComparisonItemProps {
  title: string;
  items: string[];
  cardClass: string;
  iconBg: string;
  iconColor: string;
  highlight?: boolean;
}

const ComparisonItem = ({ title, items, cardClass, iconBg, iconColor, highlight = false }: ComparisonItemProps) => {
  return (
    <Card className={`${cardClass}`}>
      <CardContent className="p-5">
        <h3 className={`text-lg font-bold mb-4 ${highlight ? 'text-primary' : 'text-gray-800'}`}>{title}</h3>
        <ul className="space-y-3">
          {items.map((item, index) => (
            <li key={index} className="flex items-start gap-3">
              <div className={`${iconBg} p-1 rounded-full mt-0.5`}>
                <Star className={`h-3 w-3 ${iconColor}`} />
              </div>
              <span className="text-sm">{item}</span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
};

interface BenefitCardProps {
  icon: React.FC<{ className?: string }>;
  title: string;
  description: string;
  iconBg: string;
}

const BenefitCard = ({ icon: Icon, title, description, iconBg }: BenefitCardProps) => {
  return (
    <Card className="border border-gray-200 hover:shadow-md transition-all">
      <CardContent className="p-5 flex gap-4">
        <div className={`${iconBg} w-10 h-10 rounded-full flex items-center justify-center shrink-0`}>
          <Icon className="h-5 w-5" />
        </div>
        <div>
          <h3 className="font-bold text-lg mb-1">{title}</h3>
          <p className="text-sm text-gray-600">{description}</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default BeyondTraditionalSection;
