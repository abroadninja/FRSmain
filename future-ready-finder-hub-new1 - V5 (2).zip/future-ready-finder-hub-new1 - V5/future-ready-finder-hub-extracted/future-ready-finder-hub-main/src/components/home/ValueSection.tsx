
import React from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { BookOpen, Clock, Calendar } from "lucide-react";

const ValueSection = () => {
  return (
    <section className="py-16 md:py-24 bg-gray-50">
      <div className="container-custom">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <Badge variant="outline" className="mb-4">Free Forever</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Why Do We Offer All This For FREE?
          </h2>
          <p className="text-lg text-gray-600">
            Our mission is simple: to help every school become future-ready. We've invested the time and effort to create 
            proven systems. Now, we give them to you, so you can save money and achieve results faster.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          <ValueCard
            icon={BookOpen}
            title="Save ₹2-5 Lakhs"
            description="Avoid high costs of education consultants."
            iconColor="bg-blue-100 text-blue-600"
          />
          
          <ValueCard
            icon={Clock}
            title="Save 100+ Hours"
            description="No need for long research. Our resources are ready."
            iconColor="bg-amber-100 text-amber-600"
          />
          
          <ValueCard
            icon={Calendar}
            title="Save 6-12 Months"
            description="Use our curriculum frameworks and start new programs quickly."
            iconColor="bg-emerald-100 text-emerald-600"
          />
        </div>
        
        <div className="text-center mt-8 text-lg">
          <p className="font-medium">
            You get a complete, tested system without any risk or cost.{" "}
            <span className="text-primary">That's our promise.</span>
          </p>
          <p className="text-gray-600 mt-2">
            Works exceptionally well even with limited budgets and resources.
          </p>
        </div>
      </div>
    </section>
  );
};

interface ValueCardProps {
  icon: React.FC<{ className?: string }>;
  title: string;
  description: string;
  iconColor: string;
}

const ValueCard = ({ icon: Icon, title, description, iconColor }: ValueCardProps) => {
  return (
    <Card className="border border-gray-200 hover:shadow-md transition-all text-center">
      <CardContent className="p-6 pt-6">
        <div className={`${iconColor} w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4`}>
          <Icon className="h-7 w-7" />
        </div>
        <h3 className="font-bold text-2xl mb-2">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </CardContent>
    </Card>
  );
};

export default ValueSection;
