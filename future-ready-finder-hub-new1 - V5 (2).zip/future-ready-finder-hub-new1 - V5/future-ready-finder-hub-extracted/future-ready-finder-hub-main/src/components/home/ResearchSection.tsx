
import React from "react";
import { SearchCheck, ArrowRight, BarChart3, ScrollText, Lightbulb, Globe, BookOpen, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { useIsMobile } from "@/hooks/use-mobile";

const ResearchSection = () => {
  const isMobile = useIsMobile();
  
  return (
    <section className="py-16 lg:py-20 bg-gradient-to-r from-gray-50 to-gray-100">
      <div className="container-custom">
        <div className="text-center mb-12">
          <Badge className="bg-primary/10 text-primary mb-3">THE VALUE DRIVER</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">We Do The Research So You Don't Have To</h2>
          <p className="text-base md:text-lg text-gray-700 max-w-3xl mx-auto">
            Instead of wasting <span className="font-semibold">hundreds of hours and lakhs of rupees</span> researching 
            educational trends and strategies, we deliver ready-to-implement systems that produce 
            immediate results for your school.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 lg:gap-8 mb-12">
          <ResearchCard 
            icon={<SearchCheck className="h-7 w-7 text-white" />}
            title="Education Trends Research"
            description="We analyze global education innovations and translate them into practical strategies for Indian schools"
          />
          <ResearchCard 
            icon={<BarChart3 className="h-7 w-7 text-white" />}
            title="Growth Strategy Research"
            description="We've tested what actually works for school growth in the Indian education market - not theory, but results"
          />
          <ResearchCard 
            icon={<ScrollText className="h-7 w-7 text-white" />}
            title="Step-by-Step Implementation"
            description="We transform complex research into simple, easy-to-follow action plans that guarantee results"
          />
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-6 md:p-10 border border-gray-100">
          <div className="grid md:grid-cols-2 gap-8 md:gap-12 items-center">
            <div className="space-y-6">
              <div>
                <Badge variant="outline" className="mb-2 border-primary/30 text-primary">THE VALUE EXCHANGE</Badge>
                <h3 className="text-2xl md:text-3xl font-bold mb-3">We Save You Time, Money, and Effort</h3>
                <p className="text-gray-700">
                  Why should every school reinvent the wheel? We've done the heavy lifting by researching, testing, and 
                  perfecting education transformation strategies. You get to:
                </p>
              </div>
              
              <ul className="space-y-4">
                {[
                  { icon: Lightbulb, text: "Implement proven strategies without costly trial and error", highlight: "Save ₹2-5 lakhs in consulting fees" },
                  { icon: Globe, text: "Access global education innovations adapted for Indian context", highlight: "Save 100+ hours of research" },
                  { icon: BookOpen, text: "Deploy ready-made future skills development frameworks", highlight: "Save 6-12 months of curriculum development" },
                  { icon: Star, text: "Follow step-by-step implementation guides with guaranteed results", highlight: "Start seeing results in 30 days" }
                ].map((item, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <div className="bg-primary/10 p-2.5 rounded-lg flex-shrink-0">
                      <item.icon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-gray-700">{item.text}</p>
                      <p className="text-primary text-sm font-medium mt-0.5">{item.highlight}</p>
                    </div>
                  </li>
                ))}
              </ul>
              
              {!isMobile && (
                <Button className="mt-2" size="lg" asChild>
                  <Link to="/signup" className="flex items-center gap-2">
                    Get Free Access Now <ArrowRight className="h-4 w-4" />
                  </Link>
                </Button>
              )}
            </div>
            
            <div className="relative">
              <div className="absolute -top-10 -left-10 w-40 h-40 bg-primary/5 rounded-full"></div>
              <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-secondary/5 rounded-full"></div>
              
              <div className="relative z-10 bg-gradient-to-br from-primary/5 to-secondary/5 p-6 rounded-xl border border-gray-100">
                <div className="bg-white rounded-lg p-4 mb-6 shadow-sm border border-gray-100">
                  <div className="flex items-start gap-4">
                    <div className="bg-primary/10 rounded-lg p-3">
                      <SearchCheck className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold mb-1">One System, Multiple Solutions</h4>
                      <p className="text-sm text-gray-600">
                        Our research has been consolidated into a complete system that addresses enrollment, 
                        parent engagement, student development, and teacher satisfaction simultaneously.
                      </p>
                    </div>
                  </div>
                </div>
                
                <img 
                  src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?ixlib=rb-1.2.1&auto=format&fit=crop&w=1050&q=80" 
                  alt="Research and Implementation" 
                  className="w-full h-auto rounded-lg shadow-md mb-6"
                />
                
                <div className="space-y-3">
                  <div className="flex items-center gap-3 bg-white p-3 rounded-lg shadow-sm">
                    <div className="bg-green-100 p-2 rounded-full">
                      <CheckIcon className="h-4 w-4 text-green-600" />
                    </div>
                    <div>
                      <h5 className="font-medium text-sm">Everything Included</h5>
                      <p className="text-xs text-gray-500">All templates, guides, and systems - nothing held back</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3 bg-white p-3 rounded-lg shadow-sm">
                    <div className="bg-green-100 p-2 rounded-full">
                      <CheckIcon className="h-4 w-4 text-green-600" />
                    </div>
                    <div>
                      <h5 className="font-medium text-sm">Zero Cost Implementation</h5>
                      <p className="text-xs text-gray-500">All strategies can be implemented without extra budget</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {isMobile && (
            <div className="mt-8 text-center">
              <Button className="w-full" size="lg" asChild>
                <Link to="/signup" className="flex items-center justify-center gap-2">
                  Get Free Access Now <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

const ResearchCard = ({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) => {
  return (
    <div className="bg-gradient-to-br from-primary via-secondary to-primary/90 text-white p-6 rounded-xl shadow-md hover:shadow-lg transition-all border border-primary/10 h-full">
      <div className="bg-white/10 p-3 w-14 h-14 flex items-center justify-center rounded-lg mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-bold mb-2">{title}</h3>
      <p className="text-white/90">{description}</p>
    </div>
  );
};

const CheckIcon = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="20 6 9 17 4 12"></polyline>
  </svg>
);

export default ResearchSection;
