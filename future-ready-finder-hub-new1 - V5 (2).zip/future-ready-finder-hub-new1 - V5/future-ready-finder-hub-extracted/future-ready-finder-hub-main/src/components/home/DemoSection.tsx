
import React from "react";
import { Button } from "@/components/ui/button";
import { ExternalLink, PlayCircle } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

const DemoSection = () => {
  const isMobile = useIsMobile();
  
  return (
    <section className="py-16 bg-gradient-to-br from-indigo-50 to-blue-50">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden border border-indigo-100">
          <div className="p-8 md:p-10 flex flex-col justify-center">
            <div className="inline-flex items-center gap-2 bg-indigo-100 text-indigo-700 px-4 py-1.5 rounded-full text-sm font-medium mb-5">
              <PlayCircle className="h-4 w-4" />
              <span>Interactive Platform Tour</span>
            </div>
            
            <h2 className="text-2xl md:text-3xl font-bold text-gray-800 mb-4">
              See How It All Works
            </h2>
            
            <p className="text-gray-600 mb-6">
              New to our platform? Take a quick tour of all our features and see exactly how 
              Future Ready Schools can transform your educational approach. Our comprehensive 
              demos will show you step-by-step how to implement these strategies in your school.
            </p>
            
            <div className="space-y-4 mb-8">
              <div className="flex items-start gap-3">
                <div className="bg-green-100 rounded-full p-1 mt-0.5">
                  <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <span className="text-gray-700">Proven strategies for educational excellence</span>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-green-100 rounded-full p-1 mt-0.5">
                  <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <span className="text-gray-700">Comprehensive resource collection for all educators</span>
              </div>
              <div className="flex items-start gap-3">
                <div className="bg-green-100 rounded-full p-1 mt-0.5">
                  <svg className="h-4 w-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <span className="text-gray-700">Customizable frameworks for your unique school needs</span>
              </div>
            </div>
            
            <Button 
              size={isMobile ? "default" : "lg"}
              className="bg-indigo-600 hover:bg-indigo-700 text-white w-full md:w-auto"
              asChild
            >
              <a 
                href="https://alldemos.futurereadyschools.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2"
              >
                Access All Demos
                <ExternalLink className="h-4 w-4" />
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default DemoSection;
