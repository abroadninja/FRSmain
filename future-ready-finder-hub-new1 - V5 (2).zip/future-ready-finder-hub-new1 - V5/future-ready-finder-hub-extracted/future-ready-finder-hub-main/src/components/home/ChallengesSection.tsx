
import React from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { Badge } from "@/components/ui/badge";
import { 
  BookOpen, 
  Users, 
  DollarSign,
  GraduationCap 
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const ChallengesSection = () => {
  const isMobile = useIsMobile();
  
  return (
    <section className="py-16 md:py-20 bg-gray-50">
      <div className="container-custom">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <Badge variant="outline" className="mb-4">Challenges</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Today's Schools Face Big Challenges
          </h2>
          <p className="text-lg text-gray-600">
            Running a school is tough. You want the best for your students, but many things can get in the way.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-6 md:gap-8">
          <ChallengeCard 
            icon={BookOpen}
            title="Skills Gap"
            description="Traditional curriculum doesn't align with rapidly evolving workplace demands."
            iconColor="bg-blue-100 text-blue-600"
          />
          
          <ChallengeCard 
            icon={Users}
            title="Enrollment Pressure"
            description="Schools struggle to differentiate in competitive education markets."
            iconColor="bg-purple-100 text-purple-600"
          />
          
          <ChallengeCard 
            icon={DollarSign}
            title="Resource Constraints"
            description="Limited budgets hinder implementation of forward-thinking programs."
            iconColor="bg-amber-100 text-amber-600"
          />
          
          <ChallengeCard 
            icon={GraduationCap}
            title="Future Unprepared"
            description="Students graduate lacking critical high-income skills for tomorrow's economy."
            iconColor="bg-emerald-100 text-emerald-600"
          />
        </div>

        <div className="text-center mt-10 text-lg font-medium">
          <p>If these are your worries, you're in the right place. <span className="text-primary font-bold">We offer REAL solutions, for FREE.</span></p>
        </div>
      </div>
    </section>
  );
};

interface ChallengeCardProps {
  icon: React.FC<{ className?: string }>;
  title: string;
  description: string;
  iconColor: string;
}

const ChallengeCard = ({ icon: Icon, title, description, iconColor }: ChallengeCardProps) => {
  return (
    <Card className="border border-gray-200 hover:shadow-md transition-all duration-300 overflow-hidden group">
      <CardContent className="p-6 space-y-4">
        <div className={`${iconColor} w-12 h-12 rounded-full flex items-center justify-center mb-4 transition-transform group-hover:scale-110`}>
          <Icon className="h-6 w-6" />
        </div>
        <h3 className="font-bold text-xl">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </CardContent>
    </Card>
  );
};

export default ChallengesSection;
