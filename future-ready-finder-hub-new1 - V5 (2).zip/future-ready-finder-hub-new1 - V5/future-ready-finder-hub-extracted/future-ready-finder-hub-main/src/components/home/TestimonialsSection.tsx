
import React from "react";
import { Badge } from "@/components/ui/badge";
import { Star, Quote } from "lucide-react";

const TestimonialsSection = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container-custom">
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4">Success Stories</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Transforming Schools Nationwide</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            See how schools across the country have revolutionized their approach with our free transformation system.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <TestimonialCard 
            name="Dr. Rajesh Sharma"
            role="Principal, Delhi Public School"
            image="https://randomuser.me/api/portraits/men/32.jpg"
            quote="futurereadyschools.com completely transformed how we prepare students for the real world. Their free resources helped us implement a future-skills curriculum that parents and students love. Our enrollment has increased by 30% in just one year."
            rating={5}
            initials="RS"
            bgColor="bg-primary/20"
            textColor="text-primary"
          />
          
          <TestimonialCard 
            name="Amy Peterson"
            role="Director, Westlake Academy"
            image="https://randomuser.me/api/portraits/women/44.jpg"
            quote="The implementation playbooks made it incredibly easy to introduce high-income skill development to our 8th-12th graders. Parents are thrilled that their children are learning skills that actually prepare them for the future economy."
            rating={5}
            initials="AP"
            bgColor="bg-secondary/20"
            textColor="text-secondary"
          />
          
          <TestimonialCard 
            name="Michael Thomas"
            role="Superintendent, Lincoln School District"
            image="https://randomuser.me/api/portraits/men/22.jpg"
            quote="The community engagement system has revolutionized how our schools interact with parents and the broader community. We've seen increased involvement, better feedback, and a true sense of partnership in education."
            rating={5}
            initials="MT"
            bgColor="bg-accent/20"
            textColor="text-accent"
          />
        </div>

        <div className="mt-16 text-center">
          <p className="text-lg text-gray-600 italic max-w-2xl mx-auto">
            "Join over 1000 schools that have already transformed their approach to education with our completely free resources and systems."
          </p>
        </div>
      </div>
    </section>
  );
};

const TestimonialCard = ({ 
  name, 
  role, 
  image, 
  quote, 
  rating, 
  initials,
  bgColor,
  textColor
}: { 
  name: string;
  role: string;
  image: string;
  quote: string;
  rating: number;
  initials: string;
  bgColor: string;
  textColor: string;
}) => {
  return (
    <div className="bg-white rounded-2xl shadow-sm p-6 border border-gray-100 hover:shadow-md transition-all relative overflow-hidden group">
      <div className="absolute -top-10 -right-10 w-20 h-20 bg-gray-100 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"></div>
      <Quote className="h-8 w-8 text-gray-200 mb-4" />
      
      <p className="text-gray-700 mb-6">{quote}</p>
      
      <div className="flex items-center">
        <div className={`w-12 h-12 rounded-full ${bgColor} flex items-center justify-center mr-4`}>
          <span className={`${textColor} font-bold text-lg`}>{initials}</span>
        </div>
        <div>
          <p className="font-bold">{name}</p>
          <p className="text-sm text-gray-600">{role}</p>
        </div>
      </div>
      
      <div className="flex mt-4">
        {[...Array(rating)].map((_, i) => (
          <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
        ))}
      </div>
    </div>
  );
};

export default TestimonialsSection;
