
import React from "react";
import { Book, Rocket, Briefcase, Trophy, Music, Palette } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const ValueComparisonSection = () => {
  return (
    <section className="py-16 md:py-24 bg-gradient-to-br from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <Badge className="mb-4">The Educational Gap</Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
            The Challenge: Traditional Education Falls Short
          </h2>
          <p className="text-lg text-gray-600">
            Is your curriculum truly preparing students for tomorrow's economy?
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {/* Traditional School Offerings */}
          <div className="bg-gray-900 text-white rounded-xl p-6 md:p-8">
            <div className="flex items-center gap-3 mb-6">
              <Book className="h-6 w-6" />
              <h3 className="text-xl md:text-2xl font-semibold">Traditional School Offerings</h3>
            </div>
            
            <div className="space-y-6">
              {traditionalOfferings.map((item, index) => (
                <div key={index} className="border-b border-gray-700 pb-5">
                  <div className="flex items-start gap-3">
                    <div className="bg-gray-800 p-2 rounded-lg mt-1">
                      <item.icon className="h-5 w-5 text-gray-400" />
                    </div>
                    <div>
                      <h4 className="font-medium text-white mb-1">{item.title}</h4>
                      <p className="text-sm text-gray-400">{item.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* What Students Actually Need */}
          <div className="bg-gradient-to-br from-orange-500 to-red-500 text-white rounded-xl p-6 md:p-8">
            <div className="flex items-center gap-3 mb-6">
              <Rocket className="h-6 w-6" />
              <h3 className="text-xl md:text-2xl font-semibold">What Students Actually Need</h3>
            </div>
            
            <div className="space-y-6">
              {studentNeeds.map((item, index) => (
                <div key={index} className="border-b border-white/20 pb-5">
                  <div className="flex items-start gap-3">
                    <div className="bg-white/20 p-2 rounded-full mt-0.5">
                      <svg className="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <div>
                      <h4 className="font-medium text-white mb-1">{item.title}</h4>
                      <p className="text-sm text-white/80">{item.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const traditionalOfferings = [
  {
    title: "Annual Career Counseling",
    description: "Brief sessions once per year",
    icon: Briefcase
  },
  {
    title: "IIT/NEET Foundation Courses",
    description: "Limited career path focus",
    icon: Book
  },
  {
    title: "Arts and Craft Classes",
    description: "Recreational rather than career-oriented",
    icon: Palette
  },
  {
    title: "Dance and Music Programs",
    description: "Focused on traditional performances",
    icon: Music
  },
  {
    title: "Sports Training",
    description: "Limited connection to future careers",
    icon: Trophy
  }
];

const studentNeeds = [
  {
    title: "Future-Ready Skills Framework",
    description: "21st-century skills integrated across all grades (2-12)"
  },
  {
    title: "High-Income Skill Discovery",
    description: "Personalized guidance for in-demand skills (8-12)"
  },
  {
    title: "Portfolio Building",
    description: "Showcase capabilities to future employers (8-12)"
  },
  {
    title: "Future-Proofed Career Paths",
    description: "Careers that will thrive in 20+ years"
  },
  {
    title: "Entrepreneurial Mindset",
    description: "Building confidence to create opportunities"
  }
];

export default ValueComparisonSection;
