
import React from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Users, Star, ArrowUpRight } from "lucide-react";

const ResultsSection = () => {
  const isMobile = useIsMobile();
  
  return (
    <section className="py-16 md:py-24 bg-gradient-to-br from-primary/5 via-secondary/5 to-accent/5">
      <div className="container-custom">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <Badge variant="outline" className="mb-4">Results</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            See Real Results for Your School
          </h2>
          <p className="text-lg text-gray-600">
            Schools using our FREE system see amazing improvements in these key areas:
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          <ResultCard 
            icon={Users}
            title="More Student Admissions"
            description="Become the top choice for parents. Attract more students with a clear, strong message."
            subheading="Significant Rise in Applications"
            points={[
              "Powerful differentiation strategy",
              "Streamlined admissions process",
              "Organic word-of-mouth growth"
            ]}
            iconColor="bg-blue-50 text-blue-600"
            accentColor="border-blue-200"
          />
          
          <ResultCard
            icon={Star}
            title="Happier, More Engaged Parents"
            description="Build a strong community. Parents will become your biggest supporters and help your school grow."
            subheading="Higher Engagement & Loyalty"
            points={[
              "Effective communication framework",
              "Strong community-building events",
              "Parent advocacy development"
            ]}
            iconColor="bg-amber-50 text-amber-600"
            accentColor="border-amber-200"
          />
          
          <ResultCard
            icon={ArrowUpRight}
            title="Students Ready for the Future"
            description="Give students practical skills and career guidance for success in tomorrow's world."
            subheading="Greater Career Confidence"
            points={[
              "High-income skills portfolio (8-12)",
              "Future-ready curriculum (2-12)",
              "Age-appropriate career exploration"
            ]}
            iconColor="bg-emerald-50 text-emerald-600"
            accentColor="border-emerald-200"
          />
        </div>
      </div>
    </section>
  );
};

interface ResultCardProps {
  icon: React.FC<{ className?: string }>;
  title: string;
  description: string;
  subheading: string;
  points: string[];
  iconColor: string;
  accentColor: string;
}

const ResultCard = ({ icon: Icon, title, description, subheading, points, iconColor, accentColor }: ResultCardProps) => {
  return (
    <Card className={`border-t-4 ${accentColor} shadow-sm hover:shadow-md transition-all`}>
      <CardContent className="p-6 pt-6">
        <div className={`${iconColor} w-14 h-14 rounded-full flex items-center justify-center mb-4`}>
          <Icon className="h-7 w-7" />
        </div>
        <h3 className="font-bold text-xl mb-2">{title}</h3>
        <p className="text-gray-600 mb-6">{description}</p>
        
        <h4 className="font-semibold text-lg text-primary mb-3">{subheading}</h4>
        <ul className="space-y-3">
          {points.map((point, index) => (
            <li key={index} className="flex items-center gap-2">
              <div className="h-2 w-2 rounded-full bg-primary"></div>
              <span className="text-gray-700">{point}</span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
};

export default ResultsSection;
