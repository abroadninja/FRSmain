
import React from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Quote, TrendingUp, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const SuccessStoriesSection = () => {
  const isMobile = useIsMobile();
  
  return (
    <section className="py-16 md:py-20 bg-white">
      <div className="container-custom">
        <div className="text-center max-w-3xl mx-auto mb-10 md:mb-16">
          <Badge variant="outline" className="mb-3 md:mb-4">PROVEN SYSTEM</Badge>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4">Real Schools, Real Results</h2>
          <p className="text-base md:text-lg text-gray-600">
            Schools implementing our system are experiencing remarkable outcomes in enrollment, parent satisfaction, and student engagement without spending a rupee.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
          <ResultCard 
            metric="22%"
            description="Average increase in admission inquiries within the first 90 days"
            highlight={true}
          />
          
          <ResultCard 
            metric="35%"
            description="Improvement in parent engagement and satisfaction metrics"
          />
          
          <ResultCard 
            metric="76%"
            description="Of students reporting clearer vision about future career paths"
          />
        </div>
        
        {/* Featured Success Story */}
        <div className="mt-12 md:mt-16 bg-gradient-to-r from-indigo-50 to-blue-50 rounded-xl overflow-hidden border border-indigo-100">
          <div className="grid grid-cols-1 md:grid-cols-2">
            <div className="p-6 md:p-8 flex flex-col justify-center">
              <Badge className="bg-indigo-100 text-indigo-700 hover:bg-indigo-200 mb-4 w-fit">CASE STUDY</Badge>
              <h3 className="text-xl md:text-2xl font-bold mb-3">From Declining Enrollment to Waiting List</h3>
              <div className="relative mb-4">
                <Quote className="absolute -top-1 -left-1 h-6 w-6 text-indigo-200" />
                <blockquote className="pl-5 italic text-gray-700 border-l-2 border-indigo-300">
                  "We implemented just two strategies from the Future Ready Schools system and saw immediate results. For the first time in five years, we have a waiting list for next year's admissions."
                </blockquote>
              </div>
              <p className="text-gray-600 text-sm">
                <strong className="block mb-1">The Challenge:</strong>
                Saraswati International School was facing declining enrollment due to increasing competition from newer schools in the area.
              </p>
              <ul className="mt-4 space-y-2">
                <SuccessListItem>First implemented the "Immediate Impact" positioning strategy</SuccessListItem>
                <SuccessListItem>Launched the High Income Skills Portfolio program for grades 9-12</SuccessListItem> 
                <SuccessListItem>Created a parent community engagement system</SuccessListItem>
              </ul>
              <div className="mt-6">
                <Button variant="outline" className="text-indigo-700" asChild>
                  <Link to="/signup">
                    <span>Get the same results for your school</span>
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
            <div className="bg-indigo-800 relative">
              <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/90 to-blue-700/90 z-10"></div>
              <img 
                src="https://images.unsplash.com/photo-1497633762265-9d179a990aa6" 
                alt="School success story" 
                className="w-full h-full object-cover mix-blend-overlay opacity-60"
              />
              <div className="absolute inset-0 z-20 flex flex-col items-center justify-center p-6 text-center text-white">
                <div className="p-4 rounded-full bg-white/10 mb-4">
                  <TrendingUp className="h-8 w-8" />
                </div>
                <h4 className="text-2xl md:text-3xl font-bold mb-2">47%</h4>
                <p className="text-lg">Increase in new student inquiries</p>
                <div className="mt-8 flex flex-col gap-3 w-full max-w-xs">
                  <div className="flex items-center gap-2 bg-white/10 p-3 rounded-lg">
                    <CheckCircle className="h-5 w-5 text-green-300" />
                    <span className="text-sm">Implemented in under 30 days</span>
                  </div>
                  <div className="flex items-center gap-2 bg-white/10 p-3 rounded-lg">
                    <CheckCircle className="h-5 w-5 text-green-300" />
                    <span className="text-sm">Zero marketing budget</span>
                  </div>
                </div>
                <p className="mt-4 text-white/80 text-sm max-w-xs">
                  "We now have clarity and a system that produces predictable results."
                </p>
                <p className="text-white/70 text-xs mt-1">- Principal, Saraswati International School</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

interface ResultCardProps {
  metric: string;
  description: string;
  highlight?: boolean;
}

const ResultCard = ({ metric, description, highlight = false }: ResultCardProps) => {
  return (
    <div className={`p-6 md:p-8 rounded-xl border border-gray-200 shadow-sm ${highlight ? 'bg-gradient-to-br from-primary/5 to-primary/10' : 'bg-white'} hover:shadow-md transition-all text-center`}>
      <h3 className={`text-3xl md:text-4xl font-bold mb-3 ${highlight ? 'text-primary' : 'text-gray-900'}`}>
        {metric}
      </h3>
      <p className="text-gray-700">{description}</p>
    </div>
  );
};

const SuccessListItem = ({ children }: { children: React.ReactNode }) => {
  return (
    <li className="flex items-center gap-2 text-sm">
      <ArrowRight className="h-4 w-4 text-indigo-500 flex-shrink-0" />
      <span>{children}</span>
    </li>
  );
};

export default SuccessStoriesSection;
