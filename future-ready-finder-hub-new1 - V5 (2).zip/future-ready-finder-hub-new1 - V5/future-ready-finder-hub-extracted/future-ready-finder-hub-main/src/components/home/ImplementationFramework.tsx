
import React from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const ImplementationFramework = () => {
  return (
    <section className="py-16 md:py-24 bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12 md:mb-16">
          <Badge variant="outline" className="mb-4">THE FRAMEWORK</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Proven 4-Step Implementation Framework
          </h2>
          <p className="text-lg text-gray-600">
            Our systematic approach ensures maximum results with minimal effort. Each step builds on the previous one, creating a comprehensive transformation.
          </p>
        </div>
        
        <div className="relative">
          {/* Connection line (hidden on mobile) */}
          <div className="hidden md:block absolute left-1/2 top-10 bottom-10 w-0.5 bg-blue-200 -translate-x-1/2 z-0"></div>
          
          <div className="space-y-16 relative z-10">
            {steps.map((step, index) => (
              <div key={index} className={`flex flex-col ${index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'} gap-10 items-center`}>
                {/* Step content */}
                <div className="w-full md:w-1/2 text-left">
                  <div className="flex items-center gap-4 mb-4">
                    <div className={`${step.colorClasses.circle} w-14 h-14 rounded-full flex items-center justify-center text-white font-bold text-2xl shadow-lg`}>
                      {index + 1}
                    </div>
                    <h3 className="text-2xl font-bold">{step.title}</h3>
                  </div>
                  
                  <p className="text-lg text-gray-700 mb-6">
                    {step.description}
                  </p>
                  
                  <ul className="space-y-3 mb-6">
                    {step.benefits.map((benefit, idx) => (
                      <li key={idx} className="flex items-start gap-3">
                        <div className={`p-1 rounded-full ${step.colorClasses.bg} flex-shrink-0 mt-1`}>
                          <CheckCircle className={`h-4 w-4 ${step.colorClasses.text}`} />
                        </div>
                        <span className="text-gray-700">{benefit}</span>
                      </li>
                    ))}
                  </ul>
                  

                </div>
                
                {/* Step image */}
                <div className="w-full md:w-1/2">
                  <div className="relative">
                    <div className={`absolute -top-3 -left-3 w-full h-full rounded-xl ${step.colorClasses.bg} transform rotate-2 opacity-20`}></div>
                    <div className="relative z-10 rounded-xl overflow-hidden shadow-lg border border-gray-200">
                      <img 
                        src={step.image} 
                        alt={step.title}
                        className="w-full h-64 md:h-80 object-cover"
                      />
                    </div>
                    
                    {/* Connection arrow (not on the last step) */}
                    {index < steps.length - 1 && (
                      <div className="hidden md:flex absolute bottom-0 left-1/2 w-12 h-12 bg-white rounded-full shadow-lg transform translate-y-1/2 -translate-x-1/2 z-20 items-center justify-center">
                        <ArrowRight className={`h-6 w-6 ${steps[index + 1].colorClasses.text}`} />
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Call to action */}
        <div className="mt-16 text-center">
          <Card className="max-w-3xl mx-auto bg-white shadow-lg border-blue-100">
            <CardContent className="p-8">
              <Badge className="mb-3 bg-blue-100 text-blue-700">START TODAY</Badge>
              <h3 className="text-2xl font-bold mb-3">Ready to Transform Your School?</h3>
              <p className="text-gray-700 mb-6">
                Our framework is designed for busy school leaders to implement quickly and start seeing results 
                within weeks, regardless of your technical abilities or previous experience.
              </p>
              <Button className="bg-blue-700 hover:bg-blue-800 text-white" size="lg" asChild>
                <Link to="/signup">
                  Get Started For Free <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

const steps = [
  {
    title: "Strategic Positioning",
    description: "Establish your school as the future-ready choice in your community with our differentiation framework that parents instantly recognize as valuable.",
    image: "https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    benefits: [
      "Stand out from competitors immediately",
      "Clear messaging that resonates with parents",
      "Implementation in days, not months"
    ],
    colorClasses: {
      circle: "bg-blue-700",
      bg: "bg-blue-100",
      text: "text-blue-700",
      border: "blue-300"
    }
  },
  {
    title: "Parent Community Building",
    description: "Create a thriving parent community that increases retention, generates referrals, and builds a protective moat around your school.",
    image: "https://images.unsplash.com/photo-1544717305-2782549b5136?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    benefits: [
      "Ready-to-use communication templates",
      "Community-building event frameworks",
      "Parent ambassador program blueprint"
    ],
    colorClasses: {
      circle: "bg-indigo-700",
      bg: "bg-indigo-100",
      text: "text-indigo-700",
      border: "indigo-300"
    }
  },
  {
    title: "Future-Ready Skills Development",
    description: "Implement our comprehensive Future-Ready Skills framework that prepares students for tomorrow's economy while impressing parents today.",
    image: "https://images.unsplash.com/photo-1509062522246-3755977927d7?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    benefits: [
      "Complete curriculum integration plan",
      "Age-appropriate skill-building activities",
      "Portfolio-based achievement system"
    ],
    colorClasses: {
      circle: "bg-purple-700",
      bg: "bg-purple-100",
      text: "text-purple-700",
      border: "purple-300"
    }
  },
  {
    title: "Growth & Sustainability",
    description: "Establish predictable enrollment growth with our tested marketing, admission optimization, and retention systems.",
    image: "https://images.unsplash.com/photo-1517048676732-d65bc937f952?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    benefits: [
      "Streamlined admission process templates",
      "Retention strategy implementation guide",
      "Word-of-mouth generation system"
    ],
    colorClasses: {
      circle: "bg-emerald-700",
      bg: "bg-emerald-100",
      text: "text-emerald-700",
      border: "emerald-300"
    }
  }
];

export default ImplementationFramework;
