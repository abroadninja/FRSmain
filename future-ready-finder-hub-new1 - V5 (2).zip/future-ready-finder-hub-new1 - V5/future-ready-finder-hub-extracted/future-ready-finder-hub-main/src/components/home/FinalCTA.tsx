
import React from "react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, Check } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

const FinalCTA = () => {
  const isMobile = useIsMobile();
  
  return (
    <section className="py-16 md:py-24 bg-gradient-to-br from-blue-700 to-indigo-700 text-white relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wOCI+PHBhdGggZD0iTTM2IDM0YzAtMi4yIDEuOC00IDQtNHM0IDEuOCA0IDQtMS44IDQtNCA0LTQtMS44LTQtNHoiLz48L2c+PC9nPjwvc3ZnPg==')] opacity-30"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center bg-white/10 backdrop-blur-sm rounded-full px-4 py-1.5 text-white border border-white/20 mb-6">
            <span className="text-sm font-medium">100% Free Access, No Credit Card Required</span>
          </div>
          
          <h2 className="text-3xl md:text-5xl font-bold mb-6">
            Ready to Transform Your School?
          </h2>
          
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Join forward-thinking educators who are preparing their students for 
            future success while increasing enrollment and parent satisfaction.
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4 mb-12">
            <Button 
              className="bg-white hover:bg-white/90 text-blue-700 px-6 py-6 text-lg font-semibold"
              size={isMobile ? "default" : "lg"}
              asChild
            >
              <Link to="/signup">
                Get Started For Free
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            
            <Button 
              variant="outline" 
              className="border-white/30 bg-white/5 text-white hover:bg-white/10 px-6 py-6 text-lg"
              size={isMobile ? "default" : "lg"}
              asChild
            >
              <a href="http://www.membership-page1.futurereadyschools.com" target="_blank" rel="noopener noreferrer">
                Membership Options
              </a>
            </Button>
          </div>
        </div>
        
        {/* Key points display based on the attached images */}
        <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-6">
          {benefits.map((benefit, index) => (
            <div key={index} className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/10 p-5">
              <div className="flex items-center gap-3 mb-3">
                <div className="bg-green-500/20 rounded-full p-1.5">
                  <Check className="h-4 w-4 text-green-300" />
                </div>
                <h3 className="font-bold text-white text-xl">{benefit.title}</h3>
              </div>
              <p className="text-white/80">{benefit.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const benefits = [
  {
    title: "100% Free",
    description: "All resources provided at no cost to your school"
  },
  {
    title: "Easy Implementation",
    description: "Step-by-step guides for seamless adoption"
  },
  {
    title: "Proven Frameworks",
    description: "Based on successful educational models"
  },
  {
    title: "Budget-Friendly",
    description: "Works with limited resources and tight budgets"
  }
];

export default FinalCTA;
