
import React from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

const TransformationPlanSection = () => {
  const isMobile = useIsMobile();
  
  return (
    <section className="py-16 md:py-24 bg-gray-50 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-20 right-20 w-40 h-40 bg-primary/5 rounded-full"></div>
      <div className="absolute bottom-20 left-20 w-60 h-60 bg-accent/5 rounded-full"></div>
      
      <div className="container-custom relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <Badge variant="outline" className="mb-4">Implementation</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Your 4-Step Plan to School Success
          </h2>
          <p className="text-lg text-gray-600">
            Our system is simple to follow. Each step builds on the last, making your school stronger.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <StepCard 
            number={1}
            title="Immediate Impact Positioning"
            description="Differentiate your school instantly with our Future-Ready Framework"
          />
          
          <StepCard
            number={2}
            title="Parent Community System"
            description="Build a thriving parent network that increases retention and referrals"
          />
          
          <StepCard
            number={3}
            title="Future-Focused Skills"
            description="Implement proven programs preparing students for tomorrow's economy"
          />
          
          <StepCard
            number={4}
            title="Sustainable Growth"
            description="Create predictable enrollment growth with tested marketing systems"
          />
        </div>

        <div className="flex justify-center mt-12">
          <Button 
            size={isMobile ? "default" : "lg"}
            className="bg-primary hover:bg-primary/90 text-white shadow-lg"
            asChild
          >
            <Link to="/signup">
              Get Your Free Future-Ready Plan <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
};

interface StepCardProps {
  number: number;
  title: string;
  description: string;
}

const StepCard = ({ number, title, description }: StepCardProps) => {
  return (
    <div className="bg-white rounded-lg p-6 border border-gray-200 shadow-sm hover:shadow-md transition-all relative overflow-hidden">
      <div className="bg-gradient-to-br from-primary/80 to-accent/80 text-white w-12 h-12 rounded-full flex items-center justify-center font-bold text-xl mb-4">
        {number}
      </div>
      <h3 className="font-bold text-xl mb-3">{title}</h3>
      <p className="text-gray-600">{description}</p>
      
      {/* Connection line for desktop */}
      {number < 4 && (
        <div className="absolute top-12 right-0 w-1/2 h-0.5 bg-gradient-to-r from-primary/50 to-accent/50 hidden lg:block"></div>
      )}
    </div>
  );
};

export default TransformationPlanSection;
