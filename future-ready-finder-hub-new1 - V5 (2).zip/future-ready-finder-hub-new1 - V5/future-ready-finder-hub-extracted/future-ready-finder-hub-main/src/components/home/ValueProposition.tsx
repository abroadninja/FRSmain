
import React from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { BookOpen, Clock, Calendar, DollarSign } from "lucide-react";

const ValueProposition = () => {
  return (
    <section className="py-16 md:py-24 bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <Badge variant="outline" className="border-blue-300 mb-4">Our Promise</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Why We Offer This For Free
          </h2>
          <p className="text-lg text-gray-600">
            Our mission is to help every school become future-ready. We're sharing these systems to remove financial barriers and help more students succeed in tomorrow's world.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          <ValueCard
            icon={BookOpen}
            title="Save on Expert Costs"
            description="Access expertise worth ₹2-5 Lakhs without any consultation fees."
            iconColor="text-blue-600"
            iconBg="bg-blue-100"
          />
          
          <ValueCard
            icon={Clock}
            title="Save Thousands of Hours"
            description="Implement ready-made systems instead of spending thousands of hours researching solutions."
            iconColor="text-amber-600"
            iconBg="bg-amber-100"
          />
          
          <ValueCard
            icon={Calendar}
            title="Faster Implementation"
            description="Start new programs in weeks instead of months, with comprehensive step-by-step guidance."
            iconColor="text-emerald-600"
            iconBg="bg-emerald-100"
          />
        </div>
        
        <div className="mt-12">
          <Card className="bg-white border-blue-100 max-w-3xl mx-auto">
            <CardContent className="p-8 text-center">
              <DollarSign className="h-10 w-10 text-blue-600 mx-auto mb-4" />
              <h3 className="font-bold text-2xl mb-3">Why Free? Our Philosophy</h3>
              <p className="text-gray-700">
                We believe every student deserves access to future-ready education, regardless of their school's resources. 
                By removing financial barriers, we're helping more schools prepare students for success in tomorrow's world.
              </p>
              
              <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-100 inline-block">
                <p className="text-blue-700 font-semibold">
                  "Education is the most powerful weapon which you can use to change the world."
                </p>
                <p className="text-sm text-blue-600 mt-1">— Nelson Mandela</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

interface ValueCardProps {
  icon: React.FC<{ className?: string }>;
  title: string;
  description: string;
  iconColor: string;
  iconBg: string;
}

const ValueCard = ({ icon: Icon, title, description, iconColor, iconBg }: ValueCardProps) => {
  return (
    <Card className="border border-blue-100 bg-white hover:shadow-md transition-all h-full">
      <CardContent className="p-6 pt-6 text-center">
        <div className={`${iconBg} w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4`}>
          <Icon className={`h-8 w-8 ${iconColor}`} />
        </div>
        <h3 className="font-bold text-xl mb-2">{title}</h3>
        <p className="text-gray-600">{description}</p>
      </CardContent>
    </Card>
  );
};

export default ValueProposition;
