
import React from "react";
import { useIsMobile } from "@/hooks/use-mobile";
import { ArrowRight, BookOpen, Users, Star, Calendar, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge";

const HowItWorksSection = () => {
  const isMobile = useIsMobile();
  
  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container-custom">
        <div className="text-center mb-12 md:mb-16">
          <Badge variant="outline" className="mb-3">THE SYSTEM</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">A Simple 4-Step System For School Transformation</h2>
          <p className="text-base md:text-lg text-gray-600 max-w-3xl mx-auto">
            Our proven implementation framework is designed for busy school leaders who want 
            maximum results with minimum effort. Each step builds on the previous one.
          </p>
        </div>
        
        <div className="relative">
          {/* Connection line (hidden on mobile) */}
          <div className="hidden md:block absolute left-1/2 top-10 bottom-10 w-0.5 bg-gray-200 -translate-x-1/2 z-0"></div>
          
          <div className="space-y-12 md:space-y-16 relative z-10">
            <Step 
              number="1" 
              title="Immediate Impact Positioning"
              description="Quickly differentiate your school with our Future-Ready Education Framework that parents immediately recognize as valuable"
              image="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
              benefits={[
                "Stand out from competitors instantly",
                "Easy to implement in just days",
                "No additional budget required"
              ]}
              color="primary"
            />
            
            <Step 
              number="2" 
              title="Parent Community System"
              description="Build a thriving parent community that increases retention, generates referrals, and creates a protective moat around your school"
              image="https://images.unsplash.com/photo-1529390079861-591de354faf5?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
              benefits={[
                "Systematic parent engagement approach",
                "Ready-to-use communication templates",
                "Community-building events framework"
              ]}
              color="secondary"
              reversed={true}
            />
            
            <Step 
              number="3" 
              title="High-Income Skills Development"
              description="Implement our proven High-Income Skills Portfolio program that prepares students for the future economy while impressing parents"
              image="https://images.unsplash.com/photo-1526498460520-4c246339dccb?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
              benefits={[
                "Complete curriculum framework",
                "Project-based portfolio system",
                "Future skills development roadmap"
              ]}
              color="accent"
            />
            
            <Step 
              number="4" 
              title="Sustainable Growth System"
              description="Create predictable enrollment growth with our tested marketing, admission, and retention systems that work in any market"
              image="https://images.unsplash.com/photo-1551836022-deb4988cc6c0?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
              benefits={[
                "Optimized admission process",
                "Word-of-mouth generation system",
                "Retention and growth strategies"
              ]}
              color="primary"
              reversed={true}
              isLast={true}
            />
          </div>
        </div>
        
        <div className="mt-16 text-center">
          <div className="bg-gray-50 p-6 md:p-8 rounded-xl max-w-3xl mx-auto">
            <Badge className="mb-3 bg-primary/10 text-primary">SUCCESS GUARANTEE</Badge>
            <h3 className="text-2xl font-bold mb-3">Implementation in 30 Days or Less</h3>
            <p className="text-gray-700 mb-6">
              The complete system is designed for busy school leaders to implement quickly and start seeing results within 30 days, 
              regardless of your technical abilities or previous experience.
            </p>
            <Button size={isMobile ? "default" : "lg"} className="bg-gradient-to-r from-primary to-secondary text-white" asChild>
              <Link to="/signup">
                Get Started For Free <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <div className="flex items-center justify-center gap-2 mt-4 text-sm text-gray-600">
              <Calendar className="h-4 w-4 text-primary" />
              <span>30-day implementation guarantee</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

interface StepProps {
  number: string;
  title: string;
  description: string;
  image: string;
  benefits: string[];
  color: "primary" | "secondary" | "accent";
  reversed?: boolean;
  isLast?: boolean;
}

const Step = ({ number, title, description, image, benefits, color, reversed = false, isLast = false }: StepProps) => {
  const isMobile = useIsMobile();
  
  const colorClasses = {
    primary: {
      bg: "bg-primary",
      borderBg: "bg-primary/10",
      textBg: "text-primary"
    },
    secondary: {
      bg: "bg-secondary",
      borderBg: "bg-secondary/10",
      textBg: "text-secondary"
    },
    accent: {
      bg: "bg-accent",
      borderBg: "bg-accent/10",
      textBg: "text-accent"
    }
  };
  
  return (
    <div className={`grid md:grid-cols-2 gap-8 md:gap-12 ${reversed && !isMobile ? 'md:grid-flow-dense' : ''}`}>
      <div className={reversed && !isMobile ? 'md:col-start-2' : ''}>
        <div className="flex items-center gap-4 mb-4">
          <div className={`w-12 h-12 rounded-full ${colorClasses[color].bg} text-white flex items-center justify-center font-bold text-xl`}>
            {number}
          </div>
          <h3 className="text-xl md:text-2xl font-bold">{title}</h3>
        </div>
        
        <p className="text-gray-700 mb-6">{description}</p>
        
        <ul className="space-y-3 mb-6">
          {benefits.map((benefit, idx) => (
            <li key={idx} className="flex items-start gap-3">
              <div className={`p-1 rounded-full ${colorClasses[color].borderBg} flex-shrink-0 mt-1`}>
                <CheckCircle className={`h-4 w-4 ${colorClasses[color].textBg}`} />
              </div>
              <span className="text-gray-700">{benefit}</span>
            </li>
          ))}
        </ul>
        
        <Button variant="outline" className={colorClasses[color].textBg} asChild>
          <Link to="/implementation-guides">Learn More</Link>
        </Button>
      </div>
      
      <div className={reversed && !isMobile ? 'md:col-start-1' : ''}>
        <div className="relative">
          <div className={`absolute -top-2 -left-2 w-full h-full rounded-xl ${colorClasses[color].borderBg} transform rotate-1`}></div>
          <img 
            src={image} 
            alt={title} 
            className="w-full h-60 md:h-72 object-cover rounded-xl relative z-10 border border-gray-100"
          />
          {!isLast && (
            <div className="hidden md:block absolute bottom-0 left-1/2 w-8 h-8 bg-white rounded-full border border-gray-200 transform translate-y-1/2 -translate-x-1/2 z-20 flex items-center justify-center">
              <ArrowRight className="h-4 w-4 text-gray-400" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default HowItWorksSection;
