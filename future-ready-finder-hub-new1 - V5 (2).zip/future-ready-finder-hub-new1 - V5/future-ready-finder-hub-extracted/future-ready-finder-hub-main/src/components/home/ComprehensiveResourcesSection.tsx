
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { 
  BookOpen, FileText, Users, ArrowRight, BookCheck, 
  BarChart, Award, TrendingUp, ExternalLink
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useIsMobile } from "@/hooks/use-mobile";
import { useAuth } from "@/components/auth/AuthProvider";

const ComprehensiveResourcesSection = () => {
  const isMobile = useIsMobile();
  const { user } = useAuth();

  return (
    <section className="py-16 md:py-24 bg-gradient-to-br from-gray-50 to-white">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <Badge className="mb-4">Everything You Need</Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
            Comprehensive Resources for School Transformation
          </h2>
          <p className="text-lg text-gray-600">
            Our platform provides everything you need to position your school as the best choice 
            in your area, all while operating within your existing budget.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto mb-12">
          {resourceCategories.map((category, index) => (
            <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-all">
              <div className={`w-12 h-12 rounded-lg ${category.bgColor} flex items-center justify-center mb-4`}>
                <category.icon className={`h-6 w-6 ${category.iconColor}`} />
              </div>
              <h3 className="text-lg font-semibold text-gray-800 mb-2">{category.title}</h3>
              <p className="text-gray-600 text-sm">{category.description}</p>
            </div>
          ))}
        </div>
        
        <div className="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden max-w-5xl mx-auto">
          <div className="grid md:grid-cols-5">
            <div className="md:col-span-3 p-6 md:p-8">
              <h3 className="text-xl md:text-2xl font-bold text-gray-800 mb-4">
                Strategic Playbooks & Implementation Resources
              </h3>
              
              <p className="text-gray-600 mb-6">
                Our comprehensive playbooks provide step-by-step guidance on positioning your school 
                as the best in your vicinity, delivering exactly what students and parents need at 
                an affordable cost. Each playbook comes with ready-to-use resources for seamless implementation.
              </p>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                {playbooks.map((item, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <div className="bg-blue-50 p-1.5 rounded-full mt-0.5">
                      <svg className="h-4 w-4 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                    <span className="text-sm text-gray-700">{item}</span>
                  </div>
                ))}
              </div>
              
              <Button 
                size={isMobile ? "default" : "lg"}
                className="bg-blue-600 hover:bg-blue-700 text-white"
                asChild
              >
                {user ? (
                  <a 
                    href="https://resource-hub.futurereadyschools.com/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2"
                  >
                    Access Resources Hub
                    <ExternalLink className="h-4 w-4" />
                  </a>
                ) : (
                  <Link 
                    to="/signup"
                    className="flex items-center gap-2"
                  >
                    Access Resources Hub
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                )}
              </Button>
            </div>
            
            <div className="md:col-span-2 bg-gradient-to-br from-blue-600 to-indigo-700 p-6 md:p-8 flex flex-col justify-center">
              <div className="bg-white/10 backdrop-blur-sm rounded-xl border border-white/20 p-5">
                <h4 className="text-lg font-semibold text-white mb-3">Resources Include:</h4>
                <ul className="space-y-3">
                  {resources.map((resource, index) => (
                    <li key={index} className="flex items-center gap-3 text-white/90">
                      <div className="bg-white/20 p-1 rounded-full">
                        <svg className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                      <span className="text-sm">{resource}</span>
                    </li>
                  ))}
                </ul>
                
                <div className="mt-5 pt-5 border-t border-white/20">
                  <p className="text-white/90 text-sm mb-4">
                    All resources are designed to increase enrollment, improve parent satisfaction, 
                    and generate additional revenue for your school.
                  </p>
                  <Button 
                    size="sm"
                    className="bg-white text-indigo-600 hover:bg-indigo-50 w-full transition-colors" 
                    asChild
                  >
                    <a 
                      href="https://alldemos.futurereadyschools.com/" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-2 font-medium"
                    >
                      View Demos
                      <ArrowRight className="h-4 w-4" />
                    </a>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const resourceCategories = [
  {
    title: "Implementation Playbooks",
    description: "Step-by-step guides for school transformation",
    icon: BookOpen,
    bgColor: "bg-blue-100",
    iconColor: "text-blue-600"
  },
  {
    title: "Parent Engagement",
    description: "Templates and strategies for parent communication",
    icon: Users,
    bgColor: "bg-green-100",
    iconColor: "text-green-600"
  },
  {
    title: "Future-Ready Curriculum",
    description: "Lessons for grades 2-12 across all skill areas",
    icon: BookCheck,
    bgColor: "bg-purple-100",
    iconColor: "text-purple-600"
  },
  {
    title: "Student Assessment",
    description: "Free psychometric and career assessments",
    icon: BarChart,
    bgColor: "bg-amber-100",
    iconColor: "text-amber-600"
  },
];

const playbooks = [
  "School Positioning Strategy",
  "Future-Ready Skills Framework",
  "High-Income Skills Development",
  "Parent Engagement Blueprint",
  "Enrollment Growth System",
  "Resource Optimization",
  "Easy Implementation Checklists",
  "Revenue Generation Models"
];

const resources = [
  "Ready-made templates",
  "Parent communication materials",
  "Marketing materials for enrollment",
  "Student development frameworks",
  "Assessment tools and guides",
  "Implementation checklists",
  "Teacher training resources",
  "Enrollment growth strategies"
];

export default ComprehensiveResourcesSection;
