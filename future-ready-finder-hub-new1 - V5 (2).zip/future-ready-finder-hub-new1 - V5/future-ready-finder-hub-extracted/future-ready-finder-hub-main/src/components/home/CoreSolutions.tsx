
import React from "react";
import { Badge } from "@/components/ui/badge";
import { GraduationCap, Users, ArrowRight, LineChart } from "lucide-react";

const CoreSolutions = () => {
  return (
    <section className="py-16 bg-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-1/3 h-1/3 bg-blue-50 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-1/3 h-1/3 bg-indigo-50 rounded-full blur-3xl"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <Badge variant="outline" className="mb-4">Our Solution</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            A Practical, Step-by-Step Approach
          </h2>
          <p className="text-lg text-gray-600">
            We provide a complete, easy-to-implement system that prepares your students for success while strengthening your school.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <img 
              src="https://images.unsplash.com/photo-1509062522246-3755977927d7?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80" 
              alt="Students using technology in a classroom" 
              className="rounded-xl object-cover w-full h-full max-h-[500px] shadow-lg"
            />
          </div>
          
          <div className="space-y-6">
            <SolutionCard 
              icon={GraduationCap}
              title="Future-Ready Framework"
              description="A comprehensive curriculum integration that develops essential 21st-century skills across all age groups."
              badge="Classes 2-12"
              iconBg="bg-blue-100 text-blue-600"
            />
            
            <SolutionCard 
              icon={Users}
              title="Community Building System"
              description="Strategic frameworks to create synergy between parents, teachers, and students for sustainable growth."
              iconBg="bg-amber-100 text-amber-600"
            />
            
            <SolutionCard 
              icon={LineChart}
              title="Enrollment Growth Strategy"
              description="Practical methods to differentiate your school and create predictable enrollment growth."
              iconBg="bg-emerald-100 text-emerald-600"
            />
            
            <SolutionCard 
              icon={ArrowRight}
              title="Implementation Support"
              description="Step-by-step guides to transform your school with minimal resources."
              iconBg="bg-violet-100 text-violet-600"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

interface SolutionCardProps {
  icon: React.FC<{ className?: string }>;
  title: string;
  description: string;
  badge?: string;
  iconBg: string;
}

const SolutionCard = ({ icon: Icon, title, description, badge, iconBg }: SolutionCardProps) => {
  return (
    <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-all">
      <div className="flex gap-4">
        <div className={`${iconBg} w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0`}>
          <Icon className="h-6 w-6" />
        </div>
        
        <div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-bold text-xl">{title}</h3>
            {badge && (
              <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">
                {badge}
              </Badge>
            )}
          </div>
          <p className="text-gray-600">{description}</p>
        </div>
      </div>
    </div>
  );
};

export default CoreSolutions;
