
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { College, isGlobalCollege } from "@/types/college.types";
import { Globe, Facebook, Twitter, Instagram, Linkedin, Youtube } from "lucide-react";
import { cn } from "@/lib/utils";

interface CollegeSocialLinksProps {
  college: College;
}

const CollegeSocialLinks: React.FC<CollegeSocialLinksProps> = ({ college }) => {
  const isGlobal = isGlobalCollege(college);
  
  if (!college.socialLinks && !(isGlobal && college.website)) {
    return null;
  }

  const socialLinks = [
    { 
      name: "Website", 
      icon: Globe, 
      url: isGlobal ? college.website : undefined,
      color: "hover:text-gray-700"
    },
    { 
      name: "Facebook", 
      icon: Facebook, 
      url: college.socialLinks?.facebook,
      color: "hover:text-blue-600"
    },
    { 
      name: "Twitter", 
      icon: Twitter, 
      url: college.socialLinks?.twitter,
      color: "hover:text-sky-500"
    },
    { 
      name: "Instagram", 
      icon: Instagram, 
      url: college.socialLinks?.instagram,
      color: "hover:text-pink-600"
    },
    { 
      name: "LinkedIn", 
      icon: Linkedin, 
      url: college.socialLinks?.linkedin,
      color: "hover:text-blue-700"
    },
    { 
      name: "YouTube", 
      icon: Youtube, 
      url: college.socialLinks?.youtube,
      color: "hover:text-red-600"
    },
  ].filter(link => link.url);

  if (socialLinks.length === 0) {
    return null;
  }

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-xl font-bold mb-4">Connect</h2>
        <div className="flex flex-wrap gap-4">
          {socialLinks.map((link, index) => {
            const Icon = link.icon;
            return (
              <a 
                key={index}
                href={link.url} 
                target="_blank" 
                rel="noopener noreferrer"
                aria-label={`Visit ${college.name} ${link.name}`}
                className={cn("flex items-center justify-center h-10 w-10 bg-gray-100 rounded-full transition-colors", link.color)}
              >
                <Icon className="h-5 w-5" />
              </a>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

export default CollegeSocialLinks;
