
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { IndiaCollege } from "@/types/college.types";
import { 
  Briefcase, 
  LineChart, 
  ArrowRight, 
  CheckCircle2, 
  XCircle, 
  PenTool, 
  UserPlus
} from "lucide-react";

interface IndianCollegeCareerRealityProps {
  college: IndiaCollege;
}

const IndianCollegeCareerReality: React.FC<IndianCollegeCareerRealityProps> = ({ college }) => {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <Briefcase className="h-5 w-5 text-indigo-600" />
          <h2 className="text-xl font-bold">The Brutal Career Reality</h2>
        </div>

        <div className="space-y-6">
          <div className="bg-indigo-50 p-4 rounded-lg border border-indigo-100">
            <h3 className="font-bold text-gray-800 mb-3">Truth About {college.name} Placements</h3>
            <p className="text-gray-700 mb-3">
              While {college.name} boasts an impressive {college.placementStats?.placementPercentage || "90+"}% placement rate and average package of ₹{((college.placementStats?.averagePackage || 2000000)/100000).toFixed(1)} LPA, these numbers hide several realities:
            </p>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start gap-2">
                <div className="min-w-5 pt-1">•</div>
                <p><span className="font-semibold">Stats are skewed by top performers:</span> The highest packages (₹{((college.placementStats?.highestPackage || 9000000)/100000).toFixed(0)} LPA) dramatically inflate averages. The median is significantly lower.</p>
              </li>
              <li className="flex items-start gap-2">
                <div className="min-w-5 pt-1">•</div>
                <p><span className="font-semibold">Branch disparities are massive:</span> CS/AI students often receive 2-4x higher offers than other engineering branches.</p>
              </li>
              <li className="flex items-start gap-2">
                <div className="min-w-5 pt-1">•</div>
                <p><span className="font-semibold">CTC ≠ In-hand salary:</span> Reported "packages" include theoretical bonuses, stock options (often with 4-year vesting), and joining bonuses that inflate the real number.</p>
              </li>
              <li className="flex items-start gap-2">
                <div className="min-w-5 pt-1">•</div>
                <p><span className="font-semibold">They don't mention career progression:</span> Initial salary matters less than growth potential. Some lower-paying roles offer faster advancement.</p>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-gray-800 mb-3 flex items-center">
              <LineChart className="h-5 w-5 text-green-600 mr-2" />
              Income Reality: Degree vs. Skills
            </h3>
            <div className="relative overflow-x-auto rounded-lg border border-gray-200 mb-4">
              <table className="w-full text-sm text-left">
                <thead className="text-xs bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 font-medium">Career Path</th>
                    <th scope="col" className="px-6 py-3 font-medium">After 4-5 Years</th>
                    <th scope="col" className="px-6 py-3 font-medium">After 7-8 Years</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="bg-white border-b">
                    <th scope="row" className="px-6 py-4 font-medium">
                      IIT Graduate (Traditional Path)
                    </th>
                    <td className="px-6 py-4">₹12-30 LPA</td>
                    <td className="px-6 py-4">₹25-60 LPA</td>
                  </tr>
                  <tr className="bg-gray-50 border-b">
                    <th scope="row" className="px-6 py-4 font-medium">
                      Self-Taught Developer + Portfolio
                    </th>
                    <td className="px-6 py-4">₹8-24 LPA</td>
                    <td className="px-6 py-4">₹20-50 LPA</td>
                  </tr>
                  <tr className="bg-white border-b">
                    <th scope="row" className="px-6 py-4 font-medium">
                      IIT + Self-Taught Skills
                    </th>
                    <td className="px-6 py-4">₹15-40 LPA</td>
                    <td className="px-6 py-4">₹30-80+ LPA</td>
                  </tr>
                  <tr className="bg-gray-50">
                    <th scope="row" className="px-6 py-4 font-medium">
                      Freelance/Remote Tech Work
                    </th>
                    <td className="px-6 py-4">₹10-50 LPA</td>
                    <td className="px-6 py-4">₹25-100+ LPA</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <p className="text-sm text-gray-600 italic mb-4">
              Note: These ranges vary greatly based on specific skills, location, company size, and individual ability to negotiate and demonstrate value.
            </p>
          </div>

          <div>
            <h3 className="font-bold text-gray-800 mb-3">What Actually Makes You Employable</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-green-50 p-4 rounded-lg border border-green-100">
                <div className="flex items-center gap-2 mb-2">
                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                  <h4 className="font-bold text-gray-800">High-Value Factors</h4>
                </div>
                <ul className="space-y-2 text-gray-700">
                  <li className="flex items-start gap-2">
                    <ArrowRight className="h-4 w-4 text-green-600 mt-1" />
                    <div>
                      <p className="font-medium">Practical project portfolio</p>
                      <p className="text-xs">Real-world applications showing your skills in action</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <ArrowRight className="h-4 w-4 text-green-600 mt-1" />
                    <div>
                      <p className="font-medium">Industry-relevant tech stack</p>
                      <p className="text-xs">Mastery of tools/frameworks currently used in target industry</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <ArrowRight className="h-4 w-4 text-green-600 mt-1" />
                    <div>
                      <p className="font-medium">Open source contributions</p>
                      <p className="text-xs">Demonstrates collaboration and code quality</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <ArrowRight className="h-4 w-4 text-green-600 mt-1" />
                    <div>
                      <p className="font-medium">Problem-solving ability</p>
                      <p className="text-xs">Can tackle complex challenges with elegant solutions</p>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="bg-red-50 p-4 rounded-lg border border-red-100">
                <div className="flex items-center gap-2 mb-2">
                  <XCircle className="h-5 w-5 text-red-600" />
                  <h4 className="font-bold text-gray-800">Overvalued Factors</h4>
                </div>
                <ul className="space-y-2 text-gray-700">
                  <li className="flex items-start gap-2">
                    <ArrowRight className="h-4 w-4 text-red-600 mt-1" />
                    <div>
                      <p className="font-medium">CGPA/Academic score</p>
                      <p className="text-xs">Beyond entry-level roles or academia, rarely matters</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <ArrowRight className="h-4 w-4 text-red-600 mt-1" />
                    <div>
                      <p className="font-medium">Certifications without projects</p>
                      <p className="text-xs">Paper credentials without practical application</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <ArrowRight className="h-4 w-4 text-red-600 mt-1" />
                    <div>
                      <p className="font-medium">Generic internships</p>
                      <p className="text-xs">Internships where you didn't build/contribute meaningfully</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-2">
                    <ArrowRight className="h-4 w-4 text-red-600 mt-1" />
                    <div>
                      <p className="font-medium">College brand alone</p>
                      <p className="text-xs">Opens doors initially but insufficient without skills</p>
                    </div>
                  </li>
                </ul>
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
              <PenTool className="h-5 w-5 text-purple-600" />
              Building Your Career Insurance Policy
            </h3>
            <p className="text-gray-700 mb-3">
              Whether or not you attend {college.name}, build these assets to ensure your long-term career success:
            </p>
            <ol className="list-decimal pl-5 space-y-3 text-gray-700">
              <li>
                <p className="font-medium">Public project portfolio</p>
                <p className="text-sm">GitHub repositories demonstrating your skills. One exceptional project beats five mediocre ones.</p>
              </li>
              <li>
                <p className="font-medium">Professional online presence</p>
                <p className="text-sm">Well-maintained LinkedIn profile, personal website/blog showcasing your work and thought process.</p>
              </li>
              <li>
                <p className="font-medium">Network of industry professionals</p>
                <p className="text-sm">Build relationships before you need them. Contribute value to communities (Discord, Reddit, LinkedIn) in your field.</p>
              </li>
              <li>
                <p className="font-medium">Specialized T-shaped skill set</p>
                <p className="text-sm">Deep in one valuable area, with breadth across related disciplines. Example: Deep in backend development + working knowledge of frontend, DevOps, and database optimization.</p>
              </li>
              <li>
                <p className="font-medium">Continuous learning system</p>
                <p className="text-sm">Develop habits to stay current with industry trends and regularly acquire new skills before they become mainstream requirements.</p>
              </li>
            </ol>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
            <div className="flex items-center gap-2 mb-2">
              <UserPlus className="h-5 w-5 text-blue-600" />
              <h3 className="font-bold text-gray-800">The New Resume: Portfolio {'>'} Degree</h3>
            </div>
            <p className="text-gray-700">
              Your career success increasingly depends on what you can demonstrate, not where you studied. Expect future employers and clients to judge you based on your portfolio, GitHub contributions, and ability to solve real problems—not your college pedigree. This is a reality {college.name} won't tell you during orientation, but one every student needs to prepare for.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default IndianCollegeCareerReality;
