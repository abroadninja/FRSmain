
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { College, isGlobalCollege } from "@/types/college.types";
import { ArrowRight, ExternalLink, BookOpen } from "lucide-react";
import { Link } from "react-router-dom";

interface CollegeAboutProps {
  college: College;
}

const CollegeAbout: React.FC<CollegeAboutProps> = ({ college }) => {
  const isGlobal = isGlobalCollege(college);

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
          <BookOpen className="h-5 w-5 text-primary" />
          About
        </h2>
        
        <div className="space-y-4">
          <p className="text-gray-600">{college.longDescription}</p>
          
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <h3 className="font-semibold text-gray-800 mb-2">The Hard Truth About Elite Education</h3>
            <p className="text-gray-600 mb-3">
              While {college.name} offers excellent resources and networking, a degree from here doesn't guarantee success. In today's economy, practical skills often outweigh prestige. Many employers now value demonstrated ability over credentials.
            </p>
            <p className="text-gray-600">
              Students who succeed here combine classroom learning with self-taught high-income skills, personal projects, and real-world application. The institution provides opportunities, but your initiative determines outcomes.
            </p>
          </div>

          <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 mt-4">
            <h3 className="font-semibold text-blue-800 mb-2">What Students Don't Tell You</h3>
            <ul className="list-disc pl-5 text-gray-700 space-y-2">
              <li>Burnout is common—most students experience extreme stress at least once per semester</li>
              <li>The "drinking from a firehose" metaphor is real; expect to feel overwhelmed by course loads</li>
              <li>Some professors prioritize research over teaching, leading to inconsistent classroom experiences</li>
              <li>There's a significant "impostor syndrome" culture that can affect mental health</li>
              <li>Building a professional network is often more valuable than perfect grades</li>
            </ul>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 mt-2">
            {isGlobal && college.website && (
              <a
                href={college.website}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-primary hover:underline mt-1"
              >
                Visit Official Website <ExternalLink className="h-4 w-4" />
              </a>
            )}
            
            <Link 
              to="/high-income-skills" 
              className="inline-flex items-center gap-1 text-primary hover:underline mt-1"
            >
              Explore Alternative Paths <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default CollegeAbout;
