
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { GlobalCollege } from "@/types/college.types";
import { Globe } from "lucide-react";

interface CollegeInternationalProps {
  college: GlobalCollege;
}

const CollegeInternational: React.FC<CollegeInternationalProps> = ({ college }) => {
  if (!college.internationalStudents) {
    return null;
  }

  const { percentage, countries, supportServices } = college.internationalStudents;

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center gap-3 mb-4">
          <Globe className="h-6 w-6 text-primary" />
          <h2 className="text-2xl font-bold">International Students</h2>
        </div>
        
        <div className="space-y-4">
          <div className="flex flex-wrap gap-x-8 gap-y-2">
            <p className="text-gray-700">
              <span className="font-medium">{percentage}%</span> international students
            </p>
            <p className="text-gray-700">
              From <span className="font-medium">{countries}</span> countries
            </p>
          </div>
          
          {supportServices && supportServices.length > 0 && (
            <div className="mt-4">
              <h3 className="text-lg font-semibold mb-2">Support Services</h3>
              <ul className="list-disc pl-5 text-gray-700">
                {supportServices.map((service, index) => (
                  <li key={index} className="mb-1">{service}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default CollegeInternational;
