
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { IndiaCollege } from "@/types/college.types";
import { Badge } from "@/components/ui/badge";
import { Lightbulb, DollarSign, GraduationCap, BookOpen, Brain, ArrowRight, Rocket } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

interface IndiaCollegeAlternativesProps {
  college: IndiaCollege;
}

const IndiaCollegeAlternatives: React.FC<IndiaCollegeAlternativesProps> = ({ college }) => {
  // Calculate if college is considered selective (under 5% acceptance rate for IITs)
  const isHighlySelective = college.acceptanceRate < 5;
  
  // Calculate if college has high competition (JEE based)
  const isJeeBasedAdmission = college.id.includes('iit-') || college.entranceExams?.includes('JEE Advanced');

  return (
    <Card className="border-2 border-primary/20 shadow-lg">
      <CardContent className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <Rocket className="h-6 w-6 text-purple-500" />
          <h2 className="text-2xl font-bold">The Truth: Elite Education In The AI Era</h2>
        </div>

        {isHighlySelective && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6">
            <p className="font-medium text-amber-800">
              <span className="font-bold">Reality check:</span> {college.name} accepts only {college.acceptanceRate}% of applicants. 
              That means for every 100 students who dream of attending, about {college.acceptanceRate < 1 ? 'less than one student' : college.acceptanceRate} get in. 
              The others? They still build successful careers—often by taking alternative paths that are faster, cheaper, and more aligned with industry needs.
            </p>
          </div>
        )}

        <div className="space-y-6">
          <div>
            <h3 className="text-xl font-bold mb-3 flex items-center">
              <Brain className="h-5 w-5 text-purple-600 mr-2" />
              The IIT Myth: What No One Tells You
            </h3>
            <div className="bg-gray-50 rounded-lg p-4 border border-gray-200">
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <div className="min-w-5 pt-1">•</div>
                  <p><span className="font-semibold">The JEE trap:</span> Spending 2-4 years preparing for JEE often builds skills that are <span className="underline">irrelevant to actual careers</span>. That time could be spent learning marketable skills instead.</p>
                </li>
                <li className="flex items-start gap-2">
                  <div className="min-w-5 pt-1">•</div>
                  <p><span className="font-semibold">Course content lag:</span> By the time material makes it into the curriculum, it's often 2-3 years behind industry standards—especially in fast-moving tech fields.</p>
                </li>
                <li className="flex items-start gap-2">
                  <div className="min-w-5 pt-1">•</div>
                  <p><span className="font-semibold">The real learning:</span> Most successful IITians build their careers on skills they learned <span className="underline">outside the formal curriculum</span>—through personal projects, internships, and online courses.</p>
                </li>
                <li className="flex items-start gap-2">
                  <div className="min-w-5 pt-1">•</div>
                  <p><span className="font-semibold">Mental health cost:</span> The pressure cooker environment leads to burnout, anxiety, depression, and sometimes worse. This rarely appears in the brochures.</p>
                </li>
              </ul>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-3 flex items-center">
              <DollarSign className="h-5 w-5 text-green-600 mr-2" />
              High-Income Skills You Can Learn Without IIT
            </h3>
            <p className="text-gray-700 mb-4">
              The market pays for skills, not degrees. These high-demand skills can be self-taught and earn ₹15-80 lakh annually with just 6-12 months of dedicated learning:
            </p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {[
                "AI Prompt Engineering", "Full-Stack Development", "Cloud Architecture", 
                "Data Engineering", "DevOps & MLOps", "Mobile App Development", 
                "Cybersecurity", "UI/UX Design", "Digital Marketing",
                "No-Code Development", "Content Creation", "Web3/Blockchain"
              ].map((skill, index) => (
                <Badge 
                  key={index} 
                  variant="outline" 
                  className="py-2 px-3 bg-gradient-to-r from-purple-50 to-transparent border-purple-200"
                >
                  {skill}
                </Badge>
              ))}
            </div>
            <div className="mt-4 bg-green-50 p-4 rounded-lg border border-green-100">
              <h4 className="font-semibold text-green-800 mb-2">The Income Reality</h4>
              <p className="text-gray-700">
                Many self-taught developers and AI specialists earn more than IIT graduates—with zero student debt and 4-5 years head start in the industry. The highest-paid roles in tech today (AI engineers, specialized developers, growth marketers) often value portfolio and experience over degrees.
              </p>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-3 flex items-center">
              <BookOpen className="h-5 w-5 text-blue-600 mr-2" />
              Get an IIT-Level Education (Without the IIT)
            </h3>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
              <div className="bg-white rounded-lg p-4 border border-blue-100 shadow-sm">
                <h4 className="font-bold text-blue-800 mb-2">Free World-Class Learning</h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• <span className="font-medium">NPTEL</span> - Free courses taught by actual IIT professors (nptel.ac.in)</li>
                  <li>• <span className="font-medium">MIT OpenCourseWare</span> - Complete MIT courses with materials (ocw.mit.edu)</li>
                  <li>• <span className="font-medium">Stanford Online</span> - Free Stanford courses (online.stanford.edu)</li>
                  <li>• <span className="font-medium">Codecademy</span> - Interactive coding tutorials (codecademy.com)</li>
                  <li>• <span className="font-medium">freeCodeCamp</span> - Comprehensive programming curriculum (freecodecamp.org)</li>
                </ul>
              </div>
              <div className="bg-white rounded-lg p-4 border border-blue-100 shadow-sm">
                <h4 className="font-bold text-blue-800 mb-2">Low-Cost Deep Learning</h4>
                <ul className="space-y-2 text-sm text-gray-700">
                  <li>• <span className="font-medium">Coursera</span> - Courses by IIT/global professors (₹3,500/month unlimited)</li>
                  <li>• <span className="font-medium">Scaler Academy</span> - Structured tech bootcamp with mentorship</li>
                  <li>• <span className="font-medium">Newton School</span> - Pay only when you get placed (ISA model)</li>
                  <li>• <span className="font-medium">Udemy</span> - Affordable courses on specific skills (₹455-3,500)</li>
                  <li>• <span className="font-medium">Masai School</span> - ISA model focused on job-ready skills</li>
                </ul>
              </div>
            </div>

            <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
              <h4 className="font-semibold text-blue-800 mb-2">The Self-Learning Advantage</h4>
              <p className="text-gray-700 mb-3">
                While IIT students follow a rigid curriculum, self-learners can:
              </p>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <div className="min-w-5 pt-1">→</div>
                  <p>Focus exclusively on current, in-demand skills without outdated prerequisites</p>
                </li>
                <li className="flex items-start gap-2">
                  <div className="min-w-5 pt-1">→</div>
                  <p>Learn at their own pace, going deep on topics they find valuable</p>
                </li>
                <li className="flex items-start gap-2">
                  <div className="min-w-5 pt-1">→</div>
                  <p>Build a real-world portfolio while learning (not after 4 years)</p>
                </li>
                <li className="flex items-start gap-2">
                  <div className="min-w-5 pt-1">→</div>
                  <p>Start earning earlier than degree-focused peers</p>
                </li>
                <li className="flex items-start gap-2">
                  <div className="min-w-5 pt-1">→</div>
                  <p>Adapt quickly to market changes without institutional delays</p>
                </li>
              </ul>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-3 flex items-center">
              <GraduationCap className="h-5 w-5 text-indigo-600 mr-2" />
              When Is An IIT Degree Actually Worth It?
            </h3>
            <p className="text-gray-700 mb-3">
              Despite the alternatives, an IIT degree remains valuable in specific contexts:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white p-4 rounded-lg border border-indigo-100 shadow-sm">
                <h4 className="font-medium text-indigo-800">Worth The Investment</h4>
                <ul className="mt-2 space-y-1 text-sm text-gray-700">
                  <li>• Research-focused careers requiring lab access</li>
                  <li>• Academic positions and higher education</li>
                  <li>• Certain government/PSU roles with specific requirements</li>
                  <li>• Fields where credentials matter more than skills</li>
                  <li>• International opportunities where IIT brand helps</li>
                </ul>
              </div>
              <div className="bg-white p-4 rounded-lg border border-red-100 shadow-sm">
                <h4 className="font-medium text-red-800">Questionable ROI</h4>
                <ul className="mt-2 space-y-1 text-sm text-gray-700">
                  <li>• Software development & engineering roles</li>
                  <li>• Data science & AI careers</li>
                  <li>• Digital marketing & content creation</li>
                  <li>• Entrepreneurship & startups</li>
                  <li>• Most tech-adjacent business roles</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-purple-50 to-transparent p-5 rounded-lg border border-purple-200">
            <h3 className="text-xl font-bold mb-2">The Smart Path Forward</h3>
            <p className="text-gray-800 mb-4">
              Whether you get into {college.name} or not, your success depends far more on your self-directed learning than any institution's name on your diploma. The most successful professionals combine formal education (when useful) with self-taught high-income skills, real-world projects, and personal branding.
            </p>
            <p className="text-gray-800 mb-4">
              <span className="font-bold">Remember:</span> In the AI era, your ability to continuously learn, adapt, and apply knowledge is exponentially more valuable than passing entrance exams or memorizing textbooks.
            </p>
            <Button className="mt-1" asChild>
              <Link to="/high-income-skills">
                Explore High-Income Skill Paths <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default IndiaCollegeAlternatives;
