
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { College } from "@/types/college.types";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Info } from "lucide-react";

interface CollegeFAQProps {
  college: College;
}

const CollegeFAQ: React.FC<CollegeFAQProps> = ({ college }) => {
  // Add more practical FAQs that aren't in the college data
  const practicalFaqs = [
    {
      question: "Is a degree from this college worth the cost?",
      answer: `It depends on your goals. For certain specialized fields like medicine or engineering, a degree from ${college.name} can open doors. However, for many career paths, the return on investment may not justify the cost. Before committing, research specific outcomes for your intended field and consider alternatives like bootcamps, certifications, or self-directed learning that could provide similar skills at a fraction of the cost.`
    },
    {
      question: "What skills won't I learn at this college but are essential in the real world?",
      answer: "Most traditional colleges, even elite ones, don't adequately teach: sales skills, personal finance management, effective communication, networking strategies, business development, entrepreneurship, AI tool usage, and real-world project management. These skills are often more valuable than academic knowledge in building wealth and career success."
    },
    {
      question: "How can I get a similar education if I don't get accepted?",
      answer: `If you don't get into ${college.name}, remember that the content taught here isn't magical or exclusive. You can access similar knowledge through: MIT OpenCourseWare (free), Coursera/edX courses (often taught by the same professors), targeted bootcamps, YouTube educational content, industry mentorship, and independent projects. Many successful people never attended elite institutions but built impressive careers through self-education.`
    },
    {
      question: "What high-income skills should I learn alongside my degree?",
      answer: "To maximize your employability and income potential, develop these skills regardless of your major: data analysis (SQL, Python, R), digital marketing (SEO, social media, email), sales and persuasion, content creation, AI prompt engineering, basic coding/web development, public speaking, and project management. These skills remain valuable regardless of economic conditions."
    }
  ];

  // Combine college-provided FAQs with our practical additions
  const combinedFaqs = [...(college.faq || []), ...practicalFaqs];

  if (combinedFaqs.length === 0) {
    return null;
  }

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-xl font-bold mb-4">Frequently Asked Questions</h2>
        
        <Accordion type="single" collapsible className="w-full">
          {combinedFaqs.map((item, index) => (
            <AccordionItem key={index} value={`faq-${index}`}>
              <AccordionTrigger className="text-left">
                {item.question}
              </AccordionTrigger>
              <AccordionContent className="text-gray-700">
                {item.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>

        <div className="mt-6 flex items-start gap-3 bg-blue-50 p-4 rounded-lg border border-blue-100">
          <Info className="h-5 w-5 text-blue-500 mt-0.5 flex-shrink-0" />
          <p className="text-sm text-blue-700">
            Remember: The questions colleges don't answer are often more important than the ones they do. Always consider the opportunity cost of time and money invested in traditional education versus alternative paths to acquiring marketable skills.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default CollegeFAQ;
