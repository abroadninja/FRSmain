
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { GlobalCollege } from "@/types/college.types";
import { Badge } from "@/components/ui/badge";
import { Lightbulb, DollarSign, GraduationCap, FileCode, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

interface CollegeAlternativesProps {
  college: GlobalCollege;
}

const CollegeAlternatives: React.FC<CollegeAlternativesProps> = ({ college }) => {
  // Calculate if college is considered expensive (over $30k/year)
  const isExpensive = college.tuitionFee > 30000;
  // Calculate if college is considered selective (under 20% acceptance rate)
  const isSelective = college.acceptanceRate < 20;

  return (
    <Card className="border-2 border-primary/20 shadow-lg">
      <CardContent className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <Lightbulb className="h-6 w-6 text-yellow-500" />
          <h2 className="text-2xl font-bold">Beyond College: Alternative Paths to Success</h2>
        </div>

        {(isExpensive || isSelective) && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-6">
            <p className="font-medium text-amber-800">
              Reality Check: {college.name} is 
              {isExpensive && isSelective 
                ? " both extremely selective (accepting only " + college.acceptanceRate + "% of applicants) and expensive ($" + college.tuitionFee.toLocaleString() + "/year)" 
                : isExpensive 
                  ? " expensive at $" + college.tuitionFee.toLocaleString() + " per year" 
                  : " highly selective, accepting only " + college.acceptanceRate + "% of applicants"}. 
              But here's the truth – in today's AI-powered world, you don't need an elite institution to build wealth and success.
            </p>
          </div>
        )}

        <div className="space-y-6">
          <div>
            <h3 className="text-xl font-bold mb-3 flex items-center">
              <DollarSign className="h-5 w-5 text-green-600 mr-2" />
              High-Income Skills You Can Learn Without College
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {[
                "AI Prompt Engineering", "Copywriting", "Digital Marketing", 
                "Web Development", "UI/UX Design", "Sales", 
                "Video Editing", "Data Analytics", "Social Media Management",
                "SEO Optimization", "Email Marketing", "Content Creation"
              ].map((skill, index) => (
                <Badge 
                  key={index} 
                  variant="outline" 
                  className="py-2 px-3 bg-gradient-to-r from-primary/5 to-transparent"
                >
                  {skill}
                </Badge>
              ))}
            </div>
            <p className="mt-4 text-gray-700">
              These skills can earn you $70,000-$150,000+ annually, often with less than 6 months of dedicated learning.
            </p>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-3 flex items-center">
              <GraduationCap className="h-5 w-5 text-blue-600 mr-2" />
              When Traditional Degrees ARE Worth It
            </h3>
            <p className="text-gray-700 mb-4">
              College degrees remain valuable in specific fields but come with significant opportunity costs. Consider a degree for:
            </p>
            <ul className="list-disc pl-5 space-y-1 text-gray-700">
              <li>Medicine, dentistry, and healthcare (legal requirements)</li>
              <li>Engineering roles requiring accreditation</li>
              <li>Research positions and academia</li>
              <li>Law and certain regulated professions</li>
              <li>Fields where the alumni network provides exceptional value</li>
            </ul>
            <p className="mt-4 text-gray-700">
              <strong>Reality Check:</strong> Even graduates from {college.name} need to continuously learn new skills to stay relevant. A degree alone – even from an elite institution – guarantees nothing in today's rapidly changing economy.
            </p>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-3 flex items-center">
              <FileCode className="h-5 w-5 text-purple-600 mr-2" />
              Alternative Education Paths
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="border rounded-lg p-4 bg-white">
                <h4 className="font-bold">Self-Directed Learning</h4>
                <p className="text-sm text-gray-600">Free or low-cost alternatives</p>
                <ul className="mt-2 text-gray-700 text-sm space-y-1">
                  <li>• YouTube tutorials & educational channels</li>
                  <li>• Free MIT OpenCourseWare classes</li>
                  <li>• Khan Academy courses</li>
                  <li>• Project-based learning</li>
                </ul>
              </div>
              <div className="border rounded-lg p-4 bg-white">
                <h4 className="font-bold">Structured Programs</h4>
                <p className="text-sm text-gray-600">More affordable than college</p>
                <ul className="mt-2 text-gray-700 text-sm space-y-1">
                  <li>• Bootcamps ($5K-20K, 3-6 months)</li>
                  <li>• Online certifications (often under $1K)</li>
                  <li>• Community college courses</li>
                  <li>• Apprenticeships & mentorships</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-primary/10 to-transparent p-5 rounded-lg border border-primary/20">
            <h3 className="text-xl font-bold mb-2">The True Path to Success in 2025+</h3>
            <p className="text-gray-800">
              The most successful people today combine formal education with self-taught high-income skills. Don't put all your eggs in the college basket. Start building real-world skills now, create a portfolio of work, and develop your personal brand. In the AI era, your ability to adapt and continuously learn is far more valuable than any single degree.
            </p>
            <Button className="mt-4" asChild>
              <Link to="/high-income-skills">
                Explore High-Income Skills <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default CollegeAlternatives;
