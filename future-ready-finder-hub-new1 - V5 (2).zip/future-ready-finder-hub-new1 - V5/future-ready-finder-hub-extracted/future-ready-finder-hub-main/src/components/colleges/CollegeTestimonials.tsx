
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { College, isGlobalCollege } from "@/types/college.types";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card as TestimonialCard, CardContent as TestimonialContent } from "@/components/ui/card";

interface CollegeTestimonialsProps {
  college: College;
}

const CollegeTestimonials: React.FC<CollegeTestimonialsProps> = ({ college }) => {
  if (!college.testimonials || college.testimonials.length === 0) {
    return null;
  }

  const isGlobal = isGlobalCollege(college);

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-4">Student & Alumni Testimonials</h2>
        
        <div className="space-y-6">
          {college.testimonials.map((testimonial, index) => (
            <TestimonialCard key={index} className="bg-gray-50 border-none">
              <TestimonialContent className="p-6">
                <div className="flex flex-col space-y-4">
                  <p className="text-gray-700 italic">&ldquo;{testimonial.quote}&rdquo;</p>
                  <div className="flex items-center space-x-4">
                    <Avatar>
                      <AvatarImage src={testimonial.image} alt={testimonial.name} />
                      <AvatarFallback>{testimonial.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-semibold">{testimonial.name}</p>
                      <p className="text-sm text-gray-500">
                        {isGlobal 
                          ? testimonial.position
                          : `${testimonial.batch} - ${testimonial.program}`}
                      </p>
                    </div>
                  </div>
                </div>
              </TestimonialContent>
            </TestimonialCard>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default CollegeTestimonials;
