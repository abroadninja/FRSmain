
import React from "react";
import { Link } from "react-router-dom";
import { MapPin } from "lucide-react";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { College, isIndianCollege } from "@/types/college.types";

interface RelatedCollegesProps {
  colleges: College[];
  title?: string;
}

const RelatedColleges: React.FC<RelatedCollegesProps> = ({ 
  colleges, 
  title = "Related Colleges" 
}) => {
  if (colleges.length === 0) return null;

  return (
    <div className="mt-8">
      <h2 className="text-2xl font-bold mb-4">{title}</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {colleges.map((college) => (
          <Card key={college.id} className="overflow-hidden">
            <div className="h-32 overflow-hidden">
              <img 
                src={college.image} 
                alt={college.name} 
                className="w-full h-full object-cover"
              />
            </div>
            <CardContent className="p-4">
              <h3 className="font-bold">{college.name}</h3>
              <div className="flex items-center mt-1 text-sm text-gray-500">
                <MapPin size={14} className="mr-1" />
                <span>
                  {college.location}, {isIndianCollege(college) ? college.state : college.country}
                </span>
              </div>
            </CardContent>
            <CardFooter className="p-4 pt-0">
              <Button variant="outline" size="sm" className="w-full" asChild>
                <Link to={`/${isIndianCollege(college) ? 'india-' : ''}colleges/${college.id}`}>
                  View Details
                </Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default RelatedColleges;
