
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { IndiaCollege } from "@/types/college.types";

interface CollegeSpecializationsProps {
  college: IndiaCollege;
}

const CollegeSpecializations: React.FC<CollegeSpecializationsProps> = ({ college }) => {
  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-4">Specializations</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {college.specializations.map((spec, index) => (
            <div key={index} className="flex items-center gap-2">
              <span className="h-2 w-2 rounded-full bg-primary" />
              <span>{spec}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default CollegeSpecializations;
