
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { College, GlobalCollege, IndiaCollege } from "@/types/college.types";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface CollegeFacultyProps {
  college: College;
}

const CollegeFaculty: React.FC<CollegeFacultyProps> = ({ college }) => {
  if (!college.facultyInfo?.notableFaculty || college.facultyInfo.notableFaculty.length === 0) {
    return null;
  }

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-4">Notable Faculty</h2>
        
        <div className="mb-4">
          <p className="text-gray-700">
            Student to faculty ratio: <span className="font-medium">{college.facultyInfo.studentFacultyRatio}</span>
          </p>
          <p className="text-gray-700">
            Total faculty: <span className="font-medium">
              {('totalCount' in college.facultyInfo) 
                ? college.facultyInfo.totalCount 
                : (college.facultyInfo.professorCount + 
                   college.facultyInfo.associateProfessorCount + 
                   college.facultyInfo.assistantProfessorCount)}
            </span>
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
          {college.facultyInfo.notableFaculty.map((faculty, index) => (
            <div key={index} className="flex gap-4">
              <Avatar className="h-16 w-16">
                <AvatarImage src={faculty.image} alt={faculty.name} />
                <AvatarFallback>{faculty.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-semibold">{faculty.name}</h3>
                <p className="text-sm text-gray-600">{faculty.position}</p>
                {faculty.achievement && (
                  <p className="text-sm text-gray-700 mt-1">{faculty.achievement}</p>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default CollegeFaculty;
