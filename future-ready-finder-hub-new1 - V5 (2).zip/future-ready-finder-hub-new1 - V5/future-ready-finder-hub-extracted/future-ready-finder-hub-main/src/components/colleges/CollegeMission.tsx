
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { College } from "@/types/college.types";
import { AlertTriangle, Info } from "lucide-react";

interface CollegeMissionProps {
  college: College;
}

const CollegeMission: React.FC<CollegeMissionProps> = ({ college }) => {
  if (!college.mission && !college.vision && (!college.values || college.values.length === 0)) {
    return null;
  }

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-4">Mission & Vision</h2>
        
        {college.mission && (
          <div className="mb-4">
            <h3 className="text-lg font-semibold mb-2">Mission</h3>
            <p className="text-gray-700">{college.mission}</p>
          </div>
        )}
        
        {college.vision && (
          <div className="mb-4">
            <h3 className="text-lg font-semibold mb-2">Vision</h3>
            <p className="text-gray-700">{college.vision}</p>
          </div>
        )}
        
        {college.values && college.values.length > 0 && (
          <div className="mb-6">
            <h3 className="text-lg font-semibold mb-2">Core Values</h3>
            <ul className="list-disc pl-5 text-gray-700">
              {college.values.map((value, index) => (
                <li key={index} className="mb-1">{value}</li>
              ))}
            </ul>
          </div>
        )}

        <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 mt-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-gray-700 font-medium">
                Reality Check: While {college.name}'s mission statement sounds impressive, remember that institutions often prioritize research and reputation over practical career preparation.
              </p>
              <p className="text-gray-600 mt-2 text-sm">
                No matter how prestigious the school, the responsibility for gaining relevant, market-ready skills ultimately falls on <span className="font-bold">you</span>. The most successful graduates supplement their education with self-directed learning in high-demand skills.
              </p>
            </div>
          </div>
        </div>
        
        <div className="bg-green-50 p-4 rounded-lg border border-green-100 mt-4">
          <div className="flex items-start gap-3">
            <Info className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-medium text-green-800">
                Pro Tip: How to Actually Use {college.name}'s Resources
              </p>
              <ul className="list-disc pl-5 text-gray-700 mt-2 space-y-1">
                <li>Attend office hours even when you don't have questions</li>
                <li>Join research labs early - email professors directly in your first year</li>
                <li>Use the alumni network aggressively for internship connections</li>
                <li>Take advantage of free access to journals, databases, and premium software</li>
                <li>Participate in hackathons and competitions for real-world project experience</li>
              </ul>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default CollegeMission;
