
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { College, isIndianCollege } from "@/types/college.types";

interface CollegeKeyInfoProps {
  college: College;
}

const CollegeKeyInfo: React.FC<CollegeKeyInfoProps> = ({ college }) => {
  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-4">Key Information</h2>
        <div className="space-y-4">
          <div>
            <p className="text-sm text-gray-500">Annual Tuition Fee</p>
            <p className="font-medium text-lg">
              {isIndianCollege(college)
                ? `₹${college.tuitionFee.toLocaleString()}`
                : `$${college.tuitionFee.toLocaleString()}`}
            </p>
          </div>
          <Separator />
          <div>
            <p className="text-sm text-gray-500">Institution Type</p>
            <p className="font-medium">{college.type}</p>
          </div>
          <Separator />
          <div>
            <p className="text-sm text-gray-500">Available Degrees</p>
            <div className="flex flex-wrap gap-2 mt-2">
              {college.degrees.map((degree, index) => (
                <Badge key={index} variant="outline">
                  {degree}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default CollegeKeyInfo;
