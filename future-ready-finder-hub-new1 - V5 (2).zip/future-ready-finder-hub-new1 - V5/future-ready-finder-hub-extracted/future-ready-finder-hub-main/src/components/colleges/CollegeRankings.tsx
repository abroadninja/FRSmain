
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { College } from "@/types/college.types";
import { Badge } from "@/components/ui/badge";
import { Trophy, TrendingUp, Search } from "lucide-react";

interface CollegeRankingsProps {
  college: College;
}

const CollegeRankings: React.FC<CollegeRankingsProps> = ({ college }) => {
  if (!college.rankings || college.rankings.length === 0) {
    return null;
  }

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          <Trophy className="h-6 w-6 text-amber-500" />
          Rankings
        </h2>
        
        <div className="space-y-4 mb-6">
          {college.rankings.map((ranking, index) => (
            <div key={index} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center justify-center h-12 w-12 bg-primary/10 rounded-full text-primary">
                <Trophy className="h-6 w-6" />
              </div>
              <div className="flex-1">
                <p className="font-medium">{ranking.source}</p>
                <p className="text-sm text-gray-600">
                  {ranking.category ? `${ranking.category} - ` : ''}{ranking.year}
                </p>
              </div>
              <Badge className="text-lg px-4 py-1 bg-primary/90 hover:bg-primary">
                #{ranking.rank}
              </Badge>
            </div>
          ))}
        </div>

        <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
          <h3 className="text-lg font-bold flex items-center mb-3">
            <TrendingUp className="h-5 w-5 mr-2 text-primary" />
            Rankings Reality Check
          </h3>
          <div className="space-y-3 text-gray-700">
            <p>
              College rankings make for good marketing, but they rarely correlate with career success or income potential. Many billionaires and industry leaders either dropped out or attended less prestigious schools.
            </p>
            <p>
              <strong>What matters more:</strong> The specific skills you develop, the network you build, the projects you complete, and your ability to market yourself. These factors significantly outweigh the prestige factor of a top-ranked institution.
            </p>
            <p>
              In today's AI-driven economy, your ability to adapt, learn independently, and apply knowledge practically is far more valuable than the name on your diploma.
            </p>
          </div>
        </div>
        
        <div className="mt-4 p-4 bg-purple-50 border border-purple-100 rounded-lg">
          <h3 className="text-lg font-semibold flex items-center mb-3 text-purple-800">
            <Search className="h-5 w-5 mr-2 text-purple-600" />
            What Employers Actually Look For
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-gray-700">
            <div className="bg-white p-3 rounded border border-purple-100">
              <h4 className="font-medium text-purple-700">Technical Skills</h4>
              <p className="text-sm mt-1">Demonstrated through projects, certifications, and real-world problem solving—not just coursework</p>
            </div>
            <div className="bg-white p-3 rounded border border-purple-100">
              <h4 className="font-medium text-purple-700">Communication</h4>
              <p className="text-sm mt-1">Ability to explain complex concepts clearly and work effectively in teams</p>
            </div>
            <div className="bg-white p-3 rounded border border-purple-100">
              <h4 className="font-medium text-purple-700">Adaptability</h4>
              <p className="text-sm mt-1">Willingness to learn new tools and approaches as technology evolves</p>
            </div>
            <div className="bg-white p-3 rounded border border-purple-100">
              <h4 className="font-medium text-purple-700">Initiative</h4>
              <p className="text-sm mt-1">Self-directed learning and problem-solving without constant supervision</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default CollegeRankings;
