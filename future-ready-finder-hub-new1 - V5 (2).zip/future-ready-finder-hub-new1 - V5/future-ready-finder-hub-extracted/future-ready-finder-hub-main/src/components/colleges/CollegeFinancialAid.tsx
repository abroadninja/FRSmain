
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { College, GlobalCollege, IndiaCollege, isGlobalCollege } from "@/types/college.types";
import { CircleCheck } from "lucide-react";

interface CollegeFinancialAidProps {
  college: College;
}

const CollegeFinancialAid: React.FC<CollegeFinancialAidProps> = ({ college }) => {
  if (!college.financialAid) {
    return null;
  }

  const isGlobal = isGlobalCollege(college);

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-4">Financial Aid & Scholarships</h2>
        
        <div className="space-y-4">
          {college.financialAid.availableAid && (
            <div className="flex items-center text-green-600 gap-2">
              <CircleCheck className="h-5 w-5" />
              <span>Financial aid available</span>
            </div>
          )}
          
          {isGlobal && college.financialAid.percentReceiving && (
            <p className="text-gray-700">
              <span className="font-medium">{college.financialAid.percentReceiving}%</span> of students receive some form of financial aid
            </p>
          )}
          
          {isGlobal && college.financialAid.averagePackage && (
            <p className="text-gray-700">
              Average financial aid package: <span className="font-medium">${college.financialAid.averagePackage.toLocaleString()}</span>
            </p>
          )}
          
          {college.financialAid.scholarships && college.financialAid.scholarships.length > 0 && (
            <div className="mt-4">
              <h3 className="text-lg font-semibold mb-2">Available Scholarships</h3>
              <ul className="list-disc pl-5 text-gray-700">
                {college.financialAid.scholarships.map((scholarship, index) => (
                  <li key={index} className="mb-1">{scholarship}</li>
                ))}
              </ul>
            </div>
          )}

          {!isGlobal && college.financialAid.feeWaivers && college.financialAid.feeWaivers.length > 0 && (
            <div className="mt-4">
              <h3 className="text-lg font-semibold mb-2">Fee Waivers</h3>
              <ul className="list-disc pl-5 text-gray-700">
                {college.financialAid.feeWaivers.map((waiver, index) => (
                  <li key={index} className="mb-1">{waiver}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default CollegeFinancialAid;
