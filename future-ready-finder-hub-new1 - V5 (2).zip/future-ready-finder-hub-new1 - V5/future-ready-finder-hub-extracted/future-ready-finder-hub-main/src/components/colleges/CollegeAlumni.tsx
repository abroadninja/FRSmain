
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { College, GlobalCollege, IndiaCollege, isGlobalCollege } from "@/types/college.types";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { GraduationCap } from "lucide-react";

interface CollegeAlumniProps {
  college: College;
}

const CollegeAlumni: React.FC<CollegeAlumniProps> = ({ college }) => {
  if (!college.notableAlumni || college.notableAlumni.length === 0) {
    return null;
  }

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-4">Notable Alumni</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {college.notableAlumni.map((alumni, index) => (
            <div key={index} className="flex gap-4 items-start">
              {alumni.image ? (
                <Avatar className="h-16 w-16">
                  <AvatarImage src={alumni.image} alt={alumni.name} />
                  <AvatarFallback>{alumni.name.charAt(0)}</AvatarFallback>
                </Avatar>
              ) : (
                <div className="flex items-center justify-center h-16 w-16 bg-primary/10 rounded-full text-primary">
                  <GraduationCap className="h-8 w-8" />
                </div>
              )}
              <div>
                <h3 className="font-semibold">{alumni.name}</h3>
                {alumni.graduationYear && (
                  <p className="text-sm text-gray-500">Class of {alumni.graduationYear}</p>
                )}
                <p className="text-sm text-gray-700 mt-1">{alumni.achievement}</p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default CollegeAlumni;
