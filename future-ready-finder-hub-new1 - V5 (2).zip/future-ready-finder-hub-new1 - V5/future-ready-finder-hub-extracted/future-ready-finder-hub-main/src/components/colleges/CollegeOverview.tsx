
import React from "react";
import { Users, School, Percent } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { College, isIndianCollege } from "@/types/college.types";

interface CollegeOverviewProps {
  college: College;
}

const CollegeOverview: React.FC<CollegeOverviewProps> = ({ college }) => {
  const foundingYear = isIndianCollege(college) ? college.estYear : college.foundedYear;

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-4">Overview</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <div className="flex items-center gap-2">
            <School className="h-5 w-5 text-primary" />
            <div>
              <p className="text-sm text-gray-500">Established</p>
              <p className="font-medium">{foundingYear}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            <div>
              <p className="text-sm text-gray-500">Students</p>
              <p className="font-medium">{college.studentsCount.toLocaleString()}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Percent className="h-5 w-5 text-primary" />
            <div>
              <p className="text-sm text-gray-500">Acceptance Rate</p>
              <p className="font-medium">{college.acceptanceRate}%</p>
            </div>
          </div>
          
          {isIndianCollege(college) && (
            <>
              <div className="flex items-center gap-2">
                <School className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-sm text-gray-500">NIRF Ranking</p>
                  <p className="font-medium">#{college.nirf}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <School className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-sm text-gray-500">Accreditation</p>
                  <p className="font-medium">{college.accreditation}</p>
                </div>
              </div>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default CollegeOverview;
