
import React from "react";
import { MapPin } from "lucide-react";
import { College, isIndianCollege } from "@/types/college.types";

interface CollegeHeroProps {
  college: College;
}

const CollegeHero: React.FC<CollegeHeroProps> = ({ college }) => {
  return (
    <div className="relative h-[400px] overflow-hidden">
      <img
        src={college.image}
        alt={college.name}
        className="w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-black/50" />
      <div className="absolute bottom-0 left-0 right-0 p-8 text-white">
        <h1 className="text-4xl font-bold mb-2">{college.name}</h1>
        <div className="flex items-center gap-2">
          <MapPin className="h-5 w-5" />
          <span>
            {college.location}, {isIndianCollege(college) ? college.state : college.country}
          </span>
        </div>
      </div>
    </div>
  );
};

export default CollegeHero;
