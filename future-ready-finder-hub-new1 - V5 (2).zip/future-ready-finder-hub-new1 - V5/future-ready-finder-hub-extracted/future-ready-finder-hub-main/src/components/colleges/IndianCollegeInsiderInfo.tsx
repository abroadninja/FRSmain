
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { AlertTriangle, MessageCircle, TrendingUp, ThumbsUp, ThumbsDown } from "lucide-react";
import { IndiaCollege } from "@/types/college.types";

interface IndianCollegeInsiderInfoProps {
  college: IndiaCollege;
}

const IndianCollegeInsiderInfo: React.FC<IndianCollegeInsiderInfoProps> = ({ college }) => {
  return (
    <Card className="border-orange-200">
      <CardContent className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <MessageCircle className="h-5 w-5 text-orange-500" />
          <h2 className="text-xl font-bold">Insider Information: What Reddit & Quora Won't Tell You</h2>
        </div>

        <div className="space-y-5">
          <div className="bg-orange-50 p-4 rounded-lg border border-orange-100">
            <h3 className="font-bold text-gray-800 mb-2 flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-orange-500" />
              The Unspoken Truths About {college.name}
            </h3>
            <ul className="space-y-3 text-gray-700">
              <li className="flex items-start gap-2">
                <div className="min-w-5 pt-1">•</div>
                <p><span className="font-semibold">JEE obsession damages career preparation:</span> The hyper-focus on JEE creates students who excel at solving theoretical problems but often lack applied skills. Many arrive at IIT without ever having built anything practical.</p>
              </li>
              <li className="flex items-start gap-2">
                <div className="min-w-5 pt-1">•</div>
                <p><span className="font-semibold">CGPA matters less than you think:</span> Beyond your first job, employers rarely care about your grades. Students who spend time building projects and skills often outperform those obsessed with perfect scores.</p>
              </li>
              <li className="flex items-start gap-2">
                <div className="min-w-5 pt-1">•</div>
                <p><span className="font-semibold">The pressure cooker environment:</span> Mental health issues are widespread but stigmatized. Students pushing through anxiety, depression, and burnout is normalized as "part of the experience."</p>
              </li>
              <li className="flex items-start gap-2">
                <div className="min-w-5 pt-1">•</div>
                <p><span className="font-semibold">Branch matters less than skills:</span> Many students in "less prestigious" branches end up with better careers because they focused on building market-relevant skills rather than obsessing over their assigned department.</p>
              </li>
            </ul>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-green-50 p-4 rounded-lg border border-green-100">
              <div className="flex items-center gap-2 mb-2">
                <ThumbsUp className="h-5 w-5 text-green-600" />
                <h3 className="font-bold text-gray-800">Worth The Hype</h3>
              </div>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <div className="min-w-5 pt-1">→</div>
                  <p><span className="font-medium">Peer group quality</span> - You'll be surrounded by brilliant minds who challenge you</p>
                </li>
                <li className="flex items-start gap-2">
                  <div className="min-w-5 pt-1">→</div>
                  <p><span className="font-medium">Research infrastructure</span> - Access to cutting-edge labs and equipment</p>
                </li>
                <li className="flex items-start gap-2">
                  <div className="min-w-5 pt-1">→</div>
                  <p><span className="font-medium">Industry connections</span> - The Research Park offers real-world exposure</p>
                </li>
                <li className="flex items-start gap-2">
                  <div className="min-w-5 pt-1">→</div>
                  <p><span className="font-medium">Alumni network</span> - Genuinely helpful for opportunities later</p>
                </li>
              </ul>
            </div>

            <div className="bg-red-50 p-4 rounded-lg border border-red-100">
              <div className="flex items-center gap-2 mb-2">
                <ThumbsDown className="h-5 w-5 text-red-600" />
                <h3 className="font-bold text-gray-800">Overhyped Aspects</h3>
              </div>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <div className="min-w-5 pt-1">→</div>
                  <p><span className="font-medium">Course curriculum</span> - Often outdated by 2-3 years compared to industry</p>
                </li>
                <li className="flex items-start gap-2">
                  <div className="min-w-5 pt-1">→</div>
                  <p><span className="font-medium">Teaching quality</span> - Highly variable; research often prioritized over education</p>
                </li>
                <li className="flex items-start gap-2">
                  <div className="min-w-5 pt-1">→</div>
                  <p><span className="font-medium">Work-life balance</span> - Poor for many students; burnout is common</p>
                </li>
                <li className="flex items-start gap-2">
                  <div className="min-w-5 pt-1">→</div>
                  <p><span className="font-medium">Practical skill building</span> - Self-initiative required; not built into curriculum</p>
                </li>
              </ul>
            </div>
          </div>

          <div>
            <h3 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-blue-500" />
              How To Actually Succeed If You Make It To {college.name}
            </h3>
            <ol className="list-decimal pl-5 space-y-3 text-gray-700">
              <li>
                <p className="font-medium">Don't chase perfect CGPA at the expense of skills</p>
                <p className="text-sm">A 7.5 GPA with strong projects and internships beats a 9.5 GPA with nothing else. Aim for "good enough" grades (7.5+) and invest remaining time in practical skills.</p>
              </li>
              <li>
                <p className="font-medium">Start building a portfolio from year one</p>
                <p className="text-sm">Create a GitHub profile and contribute consistently. Document your learning journey. Build projects that solve real problems. This matters more than your degree for most careers.</p>
              </li>
              <li>
                <p className="font-medium">Master communication and networking</p>
                <p className="text-sm">Technical skills alone aren't enough. Learn to explain complex ideas simply. Connect with seniors, alumni, and professors. Most opportunities come through relationships, not applications.</p>
              </li>
              <li>
                <p className="font-medium">Explore interdisciplinary projects</p>
                <p className="text-sm">The most innovative work happens between disciplines. Don't limit yourself to your department's focus. The Research Park is especially valuable for cross-disciplinary exposure.</p>
              </li>
              <li>
                <p className="font-medium">Prioritize mental health</p>
                <p className="text-sm">Use the counseling services. Exercise regularly. Find communities outside your hostel/department. Remember that burning out helps no one—least of all your future self.</p>
              </li>
            </ol>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default IndianCollegeInsiderInfo;
