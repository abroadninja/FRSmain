
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { GlobalCollege } from "@/types/college.types";
import { Check } from "lucide-react";

interface CollegeApplicationProcessProps {
  college: GlobalCollege;
}

const CollegeApplicationProcess: React.FC<CollegeApplicationProcessProps> = ({ college }) => {
  if (!college.applicationProcess || college.applicationProcess.length === 0) {
    return null;
  }

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-4">Application Process</h2>
        
        <ol className="space-y-3">
          {college.applicationProcess.map((step, index) => (
            <li key={index} className="flex items-start gap-3">
              <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-white">
                <Check className="h-4 w-4" />
              </div>
              <span className="text-gray-700">{step}</span>
            </li>
          ))}
        </ol>
        
        {college.admissionDeadlines && (
          <div className="mt-6">
            <h3 className="font-semibold mb-2">Application Deadlines</h3>
            <ul className="space-y-2">
              {college.admissionDeadlines.early && (
                <li className="text-gray-700">
                  <span className="font-medium">Early Action/Decision:</span> {college.admissionDeadlines.early}
                </li>
              )}
              {college.admissionDeadlines.regular && (
                <li className="text-gray-700">
                  <span className="font-medium">Regular Decision:</span> {college.admissionDeadlines.regular}
                </li>
              )}
              {college.admissionDeadlines.transfer && (
                <li className="text-gray-700">
                  <span className="font-medium">Transfer Application:</span> {college.admissionDeadlines.transfer}
                </li>
              )}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default CollegeApplicationProcess;
