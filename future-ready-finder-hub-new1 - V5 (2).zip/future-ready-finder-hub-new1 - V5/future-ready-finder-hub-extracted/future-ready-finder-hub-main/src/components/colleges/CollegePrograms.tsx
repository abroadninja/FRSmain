
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { College } from "@/types/college.types";

interface CollegeProgramsProps {
  college: College;
}

const CollegePrograms: React.FC<CollegeProgramsProps> = ({ college }) => {
  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-4">Programs Offered</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {college.programs.map((program, index) => (
            <Badge
              key={index}
              variant="secondary"
              className="text-sm py-1 px-3"
            >
              {program}
            </Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default CollegePrograms;
