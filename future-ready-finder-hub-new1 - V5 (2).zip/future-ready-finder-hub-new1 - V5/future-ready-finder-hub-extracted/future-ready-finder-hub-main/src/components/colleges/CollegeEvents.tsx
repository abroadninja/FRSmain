
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { College } from "@/types/college.types";
import { CalendarIcon } from "lucide-react";
import { Button } from "@/components/ui/button";

interface CollegeEventsProps {
  college: College;
}

const CollegeEvents: React.FC<CollegeEventsProps> = ({ college }) => {
  if (!college.upcomingEvents || college.upcomingEvents.length === 0) {
    return null;
  }

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-xl font-bold mb-4">Upcoming Events</h2>
        
        <div className="space-y-4">
          {college.upcomingEvents.map((event, index) => (
            <div key={index} className="border-b pb-4 last:border-0 last:pb-0">
              <div className="flex items-center gap-2 text-primary mb-2">
                <CalendarIcon className="h-4 w-4" />
                <span className="text-sm font-medium">{event.date}</span>
              </div>
              <h3 className="font-semibold">{event.name}</h3>
              <p className="text-sm text-gray-600 mt-1">{event.description}</p>
              {event.link && (
                <Button variant="link" className="p-0 h-auto mt-2" asChild>
                  <a href={event.link} target="_blank" rel="noopener noreferrer">
                    Learn More
                  </a>
                </Button>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default CollegeEvents;
