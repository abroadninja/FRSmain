
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { College, isGlobalCollege } from "@/types/college.types";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface CollegeGalleryProps {
  college: College;
}

const CollegeGallery: React.FC<CollegeGalleryProps> = ({ college }) => {
  if (!college.images) {
    return null;
  }

  const isGlobal = isGlobalCollege(college);
  
  // Determine which images to show based on college type
  const campusImages = college.images.campus || [];
  const classroomImages = college.images.classrooms || [];
  const labImages = college.images.labs || [];
  const facilityImages = college.images.facilities || [];
  
  // Handle different property names based on college type
  const dormitoryImages = isGlobal 
    ? (college.images.dormitories || [])
    : (college.images.hostels || []);
  
  // Filter out empty image arrays
  const tabs = [
    { id: "campus", label: "Campus", images: campusImages },
    { id: "classrooms", label: "Classrooms", images: classroomImages },
    { id: "labs", label: "Labs", images: labImages },
    { id: "facilities", label: "Facilities", images: facilityImages },
    { id: isGlobal ? "dormitories" : "hostels", 
      label: isGlobal ? "Dormitories" : "Hostels", 
      images: dormitoryImages },
  ].filter(tab => tab.images && tab.images.length > 0);
  
  if (tabs.length === 0) {
    return null;
  }

  return (
    <Card>
      <CardContent className="p-6">
        <h2 className="text-2xl font-bold mb-4">Campus Gallery</h2>
        
        <Tabs defaultValue={tabs[0].id}>
          <TabsList className="mb-4">
            {tabs.map((tab) => (
              <TabsTrigger key={tab.id} value={tab.id}>{tab.label}</TabsTrigger>
            ))}
          </TabsList>
          
          {tabs.map((tab) => (
            <TabsContent key={tab.id} value={tab.id}>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {tab.images?.map((image, index) => (
                  <div key={index} className="aspect-video overflow-hidden rounded-md">
                    <img 
                      src={image} 
                      alt={`${college.name} ${tab.label} ${index + 1}`}
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-300" 
                    />
                  </div>
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default CollegeGallery;
