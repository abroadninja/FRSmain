
import React from 'react';
import { Card } from "@/components/ui/card";
import { Book, ChevronRight } from "lucide-react";

interface LessonCardProps {
  lessonNumber: number;
  title: string;
  goal: string;
  onClick: () => void;
  viewMode?: 'grid' | 'list';
  pillarColor?: string;
}

const LessonCard = ({ lessonNumber, title, goal, onClick, viewMode = 'grid', pillarColor = "bg-primary" }: LessonCardProps) => {
  if (viewMode === 'list') {
    return (
      <Card 
        className="p-3 hover:shadow-md transition-all cursor-pointer border border-gray-100 bg-white hover:border-primary/20 group"
        onClick={onClick}
      >
        <div className="flex items-center gap-3">
          <div className={`${pillarColor} w-10 h-10 rounded-full flex items-center justify-center text-white font-semibold`}>
            {lessonNumber}
          </div>
          
          <div className="flex-1">
            <h3 className="text-base font-semibold text-gray-800 group-hover:text-primary transition-colors">{title}</h3>
            <p className="text-xs text-gray-600 line-clamp-1">{goal}</p>
          </div>
          
          <ChevronRight className="h-4 w-4 text-gray-300 group-hover:text-primary" />
        </div>
      </Card>
    );
  }

  return (
    <Card 
      className="p-5 hover:shadow-lg transition-all cursor-pointer border border-gray-100 bg-white hover:border-primary/20 group h-full"
      onClick={onClick}
    >
      <div className="flex items-start gap-4">
        <div className={`${pillarColor} p-3 rounded-lg group-hover:bg-opacity-80 transition-colors`}>
          <Book className="h-5 w-5 text-white" />
        </div>
        
        <div className="flex-1">
          <div className="flex items-center justify-between">
            <span className={`text-sm font-medium text-white px-2 py-0.5 ${pillarColor} rounded-full`}>
              Lesson {lessonNumber}
            </span>
            <span className="text-xs text-gray-400 group-hover:text-primary transition-colors">
              View details →
            </span>
          </div>
          
          <h3 className="text-lg font-semibold text-gray-800 mt-2 group-hover:text-primary transition-colors">{title}</h3>
          <p className="text-sm text-gray-600 mt-1 line-clamp-2">{goal}</p>
        </div>
      </div>
    </Card>
  );
};

export default LessonCard;
