
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Book, GraduationCap, ArrowLeft, Layers, Search, Filter, ChevronRight } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ageGroups } from "@/data/classes/ageGroups";
import { Badge } from "@/components/ui/badge";
import PillarCard from "./PillarCard";

const FutureReadyClassesApp = () => {
  const [searchTerm, setSearchTerm] = React.useState('');
  const [selectedAgeGroup, setSelectedAgeGroup] = React.useState(ageGroups[0].id);
  
  // Current selected age group
  const currentGroup = ageGroups.find(group => group.id === selectedAgeGroup) || ageGroups[0];

  return (
    <div className="container mx-auto py-8 px-4 max-w-7xl">
      {/* Header section */}
      <div className="mb-8 bg-gradient-to-r from-purple-50 to-indigo-50 rounded-xl p-6 border border-purple-100">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <Button 
            variant="outline" 
            size="sm" 
            className="mb-4 md:mb-0 self-start"
            asChild
          >
            <Link to="/dashboard" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" /> Back to Dashboard
            </Link>
          </Button>
          
          <div className="flex-1 md:text-center">
            <h1 className="text-2xl font-bold text-primary flex items-center gap-2 justify-center">
              <Book className="h-6 w-6" />
              Holistic Future Readiness Lessons
            </h1>
            <p className="text-gray-600 mt-2 max-w-2xl md:mx-auto">
              Comprehensive lesson guides and resources for teachers to deliver engaging future readiness classes.
            </p>
          </div>

          <div className="hidden md:block w-[120px]">
            {/* Spacer for alignment */}
          </div>
        </div>
      </div>

      {/* Search and filters */}
      <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-100 mb-8">
        <div className="flex flex-col md:flex-row gap-4 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search lessons..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-gray-50"
            />
          </div>
          
          <Button variant="outline" className="gap-2 bg-gray-50">
            <Filter className="h-4 w-4" /> Filter
          </Button>
        </div>
        
        {/* Age group selection */}
        <div className="flex overflow-x-auto pb-2 gap-2">
          {ageGroups.map((group) => (
            <Button 
              key={group.id}
              variant={selectedAgeGroup === group.id ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedAgeGroup(group.id)}
              className={selectedAgeGroup === group.id ? "" : "bg-gray-50"}
            >
              {group.name}
            </Button>
          ))}
        </div>
      </div>

      {/* Age group overview card */}
      <div className="bg-gradient-to-r from-purple-50 to-indigo-50 p-6 rounded-lg shadow-sm border border-purple-100 mb-8">
        <div className="flex flex-col md:flex-row justify-between gap-6">
          <div>
            <h2 className="text-xl font-bold text-primary flex items-center gap-2">
              <GraduationCap className="h-5 w-5" />
              {currentGroup.name} <span className="text-gray-500 ml-2">({currentGroup.ageRange})</span>
            </h2>
            <p className="text-gray-600 mt-2">{currentGroup.description}</p>
            
            {/* Pillar badges */}
            <div className="mt-4">
              <h3 className="text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                <Layers className="h-4 w-4 text-primary" /> Thematic Pillars
              </h3>
              <div className="flex flex-wrap gap-2">
                {currentGroup.pillars && currentGroup.pillars.map(pillar => (
                  <Badge 
                    key={pillar.id}
                    className={`${pillar.color} text-white px-3 py-1`}
                    variant="secondary"
                  >
                    {pillar.name}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="text-center bg-primary/10 p-4 rounded-lg">
              <span className="text-2xl font-bold text-primary">{currentGroup.totalLessons}</span>
              <p className="text-xs text-gray-600">Lessons</p>
            </div>
            
            <div className="text-center bg-primary/10 p-4 rounded-lg">
              <span className="text-2xl font-bold text-primary">{currentGroup.pillars?.length || 0}</span>
              <p className="text-xs text-gray-600">Pillars</p>
            </div>
          </div>
        </div>
      </div>

      {/* Pillars grid */}
      <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
        <Layers className="h-5 w-5 text-primary" /> Browse by Pillar
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {currentGroup.pillars?.map((pillar) => (
          <PillarCard key={pillar.id} pillar={pillar} groupId={currentGroup.id} />
        ))}
      </div>

      {/* Quick access to all lessons */}
      <div className="mt-8 text-center bg-gradient-to-r from-indigo-50 to-purple-50 p-6 rounded-lg border border-indigo-100">
        <h3 className="text-lg font-semibold mb-3">Need to see all lessons at once?</h3>
        <Link to={`/classes/${currentGroup.id}`}>
          <Button className="gap-2">
            View All Lessons <ChevronRight className="h-4 w-4" />
          </Button>
        </Link>
      </div>
    </div>
  );
};

export default FutureReadyClassesApp;
