
import React, { useMemo } from 'react';
import { Card } from "@/components/ui/card";
import { emotionalIntelligenceLessons } from '@/data/classes/lessonData/emotionalIntelligenceLessons';
import { socialSkillsLessons } from '@/data/classes/lessonData/socialSkillsLessons';
import { healthSafetyLessons } from '@/data/classes/lessonData/healthSafetyLessons';
import { learningThinkingLessons } from '@/data/classes/lessonData/learningThinkingLessons';
import { basicLifeSkillsLessons } from '@/data/classes/lessonData/basicLifeSkillsLessons';
import { communityAwarenessLessons } from '@/data/classes/lessonData/communityAwarenessLessons';
import { criticalThinkingLessons } from '@/data/classes/lessonData/criticalThinkingLessons';
import { creativityLessons } from '@/data/classes/lessonData/creativityLessons';
import { collaborationLessons } from '@/data/classes/lessonData/collaborationLessons';
import { communicationLessons } from '@/data/classes/lessonData/communicationLessons';
import { adaptabilityLessons } from '@/data/classes/lessonData/adaptabilityLessons';
import { Lesson } from '@/data/classes/ageGroups';

interface AllClassLessonsProps {
  onSelectLesson: (lesson: Lesson) => void;
}

const AllClassLessons = ({ onSelectLesson }: AllClassLessonsProps) => {
  const allLessons = useMemo(() => {
    const lessons = [
      ...emotionalIntelligenceLessons, 
      ...socialSkillsLessons, 
      ...healthSafetyLessons, 
      ...learningThinkingLessons, 
      ...basicLifeSkillsLessons, 
      ...communityAwarenessLessons,
      ...criticalThinkingLessons,
      ...creativityLessons,
      ...collaborationLessons,
      ...communicationLessons,
      ...adaptabilityLessons
    ];
    
    // Remove duplicate lessons by ID to ensure an accurate count
    const uniqueLessonMap = new Map();
    lessons.forEach(lesson => {
      uniqueLessonMap.set(lesson.id, lesson);
    });
    
    const uniqueLessons = Array.from(uniqueLessonMap.values());
    return uniqueLessons.sort((a, b) => a.id - b.id);
  }, []);

  return (
    <div className="space-y-4">
      <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100">
        <h2 className="text-xl font-semibold mb-2">All Lessons</h2>
        <p className="text-gray-600">View all lessons in numerical order</p>
        <p className="text-sm text-primary mt-2">Total Lessons: {allLessons.length}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {allLessons.map((lesson) => (
          <Card 
            key={lesson.id}
            className="p-4 cursor-pointer hover:shadow-md transition-shadow"
            onClick={() => onSelectLesson(lesson)}
          >
            <div className="flex items-start gap-3">
              <span className="text-2xl font-bold text-primary min-w-[2.5rem]">
                {lesson.id}
              </span>
              <div>
                <h3 className="font-medium">{lesson.title}</h3>
                <p className="text-sm text-gray-600 mt-1">{lesson.goal}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default AllClassLessons;
