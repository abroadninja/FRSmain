
import React from 'react';
import { Card } from "@/components/ui/card";
import { Lesson } from '@/data/classes/ageGroups';
import { Lightbulb, MessageSquare, FileText, Link2, Video, Clock, Target } from 'lucide-react';

interface LessonDetailsProps {
  lesson: Lesson;
  onBack: () => void;
}

const LessonDetails: React.FC<LessonDetailsProps> = ({ lesson, onBack }) => {
  return (
    <div className="animate-fade-in">
      <button 
        onClick={onBack}
        className="text-primary font-medium mb-6 flex items-center gap-2 hover:underline"
      >
        ← Back to Lessons
      </button>

      <div className="mb-6 bg-primary/5 p-6 rounded-lg border border-primary/10">
        <span className="text-sm font-medium text-primary px-2 py-0.5 bg-primary/20 rounded-full">
          Lesson {lesson.id}
        </span>
        <h1 className="text-3xl font-bold text-gray-800 mt-2 mb-3">
          {lesson.title}
        </h1>
        <p className="text-lg text-gray-600">{lesson.goal}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          <Card className="p-6 border border-gray-100">
            <div className="flex items-start gap-3 mb-6">
              <Lightbulb className="h-5 w-5 text-amber-500 mt-1 flex-shrink-0" />
              <div>
                <h2 className="font-semibold text-gray-800 mb-2">Key Idea</h2>
                <p className="text-gray-600 leading-relaxed">{lesson.keyIdea}</p>
              </div>
            </div>

            <div className="flex items-start gap-3 mb-6">
              <FileText className="h-5 w-5 text-blue-500 mt-1 flex-shrink-0" />
              <div>
                <h2 className="font-semibold text-gray-800 mb-2">Blackboard Activity</h2>
                <p className="text-gray-600 leading-relaxed whitespace-pre-wrap">{lesson.blackboardActivity}</p>
              </div>
            </div>

            {lesson.discussionPoints && lesson.discussionPoints.length > 0 && (
              <div className="flex items-start gap-3">
                <MessageSquare className="h-5 w-5 text-green-500 mt-1 flex-shrink-0" />
                <div>
                  <h2 className="font-semibold text-gray-800 mb-2">Discussion Points</h2>
                  <ul className="space-y-2">
                    {lesson.discussionPoints.map((point, index) => (
                      <li key={index} className="text-gray-600 leading-relaxed flex items-start gap-2">
                        <span className="inline-block h-5 w-5 bg-green-100 text-green-700 rounded-full flex items-center justify-center text-xs font-medium flex-shrink-0 mt-0.5">
                          {index + 1}
                        </span>
                        <span>{point}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </Card>
        </div>

        <div className="space-y-6">
          {lesson.resourceLinks && (
            <Card className="p-6 bg-gradient-to-b from-blue-50 to-white border border-gray-100">
              <h2 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
                <Link2 className="h-4 w-4 text-blue-500" />
                Resource Links for Parents
              </h2>
              <p className="text-sm text-gray-500 italic mb-4">Share these resources via WhatsApp</p>
              
              <div className="space-y-4">
                {lesson.resourceLinks.video && (
                  <div className="bg-white p-4 rounded-lg border border-gray-100">
                    <div className="flex items-center gap-3 mb-2">
                      <Video className="h-4 w-4 text-primary" />
                      <h3 className="font-medium text-gray-700">Video</h3>
                    </div>
                    <p className="text-sm text-gray-600">{lesson.resourceLinks.video}</p>
                  </div>
                )}
                
                {lesson.resourceLinks.article && (
                  <div className="bg-white p-4 rounded-lg border border-gray-100">
                    <div className="flex items-center gap-3 mb-2">
                      <FileText className="h-4 w-4 text-primary" />
                      <h3 className="font-medium text-gray-700">Article/Activity</h3>
                    </div>
                    <p className="text-sm text-gray-600">{lesson.resourceLinks.article}</p>
                  </div>
                )}
              </div>
            </Card>
          )}
          
          <Card className="p-6 border border-gray-100 bg-gradient-to-b from-amber-50 to-white">
            <h2 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
              <Clock className="h-4 w-4 text-amber-500" />
              Suggested Timing
            </h2>
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Introduction</span>
                <span className="text-sm font-medium text-gray-700">5-10 mins</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Main Activity</span>
                <span className="text-sm font-medium text-gray-700">15-20 mins</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Discussion</span>
                <span className="text-sm font-medium text-gray-700">10-15 mins</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Wrap-up</span>
                <span className="text-sm font-medium text-gray-700">5 mins</span>
              </div>
            </div>
          </Card>
          
          <Card className="p-6 border border-gray-100 bg-gradient-to-b from-green-50 to-white">
            <h2 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
              <Target className="h-4 w-4 text-green-500" />
              Learning Outcomes
            </h2>
            <ul className="space-y-2">
              <li className="text-sm text-gray-600 flex items-start gap-2">
                <span className="text-green-500">✓</span>
                <span>Understanding of the concept</span>
              </li>
              <li className="text-sm text-gray-600 flex items-start gap-2">
                <span className="text-green-500">✓</span>
                <span>Application to daily life</span>
              </li>
              <li className="text-sm text-gray-600 flex items-start gap-2">
                <span className="text-green-500">✓</span>
                <span>Development of key skills</span>
              </li>
            </ul>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default LessonDetails;
