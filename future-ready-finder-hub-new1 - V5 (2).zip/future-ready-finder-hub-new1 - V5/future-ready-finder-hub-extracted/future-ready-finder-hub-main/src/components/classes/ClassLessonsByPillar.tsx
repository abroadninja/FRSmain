
import React, { useState, useEffect } from 'react';
import { Card } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Pillar, Lesson } from '@/data/classes/ageGroups';

interface ClassLessonsByPillarProps {
  pillars: Pillar[];
  onSelectLesson: (lesson: Lesson) => void;
  initialPillar?: string;
  onPillarChange?: (pillarId: string) => void;
}

const ClassLessonsByPillar = ({ 
  pillars, 
  onSelectLesson,
  initialPillar,
  onPillarChange
}: ClassLessonsByPillarProps) => {
  const [activePillar, setActivePillar] = useState<string>(
    initialPillar || (pillars.length > 0 ? pillars[0].id : '')
  );
  
  useEffect(() => {
    if (initialPillar) {
      setActivePillar(initialPillar);
    }
  }, [initialPillar]);
  
  const handleTabChange = (value: string) => {
    setActivePillar(value);
    if (onPillarChange) {
      onPillarChange(value);
    }
  };
  
  const currentPillar = pillars.find(pillar => pillar.id === activePillar) || pillars[0];

  return (
    <div className="space-y-4">
      <Tabs 
        value={activePillar} 
        onValueChange={handleTabChange}
        className="w-full"
      >
        <div className="border-b mb-4 overflow-x-auto">
          <TabsList className="bg-transparent h-auto p-0 w-max min-w-full flex">
            {pillars.map((pillar) => (
              <TabsTrigger
                key={pillar.id}
                value={pillar.id}
                className={`py-2 px-4 border-b-2 data-[state=active]:border-primary data-[state=active]:shadow-none data-[state=active]:text-primary font-medium whitespace-nowrap`}
              >
                {pillar.name}
              </TabsTrigger>
            ))}
          </TabsList>
        </div>
        
        {pillars.map((pillar) => (
          <TabsContent 
            key={pillar.id} 
            value={pillar.id}
            className="mt-0 pt-2"
          >
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-100 mb-4">
              <h2 className="text-xl font-semibold mb-2">{pillar.name}</h2>
              <p className="text-gray-600">{pillar.description}</p>
              <div className="flex items-center gap-2 mt-2">
                <span className={`w-3 h-3 rounded-full ${pillar.color}`}></span>
                <p className="text-sm">
                  {pillar.lessons?.length || 0} Lessons
                </p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {currentPillar?.lessons?.sort((a, b) => a.id - b.id).map((lesson) => (
                <Card 
                  key={lesson.id}
                  className="p-4 cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => onSelectLesson(lesson)}
                >
                  <div className="flex items-start gap-3">
                    <span className="text-2xl font-bold text-primary min-w-[2.5rem]">
                      {lesson.id}
                    </span>
                    <div>
                      <h3 className="font-medium">{lesson.title}</h3>
                      <p className="text-sm text-gray-600 mt-1">{lesson.goal}</p>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
};

export default ClassLessonsByPillar;
