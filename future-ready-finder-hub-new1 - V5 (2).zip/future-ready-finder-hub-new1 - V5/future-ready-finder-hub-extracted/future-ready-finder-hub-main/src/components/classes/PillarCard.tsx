
import React from 'react';
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Pillar } from "@/data/classes/ageGroups";
import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";

interface PillarCardProps {
  pillar: Pillar;
  groupId: string;
}

const PillarCard = ({ pillar, groupId }: PillarCardProps) => {
  return (
    <Card className="border border-gray-100 bg-white hover:shadow-md transition-all p-5">
      <div className="flex items-start gap-4">
        <div className={`${pillar.color} text-white p-3 rounded-lg flex items-center justify-center`}>
          <span className="font-bold text-lg">{pillar.name.charAt(0)}</span>
        </div>
        
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-800 mb-1">{pillar.name}</h3>
          <p className="text-sm text-gray-600 mb-3 line-clamp-2">{pillar.description}</p>
          
          <div className="flex flex-wrap gap-2 mb-3">
            {pillar.lessons.slice(0, 3).map(lesson => (
              <Badge key={lesson.id} variant="outline" className="bg-gray-50">
                {lesson.title}
              </Badge>
            ))}
            {pillar.lessons.length > 3 && (
              <Badge variant="outline" className="bg-gray-50">
                +{pillar.lessons.length - 3} more
              </Badge>
            )}
          </div>
          
          <div className="mt-2 flex justify-between items-center">
            <span className="text-sm text-gray-500 font-medium">
              {pillar.lessons.length} lessons
            </span>
            <Link 
              to={`/classes/${groupId}?pillar=${pillar.id}`}
              className="text-primary text-sm flex items-center hover:underline"
            >
              Browse lessons <ChevronRight className="h-4 w-4 ml-1" />
            </Link>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default PillarCard;
