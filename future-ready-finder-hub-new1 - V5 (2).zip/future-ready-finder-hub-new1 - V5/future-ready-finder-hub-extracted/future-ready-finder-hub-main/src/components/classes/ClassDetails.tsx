
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowLeft, Book } from 'lucide-react';
import { Button } from "@/components/ui/button";
import ClassLessonsByPillar from './ClassLessonsByPillar';
import LessonDetails from './LessonDetails';
import AllClassLessons from './AllClassLessons';
import { ageGroups, AgeGroup, Lesson, Pillar } from '@/data/classes/ageGroups';

const ClassDetails = () => {
  const { groupId } = useParams<{ groupId: string }>();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const initialPillarId = searchParams.get('pillar');
  
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null);
  const [currentGroup, setCurrentGroup] = useState<AgeGroup | null>(null);
  const [selectedPillarId, setSelectedPillarId] = useState<string | undefined>(initialPillarId || undefined);
  
  useEffect(() => {
    console.log("Looking for age group with ID:", groupId);
    
    const group = groupId ? ageGroups.find(g => g.id === groupId) : null;
    console.log("Found group:", group);
    
    setCurrentGroup(group);
    setSelectedLesson(null);
    
    if (initialPillarId) {
      setSelectedPillarId(initialPillarId);
    }
  }, [groupId, initialPillarId]);
  
  const handleLessonClick = (lesson: Lesson) => {
    setSelectedLesson(lesson);
    window.scrollTo(0, 0);
  };
  
  const handleBackToList = () => {
    setSelectedLesson(null);
    window.scrollTo(0, 0);
  };
  
  const handleBackToGroups = () => {
    navigate('/classes');
  };

  const handlePillarChange = (pillarId: string) => {
    setSelectedPillarId(pillarId);
  };

  if (!currentGroup) {
    return (
      <div className="container mx-auto py-8 px-4 text-center">
        <h2 className="text-xl font-bold mb-4">Age group not found</h2>
        <Button onClick={() => navigate('/classes')}>
          Back to Age Groups
        </Button>
      </div>
    );
  }

  const selectedPillar = selectedPillarId 
    ? currentGroup.pillars.find(p => p.id === selectedPillarId)
    : currentGroup.pillars[0];

  return (
    <div className="container mx-auto py-8 px-4 max-w-7xl">
      {selectedLesson ? (
        <LessonDetails 
          lesson={selectedLesson}
          onBack={handleBackToList}
        />
      ) : (
        <div className="animate-fade-in">
          <div className="flex flex-col md:flex-row items-start justify-between mb-8 gap-4">
            <Button 
              variant="outline" 
              onClick={handleBackToGroups} 
              className="self-start flex items-center gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Age Groups
            </Button>
          </div>
          
          <div className="mb-8 bg-white p-6 rounded-xl shadow-sm border border-gray-100">
            <div className="flex flex-col md:flex-row justify-between gap-4">
              <div>
                <h1 className="text-2xl font-bold text-primary mb-2 flex items-center gap-2">
                  <Book className="h-5 w-5" />
                  {currentGroup.name}
                  <span className="text-gray-500 text-lg ml-2">
                    ({currentGroup.ageRange})
                  </span>
                </h1>
                <p className="text-gray-600 mt-1">{currentGroup.description}</p>
                
                <div className="mt-3 flex flex-wrap gap-2">
                  {currentGroup.pillars && currentGroup.pillars.map(pillar => (
                    <span 
                      key={pillar.id} 
                      className={`${pillar.color} text-white text-xs px-2 py-1 rounded-full`}
                    >
                      {pillar.name}
                    </span>
                  ))}
                </div>
              </div>
              
              <div className="mt-4 md:mt-0 flex items-center gap-3">
                <div className="text-center bg-primary/10 p-4 rounded-lg">
                  <span className="text-2xl font-bold text-primary">100</span>
                  <p className="text-xs text-gray-600">Total Lessons</p>
                </div>
                
                <div className="text-center bg-primary/10 p-4 rounded-lg">
                  <span className="text-2xl font-bold text-primary">{currentGroup.pillars?.length - 1}</span>
                  <p className="text-xs text-gray-600">Pillars</p>
                </div>
              </div>
            </div>
          </div>
          
          {selectedPillarId === "all-lessons" ? (
            <AllClassLessons onSelectLesson={handleLessonClick} />
          ) : (
            <ClassLessonsByPillar 
              pillars={currentGroup.pillars || []} 
              onSelectLesson={handleLessonClick}
              initialPillar={selectedPillarId}
              onPillarChange={handlePillarChange}
            />
          )}
        </div>
      )}
    </div>
  );
};

export default ClassDetails;
