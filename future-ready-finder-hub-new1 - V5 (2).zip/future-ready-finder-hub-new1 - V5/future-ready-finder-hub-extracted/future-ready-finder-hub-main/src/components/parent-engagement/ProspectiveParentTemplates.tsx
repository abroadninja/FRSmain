
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Copy, MessageSquare, FileText } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { prospectiveParentTemplates } from "@/data/parent-engagement/prospective-templates";

interface ProspectiveParentTemplatesProps {
  copyToClipboard: (text: string) => void;
}

const ProspectiveParentTemplates: React.FC<ProspectiveParentTemplatesProps> = ({ copyToClipboard }) => {
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [templateCategory, setTemplateCategory] = useState<string>("short-form");

  return (
    <div className="space-y-6">
      <Card className="bg-white border border-gray-100">
        <CardHeader>
          <CardTitle className="text-xl text-primary">Prospective Parent Communication Templates</CardTitle>
          <CardDescription>
            Ready-to-use templates to attract, engage, and nurture relationships with prospective parents
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700 mb-4">
            These professionally crafted templates help you effectively communicate with parents who are considering your school. 
            Each template highlights your school's focus on future readiness, providing compelling reasons for families to join your community.
          </p>
          
          <Tabs defaultValue={templateCategory} onValueChange={setTemplateCategory}>
            <TabsList className="mb-4">
              <TabsTrigger value="short-form">Short-Form</TabsTrigger>
              <TabsTrigger value="detailed">Detailed</TabsTrigger>
              <TabsTrigger value="community-focused">Community-Focused</TabsTrigger>
              <TabsTrigger value="social-media">Social Media</TabsTrigger>
            </TabsList>
            
            <TabsContent value="short-form">
              <div className="grid md:grid-cols-2 gap-4">
                {prospectiveParentTemplates
                  .filter(t => t.category === "short-form")
                  .map(template => (
                    <Card 
                      key={template.id} 
                      className="border border-gray-100 cursor-pointer hover:border-primary/30 hover:shadow-md transition-all"
                      onClick={() => setSelectedTemplate(template.id)}
                    >
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-lg">{template.title}</CardTitle>
                          <Badge variant="outline" className="bg-blue-50 text-blue-700">
                            {template.type}
                          </Badge>
                        </div>
                        <CardDescription className="line-clamp-2">{template.preview}</CardDescription>
                      </CardHeader>
                      <CardFooter>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="w-full justify-center" 
                          onClick={(e) => {
                            e.stopPropagation();
                            copyToClipboard(template.content);
                          }}
                        >
                          <Copy className="h-4 w-4 mr-2" /> Copy Template
                        </Button>
                      </CardFooter>
                    </Card>
                  ))
                }
              </div>
            </TabsContent>
            
            <TabsContent value="detailed">
              <div className="grid md:grid-cols-2 gap-4">
                {prospectiveParentTemplates
                  .filter(t => t.category === "detailed")
                  .map(template => (
                    <Card 
                      key={template.id} 
                      className="border border-gray-100 cursor-pointer hover:border-primary/30 hover:shadow-md transition-all"
                      onClick={() => setSelectedTemplate(template.id)}
                    >
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-lg">{template.title}</CardTitle>
                          <Badge variant="outline" className="bg-blue-50 text-blue-700">
                            {template.type}
                          </Badge>
                        </div>
                        <CardDescription className="line-clamp-2">{template.preview}</CardDescription>
                      </CardHeader>
                      <CardFooter>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="w-full justify-center" 
                          onClick={(e) => {
                            e.stopPropagation();
                            copyToClipboard(template.content);
                          }}
                        >
                          <Copy className="h-4 w-4 mr-2" /> Copy Template
                        </Button>
                      </CardFooter>
                    </Card>
                  ))
                }
              </div>
            </TabsContent>
            
            <TabsContent value="community-focused">
              <div className="grid md:grid-cols-2 gap-4">
                {prospectiveParentTemplates
                  .filter(t => t.category === "community-focused")
                  .map(template => (
                    <Card 
                      key={template.id} 
                      className="border border-gray-100 cursor-pointer hover:border-primary/30 hover:shadow-md transition-all"
                      onClick={() => setSelectedTemplate(template.id)}
                    >
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-lg">{template.title}</CardTitle>
                          <Badge variant="outline" className="bg-blue-50 text-blue-700">
                            {template.type}
                          </Badge>
                        </div>
                        <CardDescription className="line-clamp-2">{template.preview}</CardDescription>
                      </CardHeader>
                      <CardFooter>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="w-full justify-center" 
                          onClick={(e) => {
                            e.stopPropagation();
                            copyToClipboard(template.content);
                          }}
                        >
                          <Copy className="h-4 w-4 mr-2" /> Copy Template
                        </Button>
                      </CardFooter>
                    </Card>
                  ))
                }
              </div>
            </TabsContent>
            
            <TabsContent value="social-media">
              <div className="grid md:grid-cols-2 gap-4">
                {prospectiveParentTemplates
                  .filter(t => t.category === "social-media")
                  .map(template => (
                    <Card 
                      key={template.id} 
                      className="border border-gray-100 cursor-pointer hover:border-primary/30 hover:shadow-md transition-all"
                      onClick={() => setSelectedTemplate(template.id)}
                    >
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-lg">{template.title}</CardTitle>
                          <Badge variant="outline" className="bg-blue-50 text-blue-700">
                            {template.type}
                          </Badge>
                        </div>
                        <CardDescription className="line-clamp-2">{template.preview}</CardDescription>
                      </CardHeader>
                      <CardFooter>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="w-full justify-center" 
                          onClick={(e) => {
                            e.stopPropagation();
                            copyToClipboard(template.content);
                          }}
                        >
                          <Copy className="h-4 w-4 mr-2" /> Copy Template
                        </Button>
                      </CardFooter>
                    </Card>
                  ))
                }
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      
      {selectedTemplate && (
        <Card className="bg-white border border-gray-100">
          <CardHeader>
            <div className="flex justify-between">
              <div>
                <CardTitle>Template Preview</CardTitle>
                <CardDescription>
                  {prospectiveParentTemplates.find(t => t.id === selectedTemplate)?.title}
                </CardDescription>
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => {
                  const template = prospectiveParentTemplates.find(t => t.id === selectedTemplate);
                  if (template) copyToClipboard(template.content);
                }}
              >
                <Copy className="h-4 w-4 mr-2" /> Copy
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 p-4 rounded-md whitespace-pre-wrap text-gray-700">
              {prospectiveParentTemplates.find(t => t.id === selectedTemplate)?.content}
            </div>
          </CardContent>
        </Card>
      )}
      
      <Card className="bg-white border border-gray-100">
        <CardHeader>
          <CardTitle>Usage Tips</CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger>Best Practices for Engaging Prospective Parents</AccordionTrigger>
              <AccordionContent>
                <ul className="list-disc pl-5 space-y-2 text-gray-700">
                  <li><span className="font-medium">Personalize</span>: Always replace placeholder text with specific information about your school.</li>
                  <li><span className="font-medium">Follow up</span>: Send additional communications 3-5 days after initial contact.</li>
                  <li><span className="font-medium">Call to action</span>: Always include clear next steps (visit school, join WhatsApp group, etc.).</li>
                  <li><span className="font-medium">Visual appeal</span>: Add your school branding and relevant images when using these in emails/flyers.</li>
                  <li><span className="font-medium">Track effectiveness</span>: Note which messages generate the most response and refine your approach.</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-2">
              <AccordionTrigger>Communication Channels</AccordionTrigger>
              <AccordionContent>
                <ul className="list-disc pl-5 space-y-2 text-gray-700">
                  <li><span className="font-medium">WhatsApp</span>: Create broadcast lists for initial announcements and personal follow-ups.</li>
                  <li><span className="font-medium">Email</span>: Professional format for initial inquiries and detailed information.</li>
                  <li><span className="font-medium">Social Media</span>: Use shorter formats for awareness and directing to detailed information.</li>
                  <li><span className="font-medium">School Website</span>: Include these messages in your admissions or "For Prospective Parents" section.</li>
                  <li><span className="font-medium">Printed Materials</span>: Adapt for flyers and brochures to distribute locally.</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-3">
              <AccordionTrigger>Lead Management Strategy</AccordionTrigger>
              <AccordionContent>
                <p className="mb-3 text-gray-700">Create a simple system to track and nurture prospective parent leads:</p>
                <ol className="list-decimal pl-5 space-y-2 text-gray-700">
                  <li>Capture contact information consistently in your lead tracking sheet.</li>
                  <li>Categorize leads by interest level (hot, warm, cold) and source.</li>
                  <li>Schedule regular follow-ups using appropriate templates.</li>
                  <li>Document all interactions to personalize future communications.</li>
                  <li>Invite engaged prospects to parent community groups/events.</li>
                </ol>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>
    </div>
  );
};

export default ProspectiveParentTemplates;
