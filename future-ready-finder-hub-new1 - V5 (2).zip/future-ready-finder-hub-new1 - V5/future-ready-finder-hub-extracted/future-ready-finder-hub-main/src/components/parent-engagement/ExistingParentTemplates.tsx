
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Copy, MessageSquare, FileText } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { existingParentTemplates } from "@/data/parent-engagement/existing-templates";

interface ExistingParentTemplatesProps {
  copyToClipboard: (text: string) => void;
}

const ExistingParentTemplates: React.FC<ExistingParentTemplatesProps> = ({ copyToClipboard }) => {
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [templateCategory, setTemplateCategory] = useState<string>("announcements");

  return (
    <div className="space-y-6">
      <Card className="bg-white border border-gray-100">
        <CardHeader>
          <CardTitle className="text-xl text-primary">Existing Parent Communication Templates</CardTitle>
          <CardDescription>
            Ready-to-use templates to strengthen relationships with parents already in your school community
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700 mb-4">
            These templates help you maintain consistent, valuable communication with current parents. 
            Each template is designed to build trust, demonstrate your commitment to future readiness, 
            and encourage parent partnership in their child's education.
          </p>
          
          <Tabs defaultValue={templateCategory} onValueChange={setTemplateCategory}>
            <TabsList className="mb-4">
              <TabsTrigger value="announcements">Program Announcements</TabsTrigger>
              <TabsTrigger value="updates">Regular Updates</TabsTrigger>
              <TabsTrigger value="network">Family Network</TabsTrigger>
              <TabsTrigger value="skills">Skills Development</TabsTrigger>
            </TabsList>
            
            <TabsContent value="announcements">
              <div className="grid md:grid-cols-2 gap-4">
                {existingParentTemplates
                  .filter(t => t.category === "announcements")
                  .map(template => (
                    <Card 
                      key={template.id} 
                      className="border border-gray-100 cursor-pointer hover:border-primary/30 hover:shadow-md transition-all"
                      onClick={() => setSelectedTemplate(template.id)}
                    >
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-lg">{template.title}</CardTitle>
                          <Badge variant="outline" className="bg-green-50 text-green-700">
                            {template.type}
                          </Badge>
                        </div>
                        <CardDescription className="line-clamp-2">{template.preview}</CardDescription>
                      </CardHeader>
                      <CardFooter>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="w-full justify-center" 
                          onClick={(e) => {
                            e.stopPropagation();
                            copyToClipboard(template.content);
                          }}
                        >
                          <Copy className="h-4 w-4 mr-2" /> Copy Template
                        </Button>
                      </CardFooter>
                    </Card>
                  ))
                }
              </div>
            </TabsContent>
            
            <TabsContent value="updates">
              <div className="grid md:grid-cols-2 gap-4">
                {existingParentTemplates
                  .filter(t => t.category === "updates")
                  .map(template => (
                    <Card 
                      key={template.id} 
                      className="border border-gray-100 cursor-pointer hover:border-primary/30 hover:shadow-md transition-all"
                      onClick={() => setSelectedTemplate(template.id)}
                    >
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-lg">{template.title}</CardTitle>
                          <Badge variant="outline" className="bg-green-50 text-green-700">
                            {template.type}
                          </Badge>
                        </div>
                        <CardDescription className="line-clamp-2">{template.preview}</CardDescription>
                      </CardHeader>
                      <CardFooter>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="w-full justify-center" 
                          onClick={(e) => {
                            e.stopPropagation();
                            copyToClipboard(template.content);
                          }}
                        >
                          <Copy className="h-4 w-4 mr-2" /> Copy Template
                        </Button>
                      </CardFooter>
                    </Card>
                  ))
                }
              </div>
            </TabsContent>
            
            <TabsContent value="network">
              <div className="grid md:grid-cols-2 gap-4">
                {existingParentTemplates
                  .filter(t => t.category === "network")
                  .map(template => (
                    <Card 
                      key={template.id} 
                      className="border border-gray-100 cursor-pointer hover:border-primary/30 hover:shadow-md transition-all"
                      onClick={() => setSelectedTemplate(template.id)}
                    >
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-lg">{template.title}</CardTitle>
                          <Badge variant="outline" className="bg-green-50 text-green-700">
                            {template.type}
                          </Badge>
                        </div>
                        <CardDescription className="line-clamp-2">{template.preview}</CardDescription>
                      </CardHeader>
                      <CardFooter>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="w-full justify-center" 
                          onClick={(e) => {
                            e.stopPropagation();
                            copyToClipboard(template.content);
                          }}
                        >
                          <Copy className="h-4 w-4 mr-2" /> Copy Template
                        </Button>
                      </CardFooter>
                    </Card>
                  ))
                }
              </div>
            </TabsContent>
            
            <TabsContent value="skills">
              <div className="grid md:grid-cols-2 gap-4">
                {existingParentTemplates
                  .filter(t => t.category === "skills")
                  .map(template => (
                    <Card 
                      key={template.id} 
                      className="border border-gray-100 cursor-pointer hover:border-primary/30 hover:shadow-md transition-all"
                      onClick={() => setSelectedTemplate(template.id)}
                    >
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-lg">{template.title}</CardTitle>
                          <Badge variant="outline" className="bg-green-50 text-green-700">
                            {template.type}
                          </Badge>
                        </div>
                        <CardDescription className="line-clamp-2">{template.preview}</CardDescription>
                      </CardHeader>
                      <CardFooter>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="w-full justify-center" 
                          onClick={(e) => {
                            e.stopPropagation();
                            copyToClipboard(template.content);
                          }}
                        >
                          <Copy className="h-4 w-4 mr-2" /> Copy Template
                        </Button>
                      </CardFooter>
                    </Card>
                  ))
                }
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      
      {selectedTemplate && (
        <Card className="bg-white border border-gray-100">
          <CardHeader>
            <div className="flex justify-between">
              <div>
                <CardTitle>Template Preview</CardTitle>
                <CardDescription>
                  {existingParentTemplates.find(t => t.id === selectedTemplate)?.title}
                </CardDescription>
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => {
                  const template = existingParentTemplates.find(t => t.id === selectedTemplate);
                  if (template) copyToClipboard(template.content);
                }}
              >
                <Copy className="h-4 w-4 mr-2" /> Copy
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 p-4 rounded-md whitespace-pre-wrap text-gray-700">
              {existingParentTemplates.find(t => t.id === selectedTemplate)?.content}
            </div>
          </CardContent>
        </Card>
      )}
      
      <Card className="bg-white border border-gray-100">
        <CardHeader>
          <CardTitle>Parent Engagement Strategies</CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger>Building Effective Parent Communities</AccordionTrigger>
              <AccordionContent>
                <ul className="list-disc pl-5 space-y-2 text-gray-700">
                  <li><span className="font-medium">Create a structure</span>: Establish clear communication channels and scheduled updates.</li>
                  <li><span className="font-medium">Provide value first</span>: Share useful information before asking for parent involvement.</li>
                  <li><span className="font-medium">Recognize contribution</span>: Acknowledge parents who participate and support initiatives.</li>
                  <li><span className="font-medium">Foster peer connections</span>: Create opportunities for parents to connect with each other.</li>
                  <li><span className="font-medium">Make it practical</span>: Focus on actionable tips that parents can implement immediately.</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-2">
              <AccordionTrigger>Communication Calendar</AccordionTrigger>
              <AccordionContent>
                <p className="mb-3 text-gray-700">Establish a consistent communication rhythm:</p>
                <ul className="list-disc pl-5 space-y-2 text-gray-700">
                  <li><span className="font-medium">Weekly</span>: Brief updates on classroom activities and upcoming events.</li>
                  <li><span className="font-medium">Monthly</span>: More detailed newsletter with future skills focus areas and parent tips.</li>
                  <li><span className="font-medium">Quarterly</span>: Progress updates on school-wide future readiness initiatives.</li>
                  <li><span className="font-medium">Beginning/End of Term</span>: Major announcements and program updates.</li>
                  <li><span className="font-medium">Just-in-time</span>: Specific guidance before new skills units or programs are introduced.</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-3">
              <AccordionTrigger>Measuring Engagement Success</AccordionTrigger>
              <AccordionContent>
                <p className="mb-3 text-gray-700">Track these metrics to assess your parent engagement efforts:</p>
                <ol className="list-decimal pl-5 space-y-2 text-gray-700">
                  <li>Open/read rates for digital communications</li>
                  <li>Parent attendance at school events and meetings</li>
                  <li>Response rates to surveys and feedback requests</li>
                  <li>Activity levels in parent WhatsApp groups or online communities</li>
                  <li>Parent implementation of suggested activities at home (via simple feedback forms)</li>
                  <li>Testimonials and qualitative feedback on the value of communications</li>
                </ol>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </CardContent>
      </Card>
    </div>
  );
};

export default ExistingParentTemplates;
