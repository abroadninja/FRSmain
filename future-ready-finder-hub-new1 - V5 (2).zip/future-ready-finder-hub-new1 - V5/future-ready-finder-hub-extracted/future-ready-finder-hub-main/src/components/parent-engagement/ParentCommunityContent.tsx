
import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Copy, Search, FileText } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { parentCommunityContent } from "@/data/parent-engagement/community-content";

interface ParentCommunityContentProps {
  copyToClipboard: (text: string) => void;
}

const ParentCommunityContent: React.FC<ParentCommunityContentProps> = ({ copyToClipboard }) => {
  const [selectedContent, setSelectedContent] = useState<string | null>(null);
  const [contentCategory, setContentCategory] = useState<string>("essential-skills");
  const [searchTerm, setSearchTerm] = useState("");
  
  // Filter content based on search term
  const filteredContent = parentCommunityContent.filter(
    item => item.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
           item.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
           item.content.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  // Get content for the current category
  const categoryContent = filteredContent.filter(item => item.category === contentCategory);
  
  // Age group content
  const getAgeGroupContent = (ageGroup: string) => {
    return filteredContent.filter(item => item.ageGroup === ageGroup);
  };

  return (
    <div className="space-y-6">
      <Card className="bg-white border border-gray-100">
        <CardHeader>
          <CardTitle className="text-xl text-primary">Valuable Parent Community Content</CardTitle>
          <CardDescription>
            Ready-to-share educational content to engage and support parents in your school community
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700 mb-4">
            This collection provides high-value content to share with parents through your communication channels (WhatsApp, email, newsletters).
            Each piece is designed to help parents understand and support the future-ready skills their children are developing.
          </p>
          
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              type="text"
              placeholder="Search content by keyword..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 rounded-md border border-gray-200"
            />
          </div>
          
          <Tabs defaultValue={contentCategory} onValueChange={setContentCategory}>
            <TabsList className="mb-4 flex flex-wrap">
              <TabsTrigger value="essential-skills">Essential Skills</TabsTrigger>
              <TabsTrigger value="financial-literacy">Financial Literacy</TabsTrigger>
              <TabsTrigger value="digital-skills">Digital Skills</TabsTrigger>
              <TabsTrigger value="mindset">Growth Mindset</TabsTrigger>
              <TabsTrigger value="age-specific">Age-Specific</TabsTrigger>
            </TabsList>
            
            <TabsContent value="essential-skills">
              <div className="grid md:grid-cols-2 gap-4">
                {categoryContent.map(item => (
                  <Card 
                    key={item.id} 
                    className="border border-gray-100 cursor-pointer hover:border-primary/30 hover:shadow-md transition-all h-full"
                    onClick={() => setSelectedContent(item.id)}
                  >
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg">{item.title}</CardTitle>
                        <Badge variant="outline" className="bg-purple-50 text-purple-700">
                          {item.format}
                        </Badge>
                      </div>
                      <CardDescription>{item.description}</CardDescription>
                    </CardHeader>
                    <CardFooter>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="w-full justify-center" 
                        onClick={(e) => {
                          e.stopPropagation();
                          copyToClipboard(item.content);
                        }}
                      >
                        <Copy className="h-4 w-4 mr-2" /> Copy Content
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="financial-literacy">
              <div className="grid md:grid-cols-2 gap-4">
                {filteredContent
                  .filter(item => item.category === "financial-literacy")
                  .map(item => (
                    <Card 
                      key={item.id} 
                      className="border border-gray-100 cursor-pointer hover:border-primary/30 hover:shadow-md transition-all h-full"
                      onClick={() => setSelectedContent(item.id)}
                    >
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-lg">{item.title}</CardTitle>
                          <Badge variant="outline" className="bg-purple-50 text-purple-700">
                            {item.format}
                          </Badge>
                        </div>
                        <CardDescription>{item.description}</CardDescription>
                      </CardHeader>
                      <CardFooter>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="w-full justify-center" 
                          onClick={(e) => {
                            e.stopPropagation();
                            copyToClipboard(item.content);
                          }}
                        >
                          <Copy className="h-4 w-4 mr-2" /> Copy Content
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
              </div>
            </TabsContent>
            
            <TabsContent value="digital-skills">
              <div className="grid md:grid-cols-2 gap-4">
                {filteredContent
                  .filter(item => item.category === "digital-skills")
                  .map(item => (
                    <Card 
                      key={item.id} 
                      className="border border-gray-100 cursor-pointer hover:border-primary/30 hover:shadow-md transition-all h-full"
                      onClick={() => setSelectedContent(item.id)}
                    >
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-lg">{item.title}</CardTitle>
                          <Badge variant="outline" className="bg-purple-50 text-purple-700">
                            {item.format}
                          </Badge>
                        </div>
                        <CardDescription>{item.description}</CardDescription>
                      </CardHeader>
                      <CardFooter>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="w-full justify-center" 
                          onClick={(e) => {
                            e.stopPropagation();
                            copyToClipboard(item.content);
                          }}
                        >
                          <Copy className="h-4 w-4 mr-2" /> Copy Content
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
              </div>
            </TabsContent>
            
            <TabsContent value="mindset">
              <div className="grid md:grid-cols-2 gap-4">
                {filteredContent
                  .filter(item => item.category === "mindset")
                  .map(item => (
                    <Card 
                      key={item.id} 
                      className="border border-gray-100 cursor-pointer hover:border-primary/30 hover:shadow-md transition-all h-full"
                      onClick={() => setSelectedContent(item.id)}
                    >
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-lg">{item.title}</CardTitle>
                          <Badge variant="outline" className="bg-purple-50 text-purple-700">
                            {item.format}
                          </Badge>
                        </div>
                        <CardDescription>{item.description}</CardDescription>
                      </CardHeader>
                      <CardFooter>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="w-full justify-center" 
                          onClick={(e) => {
                            e.stopPropagation();
                            copyToClipboard(item.content);
                          }}
                        >
                          <Copy className="h-4 w-4 mr-2" /> Copy Content
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
              </div>
            </TabsContent>
            
            <TabsContent value="age-specific">
              <Tabs defaultValue="ages-7-9">
                <TabsList className="mb-4">
                  <TabsTrigger value="ages-7-9">Ages 7-9</TabsTrigger>
                  <TabsTrigger value="ages-10-12">Ages 10-12</TabsTrigger>
                  <TabsTrigger value="ages-13-15">Ages 13-15</TabsTrigger>
                  <TabsTrigger value="ages-16-18">Ages 16-18</TabsTrigger>
                </TabsList>
                
                <TabsContent value="ages-7-9">
                  <div className="grid md:grid-cols-2 gap-4">
                    {getAgeGroupContent("ages-7-9").map(item => (
                      <Card 
                        key={item.id} 
                        className="border border-gray-100 cursor-pointer hover:border-primary/30 hover:shadow-md transition-all h-full"
                        onClick={() => setSelectedContent(item.id)}
                      >
                        <CardHeader className="pb-2">
                          <div className="flex justify-between items-start">
                            <CardTitle className="text-lg">{item.title}</CardTitle>
                            <Badge variant="outline" className="bg-purple-50 text-purple-700">
                              {item.format}
                            </Badge>
                          </div>
                          <CardDescription>{item.description}</CardDescription>
                        </CardHeader>
                        <CardFooter>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="w-full justify-center" 
                            onClick={(e) => {
                              e.stopPropagation();
                              copyToClipboard(item.content);
                            }}
                          >
                            <Copy className="h-4 w-4 mr-2" /> Copy Content
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
                
                {/* Repeat similar structure for other age groups */}
                <TabsContent value="ages-10-12">
                  <div className="grid md:grid-cols-2 gap-4">
                    {getAgeGroupContent("ages-10-12").map(item => (
                      <Card 
                        key={item.id} 
                        className="border border-gray-100 cursor-pointer hover:border-primary/30 hover:shadow-md transition-all h-full"
                        onClick={() => setSelectedContent(item.id)}
                      >
                        <CardHeader className="pb-2">
                          <div className="flex justify-between items-start">
                            <CardTitle className="text-lg">{item.title}</CardTitle>
                            <Badge variant="outline" className="bg-purple-50 text-purple-700">
                              {item.format}
                            </Badge>
                          </div>
                          <CardDescription>{item.description}</CardDescription>
                        </CardHeader>
                        <CardFooter>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="w-full justify-center" 
                            onClick={(e) => {
                              e.stopPropagation();
                              copyToClipboard(item.content);
                            }}
                          >
                            <Copy className="h-4 w-4 mr-2" /> Copy Content
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
                
                {/* Remaining age groups follow the same pattern */}
                <TabsContent value="ages-13-15">
                  <div className="grid md:grid-cols-2 gap-4">
                    {getAgeGroupContent("ages-13-15").map(item => (
                      <Card 
                        key={item.id} 
                        className="border border-gray-100 cursor-pointer hover:border-primary/30 hover:shadow-md transition-all h-full"
                        onClick={() => setSelectedContent(item.id)}
                      >
                        <CardHeader className="pb-2">
                          <div className="flex justify-between items-start">
                            <CardTitle className="text-lg">{item.title}</CardTitle>
                            <Badge variant="outline" className="bg-purple-50 text-purple-700">
                              {item.format}
                            </Badge>
                          </div>
                          <CardDescription>{item.description}</CardDescription>
                        </CardHeader>
                        <CardFooter>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="w-full justify-center" 
                            onClick={(e) => {
                              e.stopPropagation();
                              copyToClipboard(item.content);
                            }}
                          >
                            <Copy className="h-4 w-4 mr-2" /> Copy Content
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
                
                <TabsContent value="ages-16-18">
                  <div className="grid md:grid-cols-2 gap-4">
                    {getAgeGroupContent("ages-16-18").map(item => (
                      <Card 
                        key={item.id} 
                        className="border border-gray-100 cursor-pointer hover:border-primary/30 hover:shadow-md transition-all h-full"
                        onClick={() => setSelectedContent(item.id)}
                      >
                        <CardHeader className="pb-2">
                          <div className="flex justify-between items-start">
                            <CardTitle className="text-lg">{item.title}</CardTitle>
                            <Badge variant="outline" className="bg-purple-50 text-purple-700">
                              {item.format}
                            </Badge>
                          </div>
                          <CardDescription>{item.description}</CardDescription>
                        </CardHeader>
                        <CardFooter>
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="w-full justify-center" 
                            onClick={(e) => {
                              e.stopPropagation();
                              copyToClipboard(item.content);
                            }}
                          >
                            <Copy className="h-4 w-4 mr-2" /> Copy Content
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
      
      {selectedContent && (
        <Card className="bg-white border border-gray-100">
          <CardHeader>
            <div className="flex justify-between">
              <div>
                <CardTitle>Content Preview</CardTitle>
                <CardDescription>
                  {parentCommunityContent.find(item => item.id === selectedContent)?.title}
                </CardDescription>
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => {
                  const content = parentCommunityContent.find(item => item.id === selectedContent);
                  if (content) copyToClipboard(content.content);
                }}
              >
                <Copy className="h-4 w-4 mr-2" /> Copy
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-50 p-4 rounded-md whitespace-pre-wrap text-gray-700">
              {parentCommunityContent.find(item => item.id === selectedContent)?.content}
            </div>
          </CardContent>
        </Card>
      )}
      
      <Card className="bg-white border border-gray-100">
        <CardHeader>
          <CardTitle>Content Sharing Best Practices</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-semibold text-primary mb-2">Frequency & Timing</h3>
              <ul className="list-disc pl-5 space-y-1 text-gray-700">
                <li>Share value-added content 1-2 times per week in parent communities</li>
                <li>Aim for times when parents are most likely to engage (typically evenings)</li>
                <li>Maintain consistency while avoiding overwhelming parents with too much information</li>
                <li>Group related content into themed weeks or months for better retention</li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-primary mb-2">Formatting for Maximum Impact</h3>
              <ul className="list-disc pl-5 space-y-1 text-gray-700">
                <li>Break longer content into digestible chunks with clear headings</li>
                <li>Use emojis strategically to highlight key points</li>
                <li>Add simple visuals when sharing through email or social channels</li>
                <li>Include a clear, actionable takeaway with each piece of content</li>
                <li>End with a thoughtful question to encourage parent reflection and discussion</li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold text-primary mb-2">Encouraging Engagement</h3>
              <ul className="list-disc pl-5 space-y-1 text-gray-700">
                <li>Invite parents to share their experiences related to the topic</li>
                <li>Create simple polls to gather feedback on the usefulness of content</li>
                <li>Acknowledge parents who engage with or implement suggestions</li>
                <li>Follow up with related resources for parents who show particular interest</li>
                <li>Track which topics generate the most response and provide more similar content</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ParentCommunityContent;
