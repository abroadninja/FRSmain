import React, { useState, useEffect } from "react";
import { 
  Search, BookOpen, GraduationCap, Users, Heart, Star, Copy, Filter, 
  ChevronDown, ChevronRight, Calendar, Award, Lightbulb, X
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { contentTopics } from "@/data/parent-engagement/content-topics";

interface ContentHubProps {
  copyToClipboard: (text: string) => void;
}

const ParentContentHub: React.FC<ContentHubProps> = ({ copyToClipboard }) => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedContent, setSelectedContent] = useState<string | null>(null);
  const [contentType, setContentType] = useState<string>("carousel");
  const [selectedAgeGroup, setSelectedAgeGroup] = useState<string>("7-9");
  const [selectedGrade, setSelectedGrade] = useState<string>("all");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [showFilters, setShowFilters] = useState(false);
  const [favorites, setFavorites] = useState<string[]>([]);

  const filteredContent = contentTopics.filter(topic => {
    const matchesSearch = 
      topic.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
      topic.description.toLowerCase().includes(searchTerm.toLowerCase()) || 
      (topic.content && topic.content.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesType = contentType === "all" || topic.type === contentType;
    const matchesAge = selectedAgeGroup === "all" || topic.ageGroup.includes(selectedAgeGroup);
    const matchesGrade = selectedGrade === "all" || topic.gradeLevel === selectedGrade;
    const matchesCategory = selectedCategory === "all" || topic.category === selectedCategory;
    
    return matchesSearch && matchesType && matchesAge && matchesGrade && matchesCategory;
  });

  const toggleFavorite = (id: string) => {
    if (favorites.includes(id)) {
      setFavorites(favorites.filter(favId => favId !== id));
    } else {
      setFavorites([...favorites, id]);
      toast({
        title: "Added to favorites",
        description: "This content has been added to your favorites"
      });
    }
  };
  
  const categories = Array.from(new Set(contentTopics.map(item => item.category)));
  
  const gradeLevels = Array.from(new Set(contentTopics.map(item => item.gradeLevel))).filter(Boolean);

  return (
    <TooltipProvider>
      <div className="space-y-8">
        <div className="bg-gradient-to-r from-purple-50 to-indigo-50 rounded-xl p-6 shadow-sm">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-2xl md:text-3xl font-bold text-primary mb-3">
              Parent Content Resource Hub
            </h1>
            <p className="text-gray-600 mb-6">
              Access thousands of ready-to-share content pieces for your school's parent communities. 
              Designed to establish your school as a trusted advisor in your students' developmental journey.
            </p>
            
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  type="text"
                  placeholder="Search by keyword, topic, or skill..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-full"
                />
              </div>
              
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  className="whitespace-nowrap flex-shrink-0"
                  onClick={() => setShowFilters(!showFilters)}
                >
                  <Filter className="h-4 w-4 mr-2" />
                  {showFilters ? "Hide Filters" : "Show Filters"}
                </Button>
                
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="whitespace-nowrap flex-shrink-0">
                      <Calendar className="h-4 w-4 mr-2" />
                      Age/Grade
                      <ChevronDown className="h-4 w-4 ml-1" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-60">
                    <div className="space-y-4">
                      <div>
                        <h4 className="font-medium mb-2 text-sm">Age Groups</h4>
                        <div className="grid grid-cols-2 gap-2">
                          <Button 
                            size="sm" 
                            variant={selectedAgeGroup === "all" ? "default" : "outline"}
                            onClick={() => setSelectedAgeGroup("all")}
                            className="w-full"
                          >
                            All Ages
                          </Button>
                          {["7-9", "10-12", "13-15", "16-18"].map(age => (
                            <Button 
                              key={age}
                              size="sm" 
                              variant={selectedAgeGroup === age ? "default" : "outline"}
                              onClick={() => setSelectedAgeGroup(age)}
                              className="w-full"
                            >
                              Ages {age}
                            </Button>
                          ))}
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="font-medium mb-2 text-sm">Grade Levels</h4>
                        <div className="grid grid-cols-2 gap-2">
                          <Button 
                            size="sm" 
                            variant={selectedGrade === "all" ? "default" : "outline"}
                            onClick={() => setSelectedGrade("all")}
                            className="w-full"
                          >
                            All Grades
                          </Button>
                          {["Grade 2", "Grade 3", "Grade 4", "Grade 5", "Grade 6", "Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12"].map(grade => (
                            <Button 
                              key={grade}
                              size="sm" 
                              variant={selectedGrade === grade ? "default" : "outline"}
                              onClick={() => setSelectedGrade(grade)}
                              className="w-full"
                            >
                              {grade}
                            </Button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </PopoverContent>
                </Popover>
              </div>
            </div>
            
            {showFilters && (
              <div className="mt-4 p-4 bg-white rounded-lg border border-gray-100 shadow-sm animate-fade-in">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <h4 className="text-sm font-medium mb-2">Content Type</h4>
                    <div className="grid grid-cols-2 gap-2">
                      <Button 
                        size="sm" 
                        variant={contentType === "all" ? "default" : "outline"}
                        onClick={() => setContentType("all")}
                        className="w-full"
                      >
                        All Types
                      </Button>
                      {["carousel", "thread", "square", "story", "video", "infographic"].map(type => (
                        <Button 
                          key={type}
                          size="sm" 
                          variant={contentType === type ? "default" : "outline"}
                          onClick={() => setContentType(type)}
                          className="w-full capitalize"
                        >
                          {type}
                        </Button>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-medium mb-2">Categories</h4>
                    <div className="grid grid-cols-1 gap-1 max-h-40 overflow-y-auto">
                      <label className="flex items-center space-x-2 cursor-pointer p-1 hover:bg-gray-50 rounded">
                        <Checkbox
                          checked={selectedCategory === "all"}
                          onCheckedChange={() => setSelectedCategory("all")}
                        />
                        <span className="text-sm">All Categories</span>
                      </label>
                      
                      {categories.map(category => (
                        <label key={category} className="flex items-center space-x-2 cursor-pointer p-1 hover:bg-gray-50 rounded">
                          <Checkbox
                            checked={selectedCategory === category}
                            onCheckedChange={() => setSelectedCategory(category)}
                          />
                          <span className="text-sm capitalize">{category.replace(/-/g, ' ')}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="text-sm font-medium mb-2">Quick Filters</h4>
                    <div className="space-y-2">
                      <Button size="sm" variant="outline" className="w-full justify-start" onClick={() => setSelectedCategory("essential-skills")}>
                        <GraduationCap className="h-4 w-4 mr-2" /> Essential Skills
                      </Button>
                      <Button size="sm" variant="outline" className="w-full justify-start" onClick={() => setSelectedCategory("financial-literacy")}>
                        <Award className="h-4 w-4 mr-2" /> Financial Literacy
                      </Button>
                      <Button size="sm" variant="outline" className="w-full justify-start" onClick={() => setSelectedCategory("digital-skills")}>
                        <BookOpen className="h-4 w-4 mr-2" /> Digital Skills
                      </Button>
                      <Button size="sm" variant="outline" className="w-full justify-start" onClick={() => setSelectedCategory("mindset")}>
                        <Lightbulb className="h-4 w-4 mr-2" /> Growth Mindset
                      </Button>
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-end mt-4">
                  <Button size="sm" variant="ghost" onClick={() => {
                    setSearchTerm("");
                    setContentType("all");
                    setSelectedAgeGroup("all");
                    setSelectedGrade("all");
                    setSelectedCategory("all");
                  }}>
                    Clear All Filters
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
        
        <Tabs defaultValue="content-grid" className="w-full">
          <div className="flex justify-between items-center mb-4">
            <TabsList>
              <TabsTrigger value="content-grid">Grid View</TabsTrigger>
              <TabsTrigger value="content-list">List View</TabsTrigger>
              {favorites.length > 0 && (
                <TabsTrigger value="favorites">
                  Favorites ({favorites.length})
                </TabsTrigger>
              )}
            </TabsList>
            
            <div className="text-sm text-gray-500">
              Showing {filteredContent.length} of {contentTopics.length} resources
            </div>
          </div>
          
          <TabsContent value="content-grid" className="mt-0">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredContent.length > 0 ? (
                filteredContent.map(topic => (
                  <Card 
                    key={topic.id} 
                    className="border border-gray-100 hover:shadow-md transition-all cursor-pointer h-full overflow-hidden"
                    onClick={() => setSelectedContent(topic.id)}
                  >
                    <CardHeader className={`pb-2 ${
                      topic.category === 'essential-skills' ? 'bg-blue-50/50' : 
                      topic.category === 'financial-literacy' ? 'bg-green-50/50' :
                      topic.category === 'digital-skills' ? 'bg-purple-50/50' :
                      topic.category === 'mindset' ? 'bg-amber-50/50' :
                      'bg-gray-50/50'
                    }`}>
                      <div className="flex justify-between items-start">
                        <CardTitle className="text-lg">{topic.title}</CardTitle>
                        <div className="flex items-center">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-8 w-8" 
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleFavorite(topic.id);
                            }}
                          >
                            <Star 
                              className={`h-5 w-5 ${favorites.includes(topic.id) ? 'text-amber-400 fill-amber-400' : 'text-gray-400'}`} 
                            />
                          </Button>
                        </div>
                      </div>
                      <CardDescription className="line-clamp-2">{topic.description}</CardDescription>
                    </CardHeader>
                    
                    <CardContent className="pt-3 pb-2">
                      <div className="flex flex-wrap gap-2 mb-2">
                        <Badge variant="outline" className="bg-primary/5 text-primary text-xs capitalize">
                          {topic.type}
                        </Badge>
                        <Badge variant="outline" className="bg-gray-50 text-gray-700 text-xs">
                          Ages {topic.ageGroup}
                        </Badge>
                        {topic.gradeLevel && (
                          <Badge variant="outline" className="bg-gray-50 text-gray-700 text-xs">
                            {topic.gradeLevel}
                          </Badge>
                        )}
                      </div>
                      
                      <p className="text-sm text-gray-600 line-clamp-2">
                        {topic.content && topic.content.substring(0, 120)}...
                      </p>
                    </CardContent>
                    
                    <CardFooter className="pt-2 border-t">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="w-full justify-center text-primary" 
                        onClick={(e) => {
                          e.stopPropagation();
                          if (topic.content) {
                            copyToClipboard(topic.content);
                            toast({
                              title: "Content copied",
                              description: "The content has been copied to your clipboard"
                            });
                          }
                        }}
                      >
                        <Copy className="h-4 w-4 mr-2" /> Copy Content
                      </Button>
                    </CardFooter>
                  </Card>
                ))
              ) : (
                <div className="col-span-3 p-8 text-center">
                  <div className="bg-gray-50 rounded-xl p-8 flex flex-col items-center">
                    <Search className="h-12 w-12 text-gray-300 mb-4" />
                    <h3 className="text-xl font-semibold mb-2">No content matches your search</h3>
                    <p className="text-gray-600">Try adjusting your search or filters to find what you're looking for</p>
                    <Button 
                      className="mt-4" 
                      onClick={() => {
                        setSearchTerm("");
                        setContentType("all");
                        setSelectedAgeGroup("all");
                        setSelectedGrade("all");
                        setSelectedCategory("all");
                      }}
                    >
                      Reset All Filters
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="content-list" className="mt-0">
            <div className="rounded-lg border border-gray-100 overflow-hidden">
              <div className="bg-gray-50 p-3 border-b border-gray-100 flex items-center font-medium text-gray-700">
                <div className="w-1/2 md:w-4/12">Content Title</div>
                <div className="hidden md:block md:w-2/12">Type</div>
                <div className="hidden md:block md:w-2/12">Age / Grade</div>
                <div className="hidden md:block md:w-2/12">Category</div>
                <div className="w-1/2 md:w-2/12 text-right">Actions</div>
              </div>
              
              {filteredContent.length > 0 ? (
                <div className="divide-y divide-gray-100">
                  {filteredContent.map(topic => (
                    <div 
                      key={topic.id}
                      className="p-3 hover:bg-gray-50 transition-colors flex items-center cursor-pointer"
                      onClick={() => setSelectedContent(topic.id)}
                    >
                      <div className="w-1/2 md:w-4/12 font-medium">{topic.title}</div>
                      <div className="hidden md:block md:w-2/12 capitalize">{topic.type}</div>
                      <div className="hidden md:block md:w-2/12">
                        Ages {topic.ageGroup}
                        {topic.gradeLevel && <div className="text-xs text-gray-500">{topic.gradeLevel}</div>}
                      </div>
                      <div className="hidden md:block md:w-2/12 capitalize">{topic.category.replace(/-/g, ' ')}</div>
                      <div className="w-1/2 md:w-2/12 flex items-center justify-end gap-1">
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8" 
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleFavorite(topic.id);
                          }}
                        >
                          <Star 
                            className={`h-5 w-5 ${favorites.includes(topic.id) ? 'text-amber-400 fill-amber-400' : 'text-gray-400'}`} 
                          />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8" 
                          onClick={(e) => {
                            e.stopPropagation();
                            if (topic.content) {
                              copyToClipboard(topic.content);
                              toast({
                                title: "Content copied",
                                description: "Content copied to clipboard"
                              });
                            }
                          }}
                        >
                          <Copy className="h-5 w-5 text-gray-500" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center">
                  <div className="bg-gray-50 rounded-xl p-8 flex flex-col items-center">
                    <Search className="h-12 w-12 text-gray-300 mb-4" />
                    <h3 className="text-xl font-semibold mb-2">No content matches your search</h3>
                    <p className="text-gray-600">Try adjusting your search or filters</p>
                    <Button 
                      className="mt-4" 
                      onClick={() => {
                        setSearchTerm("");
                        setContentType("all");
                        setSelectedAgeGroup("all");
                        setSelectedCategory("all");
                      }}
                    >
                      Reset All Filters
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>
          
          {favorites.length > 0 && (
            <TabsContent value="favorites" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {favorites.length > 0 ? (
                  contentTopics
                    .filter(topic => favorites.includes(topic.id))
                    .map(topic => (
                      <Card 
                        key={topic.id} 
                        className="border border-gray-100 hover:shadow-md transition-all cursor-pointer h-full overflow-hidden"
                        onClick={() => setSelectedContent(topic.id)}
                      >
                        <CardHeader className={`pb-2 ${
                          topic.category === 'essential-skills' ? 'bg-blue-50/50' : 
                          topic.category === 'financial-literacy' ? 'bg-green-50/50' :
                          topic.category === 'digital-skills' ? 'bg-purple-50/50' :
                          topic.category === 'mindset' ? 'bg-amber-50/50' :
                          'bg-gray-50/50'
                        }`}>
                          <div className="flex justify-between items-start">
                            <CardTitle className="text-lg">{topic.title}</CardTitle>
                            <Button 
                              variant="ghost" 
                              size="icon" 
                              className="h-8 w-8" 
                              onClick={(e) => {
                                e.stopPropagation();
                                toggleFavorite(topic.id);
                              }}
                            >
                              <Star className="h-5 w-5 text-amber-400 fill-amber-400" />
                            </Button>
                          </div>
                          <CardDescription>{topic.description}</CardDescription>
                        </CardHeader>
                        
                        <CardContent className="pt-3 pb-2">
                          <div className="flex flex-wrap gap-2 mb-2">
                            <Badge variant="outline" className="bg-primary/5 text-primary text-xs capitalize">
                              {topic.type}
                            </Badge>
                            <Badge variant="outline" className="bg-gray-50 text-gray-700 text-xs">
                              Ages {topic.ageGroup}
                            </Badge>
                          </div>
                          
                          <p className="text-sm text-gray-600 line-clamp-2">
                            {topic.content && topic.content.substring(0, 120)}...
                          </p>
                        </CardContent>
                        
                        <CardFooter className="pt-2 border-t">
                          <Button 
                            variant="ghost" 
                            size="sm" 
                            className="w-full justify-center text-primary" 
                            onClick={(e) => {
                              e.stopPropagation();
                              if (topic.content) {
                                copyToClipboard(topic.content);
                              }
                            }}
                          >
                            <Copy className="h-4 w-4 mr-2" /> Copy Content
                          </Button>
                        </CardFooter>
                      </Card>
                    ))
                ) : (
                  <div className="col-span-3 p-8 text-center">
                    <div className="rounded-xl border border-gray-200 p-8">
                      <Heart className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                      <h3 className="text-xl font-semibold mb-2">No favorites yet</h3>
                      <p className="text-gray-600">Mark content as favorite to access it quickly later</p>
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>
          )}
        </Tabs>
        
        {selectedContent && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
            <div className="bg-white rounded-xl shadow-xl max-w-4xl w-full max-h-[80vh] flex flex-col overflow-hidden animate-scale-in">
              <div className="p-4 border-b sticky top-0 bg-white z-10 flex justify-between items-center">
                <h3 className="text-lg font-semibold">
                  {contentTopics.find(item => item.id === selectedContent)?.title}
                </h3>
                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      const content = contentTopics.find(item => item.id === selectedContent);
                      if (content?.content) {
                        copyToClipboard(content.content);
                        toast({
                          title: "Content copied",
                          description: "Content has been copied to clipboard"
                        });
                      }
                    }}
                  >
                    <Copy className="h-4 w-4 mr-2" /> Copy
                  </Button>
                  <Button 
                    variant="ghost" 
                    size="icon"
                    onClick={() => setSelectedContent(null)}
                  >
                    <X className="h-5 w-5" />
                  </Button>
                </div>
              </div>
              <div className="p-4 overflow-y-auto flex-1">
                <div className="space-y-4">
                  <div>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline" className="bg-primary/5 text-primary capitalize">
                        {contentTopics.find(item => item.id === selectedContent)?.type}
                      </Badge>
                      <Badge variant="outline" className="bg-gray-50">
                        Ages {contentTopics.find(item => item.id === selectedContent)?.ageGroup}
                      </Badge>
                      {contentTopics.find(item => item.id === selectedContent)?.gradeLevel && (
                        <Badge variant="outline" className="bg-gray-50">
                          {contentTopics.find(item => item.id === selectedContent)?.gradeLevel}
                        </Badge>
                      )}
                      <Badge variant="outline" className="bg-gray-50 capitalize">
                        {contentTopics.find(item => item.id === selectedContent)?.category.replace(/-/g, ' ')}
                      </Badge>
                    </div>
                    <p className="text-gray-600 mt-4">
                      {contentTopics.find(item => item.id === selectedContent)?.description}
                    </p>
                  </div>
                  
                  <div className="border-t border-gray-100 pt-4">
                    <h4 className="font-medium mb-2">Content to Share:</h4>
                    <div className="bg-gray-50 p-4 rounded-lg whitespace-pre-wrap text-gray-700">
                      {contentTopics.find(item => item.id === selectedContent)?.content}
                    </div>
                  </div>
                  
                  <div className="border-t border-gray-100 pt-4">
                    <h4 className="font-medium mb-2">Sharing Recommendations:</h4>
                    <ul className="list-disc pl-5 space-y-1 text-sm text-gray-600">
                      <li>Best platform: WhatsApp, Email Newsletter, Parent Portal</li>
                      <li>Optimal sharing time: Weekday evenings or Sunday afternoons</li>
                      <li>Suggested followup: Ask for parent feedback or experiences</li>
                      <li>Supporting resources: Links to relevant school programs</li>
                    </ul>
                  </div>
                </div>
              </div>
              <div className="p-4 border-t bg-gray-50 flex justify-between">
                <Button 
                  variant="outline" 
                  onClick={() => toggleFavorite(selectedContent)}
                >
                  <Star className={`h-4 w-4 mr-2 ${
                    favorites.includes(selectedContent) ? 'text-amber-400 fill-amber-400' : ''
                  }`} />
                  {favorites.includes(selectedContent) ? 'Remove from Favorites' : 'Add to Favorites'}
                </Button>
                
                <Button 
                  variant="default"
                  onClick={() => setSelectedContent(null)}
                >
                  Close
                </Button>
              </div>
            </div>
          </div>
        )}
        
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-5 border-b border-gray-100 bg-gray-50">
            <h2 className="text-xl font-semibold text-primary">Content Sharing Best Practices</h2>
          </div>
          <div className="p-5">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <div className="flex items-center mb-3">
                  <Calendar className="h-5 w-5 text-primary mr-2" />
                  <h3 className="text-lg font-semibold">Frequency & Timing</h3>
                </div>
                <ul className="list-disc pl-5 space-y-1 text-gray-700">
                  <li>Share content 1-2 times per week</li>
                  <li>Optimal times: weekday evenings (7-9pm)</li>
                  <li>Group related content into themed weeks</li>
                  <li>Plan content calendar around school events</li>
                  <li>Use consistent posting schedule</li>
                </ul>
              </div>
              
              <div>
                <div className="flex items-center mb-3">
                  <BookOpen className="h-5 w-5 text-primary mr-2" />
                  <h3 className="text-lg font-semibold">Content Formatting</h3>
                </div>
                <ul className="list-disc pl-5 space-y-1 text-gray-700">
                  <li>Use clear, scannable headings</li>
                  <li>Break long content into digestible chunks</li>
                  <li>Include relevant emojis for visual appeal</li>
                  <li>Add simple visuals when possible</li>
                  <li>End with a clear call-to-action or question</li>
                </ul>
              </div>
              
              <div>
                <div className="flex items-center mb-3">
                  <Users className="h-5 w-5 text-primary mr-2" />
                  <h3 className="text-lg font-semibold">Engagement Strategies</h3>
                </div>
                <ul className="list-disc pl-5 space-y-1 text-gray-700">
                  <li>Ask reflective questions to prompt discussion</li>
                  <li>Invite parents to share experiences</li>
                  <li>Create simple polls for feedback</li>
                  <li>Acknowledge parents who engage</li>
                  <li>Follow up with related resources</li>
                </ul>
              </div>
            </div>
            
            <div className="mt-6 p-4 bg-blue-50/50 border-l-4 border-blue-400 rounded-r">
              <h4 className="font-semibold text-primary">Pro Tip: Test & Refine</h4>
              <p className="text-gray-700 mt-1 text-sm">
                Track which topics generate the most response and adjust your content strategy accordingly. 
                The most successful schools build their content calendar based on actual parent engagement data.
              </p>
            </div>
          </div>
        </div>
      </div>
    </TooltipProvider>
  );
};

export default ParentContentHub;
