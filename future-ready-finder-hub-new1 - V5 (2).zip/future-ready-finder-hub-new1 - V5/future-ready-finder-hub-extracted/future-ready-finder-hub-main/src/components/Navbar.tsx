
import React, { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/components/auth/AuthProvider";
import { LogOut, Menu, User, X } from "lucide-react";

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  
  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };
  
  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const handleHomeClick = (e: React.MouseEvent) => {
    e.preventDefault();
    
    // If user is on the exact URL they're trying to navigate to, don't do anything
    if ((user && location.pathname === "/") || (!user && location.pathname === "/")) {
      return;
    }
    
    // Always navigate to home when clicking home button
    navigate("/");
  };

  return (
    <nav className="bg-white shadow-sm border-b border-gray-100">
      <div className="container-custom mx-auto px-4 flex justify-between items-center h-16">
        <a href="#" onClick={handleHomeClick} className="flex items-center">
          <span className="text-xl font-bold text-primary">FutureReadySchools.com</span>
        </a>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-4">
          <a href="#" onClick={handleHomeClick} className="text-gray-600 hover:text-primary px-3 py-2">
            Home
          </a>
          <a 
            href="http://www.membership-page1.futurereadyschools.com" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="text-gray-600 hover:text-primary px-3 py-2"
          >
            Membership
          </a>
          <Link to="/contact" className="text-gray-600 hover:text-primary px-3 py-2">
            Contact
          </Link>
          
          {/* The rest of the desktop navigation */}
          {user ? (
            <>
              <Link to="/dashboard" className="text-gray-600 hover:text-primary px-3 py-2">
                Dashboard
              </Link>
              <div className="flex items-center space-x-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="flex items-center gap-1"
                  onClick={handleSignOut}
                >
                  <LogOut className="h-4 w-4" />
                  <span className="hidden sm:inline">Sign Out</span>
                </Button>
                <Button 
                  variant="default" 
                  size="sm"
                  asChild
                >
                  <Link to="/account" className="flex items-center gap-1">
                    <User className="h-4 w-4" />
                    <span className="hidden sm:inline">Account</span>
                  </Link>
                </Button>
              </div>
            </>
          ) : (
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" asChild>
                <Link to="/login">Log In</Link>
              </Button>
              <Button variant="default" size="sm" asChild>
                <Link to="/signup">Sign Up</Link>
              </Button>
            </div>
          )}
        </div>

        {/* Mobile Menu Button */}
        <button 
          onClick={toggleMenu}
          className="md:hidden text-gray-500 hover:text-gray-700 focus:outline-none"
        >
          {isMenuOpen ? (
            <X className="h-6 w-6" />
          ) : (
            <Menu className="h-6 w-6" />
          )}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <a 
              href="#" 
              onClick={(e) => {
                e.preventDefault();
                handleHomeClick(e);
                setIsMenuOpen(false);
              }} 
              className="block px-3 py-2 text-base font-medium text-gray-700 hover:bg-gray-100 hover:text-primary rounded-md"
            >
              Home
            </a>
            <a 
              href="http://www.membership-page1.futurereadyschools.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="block px-3 py-2 text-base font-medium text-gray-700 hover:bg-gray-100 hover:text-primary rounded-md"
              onClick={() => setIsMenuOpen(false)}
            >
              Membership
            </a>
            <Link 
              to="/contact" 
              className="block px-3 py-2 text-base font-medium text-gray-700 hover:bg-gray-100 hover:text-primary rounded-md"
              onClick={() => setIsMenuOpen(false)}
            >
              Contact
            </Link>
            
            {/* User-specific mobile menu */}
            {user ? (
              <>
                <Link 
                  to="/dashboard" 
                  className="block px-3 py-2 text-base font-medium text-gray-700 hover:bg-gray-100 hover:text-primary rounded-md"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Dashboard
                </Link>
                <div className="pt-2 pb-1 space-y-2">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full justify-center"
                    onClick={() => {
                      handleSignOut();
                      setIsMenuOpen(false);
                    }}
                  >
                    <LogOut className="h-4 w-4 mr-2" /> Sign Out
                  </Button>
                  <Button 
                    variant="default" 
                    size="sm" 
                    className="w-full justify-center"
                    asChild
                  >
                    <Link to="/account" onClick={() => setIsMenuOpen(false)}>
                      <User className="h-4 w-4 mr-2" /> Account
                    </Link>
                  </Button>
                </div>
              </>
            ) : (
              <div className="pt-2 pb-1 grid grid-cols-2 gap-2">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full justify-center"
                  asChild
                >
                  <Link to="/login" onClick={() => setIsMenuOpen(false)}>Log In</Link>
                </Button>
                <Button 
                  variant="default" 
                  size="sm" 
                  className="w-full justify-center"
                  asChild
                >
                  <Link to="/signup" onClick={() => setIsMenuOpen(false)}>Sign Up</Link>
                </Button>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
