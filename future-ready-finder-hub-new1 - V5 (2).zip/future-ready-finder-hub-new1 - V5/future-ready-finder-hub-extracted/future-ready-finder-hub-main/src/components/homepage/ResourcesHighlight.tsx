
import React from "react";
import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { BookOpen, Users, Calendar, ArrowRight, Brain, CheckCircle } from "lucide-react";

const ResourcesHighlight = () => {
  return (
    <section className="py-20 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-brand-50 to-white z-0"></div>
      <div className="absolute top-0 right-0 w-full h-full pattern-bg opacity-5 z-0"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge className="mb-4">Comprehensive Resources</Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Everything You Need For Student Success
          </h2>
          <p className="text-lg text-gray-600">
            Our toolkit provides comprehensive resources for future-ready education and high-income skill building for students across all grades.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card className="border border-gray-200 shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden h-full">
            <div className="h-48 overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1610116306796-6fea9f4fae38?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80" 
                alt="Future Ready Lessons" 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
            </div>
            
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-3">
                <div className="p-1.5 rounded-md bg-blue-100 text-blue-600">
                  <BookOpen className="h-4 w-4" />
                </div>
                <span className="text-sm font-medium text-gray-500">Class 2-12 Curriculum</span>
              </div>
              
              <h3 className="text-xl font-bold text-gray-900 mb-2">Future Ready Lessons</h3>
              <p className="text-gray-600 mb-4">Comprehensive lessons for all grades with ready-to-use materials to deliver future-ready education.</p>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <Calendar className="h-4 w-4 text-gray-400" />
                  <span className="text-xs text-gray-500">Complete curriculum</span>
                </div>
                
                <Button variant="link" className="text-brand-600 p-0 h-auto" asChild>
                  <Link to="/classes">
                    Access Lessons <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border border-gray-200 shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden h-full">
            <div className="h-48 overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80" 
                alt="High Income Skills Portfolio" 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
            </div>
            
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-3">
                <div className="p-1.5 rounded-md bg-purple-100 text-purple-600">
                  <Brain className="h-4 w-4" />
                </div>
                <span className="text-sm font-medium text-gray-500">Classes 8-12</span>
              </div>
              
              <h3 className="text-xl font-bold text-gray-900 mb-2">High Income Skills Portfolio</h3>
              <p className="text-gray-600 mb-4">Guidance materials for building high-income skill portfolios to prepare students for future careers.</p>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <Users className="h-4 w-4 text-gray-400" />
                  <span className="text-xs text-gray-500">Complete guidance system</span>
                </div>
                
                <Button variant="link" className="text-brand-600 p-0 h-auto" asChild>
                  <Link to="/implementation-guides?playbook=high-income">
                    Access Portfolio Guide <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border border-gray-200 shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden h-full">
            <div className="h-48 overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1552581234-26160f608093?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80" 
                alt="Career Assessment" 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              />
            </div>
            
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-3">
                <div className="p-1.5 rounded-md bg-emerald-100 text-emerald-600">
                  <CheckCircle className="h-4 w-4" />
                </div>
                <span className="text-sm font-medium text-gray-500">All Age Groups</span>
              </div>
              
              <h3 className="text-xl font-bold text-gray-900 mb-2">Free Career Assessments</h3>
              <p className="text-gray-600 mb-4">Comprehensive psychometric, skill-based and futuristic career assessments worth thousands.</p>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <Calendar className="h-4 w-4 text-gray-400" />
                  <span className="text-xs text-gray-500">Multiple assessment types</span>
                </div>
                
                <Button variant="link" className="text-brand-600 p-0 h-auto" asChild>
                  <Link to="/assessment">
                    Access Assessments <ArrowRight className="ml-1 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="mt-12 text-center">
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button size="lg" variant="default" className="bg-brand-600 hover:bg-brand-700" asChild>
              <Link to="/signup" className="flex items-center">
                Get Started for Free <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="border-brand-600 text-brand-600 hover:bg-brand-50" asChild>
              <a href="http://www.membership-page1.futurereadyschools.com" target="_blank" rel="noopener noreferrer" className="flex items-center">
                Explore Membership Plans
              </a>
            </Button>
          </div>
          <p className="mt-4 text-sm text-gray-500">
            Transform your school's approach to education with our comprehensive resources
          </p>
        </div>
      </div>
    </section>
  );
};

export default ResourcesHighlight;
