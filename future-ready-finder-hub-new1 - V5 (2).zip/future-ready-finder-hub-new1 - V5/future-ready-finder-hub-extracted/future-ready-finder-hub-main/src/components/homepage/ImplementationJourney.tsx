
import React from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";

const ImplementationJourney = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge className="mb-4">Implementation Process</Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Your Path to a Future-Ready School
          </h2>
          <p className="text-lg text-gray-600">
            Follow our proven implementation process to transform your school with minimal 
            disruption and maximum impact.
          </p>
        </div>
        
        <div className="relative">
          {/* Connection line */}
          <div className="absolute top-0 bottom-0 left-1/2 w-px bg-gray-300 hidden lg:block transform -translate-x-1/2"></div>
          
          <div className="space-y-12">
            {steps.map((step, index) => (
              <div key={index} className={`flex flex-col ${index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'} gap-8`}>
                {/* Timeline marker */}
                <div className="hidden lg:flex items-center justify-center flex-shrink-0 relative z-10">
                  <div className="w-12 h-12 rounded-full bg-brand-600 text-white flex items-center justify-center font-bold text-lg shadow-md">
                    {index + 1}
                  </div>
                </div>
                
                {/* Content */}
                <div className={`flex-1 ${index % 2 === 0 ? 'lg:text-right lg:pr-6' : 'lg:text-left lg:pl-6'}`}>
                  <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300 h-full">
                    <CardContent className="p-6 pt-6">
                      <h3 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
                        <div className="lg:hidden flex-shrink-0 w-10 h-10 rounded-full bg-brand-600 text-white flex items-center justify-center font-bold text-lg mr-3">
                          {index + 1}
                        </div>
                        <span>{step.title}</span>
                      </h3>
                      
                      <p className="text-gray-600 mb-5">{step.description}</p>
                      
                      <div className={`grid grid-cols-1 sm:grid-cols-2 gap-4 ${index % 2 === 0 ? 'lg:justify-items-end' : 'lg:justify-items-start'}`}>
                        {step.actions.map((action, idx) => (
                          <div key={idx} className={`flex items-center gap-2 ${index % 2 === 0 ? 'lg:flex-row-reverse' : 'lg:flex-row'}`}>
                            <div className={`w-2 h-2 rounded-full ${getStepColor(index)}`}></div>
                            <span className="text-gray-700">{action}</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                {/* Empty space for alignment */}
                <div className="flex-1 hidden lg:block"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const getStepColor = (index: number) => {
  const colors = [
    'bg-blue-500',
    'bg-indigo-500',
    'bg-purple-500',
    'bg-brand-500'
  ];
  return colors[index % colors.length];
};

const steps = [
  {
    title: "Assessment & Planning",
    description: "Evaluate your school's current state and develop a customized implementation roadmap.",
    actions: [
      "Complete our school readiness assessment",
      "Identify key implementation areas",
      "Form an implementation team",
      "Set measurable goals and timelines"
    ]
  },
  {
    title: "Foundation Building",
    description: "Establish the core elements that will support your transformation journey.",
    actions: [
      "Train key staff members",
      "Prepare communication materials",
      "Set up necessary infrastructure",
      "Engage initial parent and community support"
    ]
  },
  {
    title: "Phased Implementation",
    description: "Roll out the program in manageable stages to ensure sustainable adoption.",
    actions: [
      "Begin with pilot classrooms",
      "Collect and incorporate feedback",
      "Expand to additional grades",
      "Adjust approach based on results"
    ]
  },
  {
    title: "Evaluation & Growth",
    description: "Measure impact, make refinements, and plan for continued development.",
    actions: [
      "Collect data on key metrics",
      "Celebrate early successes",
      "Identify improvement opportunities",
      "Plan next phase of implementation"
    ]
  }
];

export default ImplementationJourney;
