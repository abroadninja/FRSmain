
import React from "react";
import { Badge } from "@/components/ui/badge";

const ValueProposition = () => {
  return (
    <section className="py-20 relative overflow-hidden">
      {/* Subtle background patterns */}
      <div className="absolute top-0 left-0 w-full h-full pattern-bg opacity-10 z-0"></div>
      <div className="absolute -top-24 -right-24 w-80 h-80 bg-brand-100 rounded-full blur-3xl opacity-20 z-0"></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          {/* Left column: Image */}
          <div className="lg:w-1/2 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80"
                alt="Students collaborating on a project" 
                className="w-full object-cover rounded-2xl"
              />
              
              {/* Overlay gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent"></div>
              
              {/* Stats overlay */}
              <div className="absolute bottom-0 left-0 w-full p-6">
                <div className="grid grid-cols-3 gap-4">
                  <StatItem value="100%" label="Free Access" />
                  <StatItem value="30+" label="Ready Templates" />
                  <StatItem value="5+" label="Key Skill Areas" />
                </div>
              </div>
            </div>
            
            {/* Floating card elements */}
            <div className="absolute -top-6 -right-6 bg-white p-4 rounded-lg shadow-lg max-w-[200px] hidden md:block">
              <Badge className="mb-2 bg-green-100 text-green-700 hover:bg-green-200">No Budget Required</Badge>
              <p className="text-sm text-gray-600">Works with resources you already have</p>
            </div>
          </div>
          
          {/* Right column: Content */}
          <div className="lg:w-1/2">
            <Badge variant="outline" className="mb-3">Why It Works</Badge>
            
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Education that Actually Prepares Students for the Future
            </h2>
            
            <div className="space-y-8">
              <div>
                <h3 className="text-xl font-bold text-gray-800 mb-2 flex items-center">
                  <span className="flex items-center justify-center bg-brand-100 text-brand-700 w-7 h-7 rounded-full mr-3 text-sm">1</span>
                  Addresses the Skills Gap
                </h3>
                <p className="text-gray-600 pl-10">
                  Our framework focuses on developing adaptable skills that remain relevant 
                  as technology and job markets evolve, unlike traditional curriculum that 
                  quickly becomes outdated.
                </p>
              </div>
              
              <div>
                <h3 className="text-xl font-bold text-gray-800 mb-2 flex items-center">
                  <span className="flex items-center justify-center bg-brand-100 text-brand-700 w-7 h-7 rounded-full mr-3 text-sm">2</span>
                  Practical Implementation Focus
                </h3>
                <p className="text-gray-600 pl-10">
                  We provide concrete action plans instead of vague theory. Every resource 
                  is designed to be immediately useful, with clear steps that work in 
                  real-world school environments.
                </p>
              </div>
              
              <div>
                <h3 className="text-xl font-bold text-gray-800 mb-2 flex items-center">
                  <span className="flex items-center justify-center bg-brand-100 text-brand-700 w-7 h-7 rounded-full mr-3 text-sm">3</span>
                  Resource-Conscious Design
                </h3>
                <p className="text-gray-600 pl-10">
                  Our approach works with what you have. We understand budget constraints 
                  and have designed implementation pathways that don't require significant 
                  new investments.
                </p>
              </div>
            </div>
            
            {/* Testimonial quote */}
            <blockquote className="mt-10 border-l-4 border-brand-500 pl-4 italic text-gray-600">
              "This system provided us with direction when we needed it most. The ready-to-use 
              templates saved us countless planning hours."
              <footer className="mt-2 text-gray-500 not-italic">- School Principal</footer>
            </blockquote>
          </div>
        </div>
      </div>
    </section>
  );
};

interface StatItemProps {
  value: string;
  label: string;
}

const StatItem = ({ value, label }: StatItemProps) => (
  <div className="text-center bg-white/80 backdrop-blur-sm rounded-lg p-2">
    <p className="text-xl font-bold text-gray-800">{value}</p>
    <p className="text-xs text-gray-600">{label}</p>
  </div>
);

export default ValueProposition;
