
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, Check } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

const CTASection = () => {
  const isMobile = useIsMobile();
  
  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background with gradient and pattern */}
      <div className="absolute inset-0 bg-gradient-to-br from-brand-700 via-brand-600 to-brand-800 z-0">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImRpYWdvbmFsLWhhdGNobWFyayIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSIgd2lkdGg9IjIwIiBoZWlnaHQ9IjIwIj48cGF0aCBkPSJNMCAwTDIwIDIwTTAgMjBMMjAgMCIgc3Ryb2tlPSJ3aGl0ZSIgc3Ryb2tlLXdpZHRoPSIwLjUiIHN0cm9rZS1vcGFjaXR5PSIwLjE1IiBmaWxsPSJub25lIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2RpYWdvbmFsLWhhdGNobWFyaykiLz48L3N2Zz4=')]"></div>
        </div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center mb-12">
          <div className="inline-flex items-center bg-white/10 backdrop-blur-sm rounded-full px-4 py-1.5 text-white/90 border border-white/20 mb-6 animate-fade-in">
            <span className="text-sm font-medium">100% Free Access, No Credit Card Required</span>
          </div>
          
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
            Ready to Transform Your School?
          </h2>
          
          <p className="text-xl text-white/90 mb-8">
            Join thousands of forward-thinking educators who are preparing their students for 
            future success while increasing enrollment and parent satisfaction.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-10">
            <Button 
              className="bg-white hover:bg-white/90 text-brand-800 px-6 py-7 text-lg font-semibold shadow-lg relative overflow-hidden group"
              size={isMobile ? "default" : "lg"}
              asChild
            >
              <Link to="/signup">
                <span className="absolute inset-0 w-1/2 bg-gradient-to-r from-transparent via-brand-100/30 to-transparent -translate-x-full group-hover:animate-shimmer"></span>
                Get Started For Free
                <ArrowRight className="ml-2" />
              </Link>
            </Button>
            
            <Button 
              variant="outline" 
              className="border-white/30 bg-white/5 text-white hover:bg-white/10 px-6 py-7 text-lg"
              size={isMobile ? "default" : "lg"}
              asChild
            >
              <Link to="/contact">
                Schedule a Demo
              </Link>
            </Button>
          </div>
        </div>
        
        {/* Key points display */}
        <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-6 lg:gap-8">
          {points.map((point, index) => (
            <div key={index} className="text-center bg-white/5 backdrop-blur-md rounded-xl border border-white/10 p-5">
              <div className="inline-flex items-center justify-center bg-white/10 rounded-full p-2 mb-3">
                <Check className="h-5 w-5 text-white" />
              </div>
              <h3 className="text-white font-bold mb-1">{point.title}</h3>
              <p className="text-white/70 text-sm">{point.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const points = [
  {
    title: "100% Free",
    description: "All resources provided at no cost to your school"
  },
  {
    title: "Easy Implementation",
    description: "Step-by-step guides for seamless adoption"
  },
  {
    title: "Proven Results",
    description: "Developed based on successful educational models"
  },
  {
    title: "Ongoing Support",
    description: "Access to resources and community guidance"
  }
];

export default CTASection;
