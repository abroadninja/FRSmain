import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ChevronRight, CheckCircle, ArrowRight, Star } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

const HomepageHero = () => {
  const isMobile = useIsMobile();
  
  return (
    <section className="relative overflow-hidden">
      {/* Background design with modern patterns */}
      <div className="absolute inset-0 bg-gradient-to-br from-brand-800 to-brand-600 z-0">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_500px_at_50%_200px,rgba(255,255,255,0.1),transparent)]"></div>
          <div className="absolute bottom-0 right-0 w-3/4 h-3/4 bg-[radial-gradient(circle_800px_at_100%_100%,rgba(255,255,255,0.15),transparent)]"></div>
        </div>
      </div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24 lg:py-28 relative z-10">
        <div className="flex flex-col lg:flex-row items-center lg:items-start gap-12 lg:gap-16">
          {/* Main content */}
          <div className="flex-1 text-center lg:text-left">
            <div className="inline-flex items-center bg-white/10 backdrop-blur-sm rounded-full px-4 py-1.5 text-white/90 border border-white/20 mb-6 animate-fade-in">
              <span className="text-sm font-medium">Future-Ready Education System</span>
              <div className="ml-2 h-5 w-[1px] bg-white/20"></div>
              <span className="ml-2 text-sm">100% Free</span>
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-white mb-6 leading-[1.1] animate-fade-in">
              Transform Your School Without <span className="text-yellow-300 relative inline-block">
                Breaking the Budget
                <svg className="absolute -bottom-1 left-0 w-full" viewBox="0 0 100 8" preserveAspectRatio="none">
                  <path d="M0,0 Q50,6 100,0" stroke="currentColor" strokeWidth="4" fill="none" strokeLinecap="round" />
                </svg>
              </span>
            </h1>
            
            <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto lg:mx-0">
              Our proven system helps schools develop future-ready skills in students, 
              increase enrollment, and engage parents — all with resources you already have.
            </p>
            
            {/* Key benefits quick list */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8 text-left max-w-2xl mx-auto lg:mx-0">
              {[
                "Complete implementation playbooks",
                "Parent engagement templates",
                "Student skills development framework",
                "Data-backed enrollment strategies"
              ].map((benefit, index) => (
                <div key={index} className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-yellow-300 flex-shrink-0 mt-0.5" />
                  <span className="text-white/90">{benefit}</span>
                </div>
              ))}
            </div>
            
            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button 
                className="bg-white hover:bg-white/90 text-brand-800 px-6 py-6 text-lg font-semibold shadow-lg relative overflow-hidden group"
                size={isMobile ? "default" : "lg"}
                asChild
              >
                <Link to="/signup">
                  <span className="absolute inset-0 w-1/2 bg-gradient-to-r from-transparent via-brand-100/30 to-transparent -translate-x-full group-hover:animate-shimmer"></span>
                  Get Free Access
                  <ArrowRight className="ml-2" />
                </Link>
              </Button>
              
              <Button 
                variant="outline" 
                className="border-white/30 bg-white/5 text-white hover:bg-white/10 px-6 py-6 text-lg"
                size={isMobile ? "default" : "lg"}
                asChild
              >
                <Link to="/about">
                  Learn How It Works
                  <ChevronRight className="ml-1" />
                </Link>
              </Button>
            </div>
            
            {/* Trust elements */}
            <div className="mt-8 flex items-center justify-center lg:justify-start gap-2 text-white/80 text-sm">
              <div className="flex">
                <Star className="h-4 w-4 fill-yellow-300 text-yellow-300" />
                <Star className="h-4 w-4 fill-yellow-300 text-yellow-300" />
                <Star className="h-4 w-4 fill-yellow-300 text-yellow-300" />
                <Star className="h-4 w-4 fill-yellow-300 text-yellow-300" />
                <Star className="h-4 w-4 fill-yellow-300 text-yellow-300" />
              </div>
              <span>Loved by educators across 30+ schools</span>
            </div>
          </div>
          
          {/* Visual element - stylized illustration/mockup */}
          <div className="lg:flex-1 w-full max-w-lg">
            <div className="relative">
              {/* Decorative elements */}
              <div className="absolute -top-6 -left-6 w-32 h-32 bg-accent/30 rounded-full blur-2xl"></div>
              <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-brand-500/30 rounded-full blur-2xl"></div>
              
              {/* Main card */}
              <div className="bg-white rounded-2xl shadow-2xl p-6 relative z-10 rotate-1">
                <div className="bg-brand-50 rounded-xl p-4 mb-5">
                  <h3 className="font-bold text-brand-800 text-lg flex items-center gap-2 mb-3">
                    Future-Ready Implementation System
                  </h3>
                  
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <div className="bg-green-100 p-1 rounded-full">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      </div>
                      <div>
                        <p className="text-gray-700">Complete step-by-step playbooks</p>
                        <p className="text-xs text-gray-500">Ready for immediate implementation</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <div className="bg-green-100 p-1 rounded-full">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      </div>
                      <div>
                        <p className="text-gray-700">Parent communication templates</p>
                        <p className="text-xs text-gray-500">Increase engagement & satisfaction</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start gap-3">
                      <div className="bg-green-100 p-1 rounded-full">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      </div>
                      <div>
                        <p className="text-gray-700">Student development framework</p>
                        <p className="text-xs text-gray-500">Build skills for tomorrow's economy</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <img 
                  src="https://images.unsplash.com/photo-1550399105-c4db5fb85c18?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80" 
                  alt="Students in a modern learning environment" 
                  className="w-full h-48 object-cover rounded-lg mb-4"
                />
                
                <div className="flex justify-between items-center">
                  <div>
                    <span className="text-green-600 font-semibold text-sm">Free Forever</span>
                    <p className="text-xs text-gray-500">No credit card required</p>
                  </div>
                  
                  <Button className="bg-brand-600 hover:bg-brand-700" asChild>
                    <Link to="/signup">
                      Get Access <ArrowRight className="h-4 w-4 ml-1" />
                    </Link>
                  </Button>
                </div>
              </div>
              
              {/* Floating accent card */}
              <div className="absolute -bottom-4 -left-4 bg-white rounded-lg p-3 shadow-lg max-w-[180px] -rotate-3 hidden md:block">
                <div className="flex items-center gap-2">
                  <div className="bg-blue-100 p-2 rounded-full">
                    <CheckCircle className="h-5 w-5 text-blue-600" />
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-gray-800">Works with</p>
                    <p className="text-sm text-gray-600">Any budget size</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Wave divider to next section */}
      <div className="relative h-16 bg-white mt-10">
        <svg 
          className="absolute -top-16 w-full h-16 text-white transform rotate-180" 
          viewBox="0 0 1440 100" 
          fill="currentColor" 
          preserveAspectRatio="none"
        >
          <path d="M0,50 C240,100 480,0 720,50 C960,100 1200,0 1440,50 L1440,100 L0,100 Z"></path>
        </svg>
      </div>
    </section>
  );
};

export default HomepageHero;
