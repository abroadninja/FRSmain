
import React from "react";
import { Badge } from "@/components/ui/badge";

const MissionStatement = () => {
  return (
    <section className="py-20 bg-gradient-to-br from-brand-800 to-brand-700 text-white relative overflow-hidden">
      {/* Visual elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 right-0 w-full h-full bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgdmlld0JveD0iMCAwIDIwMCAyMDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGNpcmNsZSBjeD0iMTAwIiBjeT0iMTAwIiByPSI4MCIgc3Ryb2tlPSIjZmZmIiBzdHJva2Utd2lkdGg9IjAuNSIgc3Ryb2tlLW9wYWNpdHk9IjAuMSIgZmlsbD0ibm9uZSIvPjwvc3ZnPg==')] opacity-20"></div>
      </div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <Badge variant="outline" className="border-white/30 text-white mb-4">Our Mission</Badge>
          
          <h2 className="text-3xl md:text-5xl font-bold mb-8">
            Making Future-Ready Education Accessible to Every School
          </h2>
          
          <p className="text-xl text-white/80 mb-10 leading-relaxed">
            We believe that every student deserves an education that prepares them for tomorrow's 
            world, regardless of their school's resources. Our goal is to bridge the gap between 
            traditional education and future workplace requirements without adding financial burden 
            to schools.
          </p>
          
          <div className="grid md:grid-cols-3 gap-8 mt-12">
            <MissionPillar 
              number="01"
              title="Equitable Access"
              description="Providing free tools and resources that work for schools of all sizes and budgets."
            />
            
            <MissionPillar 
              number="02"
              title="Practical Skills Focus"
              description="Building high-income skills that remain relevant regardless of technological change."
            />
            
            <MissionPillar 
              number="03"
              title="Community Building"
              description="Strengthening connections between schools, parents, and local communities."
            />
          </div>
        </div>
      </div>
    </section>
  );
};

interface MissionPillarProps {
  number: string;
  title: string;
  description: string;
}

const MissionPillar = ({ number, title, description }: MissionPillarProps) => {
  return (
    <div className="text-center">
      <div className="inline-block border border-white/30 rounded-full w-12 h-12 flex items-center justify-center mb-4">
        <span className="text-sm font-medium">{number}</span>
      </div>
      <h3 className="text-xl font-bold mb-3">{title}</h3>
      <p className="text-white/70">{description}</p>
    </div>
  );
};

export default MissionStatement;
