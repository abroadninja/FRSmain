
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, BookOpen, Users, Clock, ArrowUpRight } from "lucide-react";

const FeaturesOverview = () => {
  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge className="mb-4">Key Components</Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Everything You Need to Transform Your School
          </h2>
          <p className="text-lg text-gray-600">
            Our comprehensive system provides all the resources, templates, and guidance 
            required to implement modern education practices without added costs.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <FeatureCard
              key={index}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
              iconColor={feature.iconColor}
              benefits={feature.benefits}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

interface FeatureCardProps {
  icon: React.FC<{ className?: string }>;
  title: string;
  description: string;
  iconColor: string;
  benefits: string[];
}

const FeatureCard = ({ icon: Icon, title, description, iconColor, benefits }: FeatureCardProps) => {
  return (
    <Card className="border-none shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group h-full">
      <CardContent className="p-6 pt-6 h-full flex flex-col">
        <div className={`${iconColor} w-14 h-14 rounded-2xl flex items-center justify-center mb-6 transition-transform group-hover:scale-110`}>
          <Icon className="h-7 w-7" />
        </div>
        
        <h3 className="font-bold text-xl mb-3 text-gray-900">{title}</h3>
        <p className="text-gray-600 mb-6">{description}</p>
        
        <div className="space-y-3 mt-auto">
          {benefits.map((benefit, index) => (
            <div key={index} className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
              <span className="text-gray-700">{benefit}</span>
            </div>
          ))}
        </div>
        
        <div className="mt-6 inline-flex items-center text-brand-600 font-medium">
          Learn more <ArrowUpRight className="ml-1 h-4 w-4" />
        </div>
      </CardContent>
    </Card>
  );
};

const features = [
  {
    icon: BookOpen,
    title: "Implementation Playbooks",
    description: "Step-by-step guides to transform your school with minimal resources.",
    iconColor: "bg-blue-50 text-blue-600",
    benefits: [
      "Detailed action plans",
      "Customizable timelines",
      "Resource allocation guides"
    ]
  },
  {
    icon: Users,
    title: "Parent Engagement System",
    description: "Tools to build stronger relationships with parents and increase satisfaction.",
    iconColor: "bg-purple-50 text-purple-600",
    benefits: [
      "Communication templates",
      "Event planning guides",
      "Feedback collection systems"
    ]
  },
  {
    icon: Clock,
    title: "Future Skills Framework",
    description: "Prepare students for tomorrow's economy with key high-income skills.",
    iconColor: "bg-emerald-50 text-emerald-600",
    benefits: [
      "Critical thinking development",
      "Adaptability training",
      "Digital literacy programs"
    ]
  }
];

export default FeaturesOverview;
