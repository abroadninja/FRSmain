
import React from "react";
import { Badge } from "@/components/ui/badge";
import { Tab } from "@headlessui/react";
import { CheckCircle } from "lucide-react";

const ApproachSection = () => {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <Badge className="mb-4">Our Approach</Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Going Beyond Traditional Education
          </h2>
          <p className="text-lg text-gray-600">
            Our system directly addresses the limitations of conventional education by focusing 
            on future-ready skills and practical implementation methods.
          </p>
        </div>
        
        <Tab.Group>
          <Tab.List className="flex flex-wrap border-b border-gray-200 mb-10">
            {tabs.map((tab, index) => (
              <Tab
                key={index}
                className={({ selected }) => `
                  w-full sm:w-auto text-center px-5 py-3 text-sm font-medium border-b-2 transition-colors
                  focus:outline-none focus-visible:ring focus-visible:ring-brand-500/75
                  ${selected 
                    ? 'text-brand-700 border-brand-700' 
                    : 'text-gray-500 border-transparent hover:text-gray-700 hover:border-gray-300'
                  }
                `}
              >
                {tab.name}
              </Tab>
            ))}
          </Tab.List>
          
          <Tab.Panels>
            {tabs.map((tab, idx) => (
              <Tab.Panel key={idx} className="focus:outline-none">
                <div className="grid md:grid-cols-2 gap-12 items-center">
                  {/* Left: Image */}
                  <div className="rounded-xl overflow-hidden shadow-xl">
                    <img 
                      src={tab.image} 
                      alt={tab.name} 
                      className="w-full h-auto object-cover"
                    />
                  </div>
                  
                  {/* Right: Content */}
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900 mb-4">{tab.name}</h3>
                    <p className="text-gray-600 mb-6">{tab.description}</p>
                    
                    <div className="space-y-4">
                      {tab.benefits.map((benefit, index) => (
                        <div key={index} className="flex items-start gap-3">
                          <div className="bg-green-100 p-1 rounded-full mt-1">
                            <CheckCircle className="h-5 w-5 text-green-600" />
                          </div>
                          <div>
                            <h4 className="font-medium text-gray-900">{benefit.title}</h4>
                            <p className="text-gray-600 text-sm">{benefit.description}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </Tab.Panel>
            ))}
          </Tab.Panels>
        </Tab.Group>
      </div>
    </section>
  );
};

const tabs = [
  {
    name: "Future Skills Development",
    image: "https://images.unsplash.com/photo-1509062522246-3755977927d7?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
    description: "We focus on developing adaptable skills that remain valuable regardless of technological changes, ensuring students are prepared for careers that may not even exist yet.",
    benefits: [
      {
        title: "Critical Thinking & Problem Solving",
        description: "Structured activities that develop analytical reasoning abilities"
      },
      {
        title: "Communication & Collaboration",
        description: "Frameworks for building effective interpersonal skills"
      },
      {
        title: "Digital & Financial Literacy",
        description: "Essential knowledge for navigating the modern economy"
      }
    ]
  },
  {
    name: "Parent Engagement",
    image: "https://images.unsplash.com/photo-1543269865-cbf427effbad?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
    description: "We provide complete frameworks for meaningfully involving parents in the educational journey, creating stronger school communities and better outcomes for students.",
    benefits: [
      {
        title: "Communication Templates",
        description: "Ready-to-use materials for regular updates and special events"
      },
      {
        title: "Involvement Strategies",
        description: "Practical methods to increase parent participation"
      },
      {
        title: "Feedback Systems",
        description: "Tools to collect, analyze and implement parent suggestions"
      }
    ]
  },
  {
    name: "Resource Optimization",
    image: "https://images.unsplash.com/photo-1551836022-d5d88e9218df?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
    description: "Our implementation guides focus on making the most of existing resources rather than requiring new investments, making it feasible for schools with limited budgets.",
    benefits: [
      {
        title: "Asset Mapping Tools",
        description: "Identify underutilized resources in your school"
      },
      {
        title: "Low-Cost Implementation Plans",
        description: "Phased approaches that work with minimal funding"
      },
      {
        title: "Community Partnership Guides",
        description: "Frameworks for developing supportive local relationships"
      }
    ]
  }
];

export default ApproachSection;
