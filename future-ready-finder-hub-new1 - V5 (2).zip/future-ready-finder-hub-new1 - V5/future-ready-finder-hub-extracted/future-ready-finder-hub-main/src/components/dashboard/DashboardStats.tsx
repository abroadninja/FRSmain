
import React from "react";
import { Card } from "@/components/ui/card";
import { 
  BookOpen, Star, FileText, Rocket, BookUser, Book, 
  MessageSquare, Download, Search, CheckCircle2, Users,
  ArrowRight, BarChart3
} from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useIsMobile } from "@/hooks/use-mobile";

const DashboardStats = () => {
  const isMobile = useIsMobile();
  
  return (
    <div className="space-y-6">
      {/* Visual context finder - Main action card */}
      <div className="bg-gradient-to-r from-indigo-50 to-purple-50 p-4 sm:p-5 rounded-xl mb-6 border border-indigo-100 shadow-sm">
        <h2 className="text-xl font-semibold text-gray-800 mb-3 flex items-center gap-2">
          <BookOpen className="h-5 w-5 text-indigo-600" />
          Start Here: Implementation Playbooks
        </h2>
        <p className="text-gray-600 mb-4">
          These step-by-step playbooks are the foundation for school transformation. 
          Begin with these resources to see immediate results with minimal effort.
        </p>
        <div className="flex flex-wrap gap-3">
          <Button className="bg-indigo-600 text-white hover:bg-indigo-700" asChild>
            <Link to="/implementation-guides">Access Implementation Playbooks</Link>
          </Button>
          <Button variant="outline" asChild>
            <Link to="/implementation-guides?playbook=implementation-intro">Quick Start Guide</Link>
          </Button>
        </div>
      </div>
      
      <h2 className="text-xl font-semibold text-gray-800">Complete Resource Hub</h2>
      
      {/* Main Resource Cards - Responsive Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {/* Implementation Guides Card */}
        <ResourceCard 
          icon={<BookOpen className="h-6 w-6 text-blue-600" />}
          bgColor="blue"
          title="Implementation Guides"
          description="Access comprehensive step-by-step playbooks for school transformation"
          link="/implementation-guides"
          linkText="View Guides"
        />
        
        {/* Student Guides Card */}
        <ResourceCard 
          icon={<BookUser className="h-6 w-6 text-green-600" />}
          bgColor="green"
          title="Student Guides"
          description="Access comprehensive guides for students to build future-ready skills"
          link="/student-guides"
          linkText="View Guides"
        />
        
        {/* Future Ready Classes Card */}
        <ResourceCard 
          icon={<Book className="h-6 w-6 text-purple-600" />}
          bgColor="purple"
          title="Future Ready Classes"
          description="Access comprehensive lesson guides for holistic future readiness"
          link="/classes"
          linkText="View Classes"
        />

        {/* High Income Skills Portfolio Card */}
        <ResourceCard 
          icon={<Star className="h-6 w-6 text-amber-600" />}
          bgColor="amber"
          title="High Income Skills"
          description="Portfolio building guidance for students in classes 8-12"
          link="/implementation-guides?type=high-income"
          linkText="View Resources"
        />
        
        {/* Parent Engagement Hub Card */}
        <ResourceCard 
          icon={<Users className="h-6 w-6 text-purple-600" />}
          bgColor="purple"
          title="Parent Engagement Hub"
          description="Access templates and content for parent communication"
          link="/parent-engagement"
          linkText="View Templates"
        />
        
        {/* Career Explorer Card */}
        <ResourceCard 
          icon={<Search className="h-6 w-6 text-blue-600" />}
          bgColor="blue"
          title="Career Explorer"
          description="Explore high-value careers with detailed guidance"
          link="/career-explorer"
          linkText="Explore Careers"
        />
      </div>

      {/* Resources Hub Banner */}
      <div className="bg-gradient-to-r from-indigo-50 to-indigo-100/50 p-4 sm:p-5 rounded-xl border border-indigo-100 mt-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-start">
            <div className="bg-indigo-100 p-2 sm:p-3 rounded-lg mr-3 sm:mr-4 flex-shrink-0">
              <Download className="h-5 w-5 sm:h-6 sm:w-6 text-indigo-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-800 mb-1">Downloadable Resources Hub</h3>
              <p className="text-sm text-gray-600 max-w-2xl">
                Access all ready-to-use templates, guides, worksheets, and tools for teachers, students, and parents. 
                Everything you need to implement the programs in your school.
              </p>
            </div>
          </div>
          <Button className="bg-indigo-600 hover:bg-indigo-700 text-white w-full md:w-auto" asChild>
            <Link to="/resources">Access Resources Hub</Link>
          </Button>
        </div>
      </div>
      
      {/* Implementation approach message */}
      <div className="bg-green-50 p-4 sm:p-5 rounded-xl border border-green-100 mt-4 flex flex-col sm:flex-row items-start gap-4">
        <div className="bg-green-100 p-2 rounded-full sm:mt-1">
          <CheckCircle2 className="h-5 w-5 text-green-600" />
        </div>
        <div>
          <h3 className="font-medium text-green-800 mb-1">Simple Implementation Approach</h3>
          <p className="text-sm text-gray-600 mb-3">
            All of our resources are designed for minimal effort implementation. Start with the Quick Start Guide 
            for immediate results, then gradually implement more features as needed.
          </p>
          <Button variant="outline" size="sm" className="text-green-600 border-green-200" asChild>
            <Link to="/implementation-guides?playbook=pen-paper">View Simple Checklist</Link>
          </Button>
        </div>
      </div>

      {/* Growth Analytics Banner */}
      <div className="bg-gradient-to-r from-blue-50 to-blue-100/50 p-4 sm:p-5 rounded-xl border border-blue-100 mt-4">
        <div className="flex flex-col sm:flex-row items-start gap-4">
          <div className="bg-blue-100 p-2 rounded-full sm:mt-1">
            <BarChart3 className="h-5 w-5 text-blue-600" />
          </div>
          <div className="flex-1">
            <h3 className="font-medium text-blue-800 mb-1">Track Your School's Growth</h3>
            <p className="text-sm text-gray-600 mb-3">
              Our implementation tracking system helps you monitor progress and measure the impact 
              of the programs on your school's growth and student outcomes.
            </p>
            <Button variant="outline" size="sm" className="text-blue-600 border-blue-200" asChild>
              <Link to="/implementation-guides?playbook=tracking" className="flex items-center">
                View Growth Analytics <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

interface ResourceCardProps {
  icon: React.ReactNode;
  bgColor: "blue" | "green" | "purple" | "amber" | "rose" | "teal";
  title: string;
  description: string;
  link: string;
  linkText: string;
}

const ResourceCard = ({ icon, bgColor, title, description, link, linkText }: ResourceCardProps) => {
  const colorClasses = {
    blue: "from-blue-50 to-blue-100/50 border-blue-100 hover:shadow-blue-100/30",
    green: "from-green-50 to-green-100/50 border-green-100 hover:shadow-green-100/30",
    purple: "from-purple-50 to-purple-100/50 border-purple-100 hover:shadow-purple-100/30",
    amber: "from-amber-50 to-amber-100/50 border-amber-100 hover:shadow-amber-100/30",
    rose: "from-rose-50 to-rose-100/50 border-rose-100 hover:shadow-rose-100/30",
    teal: "from-teal-50 to-teal-100/50 border-teal-100 hover:shadow-teal-100/30"
  };
  
  const bgColorClasses = {
    blue: "bg-blue-100",
    green: "bg-green-100", 
    purple: "bg-purple-100",
    amber: "bg-amber-100",
    rose: "bg-rose-100",
    teal: "bg-teal-100"
  };

  return (
    <Card className={`p-4 sm:p-5 bg-gradient-to-r ${colorClasses[bgColor]} rounded-xl hover:shadow-md transition-all`}>
      <div className="flex items-start">
        <div className={`${bgColorClasses[bgColor]} p-3 rounded-lg mr-4 flex-shrink-0`}>
          {icon}
        </div>
        <div className="flex-1">
          <h3 className="text-base sm:text-lg font-semibold text-gray-800 mb-1">{title}</h3>
          <p className="text-xs sm:text-sm text-gray-600 mb-2 sm:mb-3">
            {description}
          </p>
          <Button variant="outline" size="sm" asChild>
            <Link to={link} className="flex items-center text-xs sm:text-sm">
              {linkText} <ArrowRight className="ml-1 h-3 w-3 sm:h-4 sm:w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </Card>
  );
};

export default DashboardStats;
