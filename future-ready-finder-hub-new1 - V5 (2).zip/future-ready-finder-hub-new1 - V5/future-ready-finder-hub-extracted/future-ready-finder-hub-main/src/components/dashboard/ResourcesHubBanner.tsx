
import React from "react";
import { ChevronRight, BookOpen } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const ResourcesHubBanner = () => {
  return (
    <div className="bg-gradient-to-r from-blue-50 to-blue-100/50 rounded-xl border border-blue-100 transition-all hover:shadow-md">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 p-4 sm:p-5 md:p-6">
        <div className="flex items-start">
          <div className="bg-blue-100 p-2 sm:p-3 rounded-lg mr-3 sm:mr-4 flex-shrink-0">
            <BookOpen className="h-5 w-5 sm:h-6 sm:w-6 text-blue-600" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-1">Resources Hub</h3>
            <p className="text-sm text-gray-600 max-w-2xl">
              Access our comprehensive collection of resources, templates, and tools for schools and teachers to implement future-ready education.
            </p>
          </div>
        </div>
        <Button 
          className="bg-blue-600 hover:bg-blue-700 text-white w-full md:w-auto" 
          asChild
        >
          <a href="https://resource-hub.futurereadyschools.com/" target="_blank" rel="noopener noreferrer" className="flex items-center justify-center">
            Access Resources Hub <ChevronRight className="ml-1 h-4 w-4" />
          </a>
        </Button>
      </div>
    </div>
  );
};

export default ResourcesHubBanner;
