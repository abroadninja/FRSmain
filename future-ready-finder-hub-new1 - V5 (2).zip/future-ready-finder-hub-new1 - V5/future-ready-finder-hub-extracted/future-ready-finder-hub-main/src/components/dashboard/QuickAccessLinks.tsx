
import React from "react";
import { 
  BookOpen, Book, MessageSquare, Download, 
  Search, Star 
} from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

const QuickAccessLinks = () => {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 lg:p-5">
      <h2 className="text-base lg:text-lg font-semibold text-gray-800 mb-3">Quick Access</h2>
      
      <div className="space-y-2 sm:space-y-3">
        <Button variant="outline" className="w-full justify-start text-left text-xs sm:text-sm" asChild>
          <Link to="/implementation-guides" className="flex items-center">
            <div className="bg-blue-100 p-1.5 rounded mr-3">
              <BookOpen className="h-3 w-3 sm:h-4 sm:w-4 text-blue-600" />
            </div>
            <span>Implementation Playbooks</span>
          </Link>
        </Button>
        
        <Button variant="outline" className="w-full justify-start text-left text-xs sm:text-sm" asChild>
          <Link to="/classes" className="flex items-center">
            <div className="bg-purple-100 p-1.5 rounded mr-3">
              <Book className="h-3 w-3 sm:h-4 sm:w-4 text-purple-600" />
            </div>
            <span>Future-Ready Classes</span>
          </Link>
        </Button>
        
        <Button variant="outline" className="w-full justify-start text-left text-xs sm:text-sm" asChild>
          <Link to="/parent-engagement" className="flex items-center">
            <div className="bg-green-100 p-1.5 rounded mr-3">
              <MessageSquare className="h-3 w-3 sm:h-4 sm:w-4 text-green-600" />
            </div>
            <span>Parent Communication</span>
          </Link>
        </Button>
        
        <Button variant="outline" className="w-full justify-start text-left text-xs sm:text-sm" asChild>
          <a href="https://resource-hub.futurereadyschools.com/" target="_blank" rel="noopener noreferrer" className="flex items-center">
            <div className="bg-amber-100 p-1.5 rounded mr-3">
              <Download className="h-3 w-3 sm:h-4 sm:w-4 text-amber-600" />
            </div>
            <span>Resources Hub</span>
          </a>
        </Button>
        
        <Button variant="outline" className="w-full justify-start text-left text-xs sm:text-sm" asChild>
          <Link to="/implementation-guides?playbook=high-income" className="flex items-center">
            <div className="bg-rose-100 p-1.5 rounded mr-3">
              <Star className="h-3 w-3 sm:h-4 sm:w-4 text-rose-600" />
            </div>
            <span>High Income Skills Program</span>
          </Link>
        </Button>
      </div>
    </div>
  );
};

export default QuickAccessLinks;
