
import React from "react";
import { Button } from "@/components/ui/button";
import { PlayCircle } from "lucide-react";

const DemoBanner = () => {
  return (
    <div className="bg-gradient-to-r from-indigo-50 to-blue-50 rounded-xl border border-indigo-100 shadow-sm mb-6">
      <div className="p-5 sm:p-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className="bg-indigo-100 p-2 sm:p-3 rounded-lg">
              <PlayCircle className="h-5 w-5 sm:h-6 sm:w-6 text-indigo-600" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-semibold text-gray-800 mb-1">
                New to our platform?
              </h3>
              <p className="text-sm text-gray-600 max-w-2xl">
                Explore our interactive demos to see how all features work together to create future-ready students 
                and transform your school. Perfect for first-time users.
              </p>
            </div>
          </div>
          
          <Button 
            className="bg-indigo-600 hover:bg-indigo-700 text-white w-full sm:w-auto" 
            asChild
          >
            <a href="https://alldemos.futurereadyschools.com" target="_blank" rel="noopener noreferrer" className="flex items-center justify-center">
              View All Demos <PlayCircle className="ml-2 h-4 w-4" />
            </a>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default DemoBanner;
