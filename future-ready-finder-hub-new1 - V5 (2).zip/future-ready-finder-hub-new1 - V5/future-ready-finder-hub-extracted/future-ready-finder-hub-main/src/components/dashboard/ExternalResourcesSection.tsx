
import React from "react";
import { 
  FileText, BookOpen, Search, Star, User, Users, 
  GraduationCap, Brain, BookUser, Clock, Book
} from "lucide-react";
import ResourceCard from "./ResourceCard";
import { useResponsive } from "@/hooks/use-responsive";

const toolsAndResources = [
  {
    id: "future-focus-assessment",
    title: "Future-Focus Assessment Tool",
    description: "A full spectrum psychometric career assessment for students who want to know the scores of various traits that would be needed to build a successful career.",
    link: "https://assessment.futurereadyschools.com/",
    icon: <Brain className="h-5 w-5 text-purple-600" />,
    color: "purple"
  },
  {
    id: "problem-solver-career-explorer",
    title: "Problem-Solver Career Explorer",
    description: "An app designed to find your suitable career options based on the type of high-value problem(s) students want to solve.",
    link: "https://careers.futurereadyschools.com/",
    icon: <Search className="h-5 w-5 text-blue-600" />,
    color: "blue"
  },
  {
    id: "future-focus-selector",
    title: "Future Focus Selector App",
    description: "A career explorer app designed for students to find their favorite careers based on various career clusters or industries.",
    link: "http://careerclusterexplore.futurereadyschools.com/",
    icon: <Star className="h-5 w-5 text-amber-600" />,
    color: "amber"
  },
  {
    id: "career-edge",
    title: "Career Edge",
    description: "An informative guidance app which helps students take notes or journal. It has high value information to plan and build a successful future.",
    link: "http://skillandcareerjournalguide.futurereadyschools.com/",
    icon: <BookUser className="h-5 w-5 text-green-600" />,
    color: "green"
  },
  {
    id: "parenting-guide",
    title: "Parenting Guide for Future-Ready Kids",
    description: "A fully informational parental guidance app for building an all-round successful future for their kids.",
    link: "https://parents-guide.futurereadyschools.com/",
    icon: <Users className="h-5 w-5 text-teal-600" />,
    color: "teal"
  },
  {
    id: "student-success-kit",
    title: "Student Success Kit",
    description: "An app with lots of tools and informative guides for students.",
    link: "http://student-success-kit.futurereadyschools.com/",
    icon: <User className="h-5 w-5 text-indigo-600" />,
    color: "indigo"
  },
  {
    id: "teachers-quick-guide",
    title: "Teachers Quick Guide on High Income Skill Building",
    description: "A quick to read, easy to implement playbook for teachers to initiate and provide continuous high income skill building guidance to students.",
    link: "https://teachersguide.futurereadyschools.com/",
    icon: <GraduationCap className="h-5 w-5 text-rose-600" />,
    color: "rose"
  },
  {
    id: "success-skills-assessment-5-8",
    title: "Success-Ready Skills Assessment (Grades 5-8)",
    description: "An app designed to assess the most important traits of student success, which are grit and learning abilities.",
    link: "http://success-skills-assessment-grade-5-8.futurereadyschools.com/",
    icon: <Brain className="h-5 w-5 text-blue-600" />,
    color: "blue"
  },
  {
    id: "success-skills-assessment-9-12",
    title: "Success-Ready Skills Assessment (Grades 9-12)",
    description: "An app designed to assess the most important traits of student success, which are grit and learning abilities.",
    link: "https://success-skills-assessments-grade-9-12.futurereadyschools.com/",
    icon: <Brain className="h-5 w-5 text-purple-600" />,
    color: "purple"
  },
  {
    id: "work-style-explorer",
    title: "My Fun Work Style Explorer (Grades 5-8)",
    description: "An assessment designed to discover the values and the work environment preferences.",
    link: "http://values-and-work-style-assesment-grades-5-8.futurereadyschools.com/",
    icon: <Star className="h-5 w-5 text-amber-600" />,
    color: "amber"
  },
  {
    id: "personality-assessment",
    title: "My Personality & Future Fun (Grades 5-8)",
    description: "A personality based psychometric career assessment which suggests suitable future-ready careers based on the student's personality type. Unlike lengthy, outdated assessments, this is simple yet effective and practical.",
    link: "http://psychometric-career-assessment-grade-5-8.futurereadyschools.com",
    icon: <User className="h-5 w-5 text-green-600" />,
    color: "green"
  },
  {
    id: "quick-guide-playbook",
    title: "Quick Guide Playbook for Schools",
    description: "A shortcut playbook for schools that don't have enough time to read all playbooks. Suitable for schools with limited resources.",
    link: "https://playbook.futurereadyschools.com/",
    icon: <Clock className="h-5 w-5 text-indigo-600" />,
    color: "indigo"
  }
];

const ExternalResourcesSection = () => {
  const { isMobile, isTablet } = useResponsive();
  
  // Determine number of columns based on screen size
  const getGridCols = () => {
    if (isMobile) return "grid-cols-1";
    if (isTablet) return "grid-cols-2";
    return "grid-cols-3";
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-gray-800">External Tools & Resources</h2>
      </div>
      
      <div className={`grid ${getGridCols()} gap-4`}>
        {toolsAndResources.map((resource) => (
          <ResourceCard
            key={resource.id}
            icon={<div className={`bg-${resource.color}-100 p-2 rounded-lg`}>{resource.icon}</div>}
            title={resource.title}
            description={resource.description}
            link={resource.link}
            linkText="Open Resource"
            isExternal={true}
            bgColor={resource.color as any}
          />
        ))}
      </div>
    </div>
  );
};

export default ExternalResourcesSection;
