
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { BookOpen, Book, MessageSquare, Star } from "lucide-react";
import { useResponsive } from "@/hooks/use-responsive";

const WelcomeSection = () => {
  const { isMobile, isTablet } = useResponsive();
  
  return (
    <div className="bg-gradient-to-r from-blue-50 via-indigo-50 to-purple-50 rounded-xl p-4 lg:p-6 border border-indigo-100 shadow-sm">
      <div className="flex flex-col lg:flex-row gap-4 lg:gap-6 items-center">
        <div className="flex-1">
          <h1 className="text-xl md:text-2xl lg:text-3xl font-bold text-gray-800 mb-2">
            Welcome to your School Growth Hub
          </h1>
          <p className="text-xs sm:text-sm lg:text-base text-gray-600 max-w-2xl mb-4">
            Access step-by-step implementation guides, classroom resources, and complete playbooks to transform your school's growth, admissions, and student skill development. Customize our resources to fit your needs and implement with any budget.
          </p>
          <div className="flex flex-wrap gap-3">
            <Button asChild className="bg-indigo-600 hover:bg-indigo-700 text-xs sm:text-sm">
              <Link to="/implementation-guides">
                Get Started with Implementation
              </Link>
            </Button>
            <Button asChild variant="outline" className="text-xs sm:text-sm">
              <Link to="/resources">Access Resources</Link>
            </Button>
          </div>
        </div>
        {!isMobile && (
          <div className="flex-shrink-0 grid grid-cols-2 gap-2 sm:gap-3">
            <Card className="bg-green-50 border-green-100 shadow-sm p-2 sm:p-3 flex items-center gap-2">
              <div className="p-1.5 sm:p-2 bg-green-100 rounded-lg">
                <BookOpen className="h-3 w-3 sm:h-5 sm:w-5 text-green-600" />
              </div>
              <span className="text-xs sm:text-sm font-medium">Implementation Guides</span>
            </Card>
            <Card className="bg-purple-50 border-purple-100 shadow-sm p-2 sm:p-3 flex items-center gap-2">
              <div className="p-1.5 sm:p-2 bg-purple-100 rounded-lg">
                <Book className="h-3 w-3 sm:h-5 sm:w-5 text-purple-600" />
              </div>
              <span className="text-xs sm:text-sm font-medium">Future-Ready Classes</span>
            </Card>
            <Card className="bg-blue-50 border-blue-100 shadow-sm p-2 sm:p-3 flex items-center gap-2">
              <div className="p-1.5 sm:p-2 bg-blue-100 rounded-lg">
                <MessageSquare className="h-3 w-3 sm:h-5 sm:w-5 text-blue-600" />
              </div>
              <span className="text-xs sm:text-sm font-medium">Parent Engagement</span>
            </Card>
            <Card className="bg-amber-50 border-amber-100 shadow-sm p-2 sm:p-3 flex items-center gap-2">
              <div className="p-1.5 sm:p-2 bg-amber-100 rounded-lg">
                <Star className="h-3 w-3 sm:h-5 sm:w-5 text-amber-600" />
              </div>
              <span className="text-xs sm:text-sm font-medium">Student Skills</span>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default WelcomeSection;
