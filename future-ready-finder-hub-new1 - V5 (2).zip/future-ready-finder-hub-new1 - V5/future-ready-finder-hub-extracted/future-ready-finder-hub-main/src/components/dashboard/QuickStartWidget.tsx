
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Rocket } from "lucide-react";

const QuickStartWidget = () => {
  return (
    <div className="bg-gradient-to-br from-indigo-600 to-blue-700 text-white rounded-xl shadow-lg p-4 lg:p-6">
      <h2 className="text-lg lg:text-xl font-bold mb-2 lg:mb-3">New to the Platform?</h2>
      <p className="text-white/90 text-xs sm:text-sm mb-4">
        Start with our simple implementation guide to get immediate results with minimal effort.
      </p>
      <Button variant="outline" className="bg-white text-indigo-700 hover:bg-white/90 w-full text-xs sm:text-sm" asChild>
        <Link to="/implementation-guides?playbook=implementation-intro">
          <Rocket className="h-3 w-3 sm:h-4 sm:w-4 mr-2" /> Quick Start Guide
        </Link>
      </Button>
    </div>
  );
};

export default QuickStartWidget;
