
import React from "react";
import { Link } from "react-router-dom";
import { BookOpen, ChevronRight, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useIsMobile } from "@/hooks/use-mobile";

const ActivePlaybooks = () => {
  const isMobile = useIsMobile();
  
  return (
    <div className="space-y-5 sm:space-y-6 bg-white rounded-xl shadow-sm border border-gray-100 p-4 sm:p-5">
      <div className="flex items-center justify-between">
        <h2 className="text-lg sm:text-xl font-semibold text-gray-800">Implementation Resources</h2>
        <Link to="/implementation-guides" className="text-blue-600 hover:text-blue-700 flex items-center text-sm font-medium">
          View All <ChevronRight className="h-4 w-4 ml-1" />
        </Link>
      </div>
      
      <div className="space-y-5 sm:space-y-6">
        {/* Implementation Playbooks Section */}
        <div>
          <h3 className="text-base sm:text-lg font-semibold mb-3 text-gray-700 flex items-center gap-2">
            <span className="w-1.5 h-5 bg-blue-600 rounded-full"></span>
            School Growth Playbooks
          </h3>
          
          <div className="relative">
            <div className="absolute left-4 sm:left-6 top-0 bottom-0 w-0.5 bg-blue-100 z-0"></div>
            <div className="space-y-4 relative z-10">
              <PlaybookItem 
                number="1"
                title="Immediate Impact – Quick Wins"
                description="Deploy proven positioning, stand out tomorrow, and turn your school's hidden strengths into immediate inquiries."
                modules={2}
                link="/implementation-guides?playbook=pb1"
              />
              
              <PlaybookItem 
                number="2"
                title="Engaging Your Parent Community"
                description="Create a thriving parent community that builds loyalty, generates referrals, and boosts retention."
                modules={2}
                link="/implementation-guides?playbook=pb2"
              />
              
              <PlaybookItem 
                number="3"
                title="Simple & Effective Admission Process"
                description="Convert more inquiries to admissions with a streamlined, easy process that eliminates friction."
                modules={2}
                link="/implementation-guides?playbook=pb3"
              />
              
              <PlaybookItem 
                number="4"
                title="Sustainable Growth & Revenue"
                description="Move beyond one-time admission fees to create predictable revenue streams with proven lead generation systems."
                modules={3}
                link="/implementation-guides?playbook=pb4"
              />
            </div>
          </div>
        </div>
        
        {/* Quick Start Guide Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <QuickGuideCard 
            color="amber"
            icon={<CheckCircle2 className="h-5 w-5 text-amber-600" />}
            title="Getting Started: Implementation Guide"
            description="Your comprehensive roadmap to implementing all playbooks efficiently and effectively, with minimal effort."
            linkText="Access Quick Start Guide"
            link="/implementation-guides?playbook=implementation-intro"
          />
          
          <QuickGuideCard 
            color="teal"
            icon={<CheckCircle2 className="h-5 w-5 text-teal-600" />}
            title="Simple Implementation Guide"
            description="A streamlined checklist for schools to quickly implement growth strategies with minimal effort and maximum results."
            linkText="View Implementation Checklist"
            link="/implementation-guides?playbook=pen-paper"
          />
        </div>
        
        {/* Skills Programs Section */}
        <div>
          <h3 className="text-base sm:text-lg font-semibold mb-3 text-gray-700 flex items-center gap-2">
            <span className="w-1.5 h-5 bg-amber-600 rounded-full"></span>
            Student Skills Programs
          </h3>
          <div className="bg-gradient-to-r from-amber-50 to-amber-100/50 rounded-xl p-4 sm:p-5 border border-amber-100">
            <div className="flex items-start gap-3">
              <div className="bg-white p-2 rounded-lg shadow-sm">
                <BookOpen className="h-5 w-5 text-amber-600" />
              </div>
              <div>
                <h4 className="text-base sm:text-lg font-medium">High Income Skills Portfolio</h4>
                <p className="text-sm text-gray-600 mb-4">
                  Step-by-step guidance for teachers to help students build portfolios and develop high-income skills using available resources.
                </p>
                
                <div className="flex flex-wrap gap-3">
                  <Button variant="default" className="bg-amber-600 hover:bg-amber-700 text-sm" asChild>
                    <Link to="/implementation-guides?playbook=high-income">
                      Access Full Program
                    </Link>
                  </Button>
                  <Button variant="outline" className="text-amber-600 text-sm" asChild>
                    <Link to="/implementation-guides?playbook=high-income&module=1">
                      View Module 1
                    </Link>
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

interface PlaybookItemProps {
  number: string;
  title: string;
  description: string;
  modules: number;
  link: string;
}

const PlaybookItem = ({ number, title, description, modules, link }: PlaybookItemProps) => {
  return (
    <div className="flex gap-3 sm:gap-4">
      <div className="flex-shrink-0 w-8 h-8 sm:w-12 sm:h-12 rounded-full bg-blue-600 text-white flex items-center justify-center">
        <span className="font-bold text-sm sm:text-base">{number}</span>
      </div>
      <div className="bg-blue-50/50 rounded-xl p-3 sm:p-4 flex-1 border border-blue-100">
        <h4 className="text-base sm:text-lg font-medium">{title}</h4>
        <p className="text-xs sm:text-sm text-gray-600 mb-2 sm:mb-3">
          {description}
        </p>
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <span className="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded-full">{modules} Implementation Modules</span>
          </div>
          <Link 
            to={link} 
            className="text-blue-600 hover:text-blue-700 flex items-center text-xs sm:text-sm"
          >
            Access Guide <ChevronRight className="h-3 w-3 sm:h-4 sm:w-4 ml-0.5" />
          </Link>
        </div>
      </div>
    </div>
  );
};

interface QuickGuideCardProps {
  color: "amber" | "teal";
  icon: React.ReactNode;
  title: string;
  description: string;
  linkText: string;
  link: string;
}

const QuickGuideCard = ({ color, icon, title, description, linkText, link }: QuickGuideCardProps) => {
  const colorClasses = {
    amber: {
      bg: "bg-amber-50",
      border: "border-amber-100",
      iconBg: "bg-amber-100",
      buttonText: "text-amber-600",
      buttonBorder: "border-amber-200",
      buttonHover: "hover:bg-amber-50"
    },
    teal: {
      bg: "bg-teal-50",
      border: "border-teal-100",
      iconBg: "bg-teal-100",
      buttonText: "text-teal-600",
      buttonBorder: "border-teal-200",
      buttonHover: "hover:bg-teal-50"
    }
  };

  return (
    <div className={`${colorClasses[color].bg} rounded-xl p-4 sm:p-5 border ${colorClasses[color].border}`}>
      <div className="flex items-center gap-3 mb-2 sm:mb-3">
        <div className={`${colorClasses[color].iconBg} p-2 rounded-lg`}>
          {icon}
        </div>
        <h4 className="text-base sm:text-lg font-medium">{title}</h4>
      </div>
      
      <p className="text-gray-600 text-xs sm:text-sm mb-3">
        {description}
      </p>
      
      <Button
        variant="outline"
        className={`${colorClasses[color].buttonText} ${colorClasses[color].buttonBorder} ${colorClasses[color].buttonHover} text-sm`}
        asChild
      >
        <Link to={link}>
          {linkText}
        </Link>
      </Button>
    </div>
  );
};

export default ActivePlaybooks;
