import React from "react";
import { BarChart, ChevronRight, BookOpen, CheckCircle2, Clock, Book, Users } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useResponsive } from "@/hooks/use-responsive";
import ResourceCard from "./ResourceCard";
import { cn } from "@/lib/utils";

const ImplementationPlaybooksSection = () => {
  const { isMobile } = useResponsive();
  
  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4 lg:p-6">
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-lg lg:text-xl font-semibold text-gray-800 flex items-center gap-2">
          <BarChart className="h-5 w-5 text-indigo-600" />
          School Growth System
        </h2>
        <Link to="/implementation-guides" className="text-blue-600 hover:text-blue-700 flex items-center text-sm font-medium">
          View All Guides <ChevronRight className="h-4 w-4 ml-1" />
        </Link>
      </div>

      {/* Quick Start Playbooks - Highlighted with special emphasis */}
      <div className="mb-6 p-4 bg-indigo-50/50 rounded-xl border border-indigo-100">
        <h3 className="font-semibold text-indigo-800 mb-3 flex items-center">
          <Clock className="mr-2 h-5 w-5 text-indigo-600" /> Quick Start Playbooks
        </h3>
        <p className="text-sm text-gray-600 mb-4">
          Get started quickly with these shortcut playbooks designed for busy schools and teachers.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Quick Guide Playbook */}
          <ResourceCard
            icon={<Clock className="h-6 w-6 text-indigo-600" />}
            title="Quick Guide Playbook for Schools"
            description="A shortcut playbook for schools that don't have enough time to read all playbooks. Suitable for schools with limited resources."
            link="https://playbook.futurereadyschools.com"
            linkText="Access Quick Guide"
            bgColor="indigo"
            highlight={true}
          />
          
          {/* Teachers Quick Guide */}
          <ResourceCard
            icon={<Book className="h-6 w-6 text-rose-600" />}
            title="Teachers Quick Guide on High Income Skill Building"
            description="A quick to read, easy to implement playbook for teachers to initiate and provide continuous high income skill building guidance to students."
            link="https://teachersguide.futurereadyschools.com"
            linkText="View Teachers Guide"
            bgColor="rose"
            highlight={true}
          />

          {/* Parent Communities Quick Guide */}
          <ResourceCard
            icon={<Users className="h-6 w-6 text-amber-600" />}
            title="Thriving Parent Communities"
            description="Build engaged parent communities that boost school growth, increase referrals, and create strong support systems for student success."
            link="https://community-building.futurereadyschools.com"
            linkText="Access Guide"
            bgColor="amber"
            highlight={true}
          />
        </div>
      </div>

      <div className="relative">
        <div className="absolute left-4 sm:left-6 top-0 bottom-0 w-0.5 bg-indigo-100 z-0 hidden sm:block"></div>
        <div className="space-y-4 sm:space-y-5 relative z-10">
          {/* Step 1 */}
          <div className={isMobile ? "bg-indigo-50 rounded-xl p-4" : "flex gap-4"}>
            {!isMobile && (
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-indigo-600 text-white flex items-center justify-center">
                <span className="font-bold">1</span>
              </div>
            )}
            <div className={cn(
              isMobile ? "" : "bg-indigo-50 rounded-xl p-4 flex-1",
              "transition-all hover:shadow-md"
            )}>
              {isMobile && (
                <div className="flex items-center mb-2">
                  <div className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs mr-2">
                    1
                  </div>
                  <h3 className="font-semibold text-base">Quick Wins Implementation</h3>
                </div>
              )}
              {!isMobile && <h3 className="font-semibold text-lg mb-1">Quick Wins Implementation</h3>}
              <p className="text-gray-600 text-xs sm:text-sm mb-3">Deploy proven positioning and stand out immediately with easy-to-implement strategies.</p>
              <Button variant="outline" size="sm" className="text-indigo-600 text-xs sm:text-sm" asChild>
                <Link to="/implementation-guides?playbook=pb1">Start Here</Link>
              </Button>
            </div>
          </div>
          
          {/* Step 2 */}
          <div className={isMobile ? "bg-purple-50 rounded-xl p-4" : "flex gap-4"}>
            {!isMobile && (
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-purple-600 text-white flex items-center justify-center">
                <span className="font-bold">2</span>
              </div>
            )}
            <div className={cn(
              isMobile ? "" : "bg-purple-50 rounded-xl p-4 flex-1",
              "transition-all hover:shadow-md"
            )}>
              {isMobile && (
                <div className="flex items-center mb-2">
                  <div className="w-6 h-6 rounded-full bg-purple-600 text-white flex items-center justify-center text-xs mr-2">
                    2
                  </div>
                  <h3 className="font-semibold text-base">Parent Community Building</h3>
                </div>
              )}
              {!isMobile && <h3 className="font-semibold text-lg mb-1">Parent Community Building</h3>}
              <p className="text-gray-600 text-xs sm:text-sm mb-3">Create a thriving parent community that builds loyalty, generates referrals, and boosts retention.</p>
              <Button variant="outline" size="sm" className="text-purple-600 text-xs sm:text-sm" asChild>
                <Link to="/implementation-guides?playbook=pb2">Access Guide</Link>
              </Button>
            </div>
          </div>
          
          {/* Step 3 */}
          <div className={isMobile ? "bg-blue-50 rounded-xl p-4" : "flex gap-4"}>
            {!isMobile && (
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-blue-600 text-white flex items-center justify-center">
                <span className="font-bold">3</span>
              </div>
            )}
            <div className={cn(
              isMobile ? "" : "bg-blue-50 rounded-xl p-4 flex-1",
              "transition-all hover:shadow-md"
            )}>
              {isMobile && (
                <div className="flex items-center mb-2">
                  <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs mr-2">
                    3
                  </div>
                  <h3 className="font-semibold text-base">Streamlined Admission Process</h3>
                </div>
              )}
              {!isMobile && <h3 className="font-semibold text-lg mb-1">Streamlined Admission Process</h3>}
              <p className="text-gray-600 text-xs sm:text-sm mb-3">Convert more inquiries with a simple, frictionless admission process.</p>
              <Button variant="outline" size="sm" className="text-blue-600 text-xs sm:text-sm" asChild>
                <Link to="/implementation-guides?playbook=pb3">Access Guide</Link>
              </Button>
            </div>
          </div>
          
          {/* Step 4 */}
          <div className={isMobile ? "bg-green-50 rounded-xl p-4" : "flex gap-4"}>
            {!isMobile && (
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-green-600 text-white flex items-center justify-center">
                <span className="font-bold">4</span>
              </div>
            )}
            <div className={cn(
              isMobile ? "" : "bg-green-50 rounded-xl p-4 flex-1",
              "transition-all hover:shadow-md"
            )}>
              {isMobile && (
                <div className="flex items-center mb-2">
                  <div className="w-6 h-6 rounded-full bg-green-600 text-white flex items-center justify-center text-xs mr-2">
                    4
                  </div>
                  <h3 className="font-semibold text-base">Sustainable Growth & Revenue</h3>
                </div>
              )}
              {!isMobile && <h3 className="font-semibold text-lg mb-1">Sustainable Growth & Revenue</h3>}
              <p className="text-gray-600 text-xs sm:text-sm mb-3">Create predictable revenue streams with proven lead generation systems.</p>
              <Button variant="outline" size="sm" className="text-green-600 text-xs sm:text-sm" asChild>
                <Link to="/implementation-guides?playbook=pb4">Access Guide</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-6 p-4 bg-blue-50/50 rounded-lg">
        <p className="text-sm text-center text-blue-800">Need premium support for rapid implementation? Our team can help.</p>
        <div className="mt-3 text-center">
          <Link to="/membership">
            <Button className="bg-blue-600 hover:bg-blue-700">
              Learn About Premium Network
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ImplementationPlaybooksSection;
