
import React from "react";
import { 
  Wrench, Brain, Search, Star, User, Users, 
  GraduationCap, BookUser, Clock, Book
} from "lucide-react";
import ResourceCard from "./ResourceCard";
import { useResponsive } from "@/hooks/use-responsive";

const ToolsAndResourcesSection = () => {
  const { isMobile, isTablet } = useResponsive();
  
  // Determine number of columns based on screen size
  const getGridCols = () => {
    if (isMobile) return "grid-cols-1";
    if (isTablet) return "grid-cols-2";
    return "grid-cols-3";
  };
  
  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-gray-800">Tools & Resources</h2>
      </div>
      
      <div className={`grid ${getGridCols()} gap-4`}>
        <ResourceCard
          icon={<div className="bg-purple-100 p-2 rounded-lg"><Brain className="h-5 w-5 text-purple-600" /></div>}
          title="Future-Focus Assessment Tool"
          description="A full spectrum psychometric career assessment for students who want to know the scores of various traits that would be needed to build a successful career."
          link="https://assessment.futurereadyschools.com/"
          linkText="Open Assessment"
          bgColor="purple"
          isExternal={true}
        />
        
        <ResourceCard
          icon={<div className="bg-blue-100 p-2 rounded-lg"><Search className="h-5 w-5 text-blue-600" /></div>}
          title="Problem-Solver Career Explorer"
          description="An app designed to find your suitable career options based on the type of high-value problem(s) students want to solve."
          link="https://careers.futurereadyschools.com/"
          linkText="Open Explorer"
          bgColor="blue"
          isExternal={true}
        />
        
        <ResourceCard
          icon={<div className="bg-amber-100 p-2 rounded-lg"><Star className="h-5 w-5 text-amber-600" /></div>}
          title="Future Focus Selector App"
          description="A career explorer app designed for students to find their favorite careers based on various career clusters or industries."
          link="http://careerclusterexplore.futurereadyschools.com/"
          linkText="Open Selector"
          bgColor="amber"
          isExternal={true}
        />
        
        <ResourceCard
          icon={<div className="bg-green-100 p-2 rounded-lg"><BookUser className="h-5 w-5 text-green-600" /></div>}
          title="Skill Building Helper App"
          description="An informative guidance app which helps students take notes or journal. It has high value information to plan and build a successful future."
          link="http://skillandcareerjournalguide.futurereadyschools.com/"
          linkText="Open App"
          bgColor="green"
          isExternal={true}
        />
        
        <ResourceCard
          icon={<div className="bg-indigo-100 p-2 rounded-lg"><Users className="h-5 w-5 text-indigo-600" /></div>}
          title="Parenting Guide for Future-Ready Kids"
          description="A fully informational parental guidance app for building an all-round successful future for their kids."
          link="https://parents-guide.futurereadyschools.com/"
          linkText="Open Guide"
          bgColor="indigo"
          isExternal={true}
        />
        
        <ResourceCard
          icon={<div className="bg-indigo-100 p-2 rounded-lg"><User className="h-5 w-5 text-indigo-600" /></div>}
          title="Student Success Kit"
          description="An app with lots of tools and informative guides for students."
          link="http://student-success-kit.futurereadyschools.com/"
          linkText="Open Success Kit"
          bgColor="indigo"
          isExternal={true}
        />
        
        <ResourceCard
          icon={<div className="bg-rose-100 p-2 rounded-lg"><GraduationCap className="h-5 w-5 text-rose-600" /></div>}
          title="Teachers Quick Guide on High Income Skills"
          description="A quick to read, easy to implement playbook for teachers to initiate and provide continuous high income skill building guidance."
          link="https://teachersguide.futurereadyschools.com/"
          linkText="Open Guide"
          bgColor="rose"
          isExternal={true}
        />
        
        <ResourceCard
          icon={<div className="bg-blue-100 p-2 rounded-lg"><Brain className="h-5 w-5 text-blue-600" /></div>}
          title="Success-Ready Skills Assessment (5-8)"
          description="An app designed to assess the most important traits of student success, which are grit and learning abilities."
          link="http://success-skills-assessment-grade-5-8.futurereadyschools.com/"
          linkText="Open Assessment"
          bgColor="blue"
          isExternal={true}
        />
        
        <ResourceCard
          icon={<div className="bg-purple-100 p-2 rounded-lg"><Brain className="h-5 w-5 text-purple-600" /></div>}
          title="Success-Ready Skills Assessment (9-12)"
          description="An app designed to assess the most important traits of student success, which are grit and learning abilities."
          link="https://success-skills-assessments-grade-9-12.futurereadyschools.com/"
          linkText="Open Assessment"
          bgColor="purple"
          isExternal={true}
        />
        
        <ResourceCard
          icon={<div className="bg-amber-100 p-2 rounded-lg"><Star className="h-5 w-5 text-amber-600" /></div>}
          title="My Fun Work Style Explorer"
          description="An assessment designed to discover the values and the work environment preferences for grades 5-8."
          link="http://values-and-work-style-assesment-grades-5-8.futurereadyschools.com/"
          linkText="Open Explorer"
          bgColor="amber"
          isExternal={true}
        />
        
        <ResourceCard
          icon={<div className="bg-green-100 p-2 rounded-lg"><User className="h-5 w-5 text-green-600" /></div>}
          title="My Personality & Future Fun"
          description="A personality based psychometric career assessment for grades 5-8 which suggests suitable future-ready careers based on personality type."
          link="http://psychometric-career-assessment-grade-5-8.futurereadyschools.com"
          linkText="Open Assessment"
          bgColor="green"
          isExternal={true}
        />
        
        <ResourceCard
          icon={<div className="bg-indigo-100 p-2 rounded-lg"><Clock className="h-5 w-5 text-indigo-600" /></div>}
          title="Quick Guide Playbook for Schools"
          description="A shortcut playbook for schools that don't have enough time to read all playbooks. Suitable for schools with limited resources."
          link="https://playbook.futurereadyschools.com/"
          linkText="Open Playbook"
          bgColor="indigo"
          isExternal={true}
        />
      </div>
    </div>
  );
};

export default ToolsAndResourcesSection;
