
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface ResourceCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  link: string;
  linkText: string;
  bgColor?: "blue" | "green" | "amber" | "purple" | "rose" | "indigo";
  highlight?: boolean;
  isExternal?: boolean;
  className?: string;
}

const ResourceCard = ({
  icon,
  title,
  description,
  link,
  linkText,
  bgColor = "blue",
  highlight = false,
  isExternal = false,
  className,
}: ResourceCardProps) => {
  // Get background color classes based on the bgColor prop
  const getBgColorClass = () => {
    const colorMap = {
      blue: "bg-blue-50/50 border-blue-100",
      green: "bg-green-50/50 border-green-100",
      amber: "bg-amber-50/50 border-amber-100", 
      purple: "bg-purple-50/50 border-purple-100",
      rose: "bg-rose-50/50 border-rose-100",
      indigo: "bg-indigo-50/50 border-indigo-100",
    };
    return colorMap[bgColor] || colorMap.blue;
  };

  // Get button color classes based on the bgColor prop
  const getButtonColorClass = () => {
    const colorMap = {
      blue: "text-blue-700 border-blue-200 hover:bg-blue-50",
      green: "text-green-700 border-green-200 hover:bg-green-50", 
      amber: "text-amber-700 border-amber-200 hover:bg-amber-50",
      purple: "text-purple-700 border-purple-200 hover:bg-purple-50",
      rose: "text-rose-700 border-rose-200 hover:bg-rose-50",
      indigo: "text-indigo-700 border-indigo-200 hover:bg-indigo-50",
    };
    return colorMap[bgColor] || colorMap.blue;
  };
  
  return (
    <div 
      className={cn(
        "rounded-lg border transition-all h-full",
        getBgColorClass(),
        highlight ? "shadow-md" : "shadow-sm",
        className
      )}
    >
      <div className="p-4 flex flex-col h-full">
        <div className="flex items-start mb-3">
          {icon}
          <h3 className="font-semibold ml-3 text-xs sm:text-sm text-gray-800 leading-tight">
            {title}
          </h3>
        </div>
        <p className="text-gray-600 text-xs mb-4 flex-grow overflow-y-auto max-h-24">
          {description}
        </p>
        <Button 
          variant="outline"
          size="sm"
          className={cn(
            "w-full justify-center text-xs px-2 whitespace-normal h-auto py-1.5 mt-auto",
            getButtonColorClass()
          )}
          asChild
        >
          {isExternal ? (
            <a href={link} target="_blank" rel="noopener noreferrer" className="flex items-center">
              <span className="truncate">{linkText}</span>
              <ChevronRight className="ml-1 h-3 w-3 flex-shrink-0" />
            </a>
          ) : (
            <Link to={link} className="flex items-center">
              <span className="truncate">{linkText}</span>
              <ChevronRight className="ml-1 h-3 w-3 flex-shrink-0" />
            </Link>
          )}
        </Button>
      </div>
    </div>
  );
};

export default ResourceCard;
