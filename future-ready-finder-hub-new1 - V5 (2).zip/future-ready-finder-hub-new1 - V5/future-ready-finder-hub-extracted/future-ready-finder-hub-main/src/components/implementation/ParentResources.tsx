
import React from "react";
import { FileText, Users, BookOpen, GraduationCap } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

const ParentResources: React.FC = () => {
  const isMobile = useIsMobile();
  
  const resourceCategories = [
    {
      id: "future-skills",
      title: "Future Skills Insights",
      icon: <GraduationCap className="h-5 w-5 lg:h-6 lg:w-6 text-primary" />,
      description: "Help parents understand the evolving landscape of career and skill requirements",
      resources: [
        { title: "21st Century Skills Guide", type: "PDF" },
        { title: "Technology & Career Trends for Parents", type: "Presentation" },
        { title: "Understanding High-Income Skills", type: "Guide" },
      ]
    },
    {
      id: "parent-guides",
      title: "Parent Support Materials",
      icon: <BookOpen className="h-5 w-5 lg:h-6 lg:w-6 text-primary" />,
      description: "Practical resources to help parents support their children's future readiness",
      resources: [
        { title: "Supporting Your Child's Career Exploration", type: "Guide" },
        { title: "Family Financial Literacy Activities", type: "Worksheet" },
        { title: "Digital Skills at Home", type: "Checklist" },
      ]
    },
    {
      id: "success-stories",
      title: "Success Stories & Case Studies",
      icon: <FileText className="h-5 w-5 lg:h-6 lg:w-6 text-primary" />,
      description: "Real examples of student success through future-ready programs",
      resources: [
        { title: "From School Project to Tech Startup", type: "Case Study" },
        { title: "How Early Career Guidance Changed My Path", type: "Student Story" },
        { title: "Parent Perspectives: Skills That Made a Difference", type: "Testimonials" },
      ]
    },
    {
      id: "community-resources",
      title: "Parent Community Content",
      icon: <Users className="h-5 w-5 lg:h-6 lg:w-6 text-primary" />,
      description: "Ready-to-share content for school WhatsApp/Telegram parent communities",
      resources: [
        { title: "Monthly Parent Newsletter Templates", type: "Templates" },
        { title: "Shareable Parenting Tips", type: "Content Pack" },
        { title: "Future Skills Quick Guides", type: "Infographics" },
      ]
    }
  ];

  return (
    <div className="p-3 lg:p-4">
      <h2 className="text-xl lg:text-2xl font-bold mb-4 lg:mb-6">Parent Resources Hub</h2>
      <p className="text-gray-600 mb-6 lg:mb-8 text-sm lg:text-base">
        Valuable materials to share with parents to help them understand and support their children's 
        future readiness development. These resources are designed to be shared through your parent communities
        and during parent-teacher interactions.
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 lg:gap-6">
        {resourceCategories.map((category) => (
          <div key={category.id} className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="bg-primary/5 p-4">
              <div className="flex items-center">
                {category.icon}
                <h3 className="text-lg lg:text-xl font-semibold ml-3">{category.title}</h3>
              </div>
              <p className="text-gray-600 mt-2 text-sm">{category.description}</p>
            </div>
            <div className="p-4">
              <ul className="space-y-2 lg:space-y-3">
                {category.resources.map((resource, index) => (
                  <li key={index} className="flex items-center justify-between text-sm lg:text-base">
                    <span>{resource.title}</span>
                    <span className="text-xs font-medium bg-gray-100 px-2 py-1 rounded">
                      {resource.type}
                    </span>
                  </li>
                ))}
              </ul>
              <div className="mt-4 flex justify-end">
                <button className="text-primary font-medium text-sm lg:text-base">
                  Coming Soon
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-6 lg:mt-8 bg-accent/10 border-l-4 border-accent p-3 lg:p-4 rounded">
        <h4 className="font-semibold text-primary text-sm lg:text-base">Want to request specific parent resources?</h4>
        <p className="text-gray-600 mt-1 text-xs lg:text-sm">
          We're continuously expanding our library of parent resources. Let us know what would be most helpful 
          for your school community, and we'll prioritize those materials.
        </p>
      </div>
    </div>
  );
};

export default ParentResources;
