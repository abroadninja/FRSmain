
import React from "react";

/**
 * Playbook 4, Module 2: Implement Multiple Subscription Programs and Value-Added Services
 */
const Playbook4Module2 = () => (
  <div className="space-y-6">
    <div className="border-b border-accent/20 pb-3">
      <h2 className="text-2xl font-bold text-primary mb-1">Implement Multiple Subscription Programs and Value-Added Services</h2>
    </div>
    
    <div className="prose max-w-none">
      <div className="bg-brand-50/50 p-5 rounded-lg border border-brand-100 shadow-sm">
        <h3 className="text-xl font-semibold text-secondary mb-2">Core Principle</h3>
        <p className="text-gray-800">
          Recurring revenue streams beyond tuition provide financial stability and growth. Stop relying solely on admissions—diversify revenue. Subscription programs are a recurring revenue lifeline.
        </p>
      </div>
      
      <div className="mt-8 space-y-6">
        <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
          <h4 className="font-semibold text-brand-700 mb-4 flex items-center border-b pb-2">
            <span className="inline-flex items-center justify-center h-7 w-7 mr-3 rounded-full bg-brand-100 text-brand-700 text-sm">1</span>
            Identify Potential Value-Added Services
          </h4>
          <div className="space-y-3 pl-4 border-l-2 border-accent/20">
            <p className="text-gray-700">Leverage existing teachers, classrooms, infrastructure. Can offer services to non-enrolled students too.</p>
            <p className="text-gray-700">Focus on skills parents want: future skills, coding, AI, public speaking, financial literacy, exam prep.</p>
            <p className="text-gray-700">Benefits: Extra revenue, stronger student outcomes, increased parent satisfaction.</p>
            <p className="font-medium text-primary">Immediate Action: Brainstorm 5 value-added services to launch in 30 days.</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
          <h4 className="font-semibold text-brand-700 mb-4 flex items-center border-b pb-2">
            <span className="inline-flex items-center justify-center h-7 w-7 mr-3 rounded-full bg-brand-100 text-brand-700 text-sm">2</span>
            Create Ongoing Subscription Programs
          </h4>
          <div className="space-y-3 pl-4 border-l-2 border-accent/20">
            <p className="text-gray-700">Design programs that offer ongoing value (monthly, quarterly, annually). Subscriptions = predictable income.</p>
            <p className="text-gray-700">Examples: Monthly coding clubs, academic support, "future-ready" upgrade packages with workshops/resources.</p>
            <p className="text-gray-700">Tiered offerings: Basic, Premium, VIP—catering to different budgets/needs.</p>
            <p className="font-medium text-primary">Immediate Action: Design 2–3 subscription structures and tiers.</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
          <h4 className="font-semibold text-brand-700 mb-4 flex items-center border-b pb-2">
            <span className="inline-flex items-center justify-center h-7 w-7 mr-3 rounded-full bg-brand-100 text-brand-700 text-sm">3</span>
            Develop Pricing Strategies
          </h4>
          <div className="space-y-3 pl-4 border-l-2 border-accent/20">
            <p className="text-gray-700">Price based on value, not cost. Cheap can signal "cheap value".</p>
            <p className="text-gray-700">Research competitors but focus on demonstrating superior value, not undercutting.</p>
            <p className="text-gray-700">Consider: value-based, tiered (good/better/best), bundling, early bird offers (for urgency).</p>
            <p className="text-gray-700">Reference: Pricing Power Chart Flowchart.</p>
            <p className="font-medium text-primary">Immediate Action: Research competitor pricing, set your initial pricing strategy emphasizing value and profitability.</p>
          </div>
        </div>
      </div>
      
      <div className="mt-8 bg-accent/5 p-5 rounded-lg border border-accent/20 shadow-sm">
        <h4 className="font-semibold text-brand-700 mb-4 border-b pb-2 border-accent/10">"Done-For-You" Resources</h4>
        <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
          <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
          <span>Pricing Power Chart Flowchart.pdf</span>
        </div>
      </div>
      
      <div className="mt-6 p-5 rounded-lg border-l-4 border-accent bg-brand-50 shadow-sm flex items-center gap-3">
        <div className="bg-accent text-white rounded-full p-1.5 flex-shrink-0">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
        </div>
        <div>
          <b className="text-primary">Action Point:</b> Brainstorm five value-added services, design 2–3 subscription programs, and create value-based pricing strategies.
        </div>
      </div>
    </div>
  </div>
);

export default Playbook4Module2;
