
import React from "react";
import { Link } from "react-router-dom";
import { BookOpen, Search, Rocket, Brain, Activity, Users, FileText, Lightbulb } from "lucide-react";

/**
 * High Income Skills Portfolio Building Guidance - Module 1: Knowing Yourself & Your Potential
 */
const HighIncomeSkillsModule1 = () => (
  <div className="space-y-8">
    <div className="border-b-2 border-accent/30 pb-4">
      <h2 className="text-2xl font-bold text-primary mb-2">Module 1: Knowing Yourself & Your Potential</h2>
      <p className="text-gray-600 italic">Helping students understand their own strengths, interests, and the power of believing in their ability to learn and grow.</p>
    </div>
    
    <div className="prose max-w-none">
      {/* Focus Area Card */}
      <div className="bg-brand-50/50 p-6 rounded-lg border border-brand-200 shadow-sm">
        <h3 className="text-xl font-semibold text-secondary mb-3 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-secondary/10 rounded-full text-secondary">
            <Lightbulb className="h-5 w-5" />
          </span>
          Focus Area
        </h3>
        <p className="text-gray-800 text-lg">
          Helping students understand their own strengths, interests, and the power of believing in their ability to learn and grow.
        </p>
      </div>
      
      {/* Teacher Session Guide */}
      <div className="mt-10">
        <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
            <BookOpen className="h-5 w-5" />
          </span>
          For Teachers: Session Guide (Approx. 45-60 minutes, adaptable)
        </h3>
        
        <div className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
          {/* Preparation */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Preparation (Before Class)</h4>
            </div>
            <div className="p-6">
              <ul className="space-y-3 pl-5 list-disc text-gray-700">
                <li>Read through this guide.</li>
                <li>Prepare simple questions to ask (see below).</li>
                <li>If possible, prepare a simple drawing or chart on the board showing "Things I Like" vs. "Things I'm Good At".</li>
                <li>Have a plan to divide students into small groups (4-6 students).</li>
              </ul>
            </div>
          </div>
          
          {/* Introduction */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Introduction (10-15 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Start a discussion about what makes each person unique.</p>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md">
                  <p><strong className="text-blue-800">Say something like:</strong> "Today, we start thinking about our future! A big part of building a successful future is knowing ourselves better. What things do you enjoy doing? What things are you naturally good at, even if it's just playing a game, helping at home, drawing, or talking to people?"</p>
                </div>
                <div className="bg-green-50 border-l-4 border-green-300 p-4 rounded-r-md mt-4">
                  <p><strong className="text-green-800">Activity:</strong> Ask students to think silently for 1 minute about ONE thing they enjoy doing and ONE thing they think they are good at.</p>
                </div>
                <div className="bg-purple-50 border-l-4 border-purple-300 p-4 rounded-r-md mt-4">
                  <p><strong className="text-purple-800">Board Work:</strong> Draw two overlapping circles on the board. Label one "Things I Enjoy" and the other "Things I Am Good At". Ask a few volunteers to share their thoughts and write keywords in the circles (e.g., Enjoy: Cricket, Talking, Music; Good At: Maths, Running, Remembering things). Point out the overlapping section – things they BOTH enjoy AND are good at. Explain this is often a great place to start exploring!</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Group Activity */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Group Activity: Strength Spotting (20-30 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Help students identify positive qualities in themselves and others.</p>
                <p><strong className="text-primary">Instructions:</strong> Divide students into small groups.</p>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md">
                  <p><strong className="text-blue-800">Say:</strong> "In your groups, take turns sharing one thing you enjoy or are good at. The rest of the group should listen carefully and then tell that person one positive quality they see in them based on what they shared. For example, if someone says they enjoy helping their family at home, a positive quality might be 'Responsibility' or 'Caring'. If someone says they are good at drawing, a quality might be 'Creativity' or 'Patience'."</p>
                </div>
                <p><strong className="text-primary">Teacher Role:</strong> Walk around, listen, encourage participation, and help groups if they get stuck finding words for qualities (Suggest words like: Hardworking, Curious, Creative, Problem-solver, Good Listener, Friendly, Organized, Brave, Patient, Leader, Helper, Funny, etc.).</p>
              </div>
            </div>
          </div>
          
          {/* Growth Mindset */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Introduction to Growth Mindset (5-10 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Introduce the idea that abilities can be developed.</p>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md">
                  <p><strong className="text-blue-800">Say:</strong> "It's great to know what you are good at now. But the most important thing is believing you can learn and get better at almost anything! It's like learning to ride a bicycle – you weren't born knowing how, you learned through practice and maybe falling down a few times. This idea is called a 'Growth Mindset' – believing your brain can grow stronger with effort."</p>
                </div>
                <div className="bg-purple-50 border-l-4 border-purple-300 p-4 rounded-r-md mt-4">
                  <p><strong className="text-purple-800">Board Work:</strong> Write "Growth Mindset = I can learn and get better with practice."</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Home Task */}
          <div>
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Assign Home Task (5 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Encourage self-reflection and use simple tools.</p>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md">
                  <p><strong className="text-blue-800">Say:</strong> "For next time, I want you to think more about your interests and strengths. Also, start exploring what 'Growth Mindset' means. You can use your phones at home."</p>
                </div>
                <p><strong className="text-primary">Explain the task clearly</strong> (also send via WhatsApp):</p>
                <div className="bg-green-50 border border-green-200 rounded-md p-4">
                  <p>"Task 1: Write down (in a notebook or phone notes) 3 things you enjoy doing and 3 things you think you are good at (can be school subjects, hobbies, helping others, anything!)."</p>
                  <p className="mt-2">"Task 2: Use Google or an AI tool like Gemini to search for information about 'Growth Mindset'. Try to understand what it means in your own words."</p>
                  <p className="mt-2">"Optional Task 3 (for curious students): Search for 'simple personality test for students free' or ask an AI like Gemini 'What are some common personality types?' and see if anything sounds interesting or like you."</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* WhatsApp Message Section */}
      <div className="mt-10">
        <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
            <FileText className="h-5 w-5" />
          </span>
          For Students: WhatsApp Message (Send after the session)
        </h3>
        <div className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
          <div className="bg-green-50 p-6 rounded-lg">
            <h4 className="font-semibold text-gray-800 text-lg mb-4 pb-2 border-b border-green-200">Subject: High Income Skills: Knowing Yourself - Home Task! 🔍</h4>
            <div className="space-y-4 text-gray-700">
              <p>"Hi everyone, Great session today talking about our strengths! 😊 Remember, knowing yourself is the first step to a bright future.</p>
              
              <div className="bg-white rounded-md p-5 border border-gray-200">
                <p className="font-medium text-gray-800 border-b pb-2 mb-3">Your Tasks:</p>
                <ul className="space-y-3 pl-5 list-disc">
                  <li><strong className="text-primary">List:</strong> Write down 3 things you ENJOY doing & 3 things you are GOOD at. 📝</li>
                  <li><strong className="text-primary">Explore:</strong> Use Google/Gemini to search and understand 'Growth Mindset'. What does it mean to you? 🤔 (Keywords below!)</li>
                  <li><strong className="text-primary">(Optional)</strong> Explore 'free personality test for students' or ask Gemini 'tell me about different personality types'. Just for fun and curiosity! 🧐</li>
                </ul>
              </div>
              
              <div className="bg-white rounded-md p-5 border border-gray-200">
                <p className="font-medium text-gray-800 border-b pb-2 mb-3">Search Keywords/Prompts for Your Tasks:</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="bg-blue-50 p-3 rounded-md">
                    <ul className="space-y-1 pl-5 list-disc">
                      <li>what is growth mindset simple explanation</li>
                      <li>growth mindset examples for students</li>
                      <li>growth mindset meaning in [Your Regional Language]</li>
                      <li>free personality test for students</li>
                    </ul>
                  </div>
                  <div className="bg-purple-50 p-3 rounded-md">
                    <ul className="space-y-1 pl-5 list-disc">
                      <li>(Ask AI): Explain growth mindset in simple terms</li>
                      <li>(Ask AI): Can you tell me about different ways people describe personalities?</li>
                      <li>(Ask AI): Give me some examples of personal strengths</li>
                    </ul>
                  </div>
                </div>
              </div>
              
              <p>Discuss in your study groups! Help each other understand. See you next time!"</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Parent Note Section */}
      <div className="mt-10">
        <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
            <Users className="h-5 w-5" />
          </span>
          For Parents: Note to Share with Parents (via WhatsApp or simple printout)
        </h3>
        <div className="p-6 border-l-4 border-brand-400 bg-brand-50 rounded-lg shadow-sm">
          <div className="space-y-4">
            <h4 className="font-semibold text-primary text-lg">Subject: Helping Your Child Discover Their Potential</h4>
            <p className="text-gray-700">
              "Dear Parents, Our school has started a 'High Income Skills Portfolio Building' program to help students prepare for their future. This week/month, we focused on helping students understand their strengths and interests, and the importance of believing they can learn new things ('Growth Mindset').
            </p>
            <div>
              <p className="font-medium text-gray-800 mb-2">How you can help at home:</p>
              <ul className="ml-6 list-disc space-y-2 text-gray-700">
                <li><strong className="text-secondary">Talk:</strong> Ask your child about what they enjoy doing and what they feel they are good at. Listen to their ideas with interest.</li>
                <li><strong className="text-secondary">Encourage:</strong> Praise their effort when they try to learn something new, even if it's difficult. Say things like "I see you are working hard on that!" instead of just focusing on results.</li>
                <li><strong className="text-secondary">Curiosity:</strong> Encourage them to ask questions and explore topics they find interesting, perhaps using a phone for searching information if available. Your support makes a big difference! Thank you."</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>

    {/* Program Overview Section */}
    <div className="mt-8">
      <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
        <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
          <Rocket className="h-5 w-5" />
        </span>
        Program Overview
      </h3>
      <div className="bg-brand-50/50 p-6 rounded-lg border border-brand-100 shadow-sm">
        <p className="text-gray-800 mb-4">
          The High Income Skills Portfolio Building program aims to help students develop valuable skills 
          for future careers, using simple methods like group discussions, self-learning with smartphones, and teamwork.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pl-4 mt-4">
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow border-l-4 border-accent/40">
            <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-accent/10 text-accent font-bold text-sm mb-2">1</span>
            <p className="font-medium">Discovering Ourselves & New Opportunities</p>
            <p className="text-gray-600 text-sm mt-1">Identify strengths, interests & growth mindset</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow border-l-4 border-accent/40">
            <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-accent/10 text-accent font-bold text-sm mb-2">2</span>
            <p className="font-medium">Exploring Different Ways to Earn a Good Future</p>
            <p className="text-gray-600 text-sm mt-1">Discover various career paths and opportunities</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow border-l-4 border-accent/40">
            <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-accent/10 text-accent font-bold text-sm mb-2">3</span>
            <p className="font-medium">Learning How to Learn Effectively</p>
            <p className="text-gray-600 text-sm mt-1">Master search, AI tools, and study techniques</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow border-l-4 border-accent/40">
            <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-accent/10 text-accent font-bold text-sm mb-2">4</span>
            <p className="font-medium">Building Your Skill Set (Ongoing & Practical)</p>
            <p className="text-gray-600 text-sm mt-1">Develop practical skills through projects</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow border-l-4 border-accent/40">
            <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-accent/10 text-accent font-bold text-sm mb-2">5</span>
            <p className="font-medium">Working Together & Sharing Ideas</p>
            <p className="text-gray-600 text-sm mt-1">Collaboration and communication skills</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow border-l-4 border-accent/40">
            <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-accent/10 text-accent font-bold text-sm mb-2">6</span>
            <p className="font-medium">Showing What You Can Do & Finding Opportunities</p>
            <p className="text-gray-600 text-sm mt-1">Portfolio building and opportunity finding</p>
          </div>
        </div>
      </div>
    </div>

    {/* Resources Section */}
    <div className="mt-8 bg-blue-50 p-6 rounded-lg border border-blue-100 shadow-sm">
      <div className="flex items-center gap-3 text-blue-800 mb-4">
        <Search className="h-5 w-5" />
        <h4 className="font-bold text-lg">Supporting Resources</h4>
      </div>
      <p className="mb-4 text-gray-700">
        These interactive tools can help students explore different career paths based on their interests and strengths:
      </p>
      <div className="flex flex-wrap gap-3">
        <Link 
          to="/implementation-guides/high-income-skills/keywords" 
          className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          <Search className="h-4 w-4" /> Keyword & Prompt Library
        </Link>
        <Link 
          to="/career-explorer/clusters" 
          className="inline-flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
        >
          <Rocket className="h-4 w-4" /> Career Cluster Explorer
        </Link>
        <Link 
          to="/career-explorer/problem-solving" 
          className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors"
        >
          <Brain className="h-4 w-4" /> Problem-Based Career Matching
        </Link>
        <Link 
          to="/career-explorer/assessment" 
          className="inline-flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700 transition-colors"
        >
          <Activity className="h-4 w-4" /> Psychometric Career Assessment
        </Link>
      </div>
    </div>
  </div>
);

export default HighIncomeSkillsModule1;
