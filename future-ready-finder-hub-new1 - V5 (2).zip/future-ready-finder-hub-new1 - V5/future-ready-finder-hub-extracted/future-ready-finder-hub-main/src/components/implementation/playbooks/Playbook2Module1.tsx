
import React from "react";

/**
 * Playbook 2, Module 1: Building High-Value, Trust-Building Touchpoints
 */
const Playbook2Module1 = () => (
  <div className="space-y-6">
    <div className="border-b border-accent/20 pb-3">
      <h2 className="text-2xl font-bold text-primary mb-1">Building High-Value, Trust-Building Touchpoints (Simplified Approach)</h2>
    </div>
    
    <div className="prose max-w-none">
      <div className="bg-brand-50/50 p-4 rounded-lg border border-brand-100">
        <h3 className="text-xl font-semibold text-secondary mb-2">Core Principle</h3>
        <p className="text-gray-800">
          Consistent, valuable interaction builds trust and strengthens the school-parent bond. Focus on leveraging your existing 
          regular touchpoints and consistently delivering high-value content, rather than complex analyses. This leads to higher 
          retention, positive word-of-mouth, and conversions. Move beyond one-way marketing to relationship building. Trust is 
          the transaction trigger; parents enroll where they trust.
        </p>
        <p className="text-gray-800 mt-3">
          Touchpoints must now actively communicate and reinforce the school's unique positioning (Future-Ready, High-Income Skills, 
          Unbeatable Value) established in Playbook 1.
        </p>
        <p className="text-gray-800 mt-3">
          A key long-term goal of building these strong relationships is to nurture passionate parents who will naturally become 
          school ambassadors and, ultimately, valuable admission ambassadors. This is further detailed in Playbook 3, Module 2, 
          which focuses on leveraging referrals and ambassadors.
        </p>
      </div>

      <div className="mt-6">
        <h3 className="text-lg font-bold text-primary mb-3">Actionable Steps</h3>
        
        <div className="space-y-6">
          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h4 className="font-semibold text-secondary border-b pb-2 flex items-center">
              <span className="inline-flex items-center justify-center h-6 w-6 mr-2 rounded-full bg-secondary/10 text-secondary font-bold text-sm">1</span>
              Focus on Existing Regular Touchpoints
            </h4>
            <div className="mt-3">
              <p className="text-gray-700 mb-2">
                Instead of a full "touchpoint map," prioritize your school's existing regular touchpoints. These typically include:
              </p>
              <div className="bg-brand-50/30 rounded-lg p-4 mt-2">
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  <li className="flex items-center gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-accent"></div>
                    <span>Parent visits to the school</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-accent"></div>
                    <span>Scheduled Parent-Teacher Meetings (PTMs)</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-accent"></div>
                    <span>School events (annual day, sports day, etc.)</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-accent"></div>
                    <span>Phone calls or emails for inquiries</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-accent"></div>
                    <span>Report card distribution</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-accent"></div>
                    <span>School newsletters</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-accent"></div>
                    <span>Alumni interactions</span>
                  </li>
                </ul>
              </div>
              <p className="text-gray-700 mt-3">
                Concentrate on making these existing touchpoints more valuable and trust-building.
              </p>
            </div>
          </div>

          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h4 className="font-semibold text-secondary border-b pb-2 flex items-center">
              <span className="inline-flex items-center justify-center h-6 w-6 mr-2 rounded-full bg-secondary/10 text-secondary font-bold text-sm">2</span>
              Prioritize High-Value Content on WhatsApp/Telegram Parent Communities
            </h4>
            <div className="mt-3">
              <h5 className="font-medium text-primary mb-2">Using WhatsApp/Telegram to Build Engaged Parent Communities</h5>
              <div className="space-y-3 pl-2">
                <div className="flex items-start gap-3">
                  <div className="h-5 w-5 rounded-full bg-accent/10 text-accent flex items-center justify-center mt-0.5 flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                  </div>
                  <div>
                    <span className="font-medium text-gray-800">Core Strategy:</span>
                    <p className="text-gray-700">One of your biggest advantages is consistently posting high-value content in dedicated WhatsApp or Telegram parent communities. (These communities are discussed in detail in Playbook 2, Module 2).</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="h-5 w-5 rounded-full bg-accent/10 text-accent flex items-center justify-center mt-0.5 flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                  </div>
                  <div>
                    <span className="font-medium text-gray-800">Announce the Upcoming Community:</span>
                    <p className="text-gray-700">If you haven't yet established these communities, begin announcing their upcoming launch to your existing parent base. Highlight the value parents will receive by joining, such as exclusive content, Q&A sessions, and a supportive network.</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="h-5 w-5 rounded-full bg-accent/10 text-accent flex items-center justify-center mt-0.5 flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                  </div>
                  <div>
                    <span className="font-medium text-gray-800">Adding Existing Parents to a Community:</span>
                    <p className="text-gray-700">Begin adding existing parents to the community (as detailed in Playbook 2, Module 2) as you announce its launch. This is the first step in creating a dedicated space for engagement and information sharing.</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="h-5 w-5 rounded-full bg-accent/10 text-accent flex items-center justify-center mt-0.5 flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                  </div>
                  <div>
                    <span className="font-medium text-gray-800">Building Thriving Parenting Communities:</span>
                    <p className="text-gray-700">Focus on building thriving parenting communities that provide high-value touchpoints. This means going beyond simple announcements and delivering content that truly benefits parents.</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="h-5 w-5 rounded-full bg-accent/10 text-accent flex items-center justify-center mt-0.5 flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                  </div>
                  <div>
                    <span className="font-medium text-gray-800">Leverage Ready-to-Use Content:</span>
                    <p className="text-gray-700">You already have access to a wealth of content resources that can be readily shared. Use the "Content Theme & Topic Idea Bank for Parents" (DFY Tool 2.2), "Initial value drop content starters.pdf," and "Content Sourcing & Curation Guide" (DFY Tool 2.3) to quickly find and prepare posts.</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="h-5 w-5 rounded-full bg-accent/10 text-accent flex items-center justify-center mt-0.5 flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                  </div>
                  <div>
                    <span className="font-medium text-gray-800">Content Examples:</span>
                    <p className="text-gray-700">General parenting tips related to future-readiness, insights into education trends, links to valuable articles/resources, Q&A sessions on future skills, invitations to free workshops or school tours, showcasing school differentiators through success stories or program snippets (value-first approach).</p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="h-5 w-5 rounded-full bg-accent/10 text-accent flex items-center justify-center mt-0.5 flex-shrink-0">
                    <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                  </div>
                  <div>
                    <span className="font-medium text-gray-800">Consistency is Key:</span>
                    <p className="text-gray-700">Regular, consistent sharing of valuable content within these communities will build trust, engagement, and a strong sense of community.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h4 className="font-semibold text-secondary border-b pb-2 flex items-center">
              <span className="inline-flex items-center justify-center h-6 w-6 mr-2 rounded-full bg-secondary/10 text-secondary font-bold text-sm">3</span>
              Enhance Existing Touchpoints (With Minimal Effort)
            </h4>
            <div className="mt-3 space-y-3 pl-2">
              <div className="flex items-start gap-3">
                <div className="h-5 w-5 rounded-full bg-accent/10 text-accent flex items-center justify-center mt-0.5 flex-shrink-0">
                  <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                </div>
                <div>
                  <span className="font-medium text-gray-800">Parent Visits:</span>
                  <p className="text-gray-700">Ensure a warm welcome, provide clear information, and highlight your school's unique value (future-readiness, high-income skills guidance).</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="h-5 w-5 rounded-full bg-accent/10 text-accent flex items-center justify-center mt-0.5 flex-shrink-0">
                  <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                </div>
                <div>
                  <span className="font-medium text-gray-800">Parent-Teacher Meetings (PTMs):</span>
                  <p className="text-gray-700">Make PTMs interactive, share specific insights about student progress, and provide resources for parents to support learning at home. Use PTMs to reinforce the school's positioning.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="h-5 w-5 rounded-full bg-accent/10 text-accent flex items-center justify-center mt-0.5 flex-shrink-0">
                  <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                </div>
                <div>
                  <span className="font-medium text-gray-800">Ready-to-Use Resources for Parents:</span>
                  <p className="text-gray-700">Use the "Curated Library Resources List" (DFY) to provide parents with valuable external resources related to future skills, parenting, and education trends. Share these resources during PTMs, parent visits, or via WhatsApp/Telegram.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mt-6 p-4 rounded-lg border-l-4 border-accent bg-brand-50 flex items-center gap-3">
        <div className="bg-accent text-white rounded-full p-1 flex-shrink-0">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
        </div>
        <div>
          <b className="text-primary">Immediate Action:</b> Brainstorm 1-2 ways to enhance parent visits or PTMs with additional value.
          Start using the "Curated Library Resources List" to share valuable information with parents.
        </div>
      </div>
    </div>
  </div>
);

export default Playbook2Module1;
