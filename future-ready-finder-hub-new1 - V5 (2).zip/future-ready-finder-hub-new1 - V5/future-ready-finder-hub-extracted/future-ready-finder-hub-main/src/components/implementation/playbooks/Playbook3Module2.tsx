
import React from "react";
import { CheckCircle } from "lucide-react";

/**
 * Playbook 3, Module 2: Leveraging Referrals and Ambassadors
 */
const Playbook3Module2 = () => (
  <div className="space-y-6">
    <div className="border-b border-accent/20 pb-3">
      <h2 className="text-2xl font-bold text-primary mb-1">Leveraging Referrals and Ambassadors</h2>
    </div>
    
    <div className="bg-brand-50/50 p-5 rounded-lg border border-brand-100 shadow-sm">
      <h3 className="text-xl font-semibold text-secondary mb-2">Core Principle</h3>
      <p className="text-gray-800">
        Happy parents and a strong network are your most effective, low-cost sales force. Turn raving fans into your secret growth engine.
      </p>
    </div>

    <div className="mt-8">
      <h3 className="text-lg font-bold text-primary mb-4">Actionable Steps</h3>
      
      <div className="space-y-6">
        <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
          <h4 className="font-semibold text-secondary mb-3 border-b pb-2">1. Initialize an "Extraordinary Affiliate Program"</h4>
          <div className="space-y-4 pl-4 border-l-2 border-accent/20">
            <div>
              <p className="font-medium text-gray-800">Incentivize Referrals:</p>
              <p className="text-gray-700">Turn parents, alumni, local businesses, staff into your sales force by rewarding successful enrollments. Rewards can be fee discounts (5-7%), cash back, cash rewards, or gifts/recognition.</p>
            </div>
            
            <div>
              <p className="font-medium text-gray-800">Define Ambassador/Partner Roles:</p>
              <div className="pl-4 mt-2 space-y-3">
                <div>
                  <p className="font-medium text-gray-700">Ambassadors:</p>
                  <p className="text-gray-600">Current parents/students/alumni who love the school. Equip them with referral links, talking points (highlighting future-readiness), reward info. Use optional Admission Ambassador Recruitment EmailWhatsApp.pdf to recruit.</p>
                </div>
                
                <div>
                  <p className="font-medium text-gray-700">Partners:</p>
                  <p className="text-gray-600">Local businesses, community centers, organizations. Explore joint promotions, cross-referrals, partnerships.</p>
                </div>
              </div>
            </div>
            
            <div>
              <p className="font-medium text-gray-800">Design the Program:</p>
              <p className="text-gray-700">Keep it simple initially. Clearly outline rewards and process. Use the conceptual Affiliate Amplifier Chart for inspiration and the Parent Referral Program "Lite" Guide. Announce using Referral Incentive Program Announcement Templates.pdf.</p>
            </div>
            
            <div>
              <p className="font-medium text-primary">Immediate Action:</p>
              <p className="text-gray-700">Design a simple parent affiliate program structure. Reach out to 3 potential local affiliate partners.</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
          <h4 className="font-semibold text-secondary mb-3 border-b pb-2">2. Turn Students & Parents into Raving Fans and Brand Ambassadors</h4>
          <div className="space-y-4 pl-4 border-l-2 border-accent/20">
            <div>
              <p className="font-medium text-gray-800">Exceed Expectations:</p>
              <p className="text-gray-700">Go the extra mile in every interaction. Small surprises, personalized attention, proactive support create fans. This is your growth strategy.</p>
            </div>
            
            <div>
              <p className="font-medium text-gray-800">Gather Social Proof:</p>
              <p className="text-gray-700">Actively collect testimonials and positive reviews (Google, website, social media). Parents trust other parents. Make leaving reviews easy (provide direct links). Ask after positive experiences. Use optional Parent Testimonial trigger flowchart.pdf and conceptual Parent Testimonial Collection System. Track using optional "Rave Review" Amplification Tracker Spreadsheet.</p>
            </div>
            
            <div>
              <p className="font-medium text-gray-800">Empower Sharing:</p>
              <p className="text-gray-700">Create opportunities for fans to share positive experiences. Provide easy-to-share content (links, graphics, key messages) highlighting differentiators (especially future-readiness). Use optional Word of mouth velocity multiplier.pdf.</p>
            </div>
            
            <div>
              <p className="font-medium text-primary">Immediate Action:</p>
              <p className="text-gray-700">Identify 3 ways to immediately exceed expectations. Create a simple system to collect 5+ testimonials this month. Provide ambassadors with shareable content.</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
          <h4 className="font-semibold text-secondary mb-3 border-b pb-2">3. Track Referral Program Effectiveness</h4>
          <div className="space-y-4 pl-4 border-l-2 border-accent/20">
            <div>
              <p className="font-medium text-gray-800">Monitor Performance:</p>
              <p className="text-gray-700">Don't just launch and forget. Track referral sources and program effectiveness using Referral Tracking System.pdf.</p>
            </div>
            
            <div>
              <p className="font-medium text-gray-800">Optimize:</p>
              <p className="text-gray-700">Analyze data. Which incentives/ambassadors/partners work best? Refine based on results. Use conceptual Referral Program Optimization Dashboard Layout and optional Parent referral rocket.pdf flowchart for ideas.</p>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div className="bg-accent/5 p-5 rounded-lg border border-accent/20 shadow-sm">
      <h3 className="text-lg font-bold text-primary mb-4 border-b pb-2 border-accent/10">"Done-For-You" Resources</h3>
      
      <div className="space-y-6">
        <div>
          <h4 className="font-semibold text-secondary mb-3">Referral/Affiliate Program</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
              <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
              <span>Parent Referral Program "Lite" Guide (Simple Strategies) - <span className="text-blue-600">Parent refferal programme lite guide.pdf</span></span>
            </div>
            <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
              <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
              <span>Referral Incentive Program Announcement Templates.pdf</span>
            </div>
            <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
              <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
              <span>Referral Tracking System.pdf</span>
            </div>
            <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
              <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
              <span>Affiliate amplifier chart.pdf (Optional Flowchart)</span>
            </div>
            <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
              <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
              <span>Parent referral rocket.pdf (Optional Flowchart)</span>
            </div>
            <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
              <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
              <span>Referral Program Optimization Dashboard Layout (Conceptual)</span>
            </div>
            <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
              <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
              <span>Parent Referral Program.pdf (Optional PDF)</span>
            </div>
          </div>
        </div>

        <div>
          <h4 className="font-semibold text-secondary mb-3">Ambassador Recruitment/Management</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
              <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
              <span>Admission Ambassador Recruitment EmailWhatsApp.pdf (Optional PDF)</span>
            </div>
            <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
              <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
              <span>community champion mobilization.pdf (Optional PDF)</span>
            </div>
          </div>
        </div>

        <div>
          <h4 className="font-semibold text-secondary mb-3">Testimonials & Social Proof</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
              <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
              <span>Parent Testimonial trigger flowchart.pdf (Optional PDF)</span>
            </div>
            <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
              <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
              <span>Parent Testimonial Collection System (Conceptual)</span>
            </div>
            <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
              <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
              <span>"Rave Review" Amplification Tracker Spreadsheet (Optional Spreadsheet)</span>
            </div>
          </div>
        </div>

        <div>
          <h4 className="font-semibold text-secondary mb-3">Related Communication</h4>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Word of mouth velocity multiplier.pdf (Optional PDF)</span>
          </div>
        </div>
      </div>
    </div>

    <div className="p-5 rounded-lg border-l-4 border-accent bg-brand-50 shadow-sm flex items-center gap-3">
      <CheckCircle className="text-accent flex-shrink-0" />
      <div>
        <h4 className="font-bold text-lg text-primary">Action Point</h4>
        <p className="text-gray-700">
          Design and announce a simple parent referral program using the "Lite" guide and templates. Reach out to 3 local partners. 
          Implement a testimonial collection system. Provide shareable content to ambassadors highlighting differentiators. 
          Start tracking referrals using Referral Tracking System.pdf.
        </p>
      </div>
    </div>
  </div>
);

export default Playbook3Module2;
