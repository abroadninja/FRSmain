
import React from "react";
import { CheckCircle } from "lucide-react";

/**
 * Playbook 5, Module 1: Integrating Future-Ready Skills (Classes 2/3 to 7)
 */
const Playbook5Module1 = () => (
  <div className="space-y-6">
    <div className="border-b border-accent/20 pb-3">
      <h2 className="text-2xl font-bold text-primary mb-1">Integrating Future-Ready Skills (Classes 2/3 to 7)</h2>
    </div>
    
    <div className="prose max-w-none">
      <div className="bg-brand-50/50 p-5 rounded-lg border border-brand-100 shadow-sm">
        <h3 className="text-xl font-semibold text-secondary mb-2">Core Principle</h3>
        <p className="text-gray-800">
          Equip younger students with foundational attitudes, skills, and knowledge essential for future learning and life, focusing on practical, understandable concepts.
        </p>
      </div>

      <div className="mt-8">
        <h3 className="text-lg font-bold text-primary flex items-center gap-2 mb-4">
          <span className="inline-flex items-center justify-center h-7 w-7 rounded-full bg-primary text-white text-sm">1</span>
          Future Readiness Pillars (Classes 2/3 to 7)
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow flex items-start gap-3">
            <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-accent/10 text-accent font-bold text-xs mt-1.5 flex-shrink-0">1</span>
            <div>
              <p className="font-semibold text-gray-800 mb-1">Critical Thinking & Problem Solving:</p>
              <p className="text-gray-600">Analyze simple information, find solutions.</p>
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow flex items-start gap-3">
            <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-accent/10 text-accent font-bold text-xs mt-1.5 flex-shrink-0">2</span>
            <div>
              <p className="font-semibold text-gray-800 mb-1">Creativity & Innovation:</p>
              <p className="text-gray-600">Foster imagination and originality.</p>
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow flex items-start gap-3">
            <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-accent/10 text-accent font-bold text-xs mt-1.5 flex-shrink-0">3</span>
            <div>
              <p className="font-semibold text-gray-800 mb-1">Communication & Collaboration:</p>
              <p className="text-gray-600">Speaking, listening, teamwork.</p>
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow flex items-start gap-3">
            <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-accent/10 text-accent font-bold text-xs mt-1.5 flex-shrink-0">4</span>
            <div>
              <p className="font-semibold text-gray-800 mb-1">Digital Literacy & Technology Awareness:</p>
              <p className="text-gray-600">Basics of tech and digital citizenship.</p>
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow flex items-start gap-3">
            <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-accent/10 text-accent font-bold text-xs mt-1.5 flex-shrink-0">5</span>
            <div>
              <p className="font-semibold text-gray-800 mb-1">Growth Mindset & Resilience:</p>
              <p className="text-gray-600">Belief in learning, bouncing back from challenges.</p>
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow flex items-start gap-3">
            <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-accent/10 text-accent font-bold text-xs mt-1.5 flex-shrink-0">6</span>
            <div>
              <p className="font-semibold text-gray-800 mb-1">Self-Awareness & Understanding Others:</p>
              <p className="text-gray-600">Emotions, respect, perspective.</p>
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow flex items-start gap-3">
            <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-accent/10 text-accent font-bold text-xs mt-1.5 flex-shrink-0">7</span>
            <div>
              <p className="font-semibold text-gray-800 mb-1">Basic Financial Literacy:</p>
              <p className="text-gray-600">Money management basics.</p>
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow flex items-start gap-3">
            <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-accent/10 text-accent font-bold text-xs mt-1.5 flex-shrink-0">8</span>
            <div>
              <p className="font-semibold text-gray-800 mb-1">Responsibility & Citizenship:</p>
              <p className="text-gray-600">Self, school, community, civic values.</p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8">
        <h3 className="text-lg font-bold text-primary flex items-center gap-2 mb-4">
          <span className="inline-flex items-center justify-center h-7 w-7 rounded-full bg-primary text-white text-sm">2</span>
          Actionable Steps
        </h3>
        
        <div className="grid gap-4 pl-5 border-l-2 border-accent/30">
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Implement Foundational Lessons:</p>
            <p className="text-gray-700">Use framework to evaluate your current curriculum for integration opportunities (critical thinking, problem-solving, etc). Start using 100 Foundational Lessons and pillar lessons. Use simple language and minimal resources; focus on activities and short lessons.</p>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Embed Skills:</p>
            <p className="text-gray-700">Weave these skills into all lesson plans, activities, and assessments. Use 100 lesson topics as your starting point for distribution across the 8 pillars.</p>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Connect to Real World:</p>
            <p className="text-gray-700">Use stories/examples that connect to students' daily lives. Integrate these lessons into regular subject teaching.</p>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Curate and Share Resources:</p>
            <p className="text-gray-700">Assign a teacher/team to find valuable low-cost/free resources. Use the Curation Strategy Framework for guidance. Share resource links with parents via WhatsApp/newsletter.</p>
          </div>
        </div>
      </div>

      <div className="mt-8 bg-accent/5 p-5 rounded-lg border border-accent/20 shadow-sm">
        <h4 className="font-semibold text-brand-700 mb-4 border-b pb-2 border-accent/10">"Done-For-You" Resources</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Future-Ready Skills Pillars (Classes 2/3 to 7) Framework/Report</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>100 Foundational Lessons (Lesson Outlines)</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>List of 100 Future Readiness Lesson Topics (from Final Index)</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Resource Curation Strategy Framework (Guide)</span>
          </div>
        </div>
      </div>
      
      <div className="mt-6 p-4 rounded-lg border-l-4 border-accent bg-brand-50 shadow-sm flex items-center gap-3">
        <div className="bg-accent text-white rounded-full p-1.5 flex-shrink-0">
          <CheckCircle className="h-4 w-4" />
        </div>
        <div>
          <b className="text-primary">Action Point:</b> Introduce these pillars and lessons to teachers; begin incorporating into plan and establish resource curation/sharing system with parents.
        </div>
      </div>
    </div>
  </div>
);

export default Playbook5Module1;
