
import React from "react";
import { Separator } from "@/components/ui/separator";

const HighIncomeSkillsModule6 = () => {
  return (
    <div className="space-y-8">
      <section>
        <h2 className="text-2xl font-bold text-primary mb-4">
          Module 6: Organizing Your Portfolio & Planning Your Ongoing Journey
        </h2>
        <p className="text-gray-600 mb-6">
          Focus: Helping students organize their Skill Portfolio Notebook, make ongoing learning plans,
          research future options generally, and understand the process for continued teacher guidance.
        </p>
      </section>

      {/* Session Guide Section */}
      <section className="space-y-6">
        <h3 className="text-xl font-semibold text-secondary">Teacher Session Guide (60-90 minutes)</h3>
        
        <div className="bg-blue-50 p-6 rounded-lg">
          <h4 className="font-semibold text-primary mb-3">Preparation</h4>
          <ul className="list-disc pl-5 space-y-2 text-gray-700">
            <li>Review the Simple Learning Plan template</li>
            <li>Prepare suggestions for organizing the Skill Portfolio Notebook</li>
            <li>Plan ongoing support strategy for notebook and learning plans</li>
          </ul>
        </div>

        {/* Activities Section */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <h4 className="font-semibold text-primary mb-3">Introduction: Your Journey & Portfolio So Far (5-10 minutes)</h4>
            <p className="text-gray-700 mb-3">
              "We've journeyed through discovering strengths, exploring careers, learning how to learn, 
              practicing skills, and communicating better. Throughout, you've hopefully started adding 
              things to your Skill Portfolio Notebook – your 'Collection of Work'. This notebook is incredibly 
              important! It shows your progress, your skills, and your plans. Today, we'll focus on 
              organizing this notebook, planning your next learning steps, and how we'll continue this 
              journey together with ongoing guidance."
            </p>
            <p className="text-gray-700">
              Revisit Growth Mindset: Link it to continuously adding to their portfolio and skills.
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <h4 className="font-semibold text-primary mb-3">Activity 1: Setting Goals for Your Portfolio (15-20 minutes)</h4>
            <p className="text-gray-700 mb-3">
              <strong>Goal:</strong> Help students decide what skills or projects they want to add next to their portfolio.
            </p>
            <ul className="list-disc pl-5 space-y-2 text-gray-700">
              <li>Guided Exercise: Ask students to look back at their notebook (if they've started) or think about Module 4 skills.</li>
              <li>Teacher: "Let's set goals for what to add to your Skill Portfolio Notebook next. Short-Term Goal (Next Month): Write down ONE specific skill you want to practice more and add proof of (like a small project description, notes from a tutorial) to your notebook this month." (Give 1-2 mins).</li>
              <li>Teacher: "Now, a Longer-Term Goal (Next Year): Think about a bigger skill or a type of project related to a career area you explored. What major addition do you hope to make to your portfolio notebook over the next year?" (Give 1-2 mins).</li>
              <li>Briefly Explain SMART (Simple Version - same as before).</li>
              <li>Say: "These goals will guide what you focus on learning and adding to your notebook. We can review these goals together later."</li>
            </ul>
          </div>

          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <h4 className="font-semibold text-primary mb-3">Activity 2: Your Personal Learning Plan (10-15 minutes)</h4>
            <p className="text-gray-700 mb-3">
              <strong>Goal:</strong> Reinforce the learning plan as a tool to achieve portfolio goals.
            </p>
            <div className="bg-gray-50 p-4 rounded-md mb-4">
              <p className="font-medium text-gray-800">Board Work Example Plan:</p>
              <ul className="list-none pl-4 space-y-1 text-gray-700">
                <li>• Skill: Content Writing</li>
                <li>• Goal: Add 2 sample blog post descriptions to notebook</li>
                <li>• Action: Find tutorial on blog structure → Write draft 1 → Get feedback → Write final description</li>
                <li>• Timeline: By end of month</li>
                <li>• Track: Written descriptions in notebook</li>
              </ul>
            </div>
            <p className="text-gray-700">
              Say: "Use this plan to break down your portfolio goals. Write these plans in your notebook! 
              It shows how you intend to build your skills. This is a living document you'll update."
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <h4 className="font-semibold text-primary mb-3">Activity 3: Organizing Your Skill Portfolio Notebook (15-20 minutes)</h4>
            <p className="text-gray-700 mb-3">
              <strong>Goal:</strong> Provide a structure for students to organize their notebook effectively.
            </p>
            <p className="text-gray-700 mb-3">
              Say: "Your notebook is your personal record. Let's think about how to organize it so it's easy to 
              understand and show others later (like for college applications or job interviews, even if informal). 
              You don't need fancy sections right away, but having some structure helps."
            </p>
            <div className="space-y-4">
              <p className="text-gray-700">Board Work/Discussion: Suggest a simple structure they can create over time in their notebook:</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-gray-50 p-4 rounded-md">
                  <h5 className="font-medium text-primary mb-2">Core Sections</h5>
                  <ul className="list-disc pl-5 space-y-1 text-gray-700">
                    <li>Section 1: <strong>About Me</strong> - Strengths, Interests, Values (from Module 1 work). Your main goals.</li>
                    <li>Section 2: <strong>Skills I'm Learning</strong> - List of skills with start dates and goals.</li>
                    <li>Section 3: <strong>My Projects & Practice</strong> - The core! Document each project/piece of work.</li>
                    <li>Section 4: <strong>My Learning Plans</strong> - Keep active learning plans here.</li>
                    <li>Section 5: <strong>Future Ideas & Research</strong> - Notes on careers, colleges, courses.</li>
                    <li>Section 6: <strong>Guidance Notes</strong> - Important advice from teachers/mentors.</li>
                  </ul>
                </div>
                <div className="bg-gray-50 p-4 rounded-md">
                  <h5 className="font-medium text-primary mb-2">Project Documentation</h5>
                  <ul className="list-disc pl-5 space-y-1 text-gray-700">
                    <li>Date</li>
                    <li>What was the task/project? (e.g., "Wrote a description for a local festival")</li>
                    <li>What steps did I take?</li>
                    <li>What did I learn? / What was challenging?</li>
                    <li>Feedback received (from teacher/peers)</li>
                    <li>Optional: Paste in sketches/photos/printouts related to projects</li>
                  </ul>
                </div>
              </div>
              <p className="text-gray-700 font-medium">
                Emphasize: "Start simple! Just begin documenting your projects clearly. You can add section 
                dividers later. The important thing is to capture your learning journey."
              </p>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <h4 className="font-semibold text-primary mb-3">Activity 4: Exploring Next Steps (10-15 minutes)</h4>
            <p className="text-gray-700 mb-3">
              <strong>Goal:</strong> Encourage research into pathways relevant to skills being built, using general examples.
            </p>
            <p className="text-gray-700 mb-3">
              Discussion/Brainstorm: "Thinking about the skills you are building in your portfolio, what options could open up after school?"
            </p>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-gray-50 p-4 rounded-md">
                  <h5 className="font-medium text-primary mb-2">Further Studies</h5>
                  <ul className="list-disc pl-5 space-y-1 text-gray-700">
                    <li>Degree Colleges (Arts, Science, Commerce)</li>
                    <li>Polytechnic Colleges (Diplomas in technical skills)</li>
                    <li>ITIs (Vocational trades)</li>
                    <li>Online Courses (Skill India, NPTEL, Coursera)</li>
                  </ul>
                </div>
                <div className="bg-gray-50 p-4 rounded-md">
                  <h5 className="font-medium text-primary mb-2">Jobs</h5>
                  <ul className="list-disc pl-5 space-y-1 text-gray-700">
                    <li>Jobs in local businesses</li>
                    <li>Government jobs (Clerical, Village level roles)</li>
                    <li>Entry-level roles in larger towns/cities</li>
                  </ul>
                </div>
                <div className="bg-gray-50 p-4 rounded-md">
                  <h5 className="font-medium text-primary mb-2">Self-Employment/Freelancing</h5>
                  <ul className="list-disc pl-5 space-y-1 text-gray-700">
                    <li>Simple design work locally</li>
                    <li>Writing content for local needs</li>
                    <li>Tutoring and other services</li>
                    <li>Online platforms (with caution)</li>
                  </ul>
                </div>
              </div>
              <p className="text-gray-700">
                Say: "Use your research skills (Module 3) to find out more about options relevant to your 
                skills and interests. Ask: What courses value the skills I'm building? What jobs use these skills? 
                Add your findings to your notebook!"
              </p>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <h4 className="font-semibold text-primary mb-3">Activity 5: Our Plan for Continuous Guidance on Your Portfolio (5-10 minutes)</h4>
            <p className="text-gray-700 mb-3">
              <strong>Goal:</strong> Explain how teachers will support the ongoing development of the Skill Portfolio Notebook.
            </p>
            <ul className="list-disc pl-5 space-y-2 text-gray-700">
              <li>"Your Skill Portfolio Notebook is key. We will use our WhatsApp group for you to share updates on projects you've added or ask questions about your learning plan."</li>
              <li>"Periodically, I will ask you to share progress from your notebook – maybe a description of a new project or an updated learning plan."</li>
              <li>"I will set aside time for you to bring your notebook and we can briefly discuss your progress, challenges, and next steps."</li>
            </ul>
            <p className="text-gray-700 mt-2">
              Say: "My role is to guide you as you build this portfolio and plan your learning. Use the support available!"
            </p>
          </div>

          <div className="bg-white p-6 rounded-lg border border-gray-200">
            <h4 className="font-semibold text-primary mb-3">Assign Home Task (Focus on Notebook & Research)</h4>
            <p className="text-gray-700 mb-3">
              <strong>Goal:</strong> Get students started organizing their notebook and doing relevant research.
            </p>
            <ul className="list-disc pl-5 space-y-2 text-gray-700">
              <li><strong>Task 1:</strong> Organize Your Notebook: Start organizing your Skill Portfolio Notebook using the sections suggested. Add any previous work/notes into the right sections.</li>
              <li><strong>Task 2:</strong> Add Your Learning Plan: Write the first draft of your learning plan (from today's goal setting) into the 'My Learning Plans' section of your notebook.</li>
              <li><strong>Task 3:</strong> Research Next Step (General): Choose ONE general option (e.g., type of college course, type of local job, a freelance skill). Use Google/AI to find information about it relevant to any student in India. Add key findings to the 'Future Ideas & Research' section of your notebook.</li>
            </ul>
          </div>
        </div>
      </section>

      <Separator />

      {/* WhatsApp Message to Students Section */}
      <section className="bg-blue-50 p-6 rounded-xl border border-blue-200">
        <h3 className="text-lg font-semibold text-primary mb-3">WhatsApp Message to Students</h3>
        <div className="prose max-w-none">
          <p className="text-gray-700 font-medium">Subject: Future Ready: Organize Your Portfolio & Keep Planning! नोटबुक 🚀</p>
          <div className="mt-4 space-y-4 text-gray-600">
            <p>"Great work today focusing on your Skill Portfolio Notebook and future plans! This notebook is your story of growth. Keep building it, with ongoing support! 🌟 Your Tasks:</p>
            
            <ul className="list-disc pl-5 mt-2">
              <li><strong>Organize Notebook:</strong> Start setting up sections in your Skill Portfolio Notebook. Add any notes/work you already have. Make it your own! 📝</li>
              <li><strong>Add Learning Plan:</strong> Write the first draft of your learning plan in the 'My Learning Plans' section of your notebook.</li>
              <li><strong>Research Next Step:</strong> Pick ONE general option (Course Type / Job Type / Freelance Skill). Research it online. Find 1-2 key facts. Add notes to your notebook. Share one interesting finding in our group!</li>
            </ul>
            
            <div className="mt-4">
              <p className="font-medium">Tips for Your Notebook:</p>
              <ul className="list-disc pl-5 mt-1">
                <li>Keep it neat. Use dates.</li>
                <li>Describe projects clearly: What did you do? What did you learn?</li>
                <li>Include feedback you receive.</li>
                <li>Update your learning plans regularly.</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Parent Communication Section */}
      <section className="bg-green-50 p-6 rounded-xl border border-green-200">
        <h3 className="text-lg font-semibold text-primary mb-3">Note for Parents</h3>
        <div className="prose max-w-none">
          <p className="text-gray-700">Subject: Supporting Your Child's Skill Portfolio & Future Planning</p>
          <div className="mt-4 space-y-2 text-gray-600">
            <p>Dear Parents,</p>
            <p>As we move to the continuous guidance phase of our 'Future Ready' program, students are focusing on building and organizing their Skill Portfolio Notebook. This notebook serves as a practical record of the skills they are learning, projects they are completing, and their plans for the future.</p>
            <p>It's a valuable tool they can use to track their progress and eventually showcase their abilities (more useful than a formal resume at this stage). We also discussed researching general options for after school (further study, jobs) relevant to the skills they are building. Teachers will provide ongoing support in developing the portfolio and plans.</p>
            <p className="font-medium mt-3">How you can help:</p>
            <ul className="list-disc pl-5 mt-2">
              <li><strong>Value the Notebook:</strong> Encourage your child to maintain their Skill Portfolio Notebook regularly.</li>
              <li><strong>Discuss Plans:</strong> Talk about the learning plans they are making and the future options they are researching.</li>
              <li><strong>Support Practice:</strong> Encourage them to practice skills and complete small projects they can add to their notebook.</li>
              <li><strong>Encourage Guidance:</strong> Remind them to ask their teacher questions and seek feedback on their portfolio and plans.</li>
            </ul>
            <p className="mt-3">Your support for this practical, ongoing process is greatly appreciated. Thank you!</p>
          </div>
        </div>
      </section>

      {/* Resources Section */}
      <section className="bg-purple-50 p-6 rounded-xl border border-purple-200">
        <h3 className="text-lg font-semibold text-primary mb-3">Research Resources & Guidelines</h3>
        <div className="space-y-4">
          <div>
            <h4 className="font-medium text-purple-700 mb-2">Guidelines for Organizing Your Skill Portfolio Notebook:</h4>
            <ul className="list-disc pl-5 space-y-1 text-gray-700">
              <li><strong>Get a Dedicated Notebook:</strong> Use one notebook specifically for this.</li>
              <li><strong>Create Simple Sections:</strong> Use divider pages or just leave space for sections.</li>
              <li><strong>Keep it Updated:</strong> Add new projects, learning, research regularly.</li>
              <li><strong>Be Neat & Clear:</strong> Write so you (and others) can understand it later. Use dates!</li>
              <li><strong>Add Evidence (Optional/Later):</strong> You can paste in small printouts, photos, or sketches related to your projects if feasible.</li>
            </ul>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-medium text-purple-700 mb-2">Keywords for Research:</h4>
              <ul className="list-disc pl-5 space-y-1 text-gray-700">
                <li>types of degree courses after 12th India</li>
                <li>polytechnic diploma courses list eligibility</li>
                <li>ITI courses list trades India</li>
                <li>Skill India portal online courses</li>
                <li>NPTEL courses for [Skill]</li>
                <li>entry level job skills needed India</li>
                <li>jobs in [Industry Type]</li>
                <li>how to start freelancing as a student India</li>
                <li>Upwork / Fiverr India beginners guide</li>
                <li>lifelong learning resources free online</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium text-purple-700 mb-2">AI Prompts:</h4>
              <ul className="list-disc pl-5 space-y-1 text-gray-700">
                <li>Suggest a simple structure for organizing a skill portfolio notebook.</li>
                <li>What kind of information should I include when describing a project in my portfolio notebook?</li>
                <li>What are common jobs available in small towns in India for someone with [Skill]?</li>
                <li>What are the general eligibility criteria for joining an ITI in India?</li>
                <li>Give me tips for staying motivated to update my learning plan regularly.</li>
              </ul>
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-md mt-4">
            <h4 className="font-medium text-primary mb-2">Teacher References:</h4>
            <p className="text-gray-700">Keywords for specific local colleges/courses, government job portals (UPSC, SSC, state PSC), popular Indian job sites (Naukri, Indeed India, LinkedIn India), Skill India portal, specific freelance platform names (with caution), goal setting frameworks (SMART goals examples), how to write a learning plan, resume keywords for students.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HighIncomeSkillsModule6;
