
import React from "react";

const Playbook6Module1 = () => {
  return (
    <div className="space-y-6">
      <div className="border-b border-accent/20 pb-3">
        <h2 className="text-2xl font-bold text-primary mb-1">Empowering Your Teachers for Future Readiness</h2>
        <p className="text-lg text-secondary">Module 1: Understanding Future-Ready Skills and Assessments</p>
      </div>
      
      <div className="prose max-w-none">
        <div className="bg-brand-50/50 p-5 rounded-lg border border-brand-100 shadow-sm">
          <h3 className="text-xl font-semibold text-secondary mb-2">Core Principle</h3>
          <p className="text-gray-800">
            Teachers need a clear understanding of future-ready skills, assessment types, and how to interpret assessment data to effectively guide students towards relevant pathways. <span className="font-bold">Stop relying on intuition; use data to guide accurately.</span>
          </p>
        </div>
        
        <div className="mt-8 space-y-6">
          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h3 className="text-lg font-bold text-primary mb-3 flex items-center gap-2">
              <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-primary text-white text-sm">1</span>
              Familiarize with Assessment Types
            </h3>
            <div className="space-y-3 pl-4 border-l-2 border-accent/20">
              <p className="text-gray-700">Understand the "Blueprints": Assessments (Personality, Career Preference, Skills) act as student "blueprints," revealing hidden talents, interests, and skill levels.</p>
              
              <div>
                <p className="font-semibold text-gray-800">Key Types Explained:</p>
                <ul className="pl-5 space-y-1 text-gray-700 mt-2">
                  <li className="flex items-start gap-2">
                    <div className="h-2 w-2 rounded-full bg-accent mt-2"></div>
                    <div><span className="font-medium">Personality:</span> How students work, learn, interact (important for team fit, work style).</div>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="h-2 w-2 rounded-full bg-accent mt-2"></div>
                    <div><span className="font-medium">Career Preference:</span> What fields naturally excite them? (Passion matters).</div>
                  </li>
                  <li className="flex items-start gap-2">
                    <div className="h-2 w-2 rounded-full bg-accent mt-2"></div>
                    <div><span className="font-medium">Skills:</span> What foundational or specific skills do they already possess?</div>
                  </li>
                </ul>
              </div>
              
              <p className="text-gray-700"><span className="font-medium">Purpose:</span> Emphasize these aren't just tests but conversation starters for guidance.</p>
            </div>
          </div>
          
          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h3 className="text-lg font-bold text-primary mb-3 flex items-center gap-2">
              <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-primary text-white text-sm">2</span>
              Interpret Assessment Reports
            </h3>
            <div className="space-y-3 pl-4 border-l-2 border-accent/20">
              <p className="text-gray-700"><span className="font-medium">Focus on Key Metrics:</span> Train teachers not to get lost in complex reports but to focus on key indicators and patterns (e.g., consistent strengths, clear interests, specific aptitude scores like "Entrepreneurial Score," "Tech Aptitude").</p>
              
              <p className="text-gray-700"><span className="font-medium">See the Signals:</span> The reports highlight potential; the teacher's job is to help unlock it.</p>
              
              <p className="text-gray-700"><span className="font-medium">Immediate Action:</span> Review sample assessment reports with teachers. Practice highlighting 3 key metrics per report.</p>
            </div>
          </div>
          
          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h3 className="text-lg font-bold text-primary mb-3 flex items-center gap-2">
              <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-primary text-white text-sm">3</span>
              Identify Student Strengths and Development Areas
            </h3>
            <div className="space-y-3 pl-4 border-l-2 border-accent/20">
              <p className="text-gray-700"><span className="font-medium">Pinpoint Potential:</span> Use assessment data to identify both strengths and areas needing development.</p>
              
              <p className="text-gray-700"><span className="font-medium">Focus on Strengths First:</span> Leverage strengths (e.g., high "Analytical Skills") to build career paths.</p>
              
              <p className="text-gray-700"><span className="font-medium">Frame Development Areas as Opportunities:</span> View areas needing development (e.g., low "Public Speaking") as growth opportunities, not limitations.</p>
              
              <p className="text-gray-700"><span className="font-medium">Immediate Action:</span> Practice listing 3 strengths and 1 development area for sample student profiles based on assessment data.</p>
            </div>
          </div>
          
          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h3 className="text-lg font-bold text-primary mb-3 flex items-center gap-2">
              <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-primary text-white text-sm">4</span>
              Match Assessments with Career Clusters
            </h3>
            <div className="space-y-3 pl-4 border-l-2 border-accent/20">
              <p className="text-gray-700"><span className="font-medium">Connect the Dots:</span> Teach how to connect student profiles (strengths, interests, skills) to the 2-3 most relevant career clusters (e.g., Technology, Healthcare, Creative Arts, Business).</p>
              
              <p className="text-gray-700"><span className="font-medium">Explore Overlaps:</span> Encourage exploring combinations and overlaps between clusters, not limiting students to just one.</p>
              
              <p className="text-gray-700"><span className="font-medium">Use Tools:</span> Utilize the Career Cluster Compass.pdf to aid in mapping assessment results to potential career paths.</p>
              
              <p className="text-gray-700"><span className="font-medium">Immediate Action:</span> Practice identifying 2-3 relevant career clusters for sample student profiles using the Compass.</p>
            </div>
          </div>
        </div>
        
        <div className="mt-8 bg-accent/5 p-5 rounded-lg border border-accent/20 shadow-sm">
          <h4 className="font-semibold text-brand-700 mb-4 border-b pb-2 border-accent/10">"Done-For-You" Resources</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
              <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
              <span>Career Cluster Compass.pdf</span>
            </div>
            <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
              <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
              <span>Student Career Assessment Tracker</span>
            </div>
            <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
              <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
              <span>Career Cluster Reference</span>
            </div>
            <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
              <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
              <span>High-Income Skill Building & Future Readiness Strategic Frameworks</span>
            </div>
          </div>
        </div>
        
        <div className="mt-6 p-5 rounded-lg border-l-4 border-accent bg-brand-50 shadow-sm flex items-center gap-3">
          <div className="bg-accent text-white rounded-full p-1.5 flex-shrink-0">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
          </div>
          <div>
            <p className="font-bold text-primary">Action Point:</p>
            <p className="text-gray-700">Review sample assessment reports with your teachers. Discuss how to interpret key metrics, identify student strengths/development areas, and connect these profiles to relevant career clusters using the Career Cluster Compass.pdf.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Playbook6Module1;
