
import React from "react";
import { CheckCircle } from "lucide-react";

/**
 * Playbook 0, Module 1: Introduction & Implementation Guide
 */
const Playbook0Module1 = () => (
  <div className="space-y-6">
    <div className="border-b border-accent/20 pb-3">
      <h2 className="text-2xl font-bold text-primary mb-1">Getting Started: Your School Growth Implementation Roadmap</h2>
    </div>
    
    <div className="prose max-w-none">
      <div className="bg-brand-50/50 p-5 rounded-lg border border-brand-100 shadow-sm">
        <h3 className="text-xl font-semibold text-secondary mb-2">Welcome to Your Implementation Journey</h3>
        <p className="text-gray-800">
          This introductory playbook will guide you through implementing all the strategies and systems for guaranteed school growth. 
          We've designed this specifically to make implementation extremely straightforward, even if you have limited time or resources.
        </p>
      </div>

      <div className="mt-8">
        <h3 className="text-lg font-bold text-primary flex items-center gap-2 mb-4">
          <span className="inline-flex items-center justify-center h-7 w-7 rounded-full bg-primary text-white text-sm">1</span>
          Understanding The Implementation Approach
        </h3>
        
        <div className="bg-white p-5 rounded-lg shadow-sm space-y-4">
          <div>
            <h4 className="font-semibold text-accent">The Progressive Implementation Philosophy</h4>
            <p className="text-gray-700">
              Each playbook is designed to work independently while also enhancing the others when implemented together. 
              You can choose to implement one playbook at a time or multiple simultaneously based on your school's needs, 
              resources, and priorities.
            </p>
          </div>
          
          <div className="pl-4 border-l-2 border-accent/20">
            <h4 className="font-semibold text-gray-800">Key Implementation Principles:</h4>
            <ul className="list-disc pl-5 text-gray-700 space-y-1">
              <li><span className="font-medium">Start Small, Scale Fast:</span> Begin with high-impact, low-effort strategies and build momentum.</li>
              <li><span className="font-medium">Use Ready Resources:</span> Every playbook contains "Done-For-You" resources to minimize workload.</li>
              <li><span className="font-medium">Adapt to Your Context:</span> Modify strategies to fit your school's unique situation and constraints.</li>
              <li><span className="font-medium">Measure & Refine:</span> Track results and make adjustments as needed for continuous improvement.</li>
              <li><span className="font-medium">Involve Your Team:</span> Delegate specific roles and responsibilities for effective implementation.</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="mt-8">
        <h3 className="text-lg font-bold text-primary flex items-center gap-2 mb-4">
          <span className="inline-flex items-center justify-center h-7 w-7 rounded-full bg-primary text-white text-sm">2</span>
          Implementation Roadmap - Recommended Order
        </h3>
        
        <div className="space-y-4 pl-5 border-l-2 border-accent/30">
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center justify-center h-6 w-6 rounded bg-primary/10 text-primary font-bold text-xs">1</span>
              <p className="font-bold text-primary">Playbook 1: Immediate Impact – Quick Wins</p>
            </div>
            <div className="pl-8 mt-2 text-gray-700">
              <p>Start here to establish your school's unique positioning and create immediate impact with minimal effort. These strategies can typically be implemented within 1-2 weeks and begin showing results almost immediately.</p>
              <p className="text-accent font-medium mt-1">Expected Timeline: 1-2 weeks to implement, immediate results</p>
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center justify-center h-6 w-6 rounded bg-primary/10 text-primary font-bold text-xs">2</span>
              <p className="font-bold text-primary">Playbook 2: Parent Community Engagement</p>
            </div>
            <div className="pl-8 mt-2 text-gray-700">
              <p>Build on your new positioning by engaging your existing parent community deeply. This creates organic growth through word-of-mouth and referrals while strengthening parent loyalty.</p>
              <p className="text-accent font-medium mt-1">Expected Timeline: 2-3 weeks to implement, 1-2 months for significant results</p>
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center justify-center h-6 w-6 rounded bg-primary/10 text-primary font-bold text-xs">3</span>
              <p className="font-bold text-primary">Playbook 3: Admission Process Optimization</p>
            </div>
            <div className="pl-8 mt-2 text-gray-700">
              <p>While working on engagement, simultaneously streamline your admission process to convert more inquiries into enrollments. This amplifies the results from your positioning and parent engagement initiatives.</p>
              <p className="text-accent font-medium mt-1">Expected Timeline: 2 weeks to implement, immediate improvement in conversion rates</p>
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center justify-center h-6 w-6 rounded bg-primary/10 text-primary font-bold text-xs">4</span>
              <p className="font-bold text-primary">Playbook 4: Sustainable Growth & Revenue</p>
            </div>
            <div className="pl-8 mt-2 text-gray-700">
              <p>Establish systems for predictable growth and diversified revenue streams beyond one-time admission fees.</p>
              <p className="text-accent font-medium mt-1">Expected Timeline: 1-2 months to implement, 2-4 months for significant results</p>
            </div>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center justify-center h-6 w-6 rounded bg-primary/10 text-primary font-bold text-xs">5</span>
              <p className="font-bold text-primary">Playbook 5: Future-Ready Education Implementation</p>
            </div>
            <div className="pl-8 mt-2 text-gray-700">
              <p>Implement the educational strategies that form the foundation of your unique positioning. This creates real delivery on your school's future-ready promise.</p>
              <p className="text-accent font-medium mt-1">Expected Timeline: Progressive implementation over 3-6 months</p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8">
        <h3 className="text-lg font-bold text-primary flex items-center gap-2 mb-4">
          <span className="inline-flex items-center justify-center h-7 w-7 rounded-full bg-primary text-white text-sm">3</span>
          Implementation Success Strategies
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Start with Quick Wins (30-Day Focus):</p>
            <p className="text-gray-700">Begin with Playbook 1's positioning updates and initial outreach. These quick wins build momentum and enthusiasm for deeper changes.</p>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Designate Implementation Champions:</p>
            <p className="text-gray-700">Assign specific individuals to oversee implementation of each playbook. Create a small team that meets weekly to coordinate efforts.</p>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Adapt Resources to Your Context:</p>
            <p className="text-gray-700">Modify templates and materials to reflect your school's specific value proposition, culture, and target audience.</p>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Track & Measure Implementation:</p>
            <p className="text-gray-700">Use the Implementation Tracking Dashboard (available in resources) to monitor progress across all playbooks and initiatives.</p>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Regular Implementation Reviews:</p>
            <p className="text-gray-700">Schedule brief weekly check-ins (15-30 minutes) to discuss progress, address challenges, and adjust approaches as needed.</p>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Focus on Staff Buy-in:</p>
            <p className="text-gray-700">Communicate the "why" behind implementation and highlight early successes to build enthusiasm among all staff members.</p>
          </div>
        </div>
      </div>

      <div className="mt-8 bg-accent/5 p-5 rounded-lg border border-accent/20 shadow-sm">
        <h4 className="font-semibold text-brand-700 mb-4 border-b pb-2 border-accent/10">"Done-For-You" Implementation Resources</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Implementation Roadmap Overview (Visual Guide)</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>90-Day Implementation Calendar Template</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Implementation Team Role Assignment Template</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Implementation Tracking Dashboard (Spreadsheet)</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Weekly Implementation Check-in Agenda Template</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Staff Communication Template for Implementation</span>
          </div>
        </div>
      </div>
      
      <div className="mt-6 p-4 rounded-lg border-l-4 border-accent bg-brand-50 shadow-sm flex items-center gap-3">
        <div className="bg-accent text-white rounded-full p-1.5 flex-shrink-0">
          <CheckCircle className="h-4 w-4" />
        </div>
        <div>
          <b className="text-primary">Action Point:</b> Download the Implementation Roadmap and 90-Day Calendar. Assemble your implementation team, assign roles, and begin with Playbook 1 this week.
        </div>
      </div>
    </div>
  </div>
);

export default Playbook0Module1;
