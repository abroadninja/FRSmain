
import React from "react";
import { Link } from "react-router-dom";
import { Search, BookOpen, Brain, Lightbulb, FileText, Users, Rocket, Activity } from "lucide-react";

/**
 * High Income Skills Portfolio Building Guidance - Module 3: Learning How to Learn Effectively
 */
const HighIncomeSkillsModule3 = () => (
  <div className="space-y-8">
    <div className="border-b-2 border-accent/30 pb-4">
      <h2 className="text-2xl font-bold text-primary mb-2">Module 3: Learning How to Learn Effectively</h2>
      <p className="text-gray-600 italic">Teaching students how to find information, learn from online resources, use AI tools smartly, take useful notes, manage their time, and learn together in groups.</p>
    </div>
    
    <div className="prose max-w-none">
      {/* Focus Area Card */}
      <div className="bg-brand-50/50 p-6 rounded-lg border border-brand-200 shadow-sm">
        <h3 className="text-xl font-semibold text-secondary mb-3 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-secondary/10 rounded-full text-secondary">
            <Brain className="h-5 w-5" />
          </span>
          Focus Area
        </h3>
        <p className="text-gray-800 text-lg">
          Mastering learning tools and techniques – Search, YouTube, AI, note-taking, time management, and collaborative learning.
        </p>
      </div>
      
      {/* Teacher Session Guide */}
      <div className="mt-10">
        <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
            <BookOpen className="h-5 w-5" />
          </span>
          For Teachers: Session Guide (Approx. 60-90 minutes, adaptable)
        </h3>
        
        <div className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
          {/* Preparation */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Preparation (Before Class)</h4>
            </div>
            <div className="p-6">
              <ul className="space-y-3 pl-5 list-disc text-gray-700">
                <li>Review the "How-To" Tips (see section at bottom) derived from the search results.</li>
                <li>Prepare simple examples for demonstrating Google Search and AI prompts on the board.</li>
                <li>Have a plan for group discussion points.</li>
              </ul>
            </div>
          </div>
          
          {/* Introduction */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Introduction: The Most Important Skill (5-10 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Emphasize that learning how to learn is key to success in any field.</p>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md">
                  <p><strong className="text-blue-800">Say something like:</strong> "We've talked about knowing yourselves and exploring jobs. But how do you learn the skills needed for those jobs, especially when teachers have limited time? The most important skill you can learn is how to learn effectively on your own! The world changes fast, and you'll need to keep learning throughout your life. Luckily, you have powerful tools right in your pocket – your smartphone, Google Search, YouTube, and free AI like Gemini. Today, we'll learn how to use them better."</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Activity 1 */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Activity 1: Searching Smartly on Google (15-20 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Teach basic techniques for better search results.</p>
                <p><strong className="text-primary">Teacher Demo (on Board):</strong></p>
                <ul className="space-y-3 pl-5 list-disc">
                  <li><strong>Keywords:</strong> "Instead of just typing 'jobs', try 'computer jobs for beginners' or 'creative jobs work from home'." (Show difference).</li>
                  <li><strong>Quotes "":</strong> "If you need an exact phrase, use quotes. Searching for "Skills for Success" will find pages with exactly those words together."</li>
                  <li><strong>Minus Sign -:</strong> "To remove unwanted results, use minus. Search jaguar animal -car to find the animal, not the car brand."</li>
                  <li><strong>Ask Questions:</strong> "You can ask full questions like what skills are needed for digital marketing?"</li>
                  <li><strong>Check the Source:</strong> "Always ask: Is this website reliable? Is it a known company, a university (.edu), a government site (.gov, .nic.in), or just someone's opinion? Look for trustworthy sources."</li>
                </ul>
                <div className="bg-green-50 border-l-4 border-green-300 p-4 rounded-r-md mt-4">
                  <p><strong className="text-green-800">Quick Practice:</strong> Ask students to suggest a topic and brainstorm good search keywords together.</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Activity 2 */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Activity 2: Learning from YouTube (10-15 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Help students find and evaluate educational videos.</p>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md">
                  <p><strong className="text-blue-800">Discussion:</strong> "YouTube has millions of videos! How do you find good ones for learning?" (Guide discussion towards points like: searching with specific keywords like 'tutorial', 'for beginners', 'in Telugu'; looking at channel reputation, number of views/likes (but be careful, popular isn't always correct), reading comments, checking if the information matches other sources).</p>
                </div>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md mt-4">
                  <p><strong className="text-blue-800">Say:</strong> "Don't just watch passively! Pause, take notes (we'll talk about that!), try things out. If a video explains something, try explaining it back in your own words."</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Activity 3 */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Activity 3: Using AI (like Gemini) as a Learning Buddy (15-20 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Show how AI can help understand concepts, summarize, and brainstorm.</p>
                <p><strong className="text-primary">Teacher Demo/Role-play (on Board):</strong></p>
                <ul className="space-y-3 pl-5 list-disc">
                  <li><strong>Ask Specific Questions:</strong> "Don't just ask 'Tell me about AI'. Ask 'Explain Artificial Intelligence to a school student in simple terms' or 'Explain Artificial Intelligence to a 10th standard student in Telugu'." (Show difference).</li>
                  <li><strong>Summarize:</strong> "You can copy text from a webpage and ask Gemini, Summarize this text in 5 bullet points."</li>
                  <li><strong>Explain:</strong> "If you don't understand a word or concept from your notes or a video, ask What does 'photosynthesis' mean? Explain it simply."</li>
                  <li><strong>Brainstorm:</strong> "Stuck for ideas? Ask Give me 5 ideas for a science project on pollution."</li>
                </ul>
                <div className="bg-yellow-50 border-l-4 border-yellow-300 p-4 rounded-r-md mt-4">
                  <p><strong className="text-yellow-800">Caution:</strong> "AI is helpful, but it's not perfect! It can sometimes make mistakes or give outdated information. Always try to double-check important facts from other reliable sources (like textbooks or trusted websites)."</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Activity 4 */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Activity 4: Quick Tips - Notes, Time & Groups (10-15 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Briefly introduce note-taking, time management, and group study benefits.</p>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md">
                  <p><strong className="text-blue-800">Note-Taking:</strong> "When learning online or in class, don't try to write everything! Focus on keywords, main ideas, and questions you have. Use your own words. Simple bullet points or numbering helps."</p>
                </div>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md mt-4">
                  <p><strong className="text-blue-800">Time Management:</strong> "You have school, homework, maybe chores, and learning these new things. Try planning! Use a simple calendar or notebook to write down deadlines. Break big tasks into smaller steps. Decide what's most important to do first."</p>
                </div>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md mt-4">
                  <p><strong className="text-blue-800">Group Study Power:</strong> "Learning together is powerful! Why? You can explain things to each other (best way to learn!), share resources you find, ask questions you might be shy to ask alone, and keep each other motivated. Use your WhatsApp groups for this!"</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Home Task */}
          <div>
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Assign Home Task (5 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Encourage practice of the skills learned.</p>
                <p><strong className="text-primary">Explain the task clearly</strong> (also send via WhatsApp):</p>
                <div className="bg-green-50 border border-green-200 rounded-md p-4">
                  <p>"Task 1: YouTube & Notes: Find a short YouTube video (5-10 mins) explaining a simple concept related to one of the jobs you explored (e.g., 'what is graphic design basics', 'how does social media marketing work simple explanation'). Watch it and take simple notes (keywords, main points)."</p>
                  <p className="mt-2">"Task 2: AI Buddy: Ask Gemini (or similar AI) 2-3 questions about the same concept. Examples: Explain [concept] in 3 sentences, What are the first steps to learn [concept]?, Summarize the main points of [concept]. Compare the AI explanation with the video."</p>
                  <p className="mt-2">"Task 3: Group Share: In your WhatsApp study group, share the link to the video you watched and ONE key thing you learned from it or from the AI explanation."</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* WhatsApp Message Section */}
      <div className="mt-10">
        <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
            <FileText className="h-5 w-5" />
          </span>
          For Students: WhatsApp Message (Send after the session)
        </h3>
        <div className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
          <div className="bg-green-50 p-6 rounded-lg">
            <h4 className="font-semibold text-gray-800 text-lg mb-4 pb-2 border-b border-green-200">Subject: High Income Skills: Learn How to Learn! 🧠✨</h4>
            <div className="space-y-4 text-gray-700">
              <p>"Hi Team, Today we learned the SUPERPOWER of learning how to learn! 🚀 Remember to use Google, YouTube, and AI tools smartly.</p>
              
              <div className="bg-white rounded-md p-5 border border-gray-200">
                <p className="font-medium text-gray-800 border-b pb-2 mb-3">Your Tasks:</p>
                <ul className="space-y-3 pl-5 list-disc">
                  <li><strong className="text-primary">Learn from Video:</strong> Find a short YouTube video (5-10 mins) on a simple job skill/concept (e.g., what is content writing for beginners, basic principles of selling). Watch & take simple notes (keywords/main points). 📝</li>
                  <li><strong className="text-primary">Ask AI:</strong> Ask Gemini (or similar AI) 2-3 questions about the same concept (e.g., Explain [concept] simply, Summarize main points of [concept], What's the first step to learn [concept]?). Compare with video. 🤔</li>
                  <li><strong className="text-primary">Share in Group:</strong> Post the video link & ONE key learning point in your WhatsApp study group. Help each other! 💬</li>
                </ul>
              </div>
              
              <div className="bg-white rounded-md p-5 border border-gray-200">
                <p className="font-medium text-gray-800 border-b pb-2 mb-3">Keywords/Prompts to Help You Learn:</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="bg-blue-50 p-3 rounded-md">
                    <p className="font-medium text-blue-800 mb-2">Google Search:</p>
                    <ul className="space-y-1 pl-5 list-disc">
                      <li>Use "exact phrase", -exclude word</li>
                      <li>site:[website.com], define: [word]</li>
                      <li>Ask full questions</li>
                      <li>Always check if the source is reliable!</li>
                    </ul>
                  </div>
                  <div className="bg-purple-50 p-3 rounded-md">
                    <p className="font-medium text-purple-800 mb-2">YouTube:</p>
                    <ul className="space-y-1 pl-5 list-disc">
                      <li>[topic] tutorial for beginners</li>
                      <li>[topic] explained simply</li>
                      <li>[topic] in [Your Language]</li>
                      <li>Look for clear explanations, check comments/channel info</li>
                    </ul>
                  </div>
                  <div className="bg-green-50 p-3 rounded-md">
                    <p className="font-medium text-green-800 mb-2">AI (Gemini) Prompts:</p>
                    <ul className="space-y-1 pl-5 list-disc">
                      <li>Explain [topic] to a 10th standard student</li>
                      <li>Summarize this text: [paste text]</li>
                      <li>Give me 5 keywords about [topic]</li>
                      <li>What are the pros and cons of [topic]?</li>
                      <li>Translate this sentence to [Your Language]: [sentence]</li>
                    </ul>
                  </div>
                  <div className="bg-amber-50 p-3 rounded-md">
                    <p className="font-medium text-amber-800 mb-2">Group Study:</p>
                    <ul className="space-y-1 pl-5 list-disc">
                      <li>Share links, explain concepts</li>
                      <li>Ask questions, quiz each other</li>
                    </ul>
                  </div>
                </div>
              </div>
              
              <p>Practice makes perfect! Keep exploring!"</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Parent Note Section */}
      <div className="mt-10">
        <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
            <Users className="h-5 w-5" />
          </span>
          For Parents: Note to Share with Parents (via WhatsApp or simple printout)
        </h3>
        <div className="p-6 border-l-4 border-brand-400 bg-brand-50 rounded-lg shadow-sm">
          <div className="space-y-4">
            <h4 className="font-semibold text-primary text-lg">Subject: Helping Your Child Become an Independent Learner</h4>
            <p className="text-gray-700">
              "Dear Parents, In our 'High Income Skills Portfolio Building' program, we are now focusing on teaching students how to learn effectively on their own. This is a very important skill for their future success. We are guiding them on how to:
            </p>
            <ul className="ml-6 list-disc space-y-1 text-gray-700">
              <li>Find reliable information using Google Search.</li>
              <li>Learn from educational videos on YouTube.</li>
              <li>Use free AI tools (like Google Gemini) carefully to understand concepts or get ideas.</li>
              <li>Take simple notes and manage their study time.</li>
              <li>Learn from and support each other in study groups.</li>
            </ul>
            <div className="mt-4">
              <p className="font-medium text-gray-800 mb-2">How you can help:</p>
              <ul className="ml-6 list-disc space-y-2 text-gray-700">
                <li><strong className="text-secondary">Encourage Curiosity:</strong> Applaud them when they try to find answers or learn something new using their phone (for learning purposes).</li>
                <li><strong className="text-secondary">Ask About Process:</strong> Instead of just asking what they learned, ask how they learned it ("Did you find a good video?", "What did you search for?").</li>
                <li><strong className="text-secondary">Value Effort:</strong> Praise their effort in trying to understand difficult topics, even if they don't get it right away. Empowering them to learn independently is key. Thank you for your support!"</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      
      {/* How-To Tips Section */}
      <div className="mt-10">
        <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
            <Lightbulb className="h-5 w-5" />
          </span>
          "How-To" Tips Summary (Teacher Reference / Shareable Snippets)
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h4 className="font-semibold text-gray-800 text-lg mb-3 border-b pb-2">How to Search Smartly on Google:</h4>
            <ul className="space-y-2 pl-5 list-disc text-gray-700">
              <li>Use specific keywords (e.g., "basic python programming tutorial" not just "python").</li>
              <li>Use quotes " " for exact phrases (e.g., "digital marketing jobs").</li>
              <li>Use hyphen - to exclude words (e.g., best free courses -udemy).</li>
              <li>Ask clear questions (e.g., what are the main types of graphic design?).</li>
              <li>Check the source! Is it trustworthy? (.edu, .gov, .org, well-known company/news site?).</li>
            </ul>
          </div>
          
          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h4 className="font-semibold text-gray-800 text-lg mb-3 border-b pb-2">How to Learn from YouTube:</h4>
            <ul className="space-y-2 pl-5 list-disc text-gray-700">
              <li>Search using specific terms + "tutorial", "explanation", "for beginners", "in [language]".</li>
              <li>Check the channel (Is it educational? How many subscribers? Recent videos?).</li>
              <li>Look at views, likes/dislikes, and read comments for feedback.</li>
              <li>Watch actively: Pause, re-watch confusing parts, take notes.</li>
              <li>Verify information from other sources if learning something important.</li>
            </ul>
          </div>
          
          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h4 className="font-semibold text-gray-800 text-lg mb-3 border-b pb-2">How to Use AI (like Gemini) to Learn:</h4>
            <ul className="space-y-2 pl-5 list-disc text-gray-700">
              <li>Be specific! Ask clear, detailed questions. Provide context.</li>
              <li>Ask for explanations in simple terms or for your grade level/language.</li>
              <li>Use it to summarize long texts or articles.</li>
              <li>Ask for different perspectives (pros/cons, different approaches).</li>
              <li>Use it for brainstorming ideas (projects, study topics).</li>
              <li>Ask follow-up questions to clarify.</li>
              <li><strong className="text-red-600">CRITICAL:</strong> Always double-check important facts/information from reliable sources. AI can make mistakes.</li>
            </ul>
          </div>
          
          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h4 className="font-semibold text-gray-800 text-lg mb-3 border-b pb-2">Simple Note-Taking Tips:</h4>
            <ul className="space-y-2 pl-5 list-disc text-gray-700">
              <li>Don't write full sentences; use keywords, short phrases.</li>
              <li>Use your own words (paraphrase) – helps you understand & remember.</li>
              <li>Use headings, bullet points (•), or numbers (1, 2, 3) to structure notes.</li>
              <li>Use symbols/abbreviations you understand (e.g., & for and, w/ for with, imp. for important). Keep a key if needed.</li>
              <li>Leave space to add your own thoughts or questions later.</li>
            </ul>
          </div>
          
          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h4 className="font-semibold text-gray-800 text-lg mb-3 border-b pb-2">Basic Time Management Tips:</h4>
            <ul className="space-y-2 pl-5 list-disc text-gray-700">
              <li>Use a calendar/agenda (physical or phone app) to track deadlines & events.</li>
              <li>Make a simple "To-Do" list daily or weekly.</li>
              <li>Prioritize: What's most important and urgent? Do that first.</li>
              <li>Break big tasks (like studying for an exam) into smaller steps.</li>
              <li>Set specific times for tasks (e.g., "Study Math from 4 PM to 5 PM").</li>
              <li>Include time for breaks and relaxation! Don't overschedule.</li>
            </ul>
          </div>
          
          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h4 className="font-semibold text-gray-800 text-lg mb-3 border-b pb-2">Tips for Good Group Study (Online/Offline):</h4>
            <ul className="space-y-2 pl-5 list-disc text-gray-700">
              <li>Keep groups small (3-5 people works well, but with limited time, you can go upto 15 per group).</li>
              <li>Come prepared (do individual reading/tasks first).</li>
              <li>Share resources (links, notes, summaries).</li>
              <li>Explain concepts to each other – teaching helps you learn!</li>
              <li>Quiz each other on key facts or concepts.</li>
              <li>Ask questions and discuss different viewpoints respectfully.</li>
              <li>Stay focused during study time, minimize distractions.</li>
              <li>Be reliable – attend sessions, contribute positively.</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    
    {/* Resources Section */}
    <div className="mt-8 bg-blue-50 p-6 rounded-lg border border-blue-100 shadow-sm">
      <div className="flex items-center gap-3 text-blue-800 mb-4">
        <Search className="h-5 w-5" />
        <h4 className="font-bold text-lg">Career Exploration Resources</h4>
      </div>
      <p className="mb-4 text-gray-700">
        These interactive tools can help students explore different career paths based on their interests and strengths:
      </p>
      <div className="flex flex-wrap gap-3">
        <Link 
          to="/implementation-guides/high-income-skills/keywords" 
          className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          <Search className="h-4 w-4" /> Keyword & Prompt Library
        </Link>
        <Link 
          to="/career-explorer/clusters" 
          className="inline-flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
        >
          <Rocket className="h-4 w-4" /> Career Cluster Explorer
        </Link>
        <Link 
          to="/career-explorer/problem-solving" 
          className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors"
        >
          <Brain className="h-4 w-4" /> Problem-Based Career Matching
        </Link>
        <Link 
          to="/career-explorer/assessment" 
          className="inline-flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700 transition-colors"
        >
          <Activity className="h-4 w-4" /> Psychometric Career Assessment
        </Link>
      </div>
    </div>
  </div>
);

export default HighIncomeSkillsModule3;
