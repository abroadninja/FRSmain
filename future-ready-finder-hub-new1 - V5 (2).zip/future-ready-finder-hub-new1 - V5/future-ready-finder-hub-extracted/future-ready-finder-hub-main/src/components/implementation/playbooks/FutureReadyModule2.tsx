
import React from "react";

/**
 * Future Ready Skills Program - Module 2: Knowing Yourself & Your Potential
 */
const FutureReadyModule2 = () => (
  <div className="space-y-6">
    <div className="border-b border-accent/20 pb-3">
      <h2 className="text-2xl font-bold text-primary mb-1">Module 2: Knowing Yourself & Your Potential</h2>
    </div>
    
    <div className="prose max-w-none">
      <div className="bg-brand-50/50 p-5 rounded-lg border border-brand-100 shadow-sm">
        <h3 className="text-xl font-semibold text-secondary mb-2">Focus Area</h3>
        <p className="text-gray-800">
          Helping students understand their own strengths, interests, and the power of believing in their ability to learn and grow.
        </p>
      </div>
      
      <div className="mt-8">
        <h3 className="text-lg font-bold text-primary mb-3">For Teachers: Session Guide</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h4 className="font-semibold text-gray-800 pb-2 border-b border-gray-100 mb-3">Preparation (Before Class)</h4>
            <ul className="space-y-2">
              <li className="flex gap-2 items-center">
                <div className="h-2 w-2 rounded-full bg-accent"></div>
                <span className="text-gray-700">Prepare simple questions about personal interests and strengths</span>
              </li>
              <li className="flex gap-2 items-center">
                <div className="h-2 w-2 rounded-full bg-accent"></div>
                <span className="text-gray-700">Create a chart showing "Things I Like" vs. "Things I'm Good At"</span>
              </li>
              <li className="flex gap-2 items-center">
                <div className="h-2 w-2 rounded-full bg-accent"></div>
                <span className="text-gray-700">Plan small group divisions (4-6 students)</span>
              </li>
            </ul>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h4 className="font-semibold text-gray-800 pb-2 border-b border-gray-100 mb-3">Introduction (10-15 minutes)</h4>
            <ul className="space-y-2">
              <li className="flex gap-2 items-center">
                <div className="h-2 w-2 rounded-full bg-accent"></div>
                <span className="text-gray-700">Start a discussion about what makes each person unique</span>
              </li>
              <li className="flex gap-2 items-center">
                <div className="h-2 w-2 rounded-full bg-accent"></div>
                <span className="text-gray-700">Have students reflect on what they enjoy and what they're naturally good at</span>
              </li>
              <li className="flex gap-2 items-center">
                <div className="h-2 w-2 rounded-full bg-accent"></div>
                <span className="text-gray-700">Draw overlapping circles on the board labeled "Things I Enjoy" and "Things I Am Good At"</span>
              </li>
              <li className="flex gap-2 items-center">
                <div className="h-2 w-2 rounded-full bg-accent"></div>
                <span className="text-gray-700">Highlight the overlap as a great place to explore potential careers</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mt-5">
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h4 className="font-semibold text-gray-800 pb-2 border-b border-gray-100 mb-3">Group Activity: Strength Spotting (20-30 minutes)</h4>
            <p className="text-gray-700">
              Divide students into small groups to share interests and skills. Group members identify positive qualities
              in each other based on what they share (e.g., responsibility, creativity, patience).
            </p>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h4 className="font-semibold text-gray-800 pb-2 border-b border-gray-100 mb-3">Introduction to Growth Mindset (5-10 minutes)</h4>
            <p className="text-gray-700">
              Explain the concept that abilities can be developed with effort, like learning to ride a bicycle.
              Write on board: "Growth Mindset = I can learn and get better with practice."
            </p>
          </div>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-sm mt-5">
          <h4 className="font-semibold text-gray-800 pb-2 border-b border-gray-100 mb-3">Home Task Assignment (5 minutes)</h4>
          <ul className="space-y-2">
            <li className="flex gap-2 items-center">
              <div className="h-2 w-2 rounded-full bg-accent"></div>
              <span className="text-gray-700">Task 1: List 3 things they enjoy and 3 things they're good at</span>
            </li>
            <li className="flex gap-2 items-center">
              <div className="h-2 w-2 rounded-full bg-accent"></div>
              <span className="text-gray-700">Task 2: Research "Growth Mindset" using Google or AI tools</span>
            </li>
            <li className="flex gap-2 items-center">
              <div className="h-2 w-2 rounded-full bg-accent"></div>
              <span className="text-gray-700">Optional Task 3: Explore personality tests or personality types</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="mt-8">
        <h3 className="text-lg font-bold text-primary mb-3">WhatsApp Message Template</h3>
        <div className="bg-gray-50 p-5 rounded-lg shadow-sm border border-gray-100">
          <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
            <p className="font-semibold text-primary mb-3">Subject: Future Ready: Knowing Yourself - Home Task!</p>
            <div className="space-y-3 text-gray-700">
              <p>
                Hi everyone, Great session today talking about our strengths! 😊 Remember, knowing yourself 
                is the first step to a bright future.
              </p>
              <div>
                <p className="font-medium">Your tasks before our next meeting:</p>
                <ol className="ml-6 list-decimal space-y-1 mt-1">
                  <li>List: Write down 3 things you ENJOY doing & 3 things you are GOOD at. 📝</li>
                  <li>Explore: Use Google/Gemini to search and understand 'Growth Mindset'. What does it mean to you? 🤔</li>
                  <li>(Optional) Explore 'free personality test for students' or ask Gemini about different personality types.</li>
                </ol>
              </div>
              
              <div>
                <p className="font-medium">Search Keywords/Prompts for Tasks:</p>
                <ul className="ml-6 list-disc space-y-1 mt-1">
                  <li>what is growth mindset simple explanation</li>
                  <li>growth mindset examples for students</li>
                  <li>growth mindset meaning in [Your Regional Language]</li>
                  <li>free personality test for students</li>
                  <li>(Ask AI): Explain growth mindset in simple terms.</li>
                  <li>(Ask AI): Can you tell me about different ways people describe personalities?</li>
                </ul>
              </div>
              <p>Discuss in your study groups! Help each other understand.</p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8">
        <h3 className="text-lg font-bold text-primary mb-3">Parent Communication</h3>
        <div className="p-5 border-l-4 border-brand-400 bg-brand-50 rounded-lg shadow-sm">
          <div className="space-y-3">
            <p className="font-semibold text-primary">Subject: Helping Your Child Discover Their Potential</p>
            <p className="text-gray-700">
              Dear Parents, Our school has started a program called 'Future Ready: Skills for Success' to help 
              students prepare for their future. This week/month, we focused on helping students understand 
              their strengths and interests, and the importance of believing they can learn new things 
              ('Growth Mindset').
            </p>
            <div>
              <p className="font-medium text-gray-800">How you can help at home:</p>
              <ul className="ml-6 list-disc space-y-1 mt-1 text-gray-700">
                <li><strong>Talk:</strong> Ask your child about what they enjoy doing and what they feel they are good at.</li>
                <li><strong>Encourage:</strong> Praise their effort when they try to learn something new, even if it's difficult.</li>
                <li><strong>Curiosity:</strong> Encourage them to ask questions and explore topics they find interesting.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

export default FutureReadyModule2;
