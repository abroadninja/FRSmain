
import React from "react";
import { CheckCircle } from "lucide-react";

/**
 * Simplified Implementation Guide - Module 1
 */
const PenPaperImplementationModule1 = () => (
  <div className="space-y-6">
    <div className="border-b border-accent/20 pb-3">
      <h2 className="text-2xl font-bold text-primary mb-1">Simple Implementation Guide</h2>
    </div>
    
    <div className="prose max-w-none">
      <div className="bg-brand-50/50 p-5 rounded-lg border border-brand-100 shadow-sm mb-6">
        <h3 className="text-xl font-semibold text-secondary mb-2">Quick Start Implementation Guide</h3>
        <p className="text-gray-800">
          This streamlined guide provides a simple checklist to help you implement all school growth strategies 
          efficiently, with minimal effort and maximum results. We've broken down the complex implementation process
          into straightforward steps that any school can follow.
        </p>
      </div>

      <div className="mt-6">
        <h3 className="text-lg font-bold text-primary flex items-center gap-2 mb-4">
          <span className="inline-flex items-center justify-center h-7 w-7 rounded-full bg-primary text-white text-sm">1</span>
          The 15-Minute Daily Implementation System
        </h3>
        
        <div className="bg-white p-5 rounded-lg shadow-sm mb-6">
          <p className="text-gray-700 mb-3">
            The most successful schools commit just 15 minutes daily to implementation. This simple approach ensures 
            you make consistent progress without overwhelming your team.
          </p>
          
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="bg-green-100 p-1 rounded-full mt-1">
                <CheckCircle className="h-4 w-4 text-green-700" />
              </div>
              <p className="text-gray-700">
                <span className="font-medium">Morning Mini-Meeting:</span> Begin each day with a 5-minute check-in 
                on your implementation focus for the day.
              </p>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="bg-green-100 p-1 rounded-full mt-1">
                <CheckCircle className="h-4 w-4 text-green-700" />
              </div>
              <p className="text-gray-700">
                <span className="font-medium">One Task Focus:</span> Choose just one implementation task to move 
                forward each day.
              </p>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="bg-green-100 p-1 rounded-full mt-1">
                <CheckCircle className="h-4 w-4 text-green-700" />
              </div>
              <p className="text-gray-700">
                <span className="font-medium">Celebration Tracker:</span> Document small wins to maintain momentum 
                and motivation.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8">
        <h3 className="text-lg font-bold text-primary flex items-center gap-2 mb-4">
          <span className="inline-flex items-center justify-center h-7 w-7 rounded-full bg-primary text-white text-sm">2</span>
          Simple Implementation Checklist
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-white p-5 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <h4 className="font-semibold text-primary mb-3 border-b pb-2 border-gray-100">Month 1: Positioning & Quick Wins</h4>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start gap-2">
                <div className="h-5 w-5 border border-gray-300 rounded-sm mt-0.5 flex-shrink-0"></div>
                <span>Define your school's unique strengths and update messaging</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="h-5 w-5 border border-gray-300 rounded-sm mt-0.5 flex-shrink-0"></div>
                <span>Create a simple parent WhatsApp community</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="h-5 w-5 border border-gray-300 rounded-sm mt-0.5 flex-shrink-0"></div>
                <span>Improve the inquiry handling process</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="h-5 w-5 border border-gray-300 rounded-sm mt-0.5 flex-shrink-0"></div>
                <span>Start sharing future-ready education content</span>
              </li>
            </ul>
          </div>
          
          <div className="bg-white p-5 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <h4 className="font-semibold text-primary mb-3 border-b pb-2 border-gray-100">Month 2-3: Community Building</h4>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start gap-2">
                <div className="h-5 w-5 border border-gray-300 rounded-sm mt-0.5 flex-shrink-0"></div>
                <span>Recruit 3-5 parent ambassadors</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="h-5 w-5 border border-gray-300 rounded-sm mt-0.5 flex-shrink-0"></div>
                <span>Hold a small parent orientation about future-ready skills</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="h-5 w-5 border border-gray-300 rounded-sm mt-0.5 flex-shrink-0"></div>
                <span>Start a weekly value-sharing routine with parents</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="h-5 w-5 border border-gray-300 rounded-sm mt-0.5 flex-shrink-0"></div>
                <span>Implement simple feedback collection system</span>
              </li>
            </ul>
          </div>
          
          <div className="bg-white p-5 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <h4 className="font-semibold text-primary mb-3 border-b pb-2 border-gray-100">Month 4-5: Student Skills Development</h4>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start gap-2">
                <div className="h-5 w-5 border border-gray-300 rounded-sm mt-0.5 flex-shrink-0"></div>
                <span>Introduce High Income Skills Portfolio program to one class</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="h-5 w-5 border border-gray-300 rounded-sm mt-0.5 flex-shrink-0"></div>
                <span>Train 1-2 teachers on portfolio guidance</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="h-5 w-5 border border-gray-300 rounded-sm mt-0.5 flex-shrink-0"></div>
                <span>Organize a simple future career exploration session</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="h-5 w-5 border border-gray-300 rounded-sm mt-0.5 flex-shrink-0"></div>
                <span>Share student success stories with parent community</span>
              </li>
            </ul>
          </div>
          
          <div className="bg-white p-5 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <h4 className="font-semibold text-primary mb-3 border-b pb-2 border-gray-100">Month 6: Growth Consolidation</h4>
            <ul className="space-y-2 text-gray-700">
              <li className="flex items-start gap-2">
                <div className="h-5 w-5 border border-gray-300 rounded-sm mt-0.5 flex-shrink-0"></div>
                <span>Review admission process improvements and results</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="h-5 w-5 border border-gray-300 rounded-sm mt-0.5 flex-shrink-0"></div>
                <span>Expand parent community engagement activities</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="h-5 w-5 border border-gray-300 rounded-sm mt-0.5 flex-shrink-0"></div>
                <span>Organize a small student portfolio showcase</span>
              </li>
              <li className="flex items-start gap-2">
                <div className="h-5 w-5 border border-gray-300 rounded-sm mt-0.5 flex-shrink-0"></div>
                <span>Plan next semester's implementation focus</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <div className="mt-8">
        <h3 className="text-lg font-bold text-primary flex items-center gap-2 mb-4">
          <span className="inline-flex items-center justify-center h-7 w-7 rounded-full bg-primary text-white text-sm">3</span>
          Implementation Success Principles
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-primary mb-2">Start Small, Win Big</p>
            <p className="text-gray-700">Begin with the smallest possible version of any implementation - get a quick win, then build on success.</p>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-primary mb-2">Consistency Over Perfection</p>
            <p className="text-gray-700">Simple actions done consistently create more impact than perfect but inconsistent implementation.</p>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-primary mb-2">Delegate & Engage</p>
            <p className="text-gray-700">Share implementation tasks among team members for ownership and faster results.</p>
          </div>
        </div>
      </div>

      <div className="mt-8 bg-accent/5 p-6 rounded-lg border border-accent/20 shadow-sm">
        <h4 className="font-semibold text-brand-700 mb-4">Implementation Success Stories</h4>
        <p className="text-gray-700 mb-3">
          Schools across India have successfully implemented these strategies with minimal resources:
        </p>
        <ul className="space-y-2 text-gray-700">
          <li className="flex items-start gap-2">
            <div className="h-2.5 w-2.5 rounded-full bg-accent mt-1.5"></div>
            <span>A small school in Tamil Nadu increased admissions by 23% using just the parent community strategy</span>
          </li>
          <li className="flex items-start gap-2">
            <div className="h-2.5 w-2.5 rounded-full bg-accent mt-1.5"></div>
            <span>An Andhra Pradesh school established a strong regional reputation for future-ready education in just 5 months</span>
          </li>
          <li className="flex items-start gap-2">
            <div className="h-2.5 w-2.5 rounded-full bg-accent mt-1.5"></div>
            <span>A rural school improved retention rates by 31% by focusing on the High Income Skills Portfolio program</span>
          </li>
        </ul>
      </div>
      
      <div className="mt-6 p-5 rounded-lg border-l-4 border-accent bg-brand-50 shadow-sm flex items-center gap-3">
        <div className="bg-accent text-white rounded-full p-1.5 flex-shrink-0">
          <CheckCircle className="h-4 w-4" />
        </div>
        <div>
          <b className="text-primary">Remember:</b> Success comes from consistent small steps. Begin with just one implementation area today, and you'll see transformative results within months.
        </div>
      </div>
    </div>
  </div>
);

export default PenPaperImplementationModule1;
