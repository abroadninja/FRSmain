
import React from "react";

/**
 * Playbook 5, Module 3: Fostering a Future-Ready Culture
 */
const Playbook5Module3 = () => (
  <div className="space-y-6">
    <div className="border-b border-accent/20 pb-3">
      <h2 className="text-2xl font-bold text-primary mb-1">Fostering a Future-Ready Culture</h2>
    </div>

    <div className="prose max-w-none">
      <div className="bg-brand-50/50 p-5 rounded-lg border border-brand-100 shadow-sm">
        <h3 className="text-xl font-semibold text-secondary mb-2">Core Principle</h3>
        <p className="text-gray-800">
          Integrate future-ready skills (critical thinking, creativity, collaboration, digital/financial literacy) across all grades, curriculum, and the entire school culture.
        </p>
      </div>
      
      <div className="mt-8">
        <h3 className="text-lg font-bold text-primary flex items-center gap-2 mb-4">
          <span className="inline-flex items-center justify-center h-7 w-7 rounded-full bg-primary text-white text-sm">1</span>
          Actionable Steps
        </h3>
        <div className="grid gap-4 pl-5 border-l-2 border-accent/30">
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Curriculum Audit:</p>
            <p className="text-gray-700">Use framework to evaluate your current curriculum for integration opportunities (critical thinking, problem-solving, etc).</p>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Embed Skills:</p>
            <p className="text-gray-700">Weave these skills into all lesson plans, activities, and assessments.</p>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Promote Independent Learning & Thinking:</p>
            <p className="text-gray-700">Encourage self-direction and project-based work; use assessments and planners to support.</p>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Develop Financial Literacy:</p>
            <p className="text-gray-700">Progressive, grade-wise implementation of saving, budgeting, investing, entrepreneurship. Use frameworks and spreadsheets to roll out a practical, DIY curriculum.</p>
          </div>
        </div>
      </div>
      
      <div className="mt-8 bg-accent/5 p-5 rounded-lg border border-accent/20 shadow-sm">
        <h4 className="font-semibold text-brand-700 mb-4 border-b pb-2 border-accent/10">"Done-For-You" Resources</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Future-Ready Skills Curriculum Outline Template</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Future-Ready Skills Curriculum Audit (Conceptual)</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Self-Learning Readiness Assessment.pdf</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Independent Learning Project Planner.pdf</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Financial Freedom Framework Spreadsheet</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Financial Literacy Curriculum Map Template</span>
          </div>
        </div>
      </div>
      
      <div className="mt-6 p-4 rounded-lg border-l-4 border-accent bg-brand-50 shadow-sm flex items-center gap-3">
        <div className="bg-accent text-white rounded-full p-1.5 flex-shrink-0">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
        </div>
        <div>
          <b className="text-primary">Action Point:</b> Conduct a curriculum audit, introduce independent learning tools, begin planning financial literacy rollout.
        </div>
      </div>
    </div>
  </div>
);

export default Playbook5Module3;
