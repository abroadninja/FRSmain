
import React from "react";
import { CheckCircle, Info } from "lucide-react";
import { 
  Card, 
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

/**
 * Playbook 1, Module 1: Establishing a Powerful and Differentiating Position
 */
const Playbook1Module1 = () => (
  <div className="space-y-8">
    <h2 className="text-2xl font-bold text-primary mb-2">Establishing a Powerful and Differentiating Position</h2>
    
    {/* Core Principle Card */}
    <Card className="border-l-4 border-l-primary">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold text-primary">Core Principle</CardTitle>
      </CardHeader>
      <CardContent className="text-gray-700">
        <p>
          Your school must stand out. You cannot be everything to everyone. School positioning involves creating a distinct 
          and desirable image in parents' minds, differentiating you from competitors. It's about perception, not just 
          offerings. Many schools mistakenly rely on general extracurriculars, but a strategic position is essential. 
          Identify your unique strengths, especially your commitment to future readiness and high-income skill building 
          guidance, and communicate this value clearly.
        </p>
      </CardContent>
    </Card>

    {/* Why Unique Positioning Section */}
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold text-primary">Why Unique Positioning is Crucial</CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="space-y-2 text-gray-700">
          <li className="flex items-start gap-2">
            <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
            <span><span className="font-medium">Stands Out:</span> Makes your school memorable and different.</span>
          </li>
          <li className="flex items-start gap-2">
            <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
            <span><span className="font-medium">Attracts Right Parents:</span> Draws families valuing your unique offer.</span>
          </li>
          <li className="flex items-start gap-2">
            <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
            <span><span className="font-medium">Simplifies Decisions:</span> Helps parents quickly see if your school fits their needs.</span>
          </li>
          <li className="flex items-start gap-2">
            <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
            <span><span className="font-medium">Justifies Value:</span> Allows you to command appropriate fees.</span>
          </li>
        </ul>
      </CardContent>
    </Card>

    {/* New Positioning Card */}
    <Card className="bg-accent/5 border border-accent/20">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold text-primary">The New Positioning Approach</CardTitle>
        <p className="text-md text-gray-600">Holistic Future Readiness & High-Income Skill Building Guidance</p>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-gray-700">
          This positioning tackles real parental concerns about their children's future by offering tangible value. 
          It's easily understood ("future readiness," "high-income skills") and inclusive, aiming to help every student succeed.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
            <h4 className="font-semibold text-primary mb-2">Holistic Future Readiness</h4>
            <p className="text-gray-700 text-sm">
              Preparing students beyond academics with skills like critical thinking, adaptability, digital literacy, 
              problem-solving, creativity, collaboration, self-awareness, and financial literacy. Emphasize preparing 
              students for the future, not just today.
            </p>
          </div>
          <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
            <h4 className="font-semibold text-primary mb-2">High-Income Skill Building</h4>
            <p className="text-gray-700 text-sm">
              Helping students (Grades 8-12) identify, develop, and portfolio-build in-demand skills leading to well-paying 
              careers, including financial literacy. Showcase specific skills and guidance.
            </p>
          </div>
          <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
            <h4 className="font-semibold text-primary mb-2">Thriving Communities</h4>
            <p className="text-gray-700 text-sm">
              Creating supportive parent and student communities working together. Foster belonging.
            </p>
          </div>
          <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
            <h4 className="font-semibold text-primary mb-2">FIRE Coaching</h4>
            <p className="text-gray-700 text-sm">
              Providing coaching on Financial Independence, Retire Early (FIRE) principles, guiding students towards 
              financial freedom and early retirement.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>

    {/* Unbeatable Value */}
    <Card className="bg-primary/5">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold text-primary">Unbeatable Value</CardTitle>
      </CardHeader>
      <CardContent className="text-gray-700">
        <p>
          Our schools now offer a comprehensive package, encompassing thriving parent and student communities, success-oriented 
          and future-ready education, high-income skill building guidance, and financial independence coaching, is unparalleled. 
          No other school, locally or globally, offers this breadth and depth of support. Even if parents wanted to access 
          similar support anywhere or online, it would cost tens of thousands of rupees per month, amounting to a few lakhs 
          in a year. And our schools provide all of them at a normal, affordable school fee to the students and parents.
        </p>
        <p className="mt-3">
          We provide ready-to-use or ready-to-customize systems, strategies, information, and updates to empower your school 
          in this endeavor. These resources will be available through these playbooks, our website (futurereadyschools.com), 
          and our free membership communities.
        </p>
      </CardContent>
    </Card>

    {/* Actionable Steps Section */}
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-bold text-primary">Actionable Steps</h3>
        <div className="flex items-center gap-2 bg-accent/10 px-3 py-1 rounded-full text-sm">
          <Info className="h-4 w-4 text-accent" />
          <span>Focus on Immediate Implementation</span>
        </div>
      </div>
      
      <Card className="border-l-4 border-l-green-500">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg font-semibold text-green-700">1. Leverage "Done-for-You" Positioning</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700 mb-3 font-medium">Use our pre-built materials and skip extensive initial groundwork.</p>
          <ul className="space-y-2 text-gray-700">
            <li className="flex items-start gap-2">
              <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
              <span>Utilize pre-built materials (Websites & Flyers etc,) incorporating this positioning.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
              <span>Skip Initial Homework: Utilize pre-built positioning materials that define your target audience and communicate your unique value.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
              <span>Access Ready-to-Use Materials: Immediately access resources like the Websites & Flyers drive link. These templates require minimal customization.</span>
            </li>
          </ul>
        </CardContent>
      </Card>

      <div className="bg-gray-50 p-6 rounded-xl border border-gray-200">
        <h4 className="text-lg font-semibold text-gray-700 mb-4 flex items-center gap-2">
          <Info className="h-5 w-5 text-blue-600" />
          Optional Steps (if you want to develop your own positioning instead)
        </h4>
        
        <Accordion type="single" collapsible className="space-y-4">
          <AccordionItem value="item-1" className="border rounded-lg bg-white overflow-hidden">
            <AccordionTrigger className="px-4 py-3 hover:bg-gray-50 text-gray-800 font-medium">
              2. Define Your Specific Edge (Internal Work)
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-3 pt-1">
              <ul className="space-y-2 text-gray-700">
                <li>Identify core strengths, especially those supporting future readiness and your ability to offer value at a normal fee. Use framework tools (USP Worksheet, etc.).</li>
                <li>Identify Core Strengths & Differentiators: Know your power. Conduct an internal assessment involving teachers, parents, and students. What do they consistently praise? Are you excelling in future-ready curriculum, exceptional teachers, community focus, STEM, or value? List 3-5 specific core strengths.</li>
                <li>Utilize Frameworks: Use tools like the Ideal Student Profile Template, Unique Selling Proposition (USP) Worksheet, Core Values & Mission Statement Guide, and Competitive Analysis Framework to refine understanding and articulation.</li>
              </ul>
            </AccordionContent>
          </AccordionItem>
          
          <AccordionItem value="item-2" className="border rounded-lg bg-white overflow-hidden">
            <AccordionTrigger className="px-4 py-3 hover:bg-gray-50 text-gray-800 font-medium">
              3. Craft Compelling Messaging
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-3 pt-1">
              <ul className="space-y-3 text-gray-700">
                <li>
                  <p><span className="font-medium">Develop Your USP:</span> Your Unique Selling Proposition is your irresistible promise, your one-liner hook. Avoid weak statements. Your USP must promise a specific, valuable outcome parents desire.</p>
                  <p className="mt-1 text-sm text-gray-600 bg-gray-50 p-2 rounded">Examples: "[School Name]: India's only future-skills focused school," "[School Name]: High-income careers guaranteed," "[School Name]: Where students build high-income skills for a future-proof career," "[School Name]: Fostering a thriving community and future-ready learning at standard fees".</p>
                </li>
                <li>
                  <p>Importantly, this unique value and these distinct advantages are offered at a normal, affordable school fee—a combination unmatched by other schools.</p>
                  <p className="mt-1 text-sm text-gray-600 bg-gray-50 p-2 rounded">Examples: "[School Name]: India's only future-skills focused school at standard fees," "[School Name]: High-income careers guaranteed at an affordable cost," "[School Name]: Where students build high-income skills for a future-proof career, all at a normal fee," "[School Name]: Fostering a thriving community and future-ready learning at standard fees, unlike any other school."</p>
                </li>
              </ul>
            </AccordionContent>
          </AccordionItem>
          
          <AccordionItem value="item-3" className="border rounded-lg bg-white overflow-hidden">
            <AccordionTrigger className="px-4 py-3 hover:bg-gray-50 text-gray-800 font-medium">
              4. Define Your Brand Voice
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-3 pt-1">
              <p className="text-gray-700">
                Ensure it reflects innovation, support, and value. This is your school's personality (e.g., innovative, supportive, authoritative, friendly). Define 3-5 descriptive words. Ensure consistency across all channels (website, social media, brochures, emails). Authenticity builds trust. Use the optional Brand Voice Consistency Checklist.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-4" className="border rounded-lg bg-white overflow-hidden">
            <AccordionTrigger className="px-4 py-3 hover:bg-gray-50 text-gray-800 font-medium">
              5. Employ the DFY Headline & Advantage Arsenal
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-3 pt-1">
              <p className="text-gray-700">
                Select headlines and talking points from "Final Index Notes" that specifically emphasize the combination of future-readiness, high-income skill focus, AND the unbeatable value/normal fee structure. This arsenal provides ready-made, persuasive language specifically designed to make your unique value proposition clear and compelling in your outreach materials, saving you time and maximizing impact even with a limited budget.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-5" className="border rounded-lg bg-white overflow-hidden">
            <AccordionTrigger className="px-4 py-3 hover:bg-gray-50 text-gray-800 font-medium">
              6. Use Powerful Language & Showcase Value
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-3 pt-1">
              <ul className="space-y-2 text-gray-700">
                <li>Employ words reflecting the tone in the DFY Arsenal, like "Transform," "Empower," "Future-proof," "Dominate," "Achievers," "Win," "Unstoppable," "Advantage" where appropriate.</li>
                <li>Highlight the unmatched educational experience we offer at Normal Fees: Emphasize that our school provides a unique and excellent education that other schools, even international schools with very high fees, can't match. We offer this superior education at normal school fees.</li>
              </ul>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-6" className="border rounded-lg bg-white overflow-hidden">
            <AccordionTrigger className="px-4 py-3 hover:bg-gray-50 text-gray-800 font-medium">
              7. Integrate Key Positioning Elements
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-3 pt-1">
              <p className="text-gray-700">
                Immediately integrate these keywords/concepts into all communication: Holistic Future Readiness / Holistic Education; Future-Readiness / Skills for the Future World; High-Income Career Building / Skill Building Guidance; Financial Freedom / Financial Literacy; Global Readiness / Global Mindset; STEM/Tech Focus / AI & Technology Readiness; Thriving Communities; Unbeatable Value / Affordable Excellence.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-7" className="border rounded-lg bg-white overflow-hidden">
            <AccordionTrigger className="px-4 py-3 hover:bg-gray-50 text-gray-800 font-medium">
              8. Highlight "Immediate Implementability"
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-3 pt-1">
              <p className="text-gray-700">
                Show parents value starts now. Parents want fast results. Emphasize that future-ready programs, DFYs, and skill-building start immediately. Use phrases like "Start future-proofing... from Day 1". Highlight "Ready-to-Use" aspects and DFY resources, showcasing complete solutions and instant value. Focus marketing on quick, tangible results ("Skills your child builds in week one," "See progress within the first month"). Use testimonials highlighting quick wins.
              </p>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-8" className="border rounded-lg bg-white overflow-hidden">
            <AccordionTrigger className="px-4 py-3 hover:bg-gray-50 text-gray-800 font-medium">
              9. Craft Your "High-Value Short Pitch"
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-3 pt-1">
              <ul className="space-y-2 text-gray-700">
                <li>Create an Instant Hook: Develop your concise (under 10 words) elevator pitch for website headlines, social media bios, etc. Make it captivating, benefit-driven, and memorable.</li>
                <li>Incorporate Positioning: Integrate chosen key positioning elements.</li>
                <li>Write and Test: Draft 3 different short pitch options. Test them with your team.</li>
              </ul>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="item-9" className="border rounded-lg bg-white overflow-hidden">
            <AccordionTrigger className="px-4 py-3 hover:bg-gray-50 text-gray-800 font-medium">
              10. Implement Immediate Positioning Updates
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-3 pt-1">
              <ul className="space-y-2 text-gray-700">
                <li>Act Today: Update headlines and key content now. Small changes have a massive impact.</li>
                <li>
                  <p>Identify Key Areas: List 5+ places for immediate updates:</p>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-1 mt-2">
                    <span className="bg-gray-50 px-2 py-1 text-xs rounded">Google business profile</span>
                    <span className="bg-gray-50 px-2 py-1 text-xs rounded">Website Homepage</span>
                    <span className="bg-gray-50 px-2 py-1 text-xs rounded">"About Us" page</span>
                    <span className="bg-gray-50 px-2 py-1 text-xs rounded">Key Benefits lists</span>
                    <span className="bg-gray-50 px-2 py-1 text-xs rounded">Brochures</span>
                    <span className="bg-gray-50 px-2 py-1 text-xs rounded">Social Media Profiles</span>
                    <span className="bg-gray-50 px-2 py-1 text-xs rounded">Flyers</span>
                    <span className="bg-gray-50 px-2 py-1 text-xs rounded">Email Signatures</span>
                    <span className="bg-gray-50 px-2 py-1 text-xs rounded">Door hangers</span>
                    <span className="bg-gray-50 px-2 py-1 text-xs rounded">Cold Calling scripts</span>
                  </div>
                </li>
                <li>Delegate and Execute: Assign updates with an end-of-day deadline. Use the Immediate Positioning Updates Checklist.</li>
              </ul>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
    </div>

    {/* Resources Section */}
    <Card className="bg-primary/5 border border-primary/20">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl font-bold text-primary">"Done-For-You" & Foundational Resources</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <h4 className="text-lg font-semibold text-secondary mb-2">Core Positioning & Planning</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <div className="bg-white rounded p-2 text-sm border border-gray-100">
              <span className="block">Ideal Student Profile Template</span>
              <span className="text-blue-600 text-xs">Ideal Student profile template.pdf</span>
            </div>
            <div className="bg-white rounded p-2 text-sm border border-gray-100">
              <span className="block">Unique Selling Proposition (USP) Worksheet</span>
              <span className="text-blue-600 text-xs">Unique selling proposition worksheet.pdf</span>
            </div>
            <div className="bg-white rounded p-2 text-sm border border-gray-100">
              <span className="block">Core Values & Mission Statement Guide</span>
              <span className="text-blue-600 text-xs">Core Values & Mission Statement Guide.pdf</span>
            </div>
            <div className="bg-white rounded p-2 text-sm border border-gray-100">
              <span className="block">Future-Ready Skills Curriculum Outline Template</span>
              <span className="text-blue-600 text-xs">Future-Ready Skills Curriculum Outline Template.pdf</span>
            </div>
            <div className="bg-white rounded p-2 text-sm border border-gray-100">
              <span className="block">Parent Persona Examples</span>
              <span className="text-blue-600 text-xs">Parent Persona Examples.pdf</span>
            </div>
            <div className="bg-white rounded p-2 text-sm border border-gray-100">
              <span className="block">Competitive Analysis Framework</span>
              <span className="text-blue-600 text-xs">Competitive Analysis Framework.pdf</span>
            </div>
          </div>
        </div>

        <div>
          <h4 className="text-lg font-semibold text-secondary mb-2">Messaging & Content Creation</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <div className="bg-white rounded p-2 text-sm border border-gray-100">
              <span className="block">Websites & Flyers (Templates via Drive Link)</span>
              <span className="text-blue-600 text-xs">Websites & Flyers</span>
            </div>
            <div className="bg-white rounded p-2 text-sm border border-gray-100">
              <span className="block">Unbeatable value headlines example.pdf</span>
              <span className="text-blue-600 text-xs">Unbeatable value headlines example.pdf</span>
            </div>
            <div className="bg-white rounded p-2 text-sm border border-gray-100">
              <span className="block">Volume message tool kit.pdf</span>
              <span className="text-blue-600 text-xs">Volume message tool kit.pdf</span>
            </div>
            <div className="bg-white rounded p-2 text-sm border border-gray-100">
              <span className="block">Three complete elevator pitch examples.pdf</span>
              <span className="text-blue-600 text-xs">Three complete elevator pitch examples.pdf</span>
            </div>
            <div className="bg-white rounded p-2 text-sm border border-gray-100">
              <span className="block">Why are we so good and affordable.pdf (Optional)</span>
              <span className="text-blue-600 text-xs">Why are we so good and affordable.pdf</span>
            </div>
          </div>
        </div>

        <div>
          <h4 className="text-lg font-semibold text-secondary mb-2">Implementation & Digital Presence</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <div className="bg-white rounded p-2 text-sm border border-gray-100">
              <span className="block">Immediate Positioning Updates Checklist</span>
              <span className="text-blue-600 text-xs">Immediate Positioning Updates Checklist</span>
            </div>
            <div className="bg-white rounded p-2 text-sm border border-gray-100">
              <span className="block">DFY for Schools: Digital Domination (Drive Link)</span>
              <span className="text-blue-600 text-xs">Digital Domination</span>
            </div>
          </div>
        </div>

        <div>
          <h4 className="text-lg font-semibold text-secondary mb-2">Optional/Related Resources</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <div className="bg-white rounded p-2 text-sm border border-gray-100">
              <span className="block">Brand Voice Consistency Checklist</span>
              <span className="text-blue-600 text-xs">Brand Voice Consistency Checklist</span>
            </div>
            <div className="bg-white rounded p-2 text-sm border border-gray-100">
              <span className="block">Value Proposition 'Amplifier' Worksheet</span>
              <span className="text-blue-600 text-xs">Conceptual DFY Tools</span>
            </div>
            <div className="bg-white rounded p-2 text-sm border border-gray-100">
              <span className="block">Word of mouth velocity multiplier.pdf</span>
              <span className="text-blue-600 text-xs">Word of mouth velocity multiplier.pdf</span>
            </div>
            <div className="bg-white rounded p-2 text-sm border border-gray-100">
              <span className="block">Value-First Communication Checklist.pdf</span>
              <span className="text-blue-600 text-xs">Value-First Communication Checklist.pdf</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>

    {/* Action Point */}
    <div className="bg-accent/10 p-6 rounded-lg flex items-start gap-4 border border-accent/20">
      <div className="bg-accent/20 p-2 rounded-full">
        <CheckCircle className="text-accent h-6 w-6" />
      </div>
      <div>
        <h4 className="font-bold text-lg text-primary mb-1">Action Point Summary</h4>
        <p className="text-gray-700">
          Access and customize Websites & Flyers templates. Perform internal assessment using USP Worksheet, etc. 
          Add them to our unique position, emphasizing future-readiness AND value-for-money. Craft USP and Short Pitch. 
          Define Brand Voice. Update key materials immediately. This message is critical for the next steps. 
          Leverage DFY Digital Domination resources.
        </p>
      </div>
    </div>
  </div>
);

export default Playbook1Module1;
