
import React from "react";

/**
 * Playbook 1, Module 2: Initial Outreach Blitz
 */
const Playbook1Module2 = () => (
  <div className="space-y-6">
    <div className="border-b border-accent/20 pb-3">
      <h2 className="text-2xl font-bold text-primary mb-1">Initial Outreach Blitz (Existing Parents & Local Vicinity)</h2>
    </div>
    
    <div className="prose max-w-none">
      <div className="bg-brand-50/50 p-4 rounded-lg border border-brand-100">
        <h3 className="text-xl font-semibold text-secondary mb-2">Core Principle</h3>
        <p className="text-gray-800">
          With your powerful positioning defined, focus outreach first on the lowest-cost, highest-potential 
          audiences: existing parents and families in your immediate vicinity (2-5 km).
        </p>
      </div>

      <div className="mt-6">
        <h3 className="text-lg font-bold text-primary mb-3">Actionable Steps</h3>
        
        <div className="space-y-6">
          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h4 className="font-semibold text-primary border-b pb-2 flex items-center">
              <span className="inline-flex items-center justify-center h-6 w-6 mr-2 rounded-full bg-primary/10 text-primary font-bold text-sm">1</span>
              Engage Existing Parents (Step 2 - See Playbook 2 for details)
            </h4>
            <div className="mt-3 space-y-2">
              <div className="flex items-start gap-2">
                <span className="text-accent font-semibold mt-1">•</span>
                <p className="text-gray-700"><span className="font-medium text-gray-800">Prerequisite:</span> Before external outreach, communicate your new positioning (Module 1) and the enhanced value (future-readiness, skill guidance, affordability) clearly and enthusiastically to your current parents.</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-accent font-semibold mt-1">•</span>
                <p className="text-gray-700"><span className="font-medium text-gray-800">Goal:</span> Turn them into informed advocates and leverage their trust (See Playbook 2, Module 1 & 2 for community strategies). This builds internal momentum and prepares your referral engine.</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-accent font-semibold mt-1">•</span>
                <p className="text-gray-700"><span className="font-medium text-gray-800">Immediate Action:</span> Draft the core message for your communication (newsletter, meeting script) to existing parents this week. Ensure it clearly explains the new focus (Future-Ready, High-Income Skills) and explicitly highlights the 'Unbeatable Value' at standard fees, using language from the DFY Arsenal.</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h4 className="font-semibold text-primary border-b pb-2 flex items-center">
              <span className="inline-flex items-center justify-center h-6 w-6 mr-2 rounded-full bg-primary/10 text-primary font-bold text-sm">2</span>
              Prioritize Hyper-Local Outreach (Step 3: 2-5 km Radius)
            </h4>
            <div className="mt-3 space-y-2">
              <div className="flex items-start gap-2">
                <span className="text-accent font-semibold mt-1">•</span>
                <p className="text-gray-700"><span className="font-medium text-gray-800">Focus:</span> Concentrate initial external outreach within a 2-5 km radius, focusing on direct interaction where possible. This is the most cost-effective way to attract genuinely interested families for smaller schools.</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-accent font-semibold mt-1">•</span>
                <p className="text-gray-700"><span className="font-medium text-gray-800">Messaging is KEY:</span> All communication in this outreach must clearly convey the unique positioning and value proposition defined in Module 1 (Future-Ready, High-Income Skills, Unbeatable Value at Normal Fees). Use the compelling headlines and advantages from the DFY Arsenal. Tell parents why you are the best, most valuable choice in their neighborhood.</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h4 className="font-semibold text-primary border-b pb-2 flex items-center">
              <span className="inline-flex items-center justify-center h-6 w-6 mr-2 rounded-full bg-primary/10 text-primary font-bold text-sm">3</span>
              The Interaction - Communicate Value & Collect Data
            </h4>
            <div className="mt-3 space-y-2">
              <div className="flex items-start gap-2">
                <span className="text-accent font-semibold mt-1">•</span>
                <p className="text-gray-700"><span className="font-medium text-gray-800">Goal:</span> Don't just drop flyers. Engage parents to explain why your school is the best choice, offering unique value (Future-Ready, High-Income Skills) at a normal fee.</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-accent font-semibold mt-1">•</span>
                <p className="text-gray-700"><span className="font-medium text-gray-800">Messaging:</span> Use your short pitch and key advantages (from Module 1 DFY Arsenal) in conversations. Be prepared to answer questions about your unique approach.</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-accent font-semibold mt-1">•</span>
                <p className="text-gray-700"><span className="font-medium text-gray-800">Data Capture:</span> During positive interactions, aim to collect contact details (Name, WhatsApp number) of interested parents. Use the Lead Enquiry tracking sheet.pdf or a simple notebook initially.</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-accent font-semibold mt-1">•</span>
                <p className="text-gray-700"><span className="font-medium text-gray-800">Community Invitation:</span> Provide interested parents with a specific invitation (small flyer or card, perhaps using Whatsapp community invitation.pdf template adapted) to join your Prospective Parent Outreach Community (See Playbook 2) for ongoing valuable tips and information.</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h4 className="font-semibold text-primary border-b pb-2 flex items-center">
              <span className="inline-flex items-center justify-center h-6 w-6 mr-2 rounded-full bg-primary/10 text-primary font-bold text-sm">4</span>
              Tactics
            </h4>
            <div className="mt-3 space-y-2">
              <div className="flex items-start gap-2">
                <span className="text-accent font-semibold mt-1">•</span>
                <p className="text-gray-700"><span className="font-medium text-gray-800">Hyper-Local Partnerships:</span> Collaborate with preschools, daycares, local businesses within the radius. Arrange brief info sessions or presence during their events to interact with parents, explain your value, collect data, and distribute flyers/community invites.</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-accent font-semibold mt-1">•</span>
                <p className="text-gray-700"><span className="font-medium text-gray-800">Ultra-Local Events:</span> Host small, value-driven events (e.g., "Future Skills Intro," parenting workshop) within the vicinity. Use these events for direct interaction, value delivery, data capture, and community invitation.</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-accent font-semibold mt-1">•</span>
                <p className="text-gray-700"><span className="font-medium text-gray-800">Targeted Flyer/Invite Distribution:</span> Distribute flyers (using DFY templates with your powerful messaging) and community invitation cards in key residential areas, community centers within the 2-5 km zone, perhaps focusing on places where brief interactions might be possible (e.g., community gatherings, local markets - if appropriate).</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-accent font-semibold mt-1">•</span>
                <p className="text-gray-700"><span className="font-medium text-gray-800">Local Notice Boards:</span> Post informative messages.</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-accent font-semibold mt-1">•</span>
                <p className="text-gray-700"><span className="font-medium text-gray-800">Flyer Message Universality:</span> While the distribution tactic is hyper-local, the core positioning message on the flyer itself (Future-Ready, High-Income Skills, Value at Normal Fee) is powerful and generally applicable, reinforcing the conversation.</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-accent font-semibold mt-1">•</span>
                <p className="text-gray-700"><span className="font-medium text-gray-800">Immediate Action:</span> Map your 2-5km radius. Identify 2-3 potential partners (preschools, community centers) or local event opportunities for direct interaction. Prepare your short pitch/talking points based on Module 1. Adapt the community invitation flyer/card. Draft the text for your main flyer using compelling headlines/advantages emphasizing your unique value. Plan one interactive outreach activity/partnership approach for the next 1-2 weeks.</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h4 className="font-semibold text-primary border-b pb-2 flex items-center">
              <span className="inline-flex items-center justify-center h-6 w-6 mr-2 rounded-full bg-primary/10 text-primary font-bold text-sm">5</span>
              Establish Basic Lead Tracking
            </h4>
            <div className="mt-3 space-y-2">
              <div className="flex items-start gap-2">
                <span className="text-accent font-semibold mt-1">•</span>
                <p className="text-gray-700"><span className="font-medium text-gray-800">Document Efforts:</span> Use a simple system (e.g., the "Lead Launchpad" spreadsheet) to track leads from all sources, including specific local interactions/events/partnerships (flyers, local events, partnerships) and existing parent referrals. Note the source.</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-accent font-semibold mt-1">•</span>
                <p className="text-gray-700"><span className="font-medium text-gray-800">Measure:</span> See which hyper-local tactics generate responses or community enrollments or leads. This informs future efforts.</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-accent font-semibold mt-1">•</span>
                <p className="text-gray-700"><span className="font-medium text-gray-800">Immediate Action:</span> Set up the "Lead Launchpad" spreadsheet today. Train staff involved in outreach on collecting contact details and logging the source accurately.</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h4 className="font-semibold text-primary border-b pb-2 flex items-center">
              <span className="inline-flex items-center justify-center h-6 w-6 mr-2 rounded-full bg-primary/10 text-primary font-bold text-sm">6</span>
              Broader Lead Generation (Secondary Focus for Low Budgets)
            </h4>
            <p className="mt-3 text-gray-700">
              Activities like wider social media ads, extensive SEO content (Playbook 7), and events outside the immediate vicinity should be considered after establishing the core positioning and maximizing local/referral efforts, or if budget allows.
            </p>
          </div>
        </div>
      </div>

      <div className="mt-8 bg-accent/5 p-5 rounded-lg border border-accent/20">
        <h4 className="font-semibold text-brand-700 mb-3">"Done-For-You" Resources</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-accent"></div>
            <span>"Lead Launchpad" Spreadsheet Template</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-accent"></div>
            <span>Websites & Flyers Templates (for local distribution)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-accent"></div>
            <span>Outreach event Activity planner.pdf (Optional)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-accent"></div>
            <span>Outreach tracking data.pdf (Optional)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-accent"></div>
            <span>Unbeatable value headlines example.pdf</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-accent"></div>
            <span>Why are we so good and affordable.pdf</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-accent"></div>
            <span>Lead Enquiry tracking sheet.pdf</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-2 w-2 rounded-full bg-accent"></div>
            <span>Whatsapp community invitation.pdf</span>
          </div>
        </div>
        <p className="mt-2 text-gray-700 italic">(Referral resources from Playbook 3 are relevant here too)</p>
      </div>
      
      <div className="mt-6 p-4 rounded-lg border-l-4 border-accent bg-brand-50 flex items-center gap-3">
        <div className="bg-accent text-white rounded-full p-1 flex-shrink-0">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
        </div>
        <div>
          <b className="text-primary">Action Point:</b> Set daily lead targets. Map your 2-5km radius and plan initial hyper-local outreach. Select 1-2 broader lead gen activities. 
          Set up and use the Lead Launchpad spreadsheet. PRIORITY 2: Communicate positioning/value to existing parents (Playbook 2). 
          PRIORITY 3: Plan and execute active hyper-local engagement (2-5km), focusing on communicating value, collecting data, 
          and inviting prospects to the community. Track leads using Lead Launchpad.
        </div>
      </div>
    </div>
  </div>
);

export default Playbook1Module2;
