
import React from "react";

/**
 * Playbook 7, Module 1: Optimizing Your Google Business Profile (GBP)
 */
const Playbook7Module1 = () => (
  <div className="space-y-6">
    <div className="border-b border-accent/20 pb-3">
      <h2 className="text-2xl font-bold text-primary mb-1">Optimizing Your Google Business Profile (GBP)</h2>
    </div>
    
    <div className="prose max-w-none">
      <div className="bg-brand-50/50 p-5 rounded-lg border border-brand-100 shadow-sm">
        <h3 className="text-xl font-semibold text-secondary mb-2">Core Principle</h3>
        <p className="text-gray-800">
          A fully optimized and actively managed Google Business Profile is a powerful, free tool for local school growth. It's your digital front door and often the first impression for parents.
        </p>
      </div>
      
      <div className="mt-8">
        <h3 className="text-lg font-bold text-primary mb-4">Actionable Steps:</h3>
        <div className="grid gap-3 pl-4 md:grid-cols-2">
          <div className="bg-white p-3 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Claim & Verify:</p>
            <p className="text-gray-700">Claim at google.com/business, enter official details, verify by postcard/phone/email.</p>
          </div>
          
          <div className="bg-white p-3 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Ensure Info Consistency:</p>
            <p className="text-gray-700">Double-check Name, Address, Phone are identical everywhere.</p>
          </div>
          
          <div className="bg-white p-3 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Categories/Hours/Website:</p>
            <p className="text-gray-700">Add primary/secondary categories, accurate hours, proper site link.</p>
          </div>
          
          <div className="bg-white p-3 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Compelling Description:</p>
            <p className="text-gray-700">Up to 750 chars, highlight future-ready, high-income guidance, use keywords.</p>
          </div>
          
          <div className="bg-white p-3 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">High-Quality Photos & Videos:</p>
            <p className="text-gray-700">Use clear, consented, relevant images, and short engaging videos.</p>
          </div>
          
          <div className="bg-white p-3 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">List Services/Attributes:</p>
            <p className="text-gray-700">Detail specific programs and features (e.g. "Future-Ready," "Career Guidance").</p>
          </div>
          
          <div className="bg-white p-3 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Encourage & Respond to Reviews:</p>
            <p className="text-gray-700">Actively request good parent reviews, reply to all using provided templates.</p>
          </div>
          
          <div className="bg-white p-3 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Google Posts:</p>
            <p className="text-gray-700">Weekly/regular posting—school news, events, program highlights, with photos/CTAs. Use Google Post Examples/Templates.</p>
          </div>
          
          <div className="bg-white p-3 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Q&amp;A:</p>
            <p className="text-gray-700">Monitor Q&amp;A section, proactively add FAQs and reply fast.</p>
          </div>
          
          <div className="bg-white p-3 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Enable Messaging:</p>
            <p className="text-gray-700">Optional—allow direct parent messages, monitored during school hours.</p>
          </div>
          
          <div className="bg-white p-3 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Monitor Insights:</p>
            <p className="text-gray-700">Track performance/searches/engagement; optimize accordingly.</p>
          </div>
        </div>
      </div>
      
      <div className="mt-8 bg-accent/5 p-5 rounded-lg border border-accent/20 shadow-sm">
        <h4 className="font-semibold text-brand-700 mb-4 border-b pb-2 border-accent/10">"Done-For-You" Resources</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>GBP Optimization Checklist</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>How-to Guides for Claiming GBP, Photos, Reviews, Q&A, Insights</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Review Response & Google Post Templates</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>10 Google Post Examples for Schools, GBP Content Calendar Ideas</span>
          </div>
        </div>
      </div>
      
      <div className="mt-6 p-4 rounded-lg border-l-4 border-accent bg-brand-50 shadow-sm flex items-center gap-3">
        <div className="bg-accent text-white rounded-full p-1.5 flex-shrink-0">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
        </div>
        <div>
          <b className="text-primary">Action Point:</b> Claim your GBP, complete all steps on the checklist, start posting weekly, and respond to reviews/FAQs.
        </div>
      </div>
    </div>
  </div>
);

export default Playbook7Module1;
