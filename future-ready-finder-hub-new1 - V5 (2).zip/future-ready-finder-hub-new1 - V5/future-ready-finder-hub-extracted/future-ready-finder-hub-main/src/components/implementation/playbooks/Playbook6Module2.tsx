
import React from "react";

const Playbook6Module2 = () => {
  return (
    <div className="space-y-6">
      <div className="border-b border-accent/20 pb-3">
        <h2 className="text-2xl font-bold text-primary mb-1">Facilitating High-Income Skill Building Guidance (Without Apps)</h2>
      </div>
      
      <div className="prose max-w-none">
        <div className="bg-brand-50/50 p-5 rounded-lg border border-brand-100 shadow-sm">
          <h3 className="text-xl font-semibold text-secondary mb-2">Core Principle</h3>
          <p className="text-gray-800">
            Provide teachers with practical strategies and resources to deliver effective High-Income Skill Building guidance sessions using simple, manual methods, focusing on resource curation, structured discussions, and portfolio development support.
          </p>
        </div>
        
        <div className="mt-8 space-y-6">
          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h3 className="text-lg font-bold text-primary mb-3 flex items-center gap-2">
              <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-primary text-white text-sm">1</span>
              Implement a Manual Tracking System
            </h3>
            <div className="space-y-3 pl-4 border-l-2 border-accent/20">
              <p className="text-gray-700">
                <span className="font-medium">Simple Tracking:</span> Since dedicated apps aren't assumed, equip teachers with simple manual tracking methods. A dedicated notebook or a shared digital document (like Google Docs/Sheets) per student group can work.
              </p>
              
              <p className="text-gray-700">
                <span className="font-medium">Track Key Info:</span> For each student (or cluster group discussion), note down: interests discussed, skills identified/practiced, portfolio ideas/progress, resources shared, and any action items assigned.
              </p>
            </div>
          </div>
          
          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h3 className="text-lg font-bold text-primary mb-3 flex items-center gap-2">
              <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-primary text-white text-sm">2</span>
              Structure Guidance Sessions Effectively
            </h3>
            <div className="space-y-4 pl-4 border-l-2 border-accent/20">
              <p className="text-gray-700">
                <span className="font-medium">Use Defined Structures:</span> Employ the Initial Setup Session(s) and Ongoing Guidance Session structures (40+ mins each) outlined previously.
              </p>
              
              <p className="text-gray-700">
                <span className="font-medium">Time Management:</span> Divide time effectively among the four career cluster groups (approx. 7-8 mins per group rotation in ongoing sessions). Use a timer.
              </p>
              
              <div>
                <p className="font-medium text-gray-800 mb-2">Facilitation Techniques:</p>
                <div className="bg-brand-50/30 p-4 rounded-md">
                  <p className="text-gray-700 mb-2">Train teachers on:</p>
                  <ul className="space-y-2 pl-4">
                    <li className="flex items-start gap-2">
                      <div className="h-2 w-2 rounded-full bg-accent mt-2"></div>
                      <div>
                        <span className="font-medium">Managing Groups:</span> Using designated areas, optional student leaders, assigning independent work during rotations.
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="h-2 w-2 rounded-full bg-accent mt-2"></div>
                      <div>
                        <span className="font-medium">Engaging Discussions:</span> Using open-ended questions, Think-Pair-Share, real-world examples, celebrating wins.
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="h-2 w-2 rounded-full bg-accent mt-2"></div>
                      <div>
                        <span className="font-medium">Addressing Learning Styles:</span> Adapting communication (visual, auditory, kinesthetic, reading/writing).
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="h-2 w-2 rounded-full bg-accent mt-2"></div>
                      <div>
                        <span className="font-medium">Handling Questions:</span> Creating a safe space, listening actively, providing clear answers or directing to further resources.
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="h-2 w-2 rounded-full bg-accent mt-2"></div>
                      <div>
                        <span className="font-medium">Maintaining Positivity:</span> Showing enthusiasm, focusing on growth, celebrating effort.
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
              
              <p className="text-gray-700">
                <span className="font-medium">Leverage Detailed Guidance:</span> Ensure teachers utilize the Detailed Guidance for Teachers on Delivering High-Income Skill Building Guidance Sessions for specific strategies.
              </p>
            </div>
          </div>
          
          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h3 className="text-lg font-bold text-primary mb-3 flex items-center gap-2">
              <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-primary text-white text-sm">3</span>
              Curate and Share Resources Manually
            </h3>
            <div className="space-y-3 pl-4 border-l-2 border-accent/20">
              <p className="text-gray-700">
                <span className="font-medium">Apply Curation Strategy:</span> Teachers must actively find, evaluate, and share free/low-cost learning materials (links, document names, key websites) using the principles from the Resource Curation Strategy for Teachers.
              </p>
              
              <div>
                <p className="font-medium text-gray-800 mb-2">Sharing Methods:</p>
                <div className="bg-brand-50/30 p-4 rounded-md">
                  <p className="text-gray-700 mb-2">Use agreed-upon channels like:</p>
                  <ul className="space-y-2 pl-4">
                    <li className="flex items-start gap-2">
                      <div className="h-2 w-2 rounded-full bg-accent mt-2"></div>
                      <div>
                        <span className="font-medium">WhatsApp Groups:</span> Share direct links with brief descriptions.
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="h-2 w-2 rounded-full bg-accent mt-2"></div>
                      <div>
                        <span className="font-medium">Shared Online Documents (Google Docs):</span> Organize resources by cluster/topic for ongoing access.
                      </div>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="h-2 w-2 rounded-full bg-accent mt-2"></div>
                      <div>
                        <span className="font-medium">Classroom Board:</span> Write key website names or resource titles.
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
              
              <p className="text-gray-700">
                <span className="font-medium">Keywords & Platforms:</span> Remind teachers of keywords and reputable platforms (Coursera, edX, Khan Academy, NPTEL, SWAYAM, YouTube channels, etc.) for finding resources.
              </p>
            </div>
          </div>
          
          <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <h3 className="text-lg font-bold text-primary mb-3 flex items-center gap-2">
              <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-primary text-white text-sm">4</span>
              Guide Portfolio Building (Manually)
            </h3>
            <div className="space-y-3 pl-4 border-l-2 border-accent/20">
              <p className="text-gray-700">
                <span className="font-medium">Explain Concepts:</span> Use the General Portfolio Building Guidance for Students to explain the 'what' and 'why'.
              </p>
              
              <p className="text-gray-700">
                <span className="font-medium">Brainstorm & Feedback:</span> During group rotations, facilitate brainstorming of relevant project ideas and provide feedback on ongoing student projects.
              </p>
              
              <p className="text-gray-700">
                <span className="font-medium">Document Ideas:</span> Encourage students to document project ideas and progress in their own notebooks or digital files.
              </p>
            </div>
          </div>
        </div>
        
        <div className="mt-8 bg-accent/5 p-5 rounded-lg border border-accent/20 shadow-sm">
          <h4 className="font-semibold text-brand-700 mb-4 border-b pb-2 border-accent/10">"Done-For-You" Resources</h4>
          
          <div className="mb-5">
            <p className="mb-2 font-medium text-gray-700">Core Guidance & Strategies:</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Detailed Guidance for Teachers on Delivering High-Income Skill Building Guidance Sessions</span>
              </div>
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Resource Curation Strategy for Teachers</span>
              </div>
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>General Portfolio Building Guidance for Students (Teacher reference for guiding students)</span>
              </div>
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Discussion Driver Flowchart.pdf (Optional - for structuring discussions)</span>
              </div>
            </div>
          </div>
          
          <div>
            <p className="mb-2 font-medium text-gray-700">Additional Resources:</p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Critical Thinking Skill Builder Toolkit</span>
              </div>
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Student Success Tracker</span>
              </div>
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>AI & Tech Opportunity Assessment Checklist</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-6 p-5 rounded-lg border-l-4 border-accent bg-brand-50 shadow-sm flex items-center gap-3">
          <div className="bg-accent text-white rounded-full p-1.5 flex-shrink-0">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
          </div>
          <div>
            <p className="font-bold text-primary">Action Point:</p>
            <p className="text-gray-700">Train teachers on using a simple manual system (notebook/shared doc) for tracking guidance sessions. Equip them with the Detailed Guidance, Resource Curation Strategy, and Portfolio Building Guidance documents. Practice session facilitation techniques and resource sharing via WhatsApp/shared docs.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Playbook6Module2;
