
import React from "react";
import { CheckCircle } from "lucide-react";

/**
 * Playbook 2, Module 2: Multiplied Outreach DFY
 */
const Playbook2Module2 = () => (
  <div className="space-y-6">
    <div className="border-b border-accent/20 pb-3">
      <h2 className="text-2xl font-bold text-primary mb-1">Multiplied Outreach DFY (Tiny Budget): Broadcast & Targeted Communities</h2>
    </div>
    
    <div className="prose max-w-none">
      <div className="bg-brand-50/50 p-5 rounded-lg border border-brand-100 shadow-sm">
        <h3 className="text-xl font-semibold text-secondary mb-2">Core Principle</h3>
        <p className="text-gray-800">
          Leverage one-to-many communication (broadcast) and distinct community groups for efficient outreach, relationship 
          building, loyalty, and lead nurturing on zero/tiny budget.
        </p>
      </div>

      <div className="mt-8">
        <h3 className="text-lg font-bold text-primary flex items-center gap-2 mb-4">
          <span className="inline-flex items-center justify-center h-7 w-7 rounded-full bg-primary text-white text-sm">1</span>
          Actionable Steps
        </h3>
        
        <div className="space-y-4 pl-5 border-l-2 border-accent/30">
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Set up Basic Broadcast Channels:</p>
            <div className="text-gray-700">
              <p><span className="font-medium">Choose Platform:</span> WhatsApp Broadcast Lists or Telegram Channels. Use DFY Tool 1.1.</p>
              <p><span className="font-medium">Build Lists:</span> Systematically collect contacts for both existing parents and prospective parents (from enquiries, events, local outreach). Keep lists separate where appropriate for targeted messaging.</p>
              <p><span className="font-medium">Purpose:</span> Quick updates, sharing broad value snippets, announcements, event invites.</p>
              <p><span className="font-medium">Immediate Action:</span> Choose platform(s), set up channels/lists, start collecting contacts systematically.</p>
            </div>
          </div>

          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Create and Manage Targeted Parent Communities:</p>
            <div className="text-gray-700">
              <p><span className="font-medium">Platform Choice:</span> WhatsApp or Telegram Groups.</p>
              
              <div className="mt-3 border-l-2 border-accent/20 pl-3">
                <h5 className="font-medium text-primary mb-2">Structure - Two Key Types:</h5>
                
                <div className="space-y-3">
                  <div className="bg-white/80 p-3 rounded-md shadow-sm border border-accent/5">
                    <h6 className="font-medium text-accent mb-1">A) Existing Parent Community Hub(s)</h6>
                    <p><span className="font-medium">Purpose:</span> Inform about positioning/implementation. Deepen relationships with current families, provide specific updates, foster loyalty, gather feedback, activate ambassadors. Membership should ideally be part of the school experience.</p>
                    <p><span className="font-medium">Structure:</span> Can be one main group or segmented by grade.</p>
                    <p><span className="font-medium">Content Focus:</span> Updates on Future Readiness/High-Income Skill program implementation, school news/events relevant to them, opportunities for feedback, sharing student successes (general or class-specific), reminders, prompts for referral program, customized updates about their children (requires careful planning for privacy/scalability).</p>
                  </div>
                  
                  <div className="bg-white/80 p-3 rounded-md shadow-sm border border-accent/5">
                    <h6 className="font-medium text-accent mb-1">B) Prospective Parent Community (e.g., "Future-Ready Families Forum")</h6>
                    <p><span className="font-medium">Purpose:</span> Nurture leads from local outreach and other channels, build trust with non-enrolled parents, showcase school's value proposition subtly, provide general value, invite to open events/webinars. Position as a valuable resource, not just a sales channel.</p>
                    <p><span className="font-medium">Structure:</span> Typically one main group for prospects in the vicinity/interested parents.</p>
                    <p><span className="font-medium">Content Focus:</span> General parenting tips related to future-readiness, insights into education trends, links to valuable articles/resources, Q&A sessions on future skills, invitations to free workshops or school tours, showcasing school differentiators through success stories or program snippets (value-first approach).</p>
                  </div>
                </div>
              </div>
              
              <p className="mt-3"><span className="font-medium">Goal:</span> Foster relevant communication, build rapport within each group type, create loyalty (existing) or trust (prospects), generate word-of-mouth/referrals.</p>
            </div>
          </div>

          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Setup:</p>
            <div className="text-gray-700 space-y-1">
              <p><span className="font-medium">Craft Community Cornerstones:</span> Use Parent Community Guidelines Template Pack (DFY Tool 1.2) - adapt slightly for each community type. Define clear Purpose Statements for each.</p>
              <p><span className="font-medium">Send Invitations/Add Members:</span> Use Whatsapp community invitation.pdf for the Prospective Parent group. Add Existing Parents directly via school communication channels, explaining the hub's purpose.</p>
              <p><span className="font-medium">Welcome New Members:</span> Use Parent community welcome message template.pdf (adapt for each group type) and Welcome Message Template & Onboarding Sequence Guide (DFY Tool 1.3).</p>
              <p><span className="font-medium">Immediate Action:</span> Set up both community types - both Existing Parent Hub(s) and Prospective Parent Outreach Community. Create the groups, finalize guidelines/purpose, prepare welcome messages. Add existing parents and send invites to initial prospects today/soon.</p>
            </div>
          </div>

          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Implement "Perpetual Touchpoint" Strategy (Tailored):</p>
            <div className="text-gray-700">
              <p><span className="font-medium">Goal:</span> Maintain consistent, valuable communication appropriate for each community type (informing existing vs. nurturing prospects).</p>
              
              <p><span className="font-medium">Broadcast Value Snippets:</span> Use broadcast for general value applicable to both groups (parenting tips, future trend insights) or segment broadcasts for group-specific announcements.</p>
              
              <div className="mt-3 pl-3 border-l-2 border-accent/20">
                <h5 className="font-medium text-primary mb-2">Community Engagement (Tailored):</h5>
                <div className="space-y-1">
                  <p><span className="font-medium">Content:</span> Use Parent Community Content Calendar Template and Content Theme & Topic Idea Bank, but select and adapt content for each community's purpose. Existing Parents get implementation updates and broader value; Prospects get broader value.</p>
                  <p><span className="font-medium">Interaction:</span> Implement Q&A. Use Discussion Starters relevant to each group's focus. Encourage peer support, especially in Existing Parent Hub. Ensure Q&A/discussions reinforce school's unique approach.</p>
                  <p><span className="font-medium">Nurturing:</span> Welcome new members, recognize active members, moderate, run contests/challenges relevant to each group. Use Community Growth Compass (Flowchart).</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8 bg-accent/5 p-5 rounded-lg border border-accent/20 shadow-sm">
        <h4 className="font-semibold text-brand-700 mb-4 border-b pb-2 border-accent/10">"Done-For-You" Resources</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-2">
          <div>
            <h5 className="font-medium text-secondary mb-2">Community Setup & Communication</h5>
            <div className="space-y-1">
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Whatsapp community invitation.pdf</span>
              </div>
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Parent community welcome message template.pdf</span>
              </div>
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Follow up templates for whatsapp.pdf</span>
              </div>
            </div>
          </div>

          <div>
            <h5 className="font-medium text-secondary mb-2">Content & Engagement</h5>
            <div className="space-y-1">
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Parent Community Content Calendar Template</span>
              </div>
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Content Theme & Topic Idea Bank for Parents.pdf</span>
              </div>
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Parent Community Q&A Management Guide</span>
              </div>
            </div>
          </div>
          
          <div>
            <h5 className="font-medium text-secondary mb-2">Planning & Tools</h5>
            <div className="space-y-1">
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Community Growth Compass (Flowchart)</span>
              </div>
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Broadcast Channel Selection Matrix (Conceptual)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mt-6 p-4 rounded-lg border-l-4 border-accent bg-brand-50 shadow-sm flex items-center gap-3">
        <div className="bg-accent text-white rounded-full p-1.5 flex-shrink-0">
          <CheckCircle className="h-4 w-4" />
        </div>
        <div>
          <b className="text-primary">Action Point:</b> Set up separate structures/groups for Existing Parents and Prospective Parents. Finalize tailored guidelines 
          and welcome messages. Prepare to onboard prospects from local outreach. Plan first week's tailored content 
          and engagement prompts for each group type.
        </div>
      </div>
    </div>
  </div>
);

export default Playbook2Module2;
