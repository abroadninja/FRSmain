
import React from "react";
import { Link } from "react-router-dom";
import { BookOpen, Search, Rocket, Brain, Activity, Users, FileText, Lightbulb } from "lucide-react";

/**
 * High Income Skills Portfolio Building Guidance - Module 4: Starting to Build Skills & Your Portfolio
 */
const HighIncomeSkillsModule4 = () => (
  <div className="space-y-8">
    <div className="border-b-2 border-accent/30 pb-4">
      <h2 className="text-2xl font-bold text-primary mb-2">Module 4: Starting to Build Skills & Your Portfolio (Collection of Work)</h2>
      <p className="text-gray-600 italic">Encouraging students to try learning practical skills through beginner projects, using online resources, 
        and starting to collect examples of their work.</p>
    </div>
    
    <div className="prose max-w-none">
      {/* Focus Area Card */}
      <div className="bg-brand-50/50 p-6 rounded-lg border border-brand-200 shadow-sm">
        <h3 className="text-xl font-semibold text-secondary mb-3 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-secondary/10 rounded-full text-secondary">
            <Lightbulb className="h-5 w-5" />
          </span>
          Focus Area
        </h3>
        <p className="text-gray-800 text-lg">
          Encouraging students to try learning practical skills through beginner projects, using online resources, 
          and starting to collect examples of their work.
        </p>
      </div>
      
      {/* Teacher Session Guide */}
      <div className="mt-10">
        <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
            <BookOpen className="h-5 w-5" />
          </span>
          For Teachers: Session Guide (Approx. 60 minutes, adaptable)
        </h3>
        
        <div className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
          {/* Preparation */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Preparation (Before Class)</h4>
            </div>
            <div className="p-6">
              <ul className="space-y-3 pl-5 list-disc text-gray-700">
                <li>Review the example Learning & Career Roadmaps (see below). Choose 1-2 to highlight on the board.</li>
                <li>Prepare for a simple in-class skill challenge.</li>
                <li>Think about how students can simply document their work initially (notebook, phone notes folder, dedicated WhatsApp group for sharing progress photos/text with you).</li>
              </ul>
            </div>
          </div>
          
          {/* Introduction */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Introduction: From Knowing to Doing (5-10 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Motivate students to apply what they've learned and start practicing skills.</p>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md">
                  <p><strong className="text-blue-800">Say something like:</strong> "We've explored jobs and learned how to learn using tools like Google and AI. 
                    Now it's time for the exciting part: actually doing things and building skills! Just knowing about driving isn't enough; 
                    you need to practice driving. Similarly, to get good at any skill, you need to practice. 
                    Even small steps and simple projects help you learn and show others what you can do."</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Activity 1 */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Activity 1: Introducing Skill Areas & Roadmaps (15-20 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Introduce a few relevant skill areas and the concept of a learning plan (Roadmap).</p>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md">
                  <p><strong className="text-blue-800">Say:</strong> "Based on the jobs we explored, let's look at a few skill areas many of you might find interesting and useful, 
                    even for local opportunities. Examples include Content Writing (writing clearly online), 
                    Basic Graphic Design (making simple visuals), or helping with Social Media."</p>
                </div>
                <div className="bg-purple-50 border-l-4 border-purple-300 p-4 rounded-r-md mt-4">
                  <p><strong className="text-purple-800">Board Work:</strong> Choose ONE skill (e.g., Content Writing). Briefly show its Learning Roadmap on the board.</p>
                </div>
                <div className="bg-green-50 border-l-4 border-green-300 p-4 rounded-r-md mt-4">
                  <p><strong className="text-green-800">Teacher:</strong> "A Learning Roadmap is like a map showing you the steps from beginner to advanced. 
                    For Content Writing: Step 1 is understanding 'What is it?' using keywords we learned last time. 
                    Step 2 is finding tools..." (Explain 2-3 steps simply). "See how the skills from Module 3 help you follow this map?"</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Activity 2 */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Activity 2: Your "Collection of Work" (Skill Portfolio in Your Notebook) (15-20 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Introduce the idea of saving proof of their work in a dedicated notebook.</p>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md">
                  <p><strong className="text-blue-800">Say:</strong> "As you practice and create things – even simple things – you need a place to keep track of them! 
                    This collection proves your skills and learning journey. Let's call it your 'Skill Portfolio', 
                    and your main tool for this will be a dedicated Notebook. This notebook will become a valuable record of your growth."</p>
                </div>
                <div className="bg-purple-50 border-l-4 border-purple-300 p-4 rounded-r-md mt-4">
                  <p><strong className="text-purple-800">Board Work:</strong> Show the Career Roadmap concept.</p>
                </div>
                <div className="bg-green-50 border-l-4 border-green-300 p-4 rounded-r-md mt-4">
                  <p><strong className="text-green-800">Teacher:</strong> "A Career Roadmap shows how practice leads to opportunities. 
                    Step 1 is building your Skill Portfolio – start by doing small projects. 
                    Step 2 is Documenting – how do you save proof in your notebook? You can write descriptions of what you did, 
                    paste in small sketches or printouts if possible later, write down feedback you received, reflect on what you learned. 
                    Step 3 is getting experience... Step 4 is looking at future roles..."</p>
                </div>
                <div className="bg-amber-50 border-l-4 border-amber-300 p-4 rounded-r-md mt-4">
                  <p><strong className="text-amber-800">Emphasize:</strong> "Start today! Dedicate a notebook just for this program and your skills. 
                    Write down the mini-project you try (from Module 4 task), what you learned, maybe even draw a simple picture if relevant. 
                    This notebook is your proof!"</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Activity 3 */}
          <div>
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Activity 3: Simple Skill Challenge (In-Class) (15-20 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Give immediate, simple practice and build confidence.</p>
                <p>Choose ONE challenge based on student interest/time:</p>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md">
                  <p><strong className="text-blue-800">Option A (Content):</strong> "In groups, think about a local shop. 
                    Write 2-3 sentences describing it attractively for a social media post." 
                    (Groups write on paper/share verbally).</p>
                </div>
                <div className="bg-green-50 border-l-4 border-green-300 p-4 rounded-r-md mt-4">
                  <p><strong className="text-green-800">Option B (Design):</strong> "Individually or in pairs, quickly sketch an idea on paper 
                    for a simple poster advertising a school event (e.g., Sports Day)."</p>
                </div>
                <div className="bg-purple-50 border-l-4 border-purple-300 p-4 rounded-r-md mt-4">
                  <p><strong className="text-purple-800">Option C (Social Media):</strong> "In groups, brainstorm 3 ideas for interesting 
                    WhatsApp Status updates or Instagram posts related to your town (e.g., a beautiful spot, a local festival, a helpful tip)."</p>
                </div>
                <div className="bg-amber-50 border-l-4 border-amber-300 p-4 rounded-r-md mt-4">
                  <p><strong className="text-amber-800">Teacher Role:</strong> Encourage participation, give positive feedback on effort and ideas. 
                    Connect it back: "See? You just created something for your 'Collection of Work'!"</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* WhatsApp Message Section */}
      <div className="mt-10">
        <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
            <FileText className="h-5 w-5" />
          </span>
          For Students: WhatsApp Message (Send after the session)
        </h3>
        <div className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
          <div className="bg-green-50 p-6 rounded-lg">
            <h4 className="font-semibold text-gray-800 text-lg mb-4 pb-2 border-b border-green-200">Subject: High Income Skills: Building Your Skills & Portfolio! 🚀</h4>
            <div className="space-y-4 text-gray-700">
              <p>"Hi everyone! Today we moved from learning to DOING! 💪 Remember, skills grow with practice, and your 'Collection of Work' proves what you can do!</p>
              
              <div className="bg-white rounded-md p-5 border border-gray-200">
                <p className="font-medium text-gray-800 border-b pb-2 mb-3">Your Tasks:</p>
                <ol className="space-y-2 list-decimal ml-5">
                  <li>
                    <strong className="text-primary">Choose & Explore:</strong> Pick ONE skill area you want to try first (e.g., Content Writing, Graphic Design, 
                    Social Media Assistant). Use its Learning Roadmap (keywords on WhatsApp) to search Google/YouTube for 
                    beginner tutorials (Step 1 & 2).
                  </li>
                  <li>
                    <strong className="text-primary">Try a Mini-Project:</strong> Watch one beginner tutorial and try a very small practice task related to it.
                  </li>
                  <li>
                    <strong className="text-primary">Document & Share:</strong> Save your mini-project (write it down, take a photo/screenshot). 
                    Share what you tried (and maybe your work!) in your WhatsApp study group. Ask questions if you get stuck!
                  </li>
                </ol>
              </div>
              
              <p>Start building your portfolio today! Every small step counts. 🌱 Help each other in your groups!</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Parent Note Section */}
      <div className="mt-10">
        <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
            <Users className="h-5 w-5" />
          </span>
          For Parents: Note to Share with Parents (via WhatsApp or simple printout)
        </h3>
        <div className="p-6 border-l-4 border-brand-400 bg-brand-50 rounded-lg shadow-sm">
          <div className="space-y-4">
            <h4 className="font-semibold text-primary text-lg">Subject: Supporting Your Child's Skill Development</h4>
            <p className="text-gray-700">
              "Dear Parents, In our High Income Skills Portfolio Building program, we're now encouraging students to start practicing useful skills and collecting examples of their work. This hands-on approach helps build confidence and creates a foundation for future opportunities.
            </p>
            <div>
              <p className="font-medium text-gray-800 mb-2">Ways you can support at home:</p>
              <ul className="ml-6 list-disc space-y-2 text-gray-700">
                <li><strong className="text-secondary">Encourage Practice:</strong> When your child attempts small projects or practical tasks, offer encouragement. Remember that imperfect attempts are valuable learning experiences.</li>
                <li><strong className="text-secondary">Provide a Notebook:</strong> If possible, provide a simple notebook where they can store their work samples, notes, and learnings.</li>
                <li><strong className="text-secondary">Show Interest:</strong> Ask about what they're learning and trying. Even if the topic is unfamiliar to you, your interest shows them that their efforts matter.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Example Learning & Career Roadmaps */}
      <div className="mt-10">
        <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
            <Rocket className="h-5 w-5" />
          </span>
          Example Learning & Career Roadmaps
        </h3>
        
        <div className="space-y-6">
          {/* Roadmap 1 */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <h4 className="text-xl font-semibold text-primary mb-2">ROADMAP 1: Content Writing (Writing for Online)</h4>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="font-medium text-blue-800 mb-1">What is it?</p>
                  <p>Writing clear and engaging text for websites, blogs, social media, emails etc.</p>
                </div>
                <div className="bg-green-50 p-4 rounded-lg mt-3">
                  <p className="font-medium text-green-800 mb-1">Why Learn?</p>
                  <p>Many businesses need good writers (English or Regional language!). Can work from anywhere.</p>
                </div>
              </div>
              
              <div className="flex-1">
                <div className="bg-white border border-gray-200 rounded-lg p-4">
                  <p className="font-medium text-primary mb-2">LEARNING Roadmap:</p>
                  <ol className="list-decimal ml-5 space-y-2">
                    <li><strong>Understand:</strong> Search "what is content writing simple explanation", "content writing basics in [Your Language]". Ask AI "Explain content writing simply."</li>
                    <li><strong>Tools:</strong> Mainly need good language skills. Practice typing (search "free typing practice online"). Use simple notes apps or Google Docs (free).</li>
                    <li><strong>Practice:</strong> Search "content writing exercises for beginners". Try: Write short descriptions, headlines, simple blog post ideas.</li>
                    <li><strong>Next Level (Future):</strong> Learn about SEO writing, copywriting, writing for different platforms. Search "learn SEO writing basics".</li>
                  </ol>
                </div>
                
                <div className="bg-white border border-gray-200 rounded-lg p-4 mt-4">
                  <p className="font-medium text-primary mb-2">CAREER Roadmap:</p>
                  <ol className="list-decimal ml-5 space-y-2">
                    <li><strong>Collection:</strong> Write sample articles (200-300 words) on topics you like, rewrite existing ads simply, write sample social media posts.</li>
                    <li><strong>Document:</strong> Save in a folder (digital/physical). Maybe start a free blog (Blogger, WordPress.com) to post your samples.</li>
                    <li><strong>Experience:</strong> Offer to write for school newsletter, local community group, or help a small local shop with their website/social media text (maybe free first). Enter online writing challenges.</li>
                    <li><strong>Roles (Future):</strong> Freelance Writer, Junior Content Writer, Copywriter Assistant.</li>
                    <li><strong>Growth:</strong> Specialize (e.g., writing for travel, tech, local news), build reputation, learn marketing skills.</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          
          {/* Roadmap 2 */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <h4 className="text-xl font-semibold text-primary mb-2">ROADMAP 2: Basic Graphic Design (Using Free Tools)</h4>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="bg-purple-50 p-4 rounded-lg">
                  <p className="font-medium text-purple-800 mb-1">What is it?</p>
                  <p>Creating visuals (images, posters, logos, social media posts) using design principles and tools.</p>
                </div>
                <div className="bg-pink-50 p-4 rounded-lg mt-3">
                  <p className="font-medium text-pink-800 mb-1">Why Learn?</p>
                  <p>Visuals are everywhere online! Needed by businesses, schools, individuals. Fun & creative.</p>
                </div>
              </div>
              
              <div className="flex-1">
                <div className="bg-white border border-gray-200 rounded-lg p-4">
                  <p className="font-medium text-primary mb-2">LEARNING Roadmap:</p>
                  <ol className="list-decimal ml-5 space-y-2">
                    <li><strong>Understand:</strong> Search "what is graphic design basics", "elements of design simple explanation". Ask AI "Explain graphic design to a beginner."</li>
                    <li><strong>Tools:</strong> Start with Canva (free app & website). Search "Canva tutorial for beginners mobile [Your Language]". Explore other free tools like Pixlr, GIMP (more advanced).</li>
                    <li><strong>Practice:</strong> Search "simple graphic design practice projects", "Canva practice exercises". Try: Design simple quotes images, event posters, social media posts, birthday cards. Recreate simple designs you see.</li>
                    <li><strong>Next Level (Future):</strong> Learn design theory (color, typography), advanced tools (Photoshop/Illustrator basics), UI/UX design basics. Search "learn color theory basics", "typography basics".</li>
                  </ol>
                </div>
                
                <div className="bg-white border border-gray-200 rounded-lg p-4 mt-4">
                  <p className="font-medium text-primary mb-2">CAREER Roadmap:</p>
                  <ol className="list-decimal ml-5 space-y-2">
                    <li><strong>Collection:</strong> Create sample designs (social media posts, flyers, simple logos for imaginary businesses, presentations). Focus on clean, clear designs.</li>
                    <li><strong>Document:</strong> Save designs as images (JPG/PNG) in a folder. Maybe use a free portfolio site (Canva has one) or a simple blog/social media page (Instagram) to showcase work.</li>
                    <li><strong>Experience:</strong> Design posters/social media graphics for school events, help local NGOs/shops with simple designs (maybe free/low cost). Participate in online design challenges (e.g., Daily Logo Challenge prompts).</li>
                    <li><strong>Roles (Future):</strong> Freelance Designer (for simple tasks), Graphic Design Assistant, Social Media Designer.</li>
                    <li><strong>Growth:</strong> Specialize (e.g., social media graphics, presentation design), learn advanced software, build a strong portfolio, learn client communication.</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
          
          {/* Roadmap 3 */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <h4 className="text-xl font-semibold text-primary mb-2">ROADMAP 3: Social Media Assistant</h4>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="bg-amber-50 p-4 rounded-lg">
                  <p className="font-medium text-amber-800 mb-1">What is it?</p>
                  <p>Helping businesses, organizations, or individuals manage their presence on social media platforms.</p>
                </div>
                <div className="bg-teal-50 p-4 rounded-lg mt-3">
                  <p className="font-medium text-teal-800 mb-1">Why Learn?</p>
                  <p>Almost everyone uses social media! Businesses need help to connect with customers online. High demand, can often work remotely.</p>
                </div>
              </div>
              
              <div className="flex-1">
                <div className="bg-white border border-gray-200 rounded-lg p-4">
                  <p className="font-medium text-primary mb-2">LEARNING Roadmap:</p>
                  <ol className="list-decimal ml-5 space-y-2">
                    <li><strong>Understand:</strong> Search "social media marketing basics explained", "how businesses use social media". Ask AI "Why is social media important for local businesses?".</li>
                    <li><strong>Tools:</strong> Know common platforms (Facebook, Instagram, WhatsApp). Learn basic features of each (creating posts, stories, using hashtags). Explore scheduling tools basics (like Meta Business Suite - free).</li>
                    <li><strong>Practice:</strong> Create practice posts for an imaginary business. Study successful accounts in your area of interest. Search "sample social media calendar for small business".</li>
                    <li><strong>Next Level (Future):</strong> Learn about creating content plans, scheduling, analytics, working with different content types (text, images, video).</li>
                  </ol>
                </div>
                
                <div className="bg-white border border-gray-200 rounded-lg p-4 mt-4">
                  <p className="font-medium text-primary mb-2">CAREER Roadmap:</p>
                  <ol className="list-decimal ml-5 space-y-2">
                    <li><strong>Collection:</strong> Create sample social media posts for imaginary businesses. Put together simple content calendars. Document engagement strategies.</li>
                    <li><strong>Document:</strong> Save screenshots of your practice posts, content ideas, strategy notes in your portfolio.</li>
                    <li><strong>Experience:</strong> Offer to help manage social media for school events, small local shops, community groups. Create and share content that showcases your understanding.</li>
                    <li><strong>Roles (Future):</strong> Social Media Assistant, Digital Marketing Assistant, Community Manager.</li>
                    <li><strong>Growth:</strong> Specialize in specific platforms, learn about paid advertising, develop content creation skills (writing, photography, video).</li>
                  </ol>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Resources Section */}
      <div className="mt-8 bg-blue-50 p-6 rounded-lg border border-blue-100 shadow-sm">
        <div className="flex items-center gap-3 text-blue-800 mb-4">
          <Search className="h-5 w-5" />
          <h4 className="font-bold text-lg">Supporting Resources</h4>
        </div>
        <p className="mb-4 text-gray-700">
          These interactive tools can help students explore different career paths based on their interests and strengths:
        </p>
        <div className="flex flex-wrap gap-3">
          <Link 
            to="/implementation-guides/high-income-skills/keywords" 
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            <Search className="h-4 w-4" /> Keyword & Prompt Library
          </Link>
          <Link 
            to="/career-explorer/clusters" 
            className="inline-flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
          >
            <Rocket className="h-4 w-4" /> Career Cluster Explorer
          </Link>
          <Link 
            to="/career-explorer/problem-solving" 
            className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors"
          >
            <Brain className="h-4 w-4" /> Problem-Based Career Matching
          </Link>
          <Link 
            to="/career-explorer/assessment" 
            className="inline-flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700 transition-colors"
          >
            <Activity className="h-4 w-4" /> Psychometric Career Assessment
          </Link>
        </div>
      </div>
    </div>
  </div>
);

export default HighIncomeSkillsModule4;
