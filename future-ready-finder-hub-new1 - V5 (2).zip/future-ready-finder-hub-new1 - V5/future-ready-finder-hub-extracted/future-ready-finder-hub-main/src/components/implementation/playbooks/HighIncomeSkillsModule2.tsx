
import React from "react";
import { Link } from "react-router-dom";
import { Search, Briefcase, GraduationCap, Brain, Activity, FileText, Users } from "lucide-react";

/**
 * High Income Skills Portfolio Building Guidance - Module 2: Exploring Different Ways to Earn a Good Future
 */
const HighIncomeSkillsModule2 = () => (
  <div className="space-y-8">
    <div className="border-b-2 border-accent/30 pb-4">
      <h2 className="text-2xl font-bold text-primary mb-2">Module 2: Exploring the World of Work & Skills for Good Jobs</h2>
      <p className="text-gray-600 italic">Broadening students' understanding of different job types, industries, and skills needed, including new and emerging opportunities. Introduce the idea of specialized 'niche' areas.</p>
    </div>
    
    <div className="prose max-w-none">
      {/* Focus Area Card */}
      <div className="bg-brand-50/50 p-6 rounded-lg border border-brand-200 shadow-sm">
        <h3 className="text-xl font-semibold text-secondary mb-3 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-secondary/10 rounded-full text-secondary">
            <Briefcase className="h-5 w-5" />
          </span>
          Focus Area
        </h3>
        <p className="text-gray-800 text-lg">
          Broadening students' understanding of different job types, industries, and the skills needed, including new and emerging opportunities. Introduce the idea of specialized 'niche' areas.
        </p>
      </div>
      
      {/* Teacher Session Guide */}
      <div className="mt-10">
        <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
            <GraduationCap className="h-5 w-5" />
          </span>
          For Teachers: Session Guide (Approx. 60-90 minutes, adaptable)
        </h3>
        
        <div className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
          {/* Preparation */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Preparation (Before Class)</h4>
            </div>
            <div className="p-6">
              <ul className="space-y-3 pl-5 list-disc text-gray-700">
                <li>Review career exploration resources to share with students (see resource links at bottom of page).</li>
                <li>Prepare the blackboard/whiteboard to write down job types and categories.</li>
                <li>Think about 1-2 examples of people you know (or know of) with interesting jobs you can briefly mention.</li>
                <li>Plan for group discussions.</li>
              </ul>
            </div>
          </div>
          
          {/* Introduction */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Introduction: Why Explore Jobs Now? (10-15 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Connect Module 1 (Knowing Yourself) to Module 2 (Exploring Options).</p>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md">
                  <p><strong className="text-blue-800">Say something like:</strong> "Last time, we talked about understanding ourselves – what we enjoy and what we are good at. Now, let's explore the huge world of jobs and work out there! Why is this important? Because knowing the options helps you connect your interests and strengths to a future path. The world is changing fast, and there are many jobs today that didn't exist a few years ago, especially jobs using computers and the internet."</p>
                </div>
                <div className="bg-green-50 border-l-4 border-green-300 p-4 rounded-r-md mt-4">
                  <p><strong className="text-green-800">Activity:</strong> Ask students: "What jobs do people in our town or families do?" List responses on the board (e.g., Farmer, Teacher, Shopkeeper, Doctor, Driver, Tailor). Acknowledge these are important jobs. Then ask, "What other kinds of jobs have you heard of, maybe seen on TV or online?" Add these (e.g., Engineer, Police, Scientist, Computer work).</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Job Categories */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Introducing Job Categories (15-20 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Show that jobs can be grouped, and there's a wide variety.</p>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md">
                  <p><strong className="text-blue-800">Say:</strong> "There are SO many jobs! Let's try to group them to understand better."</p>
                </div>
                <p><strong className="text-primary">Board Work:</strong> Write down simple categories and give 1-2 examples for each. Encourage students to suggest jobs that fit. (Adapt categories based on what feels right for your students):</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <div className="bg-purple-50 p-4 rounded-md">
                    <p className="font-medium text-purple-800 mb-2">Helping People:</p>
                    <p>Doctor, Nurse, Teacher, Customer Service</p>
                  </div>
                  <div className="bg-orange-50 p-4 rounded-md">
                    <p className="font-medium text-orange-800 mb-2">Building & Making Things:</p>
                    <p>Farmer, Construction worker, Engineer, Tailor, Factory worker, Cook</p>
                  </div>
                  <div className="bg-pink-50 p-4 rounded-md">
                    <p className="font-medium text-pink-800 mb-2">Creative Jobs (Using Imagination):</p>
                    <p>Writer, Artist, Designer, Video Maker, Musician</p>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-md">
                    <p className="font-medium text-blue-800 mb-2">Computer & Online Jobs:</p>
                    <p>Computer Repair, Online Seller, Social Media Helper, Website Designer</p>
                  </div>
                  <div className="bg-green-50 p-4 rounded-md">
                    <p className="font-medium text-green-800 mb-2">Business & Money Jobs:</p>
                    <p>Shopkeeper, Accountant, Salesperson, Bank Worker</p>
                  </div>
                  <div className="bg-amber-50 p-4 rounded-md">
                    <p className="font-medium text-amber-800 mb-2">Science & Discovery Jobs:</p>
                    <p>Scientist, Lab Worker, Researcher</p>
                  </div>
                </div>
                <div className="bg-yellow-50 border-l-4 border-yellow-300 p-4 rounded-r-md mt-3">
                  <p><strong className="text-yellow-800">Teacher Note:</strong> Briefly mention that many jobs today mix these categories (e.g., an online seller uses computers AND business skills).</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Skills for Good Jobs */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Spotlight on "Skills for Good Jobs" & New Opportunities (10-15 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Introduce the idea that certain skills are valuable across many jobs, especially new ones.</p>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md">
                  <p><strong className="text-blue-800">Say:</strong> "While there are many different jobs, many good jobs today – especially those that might pay well in the future – require similar 'Skills for Success'. These often involve using computers, communicating clearly, solving problems, and learning new things. Many new jobs are appearing in areas like Digital Marketing (helping businesses online), Content Creation (making videos or writing for the internet), Data Analysis (understanding information), and more. Many of these can even be done from home with a computer and internet!"</p>
                </div>
                <div className="bg-indigo-50 border-l-4 border-indigo-300 p-4 rounded-r-md mt-3">
                  <p><strong className="text-indigo-800">Introduce Career Explorer Tools:</strong> "We have access to several digital tools that can help you explore different careers based on your interests and strengths. We'll be using these resources throughout our high income skill portfolio building program to help you discover potential paths."</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Group Activity */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Group Activity: Job Exploration (15-20 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Get students thinking about what specific jobs involve.</p>
                <p><strong className="text-primary">Instructions:</strong> In small groups, assign each group one job (from step 3) or give them 1-2 specific job titles (e.g., Graphic Designer, Social Media Manager, Electrician, Online Tutor).</p>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md">
                  <p><strong className="text-blue-800">Say:</strong> "In your group, discuss the job(s) you were given. What do you think a person in that job does all day? What skills might they need? You don't need to know the exact answer – just discuss your ideas."</p>
                </div>
                <p><strong className="text-primary">Teacher Role:</strong> Circulate, listen, prompt thinking ("What tools might they use?", "Who do they talk to?").</p>
              </div>
            </div>
          </div>
          
          {/* Niches */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Concept of Niches (Optional, 5-10 minutes, if time permits or for older students)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Introduce specialization.</p>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md">
                  <p><strong className="text-blue-800">Say:</strong> "Think about doctors. Some are general doctors, but some are specialists – like a skin doctor (dermatologist) or a heart doctor (cardiologist). They focused on one specific area. This is called a 'niche' (pronounced 'neesh'). In many job areas, becoming very good at one specific part can be valuable. For example, instead of just 'digital marketing', someone might specialize only in helping restaurants with online ads. That's a niche!"</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Home Task */}
          <div>
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Assign Home Task (5 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Encourage independent research into specific careers.</p>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md">
                  <p><strong className="text-blue-800">Say:</strong> "Your task is to become a 'Job Detective'! Use your phones to explore 2-3 jobs that sound interesting to you. Use the keywords we will share on WhatsApp."</p>
                </div>
                <p><strong className="text-primary">Explain the task clearly</strong> (also send via WhatsApp):</p>
                <div className="bg-green-50 border border-green-200 rounded-md p-4">
                  <p>"Task: Choose 2 or 3 jobs (from the categories we discussed or any job you are curious about). Use Google/Gemini to find out:"</p>
                  <ul className="space-y-2 pl-5 list-disc mt-2">
                    <li>"1. What does a person in this job typically DO?"</li>
                    <li>"2. What skills seem important for this job?"</li>
                    <li>"3. (Optional) Is this job growing? What is a possible salary range in India (understand this can vary a LOT)?"</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* WhatsApp Message Section */}
      <div className="mt-10">
        <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
            <FileText className="h-5 w-5" />
          </span>
          For Students: WhatsApp Message (Send after the session)
        </h3>
        <div className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
          <div className="bg-green-50 p-6 rounded-lg">
            <h4 className="font-semibold text-gray-800 text-lg mb-4 pb-2 border-b border-green-200">Subject: High Income Skills: Explore Amazing Jobs! 🕵️‍♀️🕵️‍♂️</h4>
            <div className="space-y-4 text-gray-700">
              <p>"Hi everyone, Today we opened the door to the world of jobs! 🚪 Remember, exploring options helps you find the right path. Here's your 'Job Detective' mission:</p>
              
              <div className="bg-white rounded-md p-5 border border-gray-200">
                <p className="font-medium text-gray-800 border-b pb-2 mb-3">Your Task:</p>
                <ul className="space-y-3 pl-5 list-disc">
                  <li><strong className="text-primary">Choose:</strong> Pick 2-3 jobs that interest you. (Ideas: Look at the categories we discussed, or think about jobs related to Computers, Art, Helping Others, Building things, Business, Science, etc.)</li>
                  <li><strong className="text-primary">Research:</strong> Use Google/Gemini to find answers to these questions for EACH job:
                    <ul className="space-y-2 pl-5 list-disc mt-2">
                      <li>What do they DO? (Main tasks)</li>
                      <li>What SKILLS are needed? (e.g., Good communication, Math, Computer use, Creativity?)</li>
                      <li>(Optional) Is this job in demand? What is a possible starting salary in India? (Search for this info carefully, it varies!)</li>
                    </ul>
                  </li>
                </ul>
              </div>
              
              <div className="bg-white rounded-md p-5 border border-gray-200">
                <p className="font-medium text-gray-800 border-b pb-2 mb-3">Search Keywords/Prompts to Help You:</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div className="bg-blue-50 p-3 rounded-md">
                    <ul className="space-y-1 pl-5 list-disc">
                      <li>what does a [Job Title] do (e.g., what does a graphic designer do)</li>
                      <li>skills needed for [Job Title] (e.g., skills needed for digital marketing)</li>
                      <li>[Job Title] salary in India for beginners</li>
                      <li>[Job Title] career path</li>
                    </ul>
                  </div>
                  <div className="bg-purple-50 p-3 rounded-md">
                    <ul className="space-y-1 pl-5 list-disc">
                      <li>[Job Title] meaning in [Your Regional Language]</li>
                      <li>Is [Job Title] a good career in India</li>
                      <li>(Ask AI): Tell me about the job of a [Job Title]. What are the main tasks and required skills?</li>
                      <li>(Ask AI): What are some high-demand jobs in India right now related to [Industry]?</li>
                      <li>(Ask AI): Explain what a 'niche' job is with examples.</li>
                    </ul>
                  </div>
                </div>
              </div>
              
              <p>Share what you find in your study groups! What jobs seem most interesting? See you next time!"</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Parent Note Section */}
      <div className="mt-10">
        <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
            <Users className="h-5 w-5" />
          </span>
          For Parents: Note to Share with Parents (via WhatsApp or simple printout)
        </h3>
        <div className="p-6 border-l-4 border-brand-400 bg-brand-50 rounded-lg shadow-sm">
          <div className="space-y-4">
            <h4 className="font-semibold text-primary text-lg">Subject: Helping Your Child Explore Future Job Ideas</h4>
            <p className="text-gray-700">
              "Dear Parents, As part of our 'High Income Skills Portfolio Building' program, students are now exploring different types of jobs and the skills needed for them. We are looking at traditional jobs as well as new opportunities, especially those using computers and the internet.
            </p>
            <div>
              <p className="font-medium text-gray-800 mb-2">How you can help:</p>
              <ul className="ml-6 list-disc space-y-2 text-gray-700">
                <li><strong className="text-secondary">Discuss:</strong> Talk about different jobs you know. Share your own work experience or that of people you know.</li>
                <li><strong className="text-secondary">Be Open:</strong> Encourage your child to explore various fields, even ones unfamiliar to you. The job market is changing!</li>
                <li><strong className="text-secondary">Value Skills:</strong> Talk about the importance of learning skills like communication, problem-solving, and using technology, as these are useful in many jobs.</li>
                <li><strong className="text-secondary">Support Research:</strong> If possible, allow them time to use a phone to search for information about jobs that interest them. Your encouragement helps them dream big! Thank you."</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>

    {/* Resources Section */}
    <div className="mt-8 bg-blue-50 p-6 rounded-lg border border-blue-100 shadow-sm">
      <div className="flex items-center gap-3 text-blue-800 mb-4">
        <Search className="h-5 w-5" />
        <h4 className="font-bold text-lg">Career Exploration Resources</h4>
      </div>
      <p className="mb-4 text-gray-700">
        These interactive tools can help students explore different career paths based on their interests and strengths:
      </p>
      <div className="flex flex-wrap gap-3">
        <Link 
          to="/implementation-guides/high-income-skills/keywords" 
          className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          <Search className="h-4 w-4" /> Keyword & Prompt Library
        </Link>
        <Link 
          to="/career-explorer/clusters" 
          className="inline-flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
        >
          <Briefcase className="h-4 w-4" /> Career Cluster Explorer
        </Link>
        <Link 
          to="/career-explorer/problem-solving" 
          className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors"
        >
          <Brain className="h-4 w-4" /> Problem-Based Career Matching
        </Link>
        <Link 
          to="/career-explorer/assessment" 
          className="inline-flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700 transition-colors"
        >
          <Activity className="h-4 w-4" /> Psychometric Career Assessment
        </Link>
      </div>
    </div>
  </div>
);

export default HighIncomeSkillsModule2;
