
import React from "react";
import { CheckCircle } from "lucide-react";

/**
 * Playbook 3, Module 1: Simple & Effective Admission Process
 */
const Playbook3Module1 = () => (
  <div className="space-y-6">
    <div className="border-b border-accent/20 pb-3">
      <h2 className="text-2xl font-bold text-primary mb-1">Simple & Effective Admission Process</h2>
    </div>
    
    <div className="prose max-w-none">
      <div className="bg-brand-50/50 p-5 rounded-lg border border-brand-100 shadow-sm">
        <h3 className="text-xl font-semibold text-secondary mb-2">Core Principle</h3>
        <p className="text-gray-800">
          A streamlined, easy, and friction-free admission process significantly increases conversion rates. 
          Make it easy for parents to say "Yes". Efficiency multiplies output.
        </p>
      </div>

      <div className="mt-8">
        <h3 className="text-lg font-bold text-primary flex items-center gap-2 mb-4">
          <span className="inline-flex items-center justify-center h-7 w-7 rounded-full bg-primary text-white text-sm">1</span>
          Actionable Steps
        </h3>
        
        <div className="space-y-4 pl-5 border-l-2 border-accent/30">
          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Develop a Simplified Enquiry-to-Admission Flowchart:</p>
            <div className="text-gray-700 space-y-2">
              <p><span className="font-medium">Map Current Process:</span> Visualize your current admission journey from the first enquiry (call, website form, walk-in) to final enrollment. Identify every step involved.</p>
              <p><span className="font-medium">Identify Bottlenecks & Friction:</span> Pinpoint where you are losing leads. Common issues include long response times, confusing forms, excessive paperwork, long waits, and unclear communication. Track drop-off rates at each stage to find leaks.</p>
              <p><span className="font-medium">Simplify & Eliminate:</span> Critically evaluate each step. Can it be simplified, combined, or eliminated? Simplify forms, reduce paperwork, shorten waiting times. Refer to conceptual resources like Admission Easy Flow and Conversion Catalyst Flowchart for ideas. An easy process boosts conversions.</p>
              <p><span className="font-medium">Immediate Action:</span> Draw your current admission flowchart. Identify at least 3 steps to simplify or eliminate today. Use the Conversion funnel analyzer.pdf to diagnose leaks.</p>
            </div>
          </div>

          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Create a "Perpetual Communication" System for Leads:</p>
            <div className="text-gray-700 space-y-2">
              <p><span className="font-medium">Never Let Leads Go Cold:</span> Don't rely solely on manual follow-ups, which are inconsistent. Implement automated sequences for consistent nurturing.</p>
              
              <div className="bg-brand-50/30 p-3 rounded-md mt-2">
                <p className="font-medium text-primary text-sm mb-1">Example Automated Sequence:</p>
                <ul className="list-disc ml-6 space-y-1 text-gray-600">
                  <li><span className="font-medium">Msg 1 (Immediate):</span> Welcome, thank you, link to valuable resources (e.g., parent guide, future-ready info).</li>
                  <li><span className="font-medium">Msg 2 (Day 2):</span> Highlight USP, share success story, invite to tour/webinar.</li>
                  <li><span className="font-medium">Msg 3 (Day 5):</span> Spotlight value-added service/program, mention special offer, share testimonial.</li>
                  <li><span className="font-medium">Msg 4 (Day 7):</span> Reminder about deadlines/limited seats, final CTA (apply, book call).</li>
                </ul>
              </div>
              
              <p className="mt-2">Use templates like Admission Inquiry Handling EmailWhatsApp.pdf, Follow up templates for whatsapp.pdf (includes tips for hot/warm/cold leads), and Follow-up Email_WhatsApp Templates.pdf. Note: Prioritize WhatsApp in India, but consider email for upscale schools.</p>
              <p><span className="font-medium">Value-Driven Newsletter Sign-up:</span> Offer a valuable parent newsletter sign-up at enquiry to keep leads engaged long-term.</p>
              <p><span className="font-medium">Personalized Follow-up:</span> Supplement automation with personalized messages (WhatsApp) or calls for high-potential leads, addressing specific concerns.</p>
              <p><span className="font-medium">Immediate Action:</span> Set up a basic 3-4 message automated follow-up sequence. Add a newsletter sign-up to your enquiry page/form. Outline a personalized follow-up process.</p>
            </div>
          </div>

          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Implement Efficient Lead Management:</p>
            <div className="text-gray-700 space-y-2">
              <p><span className="font-medium">Centralize Lead Collection:</span> Stop scattering leads. Use a centralized system like the Lead Enquiry tracking sheet.pdf. This includes sheets for basic parent details and follow-up tracking. Start with Excel/Google Sheets if needed. Consider free CRM tools later (e.g., HubSpot Free, Zoho Free). Use the Lead Command Center template idea.</p>
              <p><span className="font-medium">Track Key Information:</span> Log Lead Source, Parent Name/Contact, Student Grade/Interests, Enquiry Date/Time, Follow-up Status (Initial Contacted, Tour Scheduled, Application Submitted, etc.), Notes (conversation history), Conversion Status (Enrolled/Lost).</p>
              <p><span className="font-medium">Track Engagement & Funnel Progress:</span> Monitor follow-up effectiveness. Track email open/click rates, message/call response rates, and conversion rates at each funnel stage (Enquiry → Tour → Application → Enrollment). Use the optional Follow-up Effectiveness Tracking Sheet.pdf or integrate into the main tracker. Analyze data to optimize.</p>
              <p><span className="font-medium">Lead Scoring (Optional):</span> Use the optional Lead Scoring & Categorization Guide.pdf to identify hot, warm, or cold leads and tailor follow-up. Focus on simple categorization if needed.</p>
              <p><span className="font-medium">Immediate Action:</span> Set up your lead tracking sheet/system today. Train your team to log every lead immediately and update diligently. Implement basic engagement tracking.</p>
            </div>
          </div>

          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Train & Equip Admission Counselors:</p>
            <div className="text-gray-700 space-y-2">
              <p><span className="font-medium">Provide Training:</span> Use the Training Outline for Admission Counselors.pdf to structure training.</p>
              <p><span className="font-medium">Equip with Sales Arsenal:</span> Give counselors tools to convert enquiries using The_Unbeatable Value_Admission Counselor Sales Arsenal.pdf.</p>
              <p><span className="font-medium">Develop Powerful Scripts:</span> Guide conversations using Powerful Admission Counselor Script.pdf.</p>
              <p><span className="font-medium">Handle Objections:</span> Prepare counselors with the optional Objection Handling Guide & Script Snippets.pdf.</p>
              <p><span className="font-medium">Post-Tour Follow-Up:</span> Implement structured follow-up after tours using the optional Post-Tour Follow-up Sequence & Templates.pdf. Use the optional School Tour Blueprint & Best Practices.pdf.</p>
              <p><span className="font-medium">Immediate Action:</span> Ensure your admissions team has access to and is trained on the core Arsenal and Script documents.</p>
            </div>
          </div>

          <div className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow">
            <p className="font-semibold text-gray-800 mb-1">Optimize Enquiry Response Time and Quality:</p>
            <div className="text-gray-700 space-y-2">
              <p><span className="font-medium">Speed Wins:</span> Respond within minutes (aim for &lt;15 min). Use automated acknowledgments immediately.</p>
              <p><span className="font-medium">Quality Matters More:</span> Personalize responses, address specific questions, show genuine interest. Use templates efficiently but personalize key sections.</p>
              <p><span className="font-medium">Immediate Action:</span> Implement a system for rapid response. Personalize enquiry response templates.</p>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-8 bg-accent/5 p-5 rounded-lg border border-accent/20 shadow-sm">
        <h4 className="font-semibold text-brand-700 mb-4 border-b pb-2 border-accent/10">"Done-For-You" Resources</h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h5 className="font-medium text-secondary mb-2">Process & Flowcharts</h5>
            <div className="space-y-1">
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Admission Easy Flow (Flowchart)</span>
              </div>
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Conversion funnel analyzer.pdf</span>
              </div>
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Conversion Catalyst Flowchart</span>
              </div>
            </div>
          </div>

          <div>
            <h5 className="font-medium text-secondary mb-2">Lead Management & Tracking</h5>
            <div className="space-y-1">
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Lead Enquiry tracking sheet.pdf</span>
              </div>
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Follow-up Effectiveness Tracking Sheet.pdf</span>
              </div>
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Lead Scoring & Categorization Guide.pdf</span>
              </div>
            </div>
          </div>

          <div>
            <h5 className="font-medium text-secondary mb-2">Communication & Follow-up</h5>
            <div className="space-y-1">
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Admission Inquiry Handling EmailWhatsApp.pdf</span>
              </div>
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Follow up templates for whatsapp.pdf</span>
              </div>
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Follow-up Email_WhatsApp Templates.pdf</span>
              </div>
            </div>
          </div>

          <div>
            <h5 className="font-medium text-secondary mb-2">Counselor Training & Scripts</h5>
            <div className="space-y-1">
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Training Outline for Admission Counselors.pdf</span>
              </div>
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>The_Unbeatable Value_Admission Counselor Sales Arsenal.pdf</span>
              </div>
              <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
                <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
                <span>Powerful Admission Counselor Script.pdf</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mt-6 p-4 rounded-lg border-l-4 border-accent bg-brand-50 shadow-sm flex items-center gap-3">
        <div className="bg-accent text-white rounded-full p-1.5 flex-shrink-0">
          <CheckCircle className="h-4 w-4" />
        </div>
        <div>
          <b className="text-primary">Action Point:</b> Draw current admission flowchart, identify 3+ simplifications. Set up lead tracking 
          and automated follow-up. Ensure counselors use Sales Arsenal/Scripts. Implement a rapid, 
          quality inquiry response system.
        </div>
      </div>
    </div>
  </div>
);

export default Playbook3Module1;
