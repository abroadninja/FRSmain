
import React from "react";
import { Link } from "react-router-dom";
import { BookOpen, Search, Rocket, Brain, Activity, Users, FileText, Lightbulb } from "lucide-react";

/**
 * High Income Skills Portfolio Building Guidance - Module 5: Communication & Collaboration
 */
const HighIncomeSkillsModule5 = () => (
  <div className="space-y-8">
    <div className="border-b-2 border-accent/30 pb-4">
      <h2 className="text-2xl font-bold text-primary mb-2">Module 5: Communication & Collaboration</h2>
      <p className="text-gray-600 italic">Helping students communicate ideas clearly (written and spoken), work effectively in teams, and give/receive helpful feedback.</p>
    </div>
    
    <div className="prose max-w-none">
      {/* Focus Area Card */}
      <div className="bg-brand-50/50 p-6 rounded-lg border border-brand-200 shadow-sm">
        <h3 className="text-xl font-semibold text-secondary mb-3 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-secondary/10 rounded-full text-secondary">
            <Lightbulb className="h-5 w-5" />
          </span>
          Focus Area
        </h3>
        <p className="text-gray-800 text-lg">
          Helping students communicate ideas clearly (written and spoken), work effectively in teams, and give/receive helpful feedback.
        </p>
      </div>
      
      {/* Teacher Session Guide */}
      <div className="mt-10">
        <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
            <BookOpen className="h-5 w-5" />
          </span>
          For Teachers: Session Guide (Approx. 60 minutes, adaptable)
        </h3>
        
        <div className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
          {/* Preparation */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Preparation (Before Class)</h4>
            </div>
            <div className="p-6">
              <ul className="space-y-3 pl-5 list-disc text-gray-700">
                <li>Review the "How-To" Tips section below.</li>
                <li>Prepare examples of clear vs. unclear written messages (maybe related to school or the program).</li>
                <li>Plan for group discussion and role-playing activities. Have the "Feedback Sandwich" idea ready to explain.</li>
              </ul>
            </div>
          </div>
          
          {/* Introduction */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Introduction: Why Talk About Talking (and Listening)? (5-10 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Highlight the importance of communication and teamwork in all areas of life.</p>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md">
                  <p><strong className="text-blue-800">Say something like:</strong> "You might be great at coding, designing, or writing, but if you can't explain your ideas clearly 
                    or work well with others, it's hard to succeed. Good communication isn't just about talking; it's also about writing clearly 
                    (like in WhatsApp or emails), listening carefully, and understanding others. Teamwork means combining everyone's strengths to 
                    achieve a common goal. These skills are needed everywhere – in jobs, in families, and among friends."</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Activity 1 */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Activity 1: Clear Messages Matter (15-20 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Improve clarity in written communication, especially in digital formats.</p>
                <div className="bg-purple-50 border-l-4 border-purple-300 p-4 rounded-r-md">
                  <p><strong className="text-purple-800">Discussion/Board Work:</strong> Show examples of unclear messages (e.g., vague requests, too much slang, 
                    typos, no context) vs. clear messages (e.g., clear purpose stated upfront, simple language, polite tone, checked for errors). 
                    Discuss why clarity is important (saves time, avoids misunderstandings).</p>
                </div>
                <div className="bg-green-50 border-l-4 border-green-300 p-4 rounded-r-md mt-4">
                  <p><strong className="text-green-800">Group Activity:</strong> Give groups a scenario (e.g., "Ask your study group to find information about [topic] 
                    before the next meeting" or "Inform your teacher you couldn't complete the home task"). 
                    Have them write a clear, concise WhatsApp message for the scenario. Groups share and compare.</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Activity 2 */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Activity 2: Teamwork Makes the Dream Work (15-20 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Discuss elements of effective group work.</p>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md">
                  <p><strong className="text-blue-800">Discussion:</strong> "Think about your study groups or any team activity. What makes a group work well together?" 
                    (Guide towards: listening to everyone, sharing ideas, respecting different opinions, staying focused on the task, 
                    dividing work fairly, helping each other). "What makes group work difficult?" 
                    (Guide towards: someone not participating, someone dominating, arguments, distractions).</p>
                </div>
                <div className="bg-amber-50 border-l-4 border-amber-300 p-4 rounded-r-md mt-4">
                  <p><strong className="text-amber-800">Connect:</strong> "Good communication is key to good teamwork. Remember the group study tips from Module 3? They help here too!"</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Activity 3 */}
          <div className="border-b border-gray-100">
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Activity 3: Helpful Feedback (Not Criticism) (15-20 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Teach how to give and receive constructive feedback.</p>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md">
                  <p><strong className="text-blue-800">Introduce "Feedback Sandwich":</strong> "Giving feedback helps others improve, and receiving it helps us improve. 
                    But it should be helpful, not hurtful. A good way is the 'Sandwich Method':</p>
                    <ul className="ml-6 list-disc mt-2">
                      <li><strong>Bread (Positive):</strong> Start with something specific you liked or thought was good.</li>
                      <li><strong>Filling (Improvement):</strong> Gently suggest ONE specific area for improvement. 
                        Use "I" statements (e.g., "I found it a bit hard to read this part") instead of "You" statements 
                        ("You wrote this badly"). Focus on the work, not the person.</li>
                      <li><strong>Bread (Positive):</strong> End with encouragement or another positive comment.</li>
                    </ul>
                </div>
                <div className="bg-green-50 border-l-4 border-green-300 p-4 rounded-r-md mt-4">
                  <p><strong className="text-green-800">Practice/Role-play:</strong> Have students pair up or in small groups. Ask them to give feedback on the mini-projects 
                    shared from Module 4 (or the in-class challenge). Guide them to use the sandwich method. Also discuss receiving feedback: 
                    "Listen openly, don't argue immediately, ask questions if you don't understand (e.g., 'Can you explain what you mean by...?'), 
                    and say 'Thank you for the feedback'."</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Activity 4 */}
          <div>
            <div className="bg-gray-50 px-6 py-3">
              <h4 className="font-semibold text-lg text-gray-800">Activity 4: Speaking Clearly (Simple Presentation) (10-15 minutes)</h4>
            </div>
            <div className="p-6">
              <div className="pl-5 text-gray-700 space-y-3">
                <p><strong className="text-primary">Goal:</strong> Build confidence in speaking briefly and clearly about their work or ideas.</p>
                <div className="bg-blue-50 border-l-4 border-blue-300 p-4 rounded-r-md">
                  <p><strong className="text-blue-800">Say:</strong> "Presenting doesn't always mean fancy slides! It often just means sharing your thoughts clearly. 
                    Key things are: Know your main point, organize your thoughts (Start - Middle - End), speak slowly and clearly 
                    enough for people to hear, and look at your listeners."</p>
                </div>
                <div className="bg-amber-50 border-l-4 border-amber-300 p-4 rounded-r-md mt-4">
                  <p><strong className="text-amber-800">Quick Practice:</strong> Ask for 3-5 volunteers to stand up and briefly (30-60 seconds) tell the class 
                    or their small group: 1. Which skill they explored (Module 4). 2. One thing they learned or tried. 
                    Focus on clarity, not perfection. Applaud effort.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* WhatsApp Message Section */}
      <div className="mt-10">
        <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
            <FileText className="h-5 w-5" />
          </span>
          For Students: WhatsApp Message (Send after the session)
        </h3>
        <div className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
          <div className="bg-green-50 p-6 rounded-lg">
            <h4 className="font-semibold text-gray-800 text-lg mb-4 pb-2 border-b border-green-200">Subject: High Income Skills: Communication & Teamwork! 🗣️👥</h4>
            <div className="space-y-4 text-gray-700">
              <p>"Hi everyone! Today we learned that clear communication and good teamwork are essential skills for any career! Remember, even experts need to explain their ideas well.</p>
              
              <div className="bg-white rounded-md p-5 border border-gray-200">
                <p className="font-medium text-gray-800 border-b pb-2 mb-3">Your Tasks:</p>
                <ol className="space-y-2 list-decimal ml-5">
                  <li>
                    <strong className="text-primary">Clear Summary:</strong> Write a clear summary (3-4 sentences) of the main points discussed 
                    in today's session in your WhatsApp study group.
                  </li>
                  <li>
                    <strong className="text-primary">Practice Feedback:</strong> Find a mini-project or idea shared by a classmate in your WhatsApp group 
                    (from Module 4 or later). Give them one piece of constructive feedback using the 'Sandwich Method' (write it kindly!).
                  </li>
                  <li>
                    <strong className="text-primary">Explain Simply:</strong> Choose ONE thing you learned this week (from any subject or this program). 
                    Practice explaining it simply in a short voice note or written message (30-60 seconds worth) in your study group.
                  </li>
                </ol>
              </div>
              
              <p>Remember, good communication helps everyone understand each other better! Keep practicing these skills every day. 🌟</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Parent Note Section */}
      <div className="mt-10">
        <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
            <Users className="h-5 w-5" />
          </span>
          For Parents: Note to Share with Parents (via WhatsApp or simple printout)
        </h3>
        <div className="p-6 border-l-4 border-brand-400 bg-brand-50 rounded-lg shadow-sm">
          <div className="space-y-4">
            <h4 className="font-semibold text-primary text-lg">Supporting Your Child's Communication Skills</h4>
            <p className="text-gray-700">
              Dear Parents, In our High Income Skills program, students are learning important communication skills that will help them in their future careers.
              You can support this learning at home by encouraging clear speaking and explaining ideas, showing the importance of listening carefully when others speak,
              and using respectful language, especially during disagreements.
            </p>
          </div>
        </div>
      </div>

      {/* How-To Tips Section */}
      <div className="mt-10">
        <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
            <Rocket className="h-5 w-5" />
          </span>
          "How-To" Tips for Communication & Collaboration
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Tips for Clear Digital Communication */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <h4 className="text-lg font-semibold text-primary mb-3">Tips for Clear Digital Communication (WhatsApp/Email):</h4>
            <ul className="space-y-2 pl-5 list-disc text-gray-700">
              <li><strong className="text-secondary">Purpose First:</strong> State the main point or request clearly at the beginning.</li>
              <li><strong className="text-secondary">Keep it Simple:</strong> Use short sentences and common words. Avoid too much slang.</li>
              <li><strong className="text-secondary">Be Polite:</strong> Use greetings (Hi/Hello) and closings (Thanks/Regards).</li>
              <li><strong className="text-secondary">Check It:</strong> Quickly reread for typos or unclear parts before sending.</li>
              <li><strong className="text-secondary">Use Formatting:</strong> Bullet points (•) or numbers can make lists easier to read.</li>
            </ul>
          </div>
          
          {/* Tips for Good Teamwork */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <h4 className="text-lg font-semibold text-primary mb-3">Tips for Good Teamwork:</h4>
            <ul className="space-y-2 pl-5 list-disc text-gray-700">
              <li><strong className="text-secondary">Listen Actively:</strong> Pay attention when others speak; don't interrupt.</li>
              <li><strong className="text-secondary">Contribute:</strong> Share your ideas and do your fair share of the work.</li>
              <li><strong className="text-secondary">Respect Others:</strong> Value different opinions, even if you disagree. Be polite.</li>
              <li><strong className="text-secondary">Stay Focused:</strong> Keep discussions on topic to achieve the group goal.</li>
              <li><strong className="text-secondary">Help Each Other:</strong> Offer help if a teammate is struggling.</li>
            </ul>
          </div>
          
          {/* How to Give Constructive Feedback */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <h4 className="text-lg font-semibold text-primary mb-3">How to Give Constructive Feedback (Sandwich Method):</h4>
            <ul className="space-y-2 pl-5 list-disc text-gray-700">
              <li><strong className="text-secondary">Be Specific:</strong> Vague feedback ("It's bad") isn't helpful. Say what needs improvement.</li>
              <li><strong className="text-secondary">Focus on Work:</strong> Comment on the task/project, not the person's ability.</li>
              <li><strong className="text-secondary">Use "I" Statements:</strong> "I found this part confusing" is better than "You explained this badly."</li>
              <li><strong className="text-secondary">Sandwich:</strong> 1. Start Positive (Specific). 2. Suggest Improvement (Specific & Gentle). 3. End Positive/Encouraging.</li>
            </ul>
          </div>
          
          {/* How to Receive Feedback */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
            <h4 className="text-lg font-semibold text-primary mb-3">How to Receive Feedback:</h4>
            <ul className="space-y-2 pl-5 list-disc text-gray-700">
              <li><strong className="text-secondary">Listen Openly:</strong> Try not to get defensive or make excuses immediately.</li>
              <li><strong className="text-secondary">Understand:</strong> Ask questions to clarify if needed ("Could you show me where?" "What do you suggest instead?").</li>
              <li><strong className="text-secondary">Reflect:</strong> Think about the feedback later. Is it valid? How can you use it?</li>
              <li><strong className="text-secondary">Say Thank You:</strong> Acknowledge the person took the time to give feedback.</li>
            </ul>
          </div>
          
          {/* Tips for Speaking Clearly */}
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200 md:col-span-2">
            <h4 className="text-lg font-semibold text-primary mb-3">Tips for Speaking Clearly (Simple Presentations):</h4>
            <ul className="space-y-2 pl-5 list-disc text-gray-700">
              <li><strong className="text-secondary">Know Your Main Point:</strong> What is the one key thing you want listeners to understand?</li>
              <li><strong className="text-secondary">Organize Simply:</strong> Have a quick plan: 1. Introduction (What are you talking about?). 2. Main Points (Explain briefly). 3. Conclusion (Summarize or main takeaway).</li>
              <li><strong className="text-secondary">Speak Clearly & Slowly:</strong> Don't rush. Speak loudly enough to be heard easily. Avoid mumbling.</li>
              <li><strong className="text-secondary">Make Eye Contact:</strong> Look at your listeners (the group or different people in the class) – it connects you.</li>
              <li><strong className="text-secondary">Keep it Brief:</strong> Especially when starting, shorter is better!</li>
            </ul>
          </div>
        </div>
      </div>
      
      {/* Resources Section */}
      <div className="mt-8 bg-blue-50 p-6 rounded-lg border border-blue-100 shadow-sm">
        <div className="flex items-center gap-3 text-blue-800 mb-4">
          <Search className="h-5 w-5" />
          <h4 className="font-bold text-lg">Supporting Resources</h4>
        </div>
        <p className="mb-4 text-gray-700">
          These interactive tools can help students explore different career paths based on their interests and strengths:
        </p>
        <div className="flex flex-wrap gap-3">
          <Link 
            to="/implementation-guides/high-income-skills/keywords" 
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            <Search className="h-4 w-4" /> Keyword & Prompt Library
          </Link>
          <Link 
            to="/career-explorer/clusters" 
            className="inline-flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
          >
            <Rocket className="h-4 w-4" /> Career Cluster Explorer
          </Link>
          <Link 
            to="/career-explorer/problem-solving" 
            className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors"
          >
            <Brain className="h-4 w-4" /> Problem-Based Career Matching
          </Link>
          <Link 
            to="/career-explorer/assessment" 
            className="inline-flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700 transition-colors"
          >
            <Activity className="h-4 w-4" /> Psychometric Career Assessment
          </Link>
        </div>
      </div>
    </div>
  </div>
);

export default HighIncomeSkillsModule5;
