
import React from "react";
import { Link } from "react-router-dom";
import { BookOpen, Search, Rocket, Brain, Activity, Users, FileText, Lightbulb, Monitor, Video, Presentation, BarChart, Share2, Laptop } from "lucide-react";

/**
 * High Income Skills Portfolio Building Guidance - Module 7: Computer & Projector Enhanced Implementation
 */
const HighIncomeSkillsModule7 = () => (
  <div className="space-y-8">
    <div className="border-b-2 border-accent/30 pb-4">
      <h2 className="text-2xl font-bold text-primary mb-2">Module 7: Computer & Projector Enhanced Implementation</h2>
      <p className="text-gray-600 italic">Guidance for implementing the High Income Skills program with technology resources in the classroom.</p>
    </div>
    
    <div className="prose max-w-none">
      {/* General Classroom Enhancements */}
      <div className="bg-brand-50/50 p-6 rounded-lg border border-brand-200 shadow-sm">
        <h3 className="text-xl font-semibold text-secondary mb-3 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-secondary/10 rounded-full text-secondary">
            <Monitor className="h-5 w-5" />
          </span>
          General Classroom Enhancements
        </h3>
        
        <div className="space-y-6">
          <section className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <div className="flex items-center gap-3 mb-3">
              <span className="flex items-center justify-center w-8 h-8 rounded-full bg-blue-100 text-blue-700">
                <Video className="h-4 w-4" />
              </span>
              <h4 className="font-semibold text-primary">Visual Demonstrations:</h4>
            </div>
            <ul className="list-disc pl-5 space-y-2 text-gray-700">
              <li><strong>Live Software Demos:</strong> Teachers can now demonstrate software tools directly instead of just describing them (e.g., show Canva interface, a simple code editor like VS Code online, navigating Google Workspace tools like Docs/Slides/Sheets, using an AI chatbot live).</li>
              <li><strong>Website Walkthroughs:</strong> Guide students through relevant websites in real-time (e.g., National Career Service portal, online course platforms like NPTEL/Swayam, Coursera, edX, Udemy, Khan Academy, Skillshare, FutureLearn, specific college websites, reliable news sources).</li>
              <li><strong>Video Integration:</strong> Seamlessly show relevant educational videos (from YouTube or other sources) directly during the session to illustrate concepts or showcase examples (e.g., "day in the life" videos for careers, tutorials).</li>
              <li><strong>Presentations:</strong> Teachers can use simple presentations (Google Slides, Canva Presentations, PowerPoint) with visuals, key points, and embedded media to structure sessions and make them more engaging.</li>
            </ul>
          </section>
          
          <section className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <div className="flex items-center gap-3 mb-3">
              <span className="flex items-center justify-center w-8 h-8 rounded-full bg-purple-100 text-purple-700">
                <Presentation className="h-4 w-4" />
              </span>
              <h4 className="font-semibold text-primary">Interactive Activities:</h4>
            </div>
            <ul className="list-disc pl-5 space-y-2 text-gray-700">
              <li><strong>Online Quizzes/Polls:</strong> Use free tools (like Kahoot!, Quizizz, Mentimeter free tier) projected on screen for fun knowledge checks or opinion gathering related to module topics.</li>
              <li><strong>Collaborative Digital Whiteboards:</strong> Use tools like Google Jamboard, Miro (free tier), or Whiteboard.chat (projected) for group brainstorming sessions (e.g., listing strengths, job ideas, project plans) where ideas can be captured digitally.</li>
              <li><strong>Shared Document Collaboration:</strong> If computers are available for student groups, they can work together on shared documents (like Google Docs) for activities like drafting project plans or writing summaries, with the teacher potentially projecting examples.</li>
            </ul>
          </section>
          
          <section className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <div className="flex items-center gap-3 mb-3">
              <span className="flex items-center justify-center w-8 h-8 rounded-full bg-green-100 text-green-700">
                <Share2 className="h-4 w-4" />
              </span>
              <h4 className="font-semibold text-primary">Showcasing Work:</h4>
            </div>
            <ul className="list-disc pl-5 space-y-2 text-gray-700">
              <li><strong>Projecting Student Digital Work:</strong> Easily display student-created digital content (simple designs from Canva, text written in Docs, basic websites/portfolios) on the projector for class feedback or celebration.</li>
            </ul>
          </section>
          
          <section className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
            <div className="flex items-center gap-3 mb-3">
              <span className="flex items-center justify-center w-8 h-8 rounded-full bg-amber-100 text-amber-700">
                <Laptop className="h-4 w-4" />
              </span>
              <h4 className="font-semibold text-primary">Enhanced Access:</h4>
            </div>
            <ul className="list-disc pl-5 space-y-2 text-gray-700">
              <li><strong>Virtual Guest Speakers:</strong> Facilitate virtual talks more easily by connecting professionals via video call (Google Meet, Zoom) displayed on the projector.</li>
              <li><strong>Digital Resource Access:</strong> Guide students directly to specific online articles, tools, or resources during the class time.</li>
            </ul>
          </section>
        </div>
      </div>

      {/* Module-Specific Additions */}
      <div className="mt-10">
        <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
            <BarChart className="h-5 w-5" />
          </span>
          Module-Specific Additions & Modifications
        </h3>
        
        <div className="bg-blue-50 p-6 rounded-xl border border-blue-200">          
          <div className="space-y-6">
            <section className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
              <h4 className="text-lg font-semibold text-primary mb-3 border-b pb-2">Module 1 (Self-Discovery):</h4>
              <ul className="list-disc pl-5 space-y-2 text-gray-700">
                <li>Project simple, free online personality or learning style quizzes for discussion (emphasize they are just for fun/exploration).</li>
                <li>Demonstrate basic mind-mapping software (like Bubbl.us free tier or MindMeister basic) projected for brainstorming strengths, interests, and goals visually.</li>
              </ul>
            </section>
            
            <section className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
              <h4 className="text-lg font-semibold text-primary mb-3 border-b pb-2">Module 2 (Career Exploration):</h4>
              <ul className="list-disc pl-5 space-y-2 text-gray-700">
                <li>Project and navigate career guidance websites (National Career Service, company career pages, LinkedIn basics).</li>
                <li>Show short "day in the life" videos or virtual tours of workplaces related to specific careers.</li>
                <li>Display the "Big List of Future-Ready Jobs" digitally, perhaps adding links or images.</li>
                <li>Easily host virtual career talks with professionals from different fields via projector.</li>
              </ul>
            </section>
            
            <section className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
              <h4 className="text-lg font-semibold text-primary mb-3 border-b pb-2">Module 3 (Learning How):</h4>
              <ul className="list-disc pl-5 space-y-2 text-gray-700">
                <li>Live demonstration of advanced Google Search operators projected on screen.</li>
                <li>Navigate and evaluate YouTube channels and videos together as a class, projected live.</li>
                <li>Interact with an AI tool (like Gemini) live on screen, demonstrating effective prompting techniques and critically evaluating responses together.</li>
                <li>Demonstrate digital note-taking apps (Google Keep, Evernote basic, Microsoft OneNote) and discuss pros/cons versus paper notes.</li>
                <li>Show digital calendar/planning tools (Google Calendar, Trello basic) for time management.</li>
              </ul>
            </section>
            
            <section className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
              <h4 className="text-lg font-semibold text-primary mb-3 border-b pb-2">Module 4 (Skill Building):</h4>
              <ul className="list-disc pl-5 space-y-2 text-gray-700">
                <li><strong className="text-secondary">Crucial Enhancement:</strong> Provide live, step-by-step demos of relevant free software tools projected clearly (e.g., getting started with Canva, basic functions of Google Docs/Sheets for project documentation, navigating a simple code editor or online learning platform).</li>
                <li>If student computers are available (even shared): Guided practice sessions where students follow the teacher's demo on their own machines for basic tasks.</li>
                <li>Project high-quality beginner tutorials and potentially pause for discussion or practice steps.</li>
                <li>Demonstrate how to set up a simple digital portfolio using free platforms (like Google Sites, Canva's portfolio feature, or a simple blog).</li>
              </ul>
            </section>
            
            <section className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
              <h4 className="text-lg font-semibold text-primary mb-3 border-b pb-2">Module 5 (Communication/Collaboration):</h4>
              <ul className="list-disc pl-5 space-y-2 text-gray-700">
                <li>Use projected collaborative tools (Google Docs, Jamboard, Miro) for group writing or brainstorming activities during the session.</li>
                <li>Introduce and demonstrate creating simple digital presentations (using Canva Presentations, Google Slides, or similar free tools). Students can practice creating 1-2 slides on their chosen skill/project.</li>
                <li>Practice professional email/message writing using a projected email interface or document.</li>
                <li>Potentially record short (30-60 sec) practice presentations using a computer's webcam/mic (if available) and play back for constructive peer feedback using the projector.</li>
              </ul>
            </section>
            
            <section className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
              <h4 className="text-lg font-semibold text-primary mb-3 border-b pb-2">Module 6 (Future Planning):</h4>
              <ul className="list-disc pl-5 space-y-2 text-gray-700">
                <li>Demonstrate creating a digital resume using templates available in Google Docs or Canva, projected live.</li>
                <li>Live navigation of local college websites (e.g., colleges near Parvathipuram, Andhra University), online course platforms (Swayam, NPTEL), job portals (Naukri, Indeed, LinkedIn), and government career sites, showing students how to find specific information (courses, eligibility, job descriptions, application processes).</li>
                <li>Showcase examples of online freelance platform profiles (Upwork, Fiverr) while reiterating cautions.</li>
              </ul>
            </section>
          </div>
        </div>
      </div>

      {/* New Resources Section */}
      <div className="mt-10">
        <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
            <FileText className="h-5 w-5" />
          </span>
          New Resources/Guides Needed (Digital Focus)
        </h3>
        
        <div className="bg-purple-50 p-6 rounded-xl border border-purple-200">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
              <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-purple-100 text-purple-700 text-sm mb-2">1</span>
              <h4 className="font-medium text-gray-900 mb-2">Basic Computer & Internet Use Guide</h4>
              <p className="text-gray-700 text-sm">For students completely new to computers. Covers parts of a computer, using a mouse/keyboard, opening software, basic file management (folders, saving), opening a web browser, navigating websites safely. Could include Telugu vocabulary.</p>
            </div>
            
            <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
              <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-purple-100 text-purple-700 text-sm mb-2">2</span>
              <h4 className="font-medium text-gray-900 mb-2">Creating Simple Digital Presentations Guide</h4>
              <p className="text-gray-700 text-sm">Tips on using free tools (Canva, Google Slides), structuring slides (less text, more visuals), basic design principles for presentations, delivering with digital aids.</p>
            </div>
            
            <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
              <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-purple-100 text-purple-700 text-sm mb-2">3</span>
              <h4 className="font-medium text-gray-900 mb-2">Specific Software Tool Basics Guides</h4>
              <p className="text-gray-700 text-sm">Simple guides for tools heavily used/demonstrated (e.g., "Getting Started with Canva", "Google Docs Basics for Students").</p>
            </div>
            
            <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
              <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-purple-100 text-purple-700 text-sm mb-2">4</span>
              <h4 className="font-medium text-gray-900 mb-2">Online Safety & Digital Citizenship Guide</h4>
              <p className="text-gray-700 text-sm">Expanded tips covering safe browsing, protecting personal information online, identifying scams/phishing, understanding digital footprint, cyberbullying awareness and reporting (crucial with increased online activity).</p>
            </div>
            
            <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100 md:col-span-2">
              <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-purple-100 text-purple-700 text-sm mb-2">5</span>
              <h4 className="font-medium text-gray-900 mb-2">Updated Tool Recommendations</h4>
              <p className="text-gray-700 text-sm">List of recommended free digital tools for note-taking, planning, collaboration, and portfolio building accessible via browser or simple apps.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Updated Keywords Section */}
      <div className="mt-10">
        <h3 className="text-xl font-bold text-primary mb-5 flex items-center gap-3">
          <span className="flex items-center justify-center w-9 h-9 bg-primary/10 rounded-full text-primary">
            <Search className="h-5 w-5" />
          </span>
          Updated Keywords/Prompts
        </h3>
        
        <div className="bg-green-50 p-6 rounded-xl border border-green-200">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <h4 className="font-semibold text-green-700 border-b border-green-200 pb-2">Software Tutorial Keywords</h4>
              <ul className="list-disc pl-5 space-y-2 text-gray-700">
                <li>Canva tutorial video for beginners</li>
                <li>Google Slides tutorial step by step</li>
                <li>How to use VS Code for beginners</li>
                <li>Microsoft Word basic tutorial</li>
                <li>How to create Google account tutorial</li>
              </ul>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold text-green-700 border-b border-green-200 pb-2">Collaboration Platform Keywords</h4>
              <ul className="list-disc pl-5 space-y-2 text-gray-700">
                <li>Google Docs collaboration tips</li>
                <li>Miro whiteboard tutorial for students</li>
                <li>Google Jamboard how to use for classroom</li>
                <li>Shared document best practices</li>
              </ul>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold text-green-700 border-b border-green-200 pb-2">AI Prompts for Digital Tools</h4>
              <ul className="list-disc pl-5 space-y-2 text-gray-700">
                <li>Explain how to use Google Sites to create a portfolio</li>
                <li>Give me tips for designing an effective presentation slide</li>
                <li>How do I create a simple resume in Google Docs?</li>
                <li>What free tools can I use to create graphics online?</li>
              </ul>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold text-green-700 border-b border-green-200 pb-2">Digital Safety Search Terms</h4>
              <ul className="list-disc pl-5 space-y-2 text-gray-700">
                <li>Online safety rules India</li>
                <li>How to identify phishing email</li>
                <li>Digital footprint meaning and importance</li>
                <li>How to create strong password</li>
                <li>Safe browsing tips for students</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
      
      {/* Resources Section */}
      <div className="mt-8 bg-blue-50 p-6 rounded-lg border border-blue-100 shadow-sm">
        <div className="flex items-center gap-3 text-blue-800 mb-4">
          <Search className="h-5 w-5" />
          <h4 className="font-bold text-lg">Supporting Resources</h4>
        </div>
        <p className="mb-4 text-gray-700">
          These interactive tools can help students explore different career paths based on their interests and strengths:
        </p>
        <div className="flex flex-wrap gap-3">
          <Link 
            to="/implementation-guides/high-income-skills/keywords" 
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            <Search className="h-4 w-4" /> Keyword & Prompt Library
          </Link>
          <Link 
            to="/career-explorer/clusters" 
            className="inline-flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
          >
            <Rocket className="h-4 w-4" /> Career Cluster Explorer
          </Link>
          <Link 
            to="/career-explorer/problem-solving" 
            className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors"
          >
            <Brain className="h-4 w-4" /> Problem-Based Career Matching
          </Link>
          <Link 
            to="/career-explorer/assessment" 
            className="inline-flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700 transition-colors"
          >
            <Activity className="h-4 w-4" /> Psychometric Career Assessment
          </Link>
        </div>
      </div>
    </div>
  </div>
);

export default HighIncomeSkillsModule7;
