
import React from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Search, BookOpen, Brain, Lightbulb, Briefcase } from "lucide-react";

const HighIncomeSkillsKeywordLibrary = () => (
  <div className="space-y-8">
    <div className="flex items-center gap-2 mb-6">
      <Link to="/implementation-guides/high-income-skills" className="text-primary hover:text-primary-dark flex items-center gap-1">
        <ArrowLeft className="h-4 w-4" /> Back to High Income Skills Modules
      </Link>
    </div>
    
    <div className="border-b border-accent/20 pb-3">
      <h2 className="text-2xl font-bold text-primary mb-1">High Income Skills Search & Prompt Library</h2>
      <p className="text-gray-600 italic">Complete collection of keywords and prompts for teachers and students to use</p>
    </div>

    <div className="bg-brand-50/50 p-5 rounded-lg border border-brand-100 shadow-sm">
      <h3 className="text-xl font-semibold text-secondary mb-3 flex items-center">
        <Search className="h-5 w-5 mr-2" />
        How To Use This Resource
      </h3>
      <p className="text-gray-800 mb-4">
        This resource provides curated lists of search keywords, phrases, and AI prompts that both teachers and students can use to find 
        information and resources related to each module of the High Income Skills Portfolio Building program. Use these terms with 
        Google Search, YouTube, or AI chatbots (like Gemini, Claude, or ChatGPT if available).
      </p>
      <div className="bg-white p-4 rounded-lg shadow-sm">
        <h4 className="font-medium text-primary mb-2">Tips for Effective Searching:</h4>
        <ul className="space-y-1 ml-4 text-gray-700 list-disc">
          <li>Be specific with your search terms.</li>
          <li>Add "free" to find no-cost resources.</li>
          <li>Add "beginners" or "tutorial" for learning content.</li>
          <li>Add "examples" to see practical applications.</li>
          <li>Search in English or your preferred regional language.</li>
          <li>Use quotes " " for exact phrase matching.</li>
        </ul>
      </div>
    </div>

    {/* Module 1: Self-Discovery Section */}
    <div className="mt-8">
      <div className="bg-blue-50 p-5 rounded-lg border border-blue-100">
        <h3 className="text-lg font-bold text-primary mb-3 flex items-center">
          <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-blue-100 text-blue-700 font-bold text-sm mr-2">1</span>
          Module 1: Self-Discovery Keywords
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h4 className="font-semibold text-blue-700 mb-3 flex items-center">
              <Search className="h-4 w-4 mr-2" />
              Basic Search Terms
            </h4>
            <ul className="space-y-1.5 pl-3 text-gray-700">
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-blue-500 mt-1.5 mr-2"></span>
                "How to identify my strengths and skills"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-blue-500 mt-1.5 mr-2"></span>
                "Free personality test simple"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-blue-500 mt-1.5 mr-2"></span>
                "What is growth mindset simple explanation"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-blue-500 mt-1.5 mr-2"></span>
                "How to discover what I'm good at"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-blue-500 mt-1.5 mr-2"></span>
                "Self awareness activities for students"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-blue-500 mt-1.5 mr-2"></span>
                "List of skills and talents examples"
              </li>
            </ul>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h4 className="font-semibold text-green-700 mb-3 flex items-center">
              <Lightbulb className="h-4 w-4 mr-2" />
              AI Prompt Ideas
            </h4>
            <ul className="space-y-1.5 pl-3 text-gray-700">
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "List 20 different types of personal strengths and talents people can have."
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "Help me identify my personal strengths based on these activities I enjoy: [list activities]"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "Explain growth mindset vs fixed mindset with examples for teenagers."
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "Create a list of 10 simple questions I can ask myself to discover my interests."
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "What are 5 free tools or activities to help understand my personality type?"
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    
    {/* Module 2: Career Exploration Section */}
    <div className="mt-8">
      <div className="bg-purple-50 p-5 rounded-lg border border-purple-100">
        <h3 className="text-lg font-bold text-primary mb-3 flex items-center">
          <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-purple-100 text-purple-700 font-bold text-sm mr-2">2</span>
          Module 2: Career Exploration Keywords
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h4 className="font-semibold text-purple-700 mb-3 flex items-center">
              <Search className="h-4 w-4 mr-2" />
              Basic Search Terms
            </h4>
            <ul className="space-y-1.5 pl-3 text-gray-700">
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-purple-500 mt-1.5 mr-2"></span>
                "Different types of jobs list India"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-purple-500 mt-1.5 mr-2"></span>
                "Online jobs from mobile phone"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-purple-500 mt-1.5 mr-2"></span>
                "Future jobs in India"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-purple-500 mt-1.5 mr-2"></span>
                "Jobs for people who like [interest]"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-purple-500 mt-1.5 mr-2"></span>
                "Small business ideas India"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-purple-500 mt-1.5 mr-2"></span>
                "High paying skills India"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-purple-500 mt-1.5 mr-2"></span>
                "In-demand remote jobs"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-purple-500 mt-1.5 mr-2"></span>
                "Future work trends"
              </li>
            </ul>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h4 className="font-semibold text-green-700 mb-3 flex items-center">
              <Lightbulb className="h-4 w-4 mr-2" />
              AI Prompt Ideas
            </h4>
            <ul className="space-y-1.5 pl-3 text-gray-700">
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "List 20 different types of jobs people do in India."
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "What jobs can someone do using just a smartphone?"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "What skills are needed for [job name]?"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "Generate a list of 50 different career ideas, including new online jobs and business ideas."
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "What are the most in-demand jobs that don't require a college degree?"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "How can I make money online with basic English skills?"
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    {/* Module 3: Learning How To Learn Section */}
    <div className="mt-8">
      <div className="bg-green-50 p-5 rounded-lg border border-green-100">
        <h3 className="text-lg font-bold text-primary mb-3 flex items-center">
          <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-green-100 text-green-700 font-bold text-sm mr-2">3</span>
          Module 3: Learning How To Learn Keywords
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h4 className="font-semibold text-green-700 mb-3 flex items-center">
              <Search className="h-4 w-4 mr-2" />
              Basic Search Terms
            </h4>
            <ul className="space-y-1.5 pl-3 text-gray-700">
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "How to search Google effectively"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "How to learn anything fast"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "Best way to learn from YouTube videos"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "[Skill Name] tutorial for beginners"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "[Skill Name] step by step guide"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "[Skill Name] advanced course free"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "[Skill Name] expert tips"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "Learning techniques like Feynman technique"
              </li>
            </ul>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h4 className="font-semibold text-green-700 mb-3 flex items-center">
              <Lightbulb className="h-4 w-4 mr-2" />
              AI Prompt Ideas
            </h4>
            <ul className="space-y-1.5 pl-3 text-gray-700">
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "Create a simple plan to learn [skill name] using online resources."
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "Find good YouTube channels for learning [topic] easily."
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "Explain [a complex topic] in very simple terms."
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "What are the most effective study techniques for remembering information?"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "How can I improve my focus while studying?"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "Create a 30-day plan to learn the basics of [skill]."
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    {/* Module 4: Skill Building Section */}
    <div className="mt-8">
      <div className="bg-orange-50 p-5 rounded-lg border border-orange-100">
        <h3 className="text-lg font-bold text-primary mb-3 flex items-center">
          <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-orange-100 text-orange-700 font-bold text-sm mr-2">4</span>
          Module 4: Skill Building Keywords
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h4 className="font-semibold text-orange-700 mb-3 flex items-center">
              <Search className="h-4 w-4 mr-2" />
              Basic Search Terms
            </h4>
            <ul className="space-y-1.5 pl-3 text-gray-700">
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-orange-500 mt-1.5 mr-2"></span>
                "Content writing tutorial beginners"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-orange-500 mt-1.5 mr-2"></span>
                "Graphic design free tools for beginners"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-orange-500 mt-1.5 mr-2"></span>
                "Social media basics for business"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-orange-500 mt-1.5 mr-2"></span>
                "Basic website design free tools"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-orange-500 mt-1.5 mr-2"></span>
                "Learn data entry beginner guide"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-orange-500 mt-1.5 mr-2"></span>
                "Basic photography tips mobile phone"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-orange-500 mt-1.5 mr-2"></span>
                "Canva tutorial for beginners"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-orange-500 mt-1.5 mr-2"></span>
                "Simple video editing mobile apps"
              </li>
            </ul>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h4 className="font-semibold text-green-700 mb-3 flex items-center">
              <Lightbulb className="h-4 w-4 mr-2" />
              AI Prompt Ideas
            </h4>
            <ul className="space-y-1.5 pl-3 text-gray-700">
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "Give me 5 simple projects to practice [skill name]."
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "What free tools can I use to learn [skill] on my phone?"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "Create a simple 7-day challenge to practice [skill] for 15 minutes each day."
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "What are the most basic things to learn first in [skill area]?"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "How can I practice [skill] without spending money on equipment?"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "What are 3 small projects I can complete this week to practice [skill]?"
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    {/* Module 5: Communication & Collaboration Section */}
    <div className="mt-8">
      <div className="bg-red-50 p-5 rounded-lg border border-red-100">
        <h3 className="text-lg font-bold text-primary mb-3 flex items-center">
          <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-red-100 text-red-700 font-bold text-sm mr-2">5</span>
          Module 5: Communication & Collaboration Keywords
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h4 className="font-semibold text-red-700 mb-3 flex items-center">
              <Search className="h-4 w-4 mr-2" />
              Basic Search Terms
            </h4>
            <ul className="space-y-1.5 pl-3 text-gray-700">
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-red-500 mt-1.5 mr-2"></span>
                "How to communicate clearly"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-red-500 mt-1.5 mr-2"></span>
                "Tips for writing professional messages"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-red-500 mt-1.5 mr-2"></span>
                "How to work well in a team"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-red-500 mt-1.5 mr-2"></span>
                "Public speaking tips beginners"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-red-500 mt-1.5 mr-2"></span>
                "How to give constructive feedback"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-red-500 mt-1.5 mr-2"></span>
                "Effective group discussion techniques"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-red-500 mt-1.5 mr-2"></span>
                "How to write clear emails"
              </li>
            </ul>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h4 className="font-semibold text-green-700 mb-3 flex items-center">
              <Lightbulb className="h-4 w-4 mr-2" />
              AI Prompt Ideas
            </h4>
            <ul className="space-y-1.5 pl-3 text-gray-700">
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "Give me examples of clear vs unclear messages."
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "How can I politely disagree with someone in a group discussion?"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "Write an example of giving constructive feedback about [topic]."
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "What are 5 common communication mistakes and how to avoid them?"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "Help me write a clear message explaining [topic] to someone who knows nothing about it."
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "Give me tips for speaking confidently when presenting ideas."
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>

    {/* Module 6: Portfolio Building & Future Planning */}
    <div className="mt-8">
      <div className="bg-teal-50 p-5 rounded-lg border border-teal-100">
        <h3 className="text-lg font-bold text-primary mb-3 flex items-center">
          <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-teal-100 text-teal-700 font-bold text-sm mr-2">6</span>
          Module 6: Portfolio & Future Planning Keywords
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h4 className="font-semibold text-teal-700 mb-3 flex items-center">
              <Search className="h-4 w-4 mr-2" />
              Basic Search Terms
            </h4>
            <ul className="space-y-1.5 pl-3 text-gray-700">
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-teal-500 mt-1.5 mr-2"></span>
                "How to create a simple portfolio"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-teal-500 mt-1.5 mr-2"></span>
                "CV resume writing for beginners"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-teal-500 mt-1.5 mr-2"></span>
                "Free portfolio website builders"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-teal-500 mt-1.5 mr-2"></span>
                "How to find job opportunities locally"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-teal-500 mt-1.5 mr-2"></span>
                "Freelance beginners guide"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-teal-500 mt-1.5 mr-2"></span>
                "Free online courses with certificates"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-teal-500 mt-1.5 mr-2"></span>
                "How to find career opportunities without degree"
              </li>
            </ul>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h4 className="font-semibold text-green-700 mb-3 flex items-center">
              <Lightbulb className="h-4 w-4 mr-2" />
              AI Prompt Ideas
            </h4>
            <ul className="space-y-1.5 pl-3 text-gray-700">
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "Help me create a simple resume for a beginner in [field]."
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "What should I include in a portfolio for [skill area]?"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "List 10 ways to find opportunities to practice [skill] in my local community."
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "Write a simple introduction paragraph about myself for a portfolio website."
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "How can I organize my projects for a simple portfolio?"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "What free online courses would help me improve at [skill]?"
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  
    {/* Module 7: Computer & Projector Enhanced Implementation */}
    <div className="mt-8">
      <div className="bg-indigo-50 p-5 rounded-lg border border-indigo-100">
        <h3 className="text-lg font-bold text-primary mb-3 flex items-center">
          <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-indigo-100 text-indigo-700 font-bold text-sm mr-2">7</span>
          Module 7: Computer & Projector Enhanced Implementation
        </h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h4 className="font-semibold text-indigo-700 mb-3 flex items-center">
              <Search className="h-4 w-4 mr-2" />
              Basic Search Terms
            </h4>
            <ul className="space-y-1.5 pl-3 text-gray-700">
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-indigo-500 mt-1.5 mr-2"></span>
                "Basic computer use guide"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-indigo-500 mt-1.5 mr-2"></span>
                "How to connect projector to computer"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-indigo-500 mt-1.5 mr-2"></span>
                "Create simple digital presentations"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-indigo-500 mt-1.5 mr-2"></span>
                "Online safety guide for students"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-indigo-500 mt-1.5 mr-2"></span>
                "Canva tutorial for beginners"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-indigo-500 mt-1.5 mr-2"></span>
                "Digital citizenship basics"
              </li>
            </ul>
          </div>
          
          <div className="bg-white p-4 rounded-lg shadow-sm">
            <h4 className="font-semibold text-green-700 mb-3 flex items-center">
              <Lightbulb className="h-4 w-4 mr-2" />
              AI Prompt Ideas
            </h4>
            <ul className="space-y-1.5 pl-3 text-gray-700">
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "Explain how to use Google Sites to create a portfolio"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "Give me tips for designing an effective presentation slide"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "Create a simple outline for teaching basic computer skills" 
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "How to identify phishing emails - simple rules"
              </li>
              <li className="flex items-start">
                <span className="inline-block h-1.5 w-1.5 rounded-full bg-green-500 mt-1.5 mr-2"></span>
                "List of tools for digital collaboration in classroom"
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    
    <div className="mt-8 p-5 bg-blue-50 rounded-lg border border-blue-100">
      <h3 className="text-lg font-bold text-primary mb-3">Return to High Income Skills Resources</h3>
      <div className="flex flex-wrap gap-3">
        <Link 
          to="/implementation-guides/high-income-skills"
          className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
        >
          <BookOpen className="h-4 w-4" /> View All Modules
        </Link>
        <Link 
          to="/career-explorer/clusters" 
          className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors"
        >
          <Briefcase className="h-4 w-4" /> Career Cluster Explorer
        </Link>
        <Link 
          to="/career-explorer/problem-solving" 
          className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors"
        >
          <Brain className="h-4 w-4" /> Problem-Based Career Matching
        </Link>
      </div>
    </div>
  </div>
);

export default HighIncomeSkillsKeywordLibrary;
