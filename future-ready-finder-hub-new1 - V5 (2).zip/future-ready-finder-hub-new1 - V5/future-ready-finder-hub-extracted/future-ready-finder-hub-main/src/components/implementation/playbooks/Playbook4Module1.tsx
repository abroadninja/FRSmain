
import React from "react";

/**
 * Playbook 4, Module 1: Everyday Lead Generation ( For Admissions & Value-Added services)
 */
const Playbook4Module1 = () => (
  <div className="space-y-6">
    <div className="border-b border-accent/20 pb-3">
      <h2 className="text-2xl font-bold text-primary mb-1">Everyday Lead Generation (For Admissions & Value-Added Services)</h2>
    </div>
    
    <div className="prose max-w-none">
      <div className="bg-brand-50/50 p-5 rounded-lg border border-brand-100 shadow-sm">
        <h3 className="text-xl font-semibold text-secondary mb-2">Core Principle</h3>
        <p className="text-gray-800">
          Consistent lead generation across multiple channels is essential for sustained growth and predictable enrollment. Leads are the lifeblood of the school. Stop hoping for leads; generate them daily and intentionally.
        </p>
      </div>

      <div className="mt-8 space-y-6">
        <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
          <h4 className="font-semibold text-brand-700 mb-4 flex items-center border-b pb-2">
            <span className="inline-flex items-center justify-center h-7 w-7 mr-3 rounded-full bg-brand-100 text-brand-700 text-sm">1</span>
            Setting Daily Lead Generation Targets
          </h4>
          <div className="space-y-3 pl-4 border-l-2 border-accent/20">
            <p className="text-gray-700"><span className="font-medium text-gray-900">Be Intentional:</span> Set specific, measurable, achievable, relevant, and time-bound (SMART) daily lead targets for both admissions enquiries <u>and</u> value-added service sign-ups or trials.</p>
            
            <p className="text-gray-700"><span className="font-medium text-gray-900">Example Targets:</span> 10 new admission enquiry calls/forms, 20 website form submissions, 5 value-added service trial sign-ups per day. Adjust based on school size, goals, resources.</p>
            
            <p className="text-gray-700"><span className="font-medium text-gray-900">Force Action:</span> Targets create urgency and intentional growth. Write them down, make them visible to the team. Hit them—repeat!</p>
            
            <p className="font-medium text-primary">Immediate Action: Define and document daily lead generation targets for admissions and value-added services.</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
          <h4 className="font-semibold text-brand-700 mb-4 flex items-center border-b pb-2">
            <span className="inline-flex items-center justify-center h-7 w-7 mr-3 rounded-full bg-brand-100 text-brand-700 text-sm">2</span>
            Implement Multiple Lead Generation Activities (Online & Offline)
          </h4>
          <div className="space-y-3 pl-4 border-l-2 border-accent/20">
            <p className="text-gray-700"><span className="font-medium text-gray-900">Diversify or Die:</span> Relying on one lead source is risky. Build multiple lead engines, online & offline.</p>
            
            <div>
              <p className="font-medium text-gray-900 mb-2">Online:</p>
              <ul className="space-y-2 pl-4">
                <li className="text-gray-700">Hyper-targeted Social Media Ads (FB/Instagram, 2–5km radius).</li>
                <li className="text-gray-700">SEO-optimized Website & Landing Pages (rank for "best schools near me" and similar).</li>
                <li className="text-gray-700">Content Marketing (blogs, guides, webinars). Use resources like Social Media Content Starters, Content Marketing Matrix Flowchart.</li>
              </ul>
            </div>
            
            <div>
              <p className="font-medium text-gray-900 mb-2">Offline:</p>
              <ul className="space-y-2 pl-4">
                <li className="text-gray-700">Community events, workshops, fairs (Outreach Event Activity Planner).</li>
                <li className="text-gray-700">Partnerships with local businesses, preschools, etc.</li>
                <li className="text-gray-700">Referral Programs (see Playbook 3), Hyper-local flyers/posters.</li>
              </ul>
            </div>
            
            <p className="text-gray-700"><span className="font-medium text-gray-900">Focus on Quality, Not Just Quantity:</span> Prioritize strategies that bring in genuinely interested, qualified leads!</p>
            
            <p className="font-medium text-primary">Immediate Action: List three online and three offline activities to implement now. Assign responsibility!</p>
          </div>
        </div>

        <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-100">
          <h4 className="font-semibold text-brand-700 mb-4 flex items-center border-b pb-2">
            <span className="inline-flex items-center justify-center h-7 w-7 mr-3 rounded-full bg-brand-100 text-brand-700 text-sm">3</span>
            Documenting & Tracking Results
          </h4>
          <div className="space-y-3 pl-4 border-l-2 border-accent/20">
            <p className="text-gray-700"><span className="font-medium text-gray-900">Measure to Manage:</span> Track EVERYTHING. What gets measured gets managed; what gets managed grows.</p>
            
            <p className="text-gray-700">Use the "Lead Launchpad": Track channel/activity, cost, leads, conversion rate, ROI. Use resources like the Lead Generation Activity Tracker/Outreach Tracking Data.</p>
            
            <p className="text-gray-700"><span className="font-medium text-gray-900">Analyze & Optimize:</span> Double down on what's working, cut what's not. Data-driven growth—review numbers regularly.</p>
            
            <p className="font-medium text-primary">Immediate Action: Set up the Lead Launchpad spreadsheet and start using it <b>today</b>.</p>
          </div>
        </div>
      </div>
      
      <div className="mt-8 bg-accent/5 p-5 rounded-lg border border-accent/20 shadow-sm">
        <h4 className="font-semibold text-brand-700 mb-4 border-b pb-2 border-accent/10">"Done-For-You" Resources</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Lead Launchpad Spreadsheet Template</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Social Media Content Starters.pdf</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Content Marketing Matrix Flowchart.pdf</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Outreach Event Activity Planner.pdf</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Outreach Tracking Data</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Lead Generation Activity Tracker</span>
          </div>
          <div className="flex items-center gap-2 p-2 hover:bg-white/80 rounded transition-colors">
            <div className="h-2.5 w-2.5 rounded-full bg-accent"></div>
            <span>Lead Conversion Tracking Dashboard</span>
          </div>
        </div>
      </div>
      
      <div className="mt-6 p-5 rounded-lg border-l-4 border-accent bg-brand-50 shadow-sm flex items-center gap-3">
        <div className="bg-accent text-white rounded-full p-1.5 flex-shrink-0">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
        </div>
        <div>
          <b className="text-primary">Action Point:</b> Set daily targets, list online/offline activities, and start tracking with Lead Launchpad spreadsheet.
        </div>
      </div>
    </div>
  </div>
);

export default Playbook4Module1;
