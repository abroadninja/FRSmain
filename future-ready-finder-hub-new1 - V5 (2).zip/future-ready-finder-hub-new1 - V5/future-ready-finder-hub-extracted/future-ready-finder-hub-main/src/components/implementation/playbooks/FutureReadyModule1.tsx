
import React from "react";

/**
 * Future Ready Skills Program - Module 1: Program Introduction
 */
const FutureReadyModule1 = () => (
  <div className="space-y-6">
    <div className="border-b border-accent/20 pb-3">
      <h2 className="text-2xl font-bold text-primary mb-1">Future Ready: Skills for Success Program</h2>
    </div>
    
    <div className="prose max-w-none">
      <div className="bg-brand-50/50 p-5 rounded-lg border border-brand-100 shadow-sm">
        <h3 className="text-xl font-semibold text-secondary mb-2">Program Introduction</h3>
        <p className="text-gray-800">
          A comprehensive approach to equip students with practical skills needed for future success,
          using accessible tools and methodologies.
        </p>
      </div>
      
      <div className="mt-8">
        <h3 className="text-lg font-bold text-primary mb-3">Program Goals</h3>
        <div className="bg-white p-4 rounded-lg shadow-sm">
          <ul className="space-y-2">
            <li className="flex gap-2 items-center">
              <div className="h-2 w-2 rounded-full bg-accent"></div>
              <span className="text-gray-800">Help every student discover their talents and learn practical skills that can lead to good jobs and a successful future</span>
            </li>
            <li className="flex gap-2 items-center">
              <div className="h-2 w-2 rounded-full bg-accent"></div>
              <span className="text-gray-800">Guide students on how they can keep learning and growing even after they leave school</span>
            </li>
            <li className="flex gap-2 items-center">
              <div className="h-2 w-2 rounded-full bg-accent"></div>
              <span className="text-gray-800">Show them how to use simple tools like smartphones, Google, and free AI (like Gemini) to learn anything they want</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="mt-6">
        <h3 className="text-lg font-bold text-primary mb-3">Teacher's Role</h3>
        <div className="bg-white p-4 rounded-lg shadow-sm">
          <ul className="space-y-2">
            <li className="flex gap-2 items-center">
              <div className="h-2 w-2 rounded-full bg-accent"></div>
              <span className="text-gray-800">Act as a guide and motivator rather than teaching every skill directly</span>
            </li>
            <li className="flex gap-2 items-center">
              <div className="h-2 w-2 rounded-full bg-accent"></div>
              <span className="text-gray-800">Spark interest and demonstrate self-directed learning pathways</span>
            </li>
            <li className="flex gap-2 items-center">
              <div className="h-2 w-2 rounded-full bg-accent"></div>
              <span className="text-gray-800">Encourage group collaboration and peer learning</span>
            </li>
            <li className="flex gap-2 items-center">
              <div className="h-2 w-2 rounded-full bg-accent"></div>
              <span className="text-gray-800">Use blackboard/whiteboard for key ideas during limited class time</span>
            </li>
            <li className="flex gap-2 items-center">
              <div className="h-2 w-2 rounded-full bg-accent"></div>
              <span className="text-gray-800">Leverage WhatsApp to share resources, notes, and encouragement</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="mt-6">
        <h3 className="text-lg font-bold text-primary mb-3">Program Structure</h3>
        <div className="bg-white p-5 rounded-lg shadow-sm">
          <div className="mb-4">
            <p className="font-medium text-gray-800">Frequency:</p>
            <p className="text-gray-700">Weekly (2 hours/week) or monthly (2 hours/month), adaptable to school schedules</p>
          </div>
          
          <div>
            <p className="font-medium text-gray-800 mb-2">Session Format:</p>
            <div className="space-y-3 pl-4 border-l-2 border-accent/30">
              <div className="p-2">
                <p className="font-medium text-gray-700">Teacher Introduction (15-20 mins):</p>
                <p className="text-gray-600">Topic introduction, questions, discussion, key points on blackboard</p>
              </div>
              
              <div className="p-2">
                <p className="font-medium text-gray-700">Group Activity (30-60 mins):</p>
                <p className="text-gray-600">Small group discussions, problem-solving, collaborative learning</p>
              </div>
              
              <div className="p-2">
                <p className="font-medium text-gray-700">Home Task Assignment (5-10 mins):</p>
                <p className="text-gray-600">Clear instructions for self-directed learning using phones</p>
              </div>
              
              <div className="p-2">
                <p className="font-medium text-gray-700">Quick Sharing (Optional, 5-10 mins):</p>
                <p className="text-gray-600">Brief student presentations of their learning</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-6">
        <h3 className="text-lg font-bold text-primary mb-3">Main Topics</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="bg-white p-3 rounded-lg shadow-sm flex items-start gap-2">
            <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-accent/10 text-accent font-bold text-xs mt-1">1</span>
            <div>
              <p className="font-medium text-gray-800">Knowing Yourself:</p>
              <p className="text-gray-600">Finding interests and strengths, setting goals, developing growth mindset</p>
            </div>
          </div>
          
          <div className="bg-white p-3 rounded-lg shadow-sm flex items-start gap-2">
            <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-accent/10 text-accent font-bold text-xs mt-1">2</span>
            <div>
              <p className="font-medium text-gray-800">Exploring Jobs & Skills:</p>
              <p className="text-gray-600">Career exploration, high-income skills, diverse job areas</p>
            </div>
          </div>
          
          <div className="bg-white p-3 rounded-lg shadow-sm flex items-start gap-2">
            <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-accent/10 text-accent font-bold text-xs mt-1">3</span>
            <div>
              <p className="font-medium text-gray-800">Learning How to Learn:</p>
              <p className="text-gray-600">Research techniques, using online resources, group study methods</p>
            </div>
          </div>
          
          <div className="bg-white p-3 rounded-lg shadow-sm flex items-start gap-2">
            <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-accent/10 text-accent font-bold text-xs mt-1">4</span>
            <div>
              <p className="font-medium text-gray-800">Building Skills:</p>
              <p className="text-gray-600">Practical projects, portfolio development, skill demonstration</p>
            </div>
          </div>
          
          <div className="bg-white p-3 rounded-lg shadow-sm flex items-start gap-2">
            <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-accent/10 text-accent font-bold text-xs mt-1">5</span>
            <div>
              <p className="font-medium text-gray-800">Working Together:</p>
              <p className="text-gray-600">Communication, feedback, presentation skills</p>
            </div>
          </div>
          
          <div className="bg-white p-3 rounded-lg shadow-sm flex items-start gap-2">
            <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-accent/10 text-accent font-bold text-xs mt-1">6</span>
            <div>
              <p className="font-medium text-gray-800">Planning Next Steps:</p>
              <p className="text-gray-600">Post-school learning plans, education/career exploration</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
        <div>
          <h3 className="text-lg font-bold text-primary mb-3">Parent Engagement</h3>
          <div className="bg-white p-4 rounded-lg shadow-sm h-full">
            <ul className="space-y-2">
              <li className="flex gap-2 items-center">
                <div className="h-2 w-2 rounded-full bg-accent"></div>
                <span className="text-gray-800">Simple explanatory notes about the program's purpose</span>
              </li>
              <li className="flex gap-2 items-center">
                <div className="h-2 w-2 rounded-full bg-accent"></div>
                <span className="text-gray-800">Requests for encouraging exploration and productive phone use</span>
              </li>
              <li className="flex gap-2 items-center">
                <div className="h-2 w-2 rounded-full bg-accent"></div>
                <span className="text-gray-800">Monthly updates on student activities and learning focus</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div>
          <h3 className="text-lg font-bold text-primary mb-3">Key Resources</h3>
          <div className="bg-white p-4 rounded-lg shadow-sm h-full">
            <ol className="space-y-2">
              <li className="flex gap-2 items-center">
                <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-accent/10 text-accent font-bold text-xs">1</span>
                <span className="text-gray-800"><strong>Future-Ready Jobs List:</strong> Comprehensive compilation of diverse career options</span>
              </li>
              <li className="flex gap-2 items-center">
                <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-accent/10 text-accent font-bold text-xs">2</span>
                <span className="text-gray-800"><strong>Learning Paths & Career Steps:</strong> Skill development roadmaps and career progression guides</span>
              </li>
              <li className="flex gap-2 items-center">
                <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-accent/10 text-accent font-bold text-xs">3</span>
                <span className="text-gray-800"><strong>How-To Guides:</strong> Practical instruction for effective research, learning, and collaboration</span>
              </li>
              <li className="flex gap-2 items-center">
                <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-accent/10 text-accent font-bold text-xs">4</span>
                <span className="text-gray-800"><strong>Search Keywords & AI Prompts:</strong> Ready-to-use queries for student self-learning</span>
              </li>
            </ol>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
        <div className="p-5 border-l-4 border-primary bg-primary/5 rounded-lg shadow-sm">
          <h4 className="font-semibold mb-3 text-primary">Encouraging Self-Learning & Group Work</h4>
          <ul className="pl-5 space-y-2 text-gray-700 list-disc">
            <li>Consistently reinforce students' ability to find answers independently</li>
            <li>Design collaborative activities requiring mutual assistance</li>
            <li>Utilize WhatsApp for study groups and resource sharing</li>
            <li>Recognize and praise effort, discovery, and peer support</li>
          </ul>
        </div>

        <div className="p-5 border-l-4 border-accent bg-brand-50 rounded-lg shadow-sm">
          <h4 className="font-semibold mb-3 text-accent">Technology Integration</h4>
          <ul className="pl-5 space-y-2 text-gray-700 list-disc">
            <li>Normalize search engines and AI tools as learning resources</li>
            <li>Teach effective query formulation and information evaluation</li>
            <li>Encourage regional language use when preferred</li>
            <li>Focus on accessible free tools and resources</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
);

export default FutureReadyModule1;
