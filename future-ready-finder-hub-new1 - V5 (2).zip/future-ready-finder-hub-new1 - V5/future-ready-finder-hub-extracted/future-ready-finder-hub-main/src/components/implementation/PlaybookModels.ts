export interface Module {
  id: string;
  title: string;
  summary?: string;
  actionable?: string[];
}

export interface Playbook {
  id: string;
  title: string;
  description: string;
  objective: string;
  audience: string;
  modules: Module[];
}

export const playbooks: Playbook[] = [
  // Implementation Guide Playbook
  {
    id: "pb0",
    title: "Getting Started: Implementation Guide",
    description: "The introductory guide to make implementation extremely easy for all schools.",
    objective: "Provide a macro-level roadmap for implementing all playbooks efficiently.",
    audience: "School leadership, implementation teams, and administrators",
    modules: [
      {
        id: "pb0m1",
        title: "Your School Growth Implementation Roadmap",
        summary: "A comprehensive introduction to implementing all playbooks effectively.",
        actionable: [
          "Review implementation roadmap",
          "Assemble implementation team",
          "Select initial playbook focus",
          "Set up tracking system"
        ]
      }
    ]
  },
  
  // Simple Implementation Guide Playbook (updated name)
  {
    id: "pp1",
    title: "Simple Implementation Guide",
    description: "A streamlined checklist for schools to quickly implement growth strategies with minimal effort.",
    objective: "Provide a simple, step-by-step approach to school growth implementation.",
    audience: "Schools looking for quick wins and simplified implementation methods",
    modules: [
      {
        id: "pp1m1",
        title: "Simple Implementation Checklist",
        summary: "Easy-to-follow guide for implementing school growth strategies efficiently.",
        actionable: [
          "Follow the 15-minute daily implementation system",
          "Use the simple implementation checklist",
          "Apply implementation success principles",
          "Review success stories and adapt for your school"
        ]
      }
    ]
  },
  
  // Standard Playbooks (1-7)
  {
    id: "pb1",
    title: "Immediate Impact – Quick Wins",
    description: "Deploy proven positioning, stand out tomorrow, and turn your school's hidden strengths into immediate inquiries.",
    objective: "Create immediate impact and differentiation through strategic positioning and outreach.",
    audience: "School leaders, marketing teams, admission departments",
    modules: [
      {
        id: "pb1m1",
        title: "Module 1: Powerful Positioning (Immediate Implementation)",
        summary: "Establish a unique school position that stands out in the market.",
        actionable: [
          "Develop your unique positioning statement",
          "Create messaging that highlights future-ready education",
          "Update website and marketing materials",
          "Train staff on new positioning"
        ]
      },
      {
        id: "pb1m2",
        title: "Module 2: Initial Outreach Blitz",
        summary: "Targeted local outreach to existing and prospective parents.",
        actionable: [
          "Engage existing parents as advocates",
          "Target prospective parents within 2-5km radius",
          "Distribute updated marketing materials",
          "Track leads and follow up systematically"
        ]
      }
    ]
  },
  {
    id: "pb2",
    title: "Engaging Your Parent Community",
    description: "Create a thriving parent community that builds loyalty, generates referrals, and boosts retention.",
    objective: "Develop parent engagement systems that foster advocacy and referrals.",
    audience: "School leadership, parent coordination teams, communications staff",
    modules: [
      {
        id: "pb2m1",
        title: "Module 1: High-Value, Trust-Building Touchpoints",
        summary: "Create meaningful interactions with parents at every opportunity.",
        actionable: [
          "Map all parent touchpoints",
          "Design improved parent visit experiences",
          "Establish regular digital value sharing",
          "Create content sharing calendar"
        ]
      },
      {
        id: "pb2m2",
        title: "Module 2: Multiplied Outreach DFY (Tiny Budget)",
        summary: "Set up broadcast channels and targeted parent communities.",
        actionable: [
          "Establish parent WhatsApp/Telegram groups",
          "Create separate existing and prospective parent communities",
          "Implement content sharing strategy",
          "Train staff on community management"
        ]
      }
    ]
  },
  {
    id: "pb3",
    title: "Simple & Effective Admission Process",
    description: "Convert more inquiries to admissions with a streamlined, easy process that eliminates friction.",
    objective: "Optimize the admission process to increase conversion rates significantly.",
    audience: "Admission staff, school administrators, front desk personnel",
    modules: [
      {
        id: "pb3m1",
        title: "Module 1: Simplified Inquiry-to-Admission Process",
        summary: "Streamline the admission funnel for maximum conversions.",
        actionable: [
          "Map and simplify the admission process",
          "Create perpetual communication system",
          "Implement effective lead management",
          "Train admission counselors",
          "Optimize response time and quality"
        ]
      },
      {
        id: "pb3m2",
        title: "Module 2: Parent Ambassador Program",
        summary: "Develop a network of parent advocates driving admissions."
      }
    ]
  },
  {
    id: "pb4",
    title: "Sustainable Growth & Revenue",
    description: "Move beyond one-time admission fees to create predictable revenue streams with proven lead generation systems.",
    objective: "Establish sustainable growth systems and diversified revenue streams.",
    audience: "School management, finance department, leadership team",
    modules: [
      {
        id: "pb4m1",
        title: "Module 1: Systematic Lead Generation"
      },
      {
        id: "pb4m2", 
        title: "Module 2: Revenue Stream Diversification"
      },
      {
        id: "pb4m3",
        title: "Module 3: Retention & Value Enhancement"
      }
    ]
  },
  {
    id: "pb5",
    title: "Future-Ready Education Implementation",
    description: "Transform your curriculum to deliver on the future-ready education promise, becoming truly differentiated.",
    objective: "Implement future-ready education strategies across all grade levels.",
    audience: "Academic leadership, teachers, curriculum designers",
    modules: [
      {
        id: "pb5m1",
        title: "Module 1: Integrating Future-Ready Skills (Classes 2/3 to 7)",
        summary: "Equip younger students with foundational attitudes, skills, and knowledge."
      },
      {
        id: "pb5m2",
        title: "Module 2: Strategic Implementation (Classes 8 to 12)",
        summary: "Implement more advanced future-ready education for older students."
      },
      {
        id: "pb5m3",
        title: "Module 3: Fostering a Future-Ready Culture",
        summary: "Integrate future-ready skills across curriculum and school culture."
      }
    ]
  },
  {
    id: "pb6",
    title: "Effective School-Parent Partnerships",
    description: "Create collaborative partnerships with parents to support student development and school reputation.",
    objective: "Foster productive school-parent relationships that enhance student outcomes.",
    audience: "School leadership, teachers, parent liaison staff",
    modules: [
      {
        id: "pb6m1",
        title: "Module 1: Structured Parent Involvement System"
      },
      {
        id: "pb6m2",
        title: "Module 2: Parent Education & Support"
      }
    ]
  },
  {
    id: "pb7",
    title: "Staff Development & Retention",
    description: "Build a committed, capable team that delivers on your school's promise consistently.",
    objective: "Develop staff capabilities and increase retention through effective practices.",
    audience: "School leadership, HR department, department heads",
    modules: [
      {
        id: "pb7m1",
        title: "Module 1: Teaching Staff Development"
      },
      {
        id: "pb7m2",
        title: "Module 2: Administrative Staff Optimization"
      }
    ]
  },
  
  // High Income Skills Playbook
  {
    id: "hi1",
    title: "High Income Skills Portfolio Building",
    description: "Step-by-step guidance for teachers to help students build portfolios and develop high-income skills.",
    objective: "Equip students with valuable skills for future careers and portfolio development.",
    audience: "Teachers and educators working with students in grades 8-12",
    modules: [
      {
        id: "hi1m1",
        title: "Module 1: Discovering Ourselves & New Opportunities"
      },
      {
        id: "hi1m2",
        title: "Module 2: Exploring Different Ways to Earn"
      },
      {
        id: "hi1m3",
        title: "Module 3: Learning How to Learn Effectively"
      },
      {
        id: "hi1m4",
        title: "Module 4: Building Your Skill Set"
      },
      {
        id: "hi1m5",
        title: "Module 5: Working Together & Sharing Ideas"
      },
      {
        id: "hi1m6",
        title: "Module 6: Organizing Your Portfolio"
      },
      {
        id: "hi1m7",
        title: "Module 7: Computer & Projector Enhanced Implementation"
      }
    ]
  }
];
