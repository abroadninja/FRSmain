import React, { useState, useEffect } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { Playbook, playbooks } from "./PlaybookModels";
import Playbook0Module1 from "./playbooks/Playbook0Module1";
import Playbook1Module1 from "./playbooks/Playbook1Module1";
import Playbook1Module2 from "./playbooks/Playbook1Module2";
import Playbook2Module1 from "./playbooks/Playbook2Module1";
import Playbook2Module2 from "./playbooks/Playbook2Module2";
import Playbook3Module1 from "./playbooks/Playbook3Module1";
import Playbook3Module2 from "./playbooks/Playbook3Module2";
import Playbook4Module1 from "./playbooks/Playbook4Module1";
import Playbook4Module2 from "./playbooks/Playbook4Module2";
import Playbook4Module3 from "./playbooks/Playbook4Module3";
import Playbook5Module1 from "./playbooks/Playbook5Module1";
import Playbook5Module2 from "./playbooks/Playbook5Module2";
import Playbook5Module3 from "./playbooks/Playbook5Module3";
import Playbook6Module1 from "./playbooks/Playbook6Module1";
import Playbook6Module2 from "./playbooks/Playbook6Module2";
import Playbook7Module1 from "./playbooks/Playbook7Module1";
import Playbook7Module2 from "./playbooks/Playbook7Module2";
import HighIncomeSkillsModule1 from "./playbooks/HighIncomeSkillsModule1";
import HighIncomeSkillsModule2 from "./playbooks/HighIncomeSkillsModule2";
import HighIncomeSkillsModule3 from "./playbooks/HighIncomeSkillsModule3";
import HighIncomeSkillsModule4 from "./playbooks/HighIncomeSkillsModule4";
import HighIncomeSkillsModule5 from "./playbooks/HighIncomeSkillsModule5";
import HighIncomeSkillsModule6 from "./playbooks/HighIncomeSkillsModule6";
import HighIncomeSkillsModule7 from "./playbooks/HighIncomeSkillsModule7";
import HighIncomeSkillsKeywordLibrary from "./playbooks/HighIncomeSkillsKeywordLibrary";
import PenPaperImplementationModule1 from "./playbooks/PenPaperImplementationModule1";
import FutureReadyModule1 from "./playbooks/FutureReadyModule1";
import FutureReadyModule2 from "./playbooks/FutureReadyModule2";
import { ChevronRight, Book, Search } from "lucide-react";

const PlaybookContent: React.FC = () => {
  const [searchParams] = useSearchParams();
  const [selectedPlaybook, setSelectedPlaybook] = useState<Playbook | null>(null);
  const [selectedModule, setSelectedModule] = useState<string | null>(null);
  const [showKeywordLibrary, setShowKeywordLibrary] = useState(false);

  useEffect(() => {
    const playbookParam = searchParams.get('playbook');
    const keywordParam = searchParams.get('resource');
    
    if (keywordParam === 'keywords' && playbookParam === 'high-income-skills') {
      setShowKeywordLibrary(true);
      return;
    } else {
      setShowKeywordLibrary(false);
    }
    
    if (playbookParam) {
      const playbook = playbooks.find(p => {
        if (playbookParam === 'high-income') return p.id === 'hi1';
        if (playbookParam === 'implementation-intro') return p.id === 'pb0';
        if (playbookParam === 'pen-paper') return p.id === 'pp1';
        return p.id === playbookParam;
      });
      
      if (playbook) {
        setSelectedPlaybook(playbook);
        // Optionally auto-select first module
        // setSelectedModule(playbook.modules[0].id);
      }
    }
  }, [searchParams]);

  const renderModuleContent = () => {
    if (showKeywordLibrary) {
      return <HighIncomeSkillsKeywordLibrary />;
    }
    
    if (!selectedModule) return null;

    const moduleComponents: Record<string, React.ReactNode> = {
      "pb0m1": <Playbook0Module1 />,
      "pb1m1": <Playbook1Module1 />,
      "pb1m2": <Playbook1Module2 />,
      "pb2m1": <Playbook2Module1 />,
      "pb2m2": <Playbook2Module2 />,
      "pb3m1": <Playbook3Module1 />,
      "pb3m2": <Playbook3Module2 />,
      "pb4m1": <Playbook4Module1 />,
      "pb4m2": <Playbook4Module2 />,
      "pb4m3": <Playbook4Module3 />,
      "pb5m1": <Playbook5Module1 />,
      "pb5m2": <Playbook5Module2 />,
      "pb5m3": <Playbook5Module3 />,
      "pb6m1": <Playbook6Module1 />,
      "pb6m2": <Playbook6Module2 />,
      "pb7m1": <Playbook7Module1 />,
      "pb7m2": <Playbook7Module2 />,
      "hi1m1": <HighIncomeSkillsModule1 />,
      "hi1m2": <HighIncomeSkillsModule2 />,
      "hi1m3": <HighIncomeSkillsModule3 />,
      "hi1m4": <HighIncomeSkillsModule4 />,
      "hi1m5": <HighIncomeSkillsModule5 />,
      "hi1m6": <HighIncomeSkillsModule6 />,
      "hi1m7": <HighIncomeSkillsModule7 />,
      "pp1m1": <PenPaperImplementationModule1 />,
    };

    return moduleComponents[selectedModule] || <p>Module content not found</p>;
  };

  const handleSelectPlaybook = (playbook: Playbook) => {
    setSelectedPlaybook(playbook);
    setSelectedModule(null);
    setShowKeywordLibrary(false);
  };

  const handleSelectModule = (moduleId: string) => {
    setSelectedModule(moduleId);
    setShowKeywordLibrary(false);
  };

  const handleBack = () => {
    if (showKeywordLibrary) {
      setShowKeywordLibrary(false);
      // If coming from a playbook, go back to it
      if (selectedPlaybook && selectedPlaybook.id === 'hi1') {
        return;
      } else {
        setSelectedPlaybook(null);
      }
    } else if (selectedModule) {
      setSelectedModule(null);
    } else {
      setSelectedPlaybook(null);
    }
  };

  const getGroupedPlaybooks = () => {
    // Standard playbooks (1-7)
    const standardPlaybooks = playbooks.filter(p => ['pb1', 'pb2', 'pb3', 'pb4', 'pb5', 'pb6', 'pb7'].includes(p.id));
    
    // Special implementation guide playbooks (0 and pen-paper)
    const implementationPlaybooks = playbooks.filter(p => ['pb0', 'pp1'].includes(p.id));
    
    // Skills playbooks
    const skillsPlaybooks = playbooks.filter(p => ['hi1'].includes(p.id));
    
    return {
      standard: standardPlaybooks,
      implementation: implementationPlaybooks,
      skills: skillsPlaybooks
    };
  };

  const groupedPlaybooks = getGroupedPlaybooks();

  return (
    <div className="p-4">
      {showKeywordLibrary ? (
        <div>
          <div className="mb-6">
            <button
              className="text-primary font-medium mb-2"
              onClick={handleBack}
            >
              ← Back to High Income Skills
            </button>
            <h2 className="text-2xl font-bold text-primary">High Income Skills Resources</h2>
            <h3 className="text-xl font-semibold text-secondary">
              Keyword & Prompt Library
            </h3>
          </div>
          <div className="bg-white rounded-lg shadow-md p-6">
            <HighIncomeSkillsKeywordLibrary />
          </div>
        </div>
      ) : !selectedPlaybook ? (
        <div>
          <h2 className="text-2xl font-bold mb-4">Implementation Playbooks</h2>
          
          {/* Implementation Guide Playbooks Section */}
          <div className="mb-8">
            <h3 className="text-xl font-semibold mb-4 text-gray-700">Implementation Guides & Tools</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {groupedPlaybooks.implementation.map((playbook) => (
                <div
                  key={playbook.id}
                  className="bg-white rounded-lg shadow-md p-6 cursor-pointer hover:shadow-lg transition-shadow border-l-4 border-secondary"
                  onClick={() => handleSelectPlaybook(playbook)}
                >
                  <h3 className="text-xl font-semibold text-secondary mb-2 flex items-center">
                    <Book className="mr-2 h-5 w-5 text-secondary" />
                    {playbook.title}
                  </h3>
                  <p className="text-gray-600 mb-4">{playbook.description}</p>
                  <div className="text-sm text-gray-500">
                    <p><strong>Objective:</strong> {playbook.objective}</p>
                    <p className="mt-2"><strong>For:</strong> {playbook.audience}</p>
                  </div>
                  <div className="mt-4 flex justify-end">
                    <button
                      className="text-secondary font-medium flex items-center"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSelectPlaybook(playbook);
                      }}
                    >
                      View Guide <ChevronRight className="ml-1 h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          {/* Standard Playbooks (1-7) Section */}
          <div className="mb-8">
            <h3 className="text-xl font-semibold mb-4 text-gray-700">School Growth Implementation</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {groupedPlaybooks.standard.map((playbook) => {
                // Extract playbook number from id (e.g., "pb1" -> "1")
                const playbookNumber = playbook.id.replace('pb', '');
                
                return (
                  <div
                    key={playbook.id}
                    className="bg-white rounded-lg shadow-md p-6 cursor-pointer hover:shadow-lg transition-shadow"
                    onClick={() => handleSelectPlaybook(playbook)}
                  >
                    <h3 className="text-xl font-semibold text-primary mb-2 flex items-center">
                      <span className="inline-flex items-center justify-center h-6 w-6 rounded-full bg-primary/10 text-primary font-bold text-sm mr-2">
                        {playbookNumber}
                      </span>
                      {playbook.title}
                    </h3>
                    <p className="text-gray-600 mb-4">{playbook.description}</p>
                    <div className="text-sm text-gray-500">
                      <p><strong>Objective:</strong> {playbook.objective}</p>
                      <p className="mt-2"><strong>For:</strong> {playbook.audience}</p>
                    </div>
                    <div className="mt-4 flex justify-end">
                      <button
                        className="text-primary font-medium flex items-center"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSelectPlaybook(playbook);
                        }}
                      >
                        View Modules <ChevronRight className="ml-1 h-4 w-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          
          {/* Student Skills Programs Section */}
          <div>
            <h3 className="text-xl font-semibold mb-4 text-gray-700">Student Skills Programs</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {groupedPlaybooks.skills.map((playbook) => (
                <div
                  key={playbook.id}
                  className="bg-white rounded-lg shadow-md p-6 cursor-pointer hover:shadow-lg transition-shadow border-l-4 border-green-500"
                  onClick={() => handleSelectPlaybook(playbook)}
                >
                  <h3 className="text-xl font-semibold text-green-700 mb-2 flex items-center">
                    <Book className="mr-2 h-5 w-5 text-green-700" />
                    {playbook.title}
                  </h3>
                  <p className="text-gray-600 mb-4">{playbook.description}</p>
                  <div className="text-sm text-gray-500">
                    <p><strong>Objective:</strong> {playbook.objective}</p>
                    <p className="mt-2"><strong>For:</strong> {playbook.audience}</p>
                  </div>
                  <div className="mt-4 flex justify-end">
                    <button
                      className="text-green-700 font-medium flex items-center"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSelectPlaybook(playbook);
                      }}
                    >
                      View Program <ChevronRight className="ml-1 h-4 w-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div>
          {selectedModule ? (
            <div>
              <div className="mb-6">
                <button
                  className="text-primary font-medium mb-2"
                  onClick={handleBack}
                >
                  ← Back to Modules
                </button>
                <h2 className="text-2xl font-bold text-primary">{selectedPlaybook.title}</h2>
                <h3 className="text-xl font-semibold text-secondary">
                  {selectedPlaybook.modules.find(m => m.id === selectedModule)?.title}
                </h3>
              </div>
              <div className="bg-white rounded-lg shadow-md p-6">
                {renderModuleContent()}
              </div>
              
              {/* Special resources for High Income Skills */}
              {selectedPlaybook.id === 'hi1' && (
                <div className="mt-6 bg-blue-50 p-5 rounded-lg border border-blue-100 shadow-sm">
                  <div className="flex items-center gap-2 text-blue-800 mb-3">
                    <Search className="h-5 w-5" />
                    <h4 className="font-bold text-lg">Supporting Resources</h4>
                  </div>
                  <div className="flex flex-wrap gap-3">
                    <Link 
                      to="/implementation-guides?playbook=high-income-skills&resource=keywords" 
                      className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                    >
                      <Search className="h-4 w-4" /> Keyword & Prompt Library
                    </Link>
                    <Link 
                      to="/career-explorer/clusters" 
                      className="inline-flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
                    >
                      <Book className="h-4 w-4" /> Career Cluster Explorer
                    </Link>
                    <Link 
                      to="/career-explorer/problem-solving" 
                      className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors"
                    >
                      <Book className="h-4 w-4" /> Problem-Based Career Matching
                    </Link>
                    <Link 
                      to="/career-explorer/assessment" 
                      className="inline-flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700 transition-colors"
                    >
                      <Book className="h-4 w-4" /> Psychometric Career Assessment
                    </Link>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div>
              <button
                className="text-primary font-medium mb-4"
                onClick={handleBack}
              >
                ← Back to Playbooks
              </button>
              
              {/* Show playbook number for standard playbooks (1-7) */}
              {selectedPlaybook.id.startsWith('pb') && selectedPlaybook.id !== 'pb0' && (
                <h2 className="text-2xl font-bold text-primary mb-2">
                  <span className="inline-flex items-center justify-center h-7 w-7 rounded-full bg-primary/10 text-primary font-bold text-sm mr-2">
                    {selectedPlaybook.id.replace('pb', '')}
                  </span>
                  {selectedPlaybook.title}
                </h2>
              )}
              
              {/* For non-standard playbooks, don't show number */}
              {(selectedPlaybook.id === 'pb0' || !selectedPlaybook.id.startsWith('pb')) && (
                <h2 className="text-2xl font-bold text-primary mb-2">{selectedPlaybook.title}</h2>
              )}
              
              <p className="text-gray-600 mb-6">{selectedPlaybook.description}</p>
              
              <div className="bg-white rounded-lg shadow-md p-6 mb-6">
                <h3 className="text-xl font-semibold mb-2">Overview</h3>
                <p><strong>Objective:</strong> {selectedPlaybook.objective}</p>
                <p className="mt-2"><strong>Target Audience:</strong> {selectedPlaybook.audience}</p>
              </div>
              
              <h3 className="text-xl font-semibold mb-4">Modules</h3>
              <div className="grid grid-cols-1 gap-4">
                {selectedPlaybook.modules.map((module) => (
                  <div
                    key={module.id}
                    className="bg-white rounded-lg shadow-md p-6 cursor-pointer hover:shadow-lg transition-shadow"
                    onClick={() => handleSelectModule(module.id)}
                  >
                    <h4 className="text-lg font-semibold text-primary">{module.title}</h4>
                    {module.summary && <p className="text-gray-600 mt-2">{module.summary}</p>}
                    
                    {module.actionable && module.actionable.length > 0 && (
                      <div className="mt-4">
                        <p className="text-sm font-semibold text-gray-700">Key Actions:</p>
                        <ul className="list-disc list-inside text-sm text-gray-600">
                          {module.actionable.slice(0, 2).map((action, idx) => (
                            <li key={idx}>{action}</li>
                          ))}
                          {module.actionable.length > 2 && (
                            <li className="text-primary">
                              +{module.actionable.length - 2} more actions...
                            </li>
                          )}
                        </ul>
                      </div>
                    )}
                    
                    <div className="mt-4 flex justify-end">
                      <button
                        className="text-primary font-medium flex items-center"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleSelectModule(module.id);
                        }}
                      >
                        View Content <ChevronRight className="ml-1 h-4 w-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Special resources for High Income Skills */}
              {selectedPlaybook.id === 'hi1' && (
                <div className="mt-6 bg-blue-50 p-5 rounded-lg border border-blue-100 shadow-sm">
                  <div className="flex items-center gap-2 text-blue-800 mb-3">
                    <Search className="h-5 w-5" />
                    <h4 className="font-bold text-lg">Supporting Resources</h4>
                  </div>
                  <div className="flex flex-wrap gap-3">
                    <Link 
                      to="/implementation-guides?playbook=high-income-skills&resource=keywords" 
                      className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                    >
                      <Search className="h-4 w-4" /> Keyword & Prompt Library
                    </Link>
                    <Link 
                      to="/career-explorer/clusters" 
                      className="inline-flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
                    >
                      <Book className="h-4 w-4" /> Career Cluster Explorer
                    </Link>
                    <Link 
                      to="/career-explorer/problem-solving" 
                      className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors"
                    >
                      <Book className="h-4 w-4" /> Problem-Based Career Matching
                    </Link>
                    <Link 
                      to="/career-explorer/assessment" 
                      className="inline-flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700 transition-colors"
                    >
                      <Book className="h-4 w-4" /> Psychometric Career Assessment
                    </Link>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default PlaybookContent;
