
import { Module } from "../PlaybookModels";

// Define modules for the Future Ready Skills playbook
export const futureReadyModules: Module[] = [
  {
    id: "fr1m1",
    title: "Program Introduction & Implementation Guide",
    summary: "Overview of the Future Ready Skills program and how to implement it effectively in any school setting.",
    actionable: [
      "Understand program objectives and structure",
      "Review flexible implementation approaches",
      "Plan for resource utilization",
      "Develop assessment strategies"
    ]
  },
  {
    id: "fr1m2",
    title: "Knowing Yourself & Your Potential",
    summary: "Help students understand their own strengths, interests, and the power of believing in their ability to learn and grow.",
    actionable: [
      "Conduct strength spotting group activities",
      "Introduce growth mindset concepts",
      "Facilitate self-reflection exercises",
      "Guide personality exploration"
    ]
  },
  {
    id: "fr1m3",
    title: "Exploring the World of Work & Skills",
    summary: "Broadening students' understanding of different job types, industries, and the skills needed, including new and emerging opportunities.",
    actionable: [
      "Categorize job types for easy understanding",
      "Explore high-demand skills across industries",
      "Introduce niche specialization concepts",
      "Research career options relevant to interests"
    ]
  },
  {
    id: "fr1m4",
    title: "Learning How to Learn Effectively",
    summary: "Teaching students how to find information, learn from online resources, use AI tools smartly, take notes, manage time, and learn in groups.",
    actionable: [
      "Demonstrate effective search techniques",
      "Practice using AI tools for learning",
      "Teach basic note-taking methods",
      "Implement group learning strategies"
    ]
  },
  {
    id: "fr1m5",
    title: "Starting to Build Skills & Your Portfolio",
    summary: "Encouraging students to try learning practical skills through beginner projects and starting to collect examples of their work.",
    actionable: [
      "Introduce learning roadmaps for key skills",
      "Facilitate simple skill practice activities",
      "Guide portfolio collection methods",
      "Create learning documentation systems"
    ]
  },
  {
    id: "fr1m6",
    title: "Communication & Collaboration",
    summary: "Helping students communicate ideas clearly, work effectively in teams, and give/receive helpful feedback.",
    actionable: [
      "Teach clear messaging techniques",
      "Practice the feedback sandwich method",
      "Develop effective teamwork strategies",
      "Build basic presentation skills"
    ]
  },
  {
    id: "fr1m7",
    title: "Organizing Your Portfolio & Planning",
    summary: "Helping students organize their Skill Portfolio Notebook, make ongoing learning plans, and research future options.",
    actionable: [
      "Structure portfolio organization systems",
      "Create personal learning plans",
      "Research potential education pathways",
      "Develop continuous improvement habits"
    ]
  }
];
