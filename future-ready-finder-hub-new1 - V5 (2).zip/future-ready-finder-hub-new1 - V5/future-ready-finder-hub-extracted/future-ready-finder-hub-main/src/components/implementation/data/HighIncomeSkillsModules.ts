
export const highIncomeSkillsModules = [
  {
    id: "hi1m1",
    title: "Module 1: Discovering Ourselves & New Opportunities",
    summary: "Help students identify their unique strengths, interests, and relevant skill opportunities through thoughtful self-reflection and guided exploration.",
    actionable: [
      "Lead strength identification sessions",
      "Facilitate future role exploration",
      "Introduce the portfolio notebook system",
      "Guide students in documenting their first reflections"
    ]
  },
  {
    id: "hi1m2",
    title: "Module 2: Exploring Different Ways to Earn",
    summary: "Introduce students to various paths for using their skills in the future, from employment to entrepreneurship, with accessible local examples.",
    actionable: [
      "Use the Big List of Future-Ready Jobs activity",
      "Facilitate the Three Paths exploration exercise",
      "Guide students in identifying practical next steps",
      "Help students document career interests in their portfolios"
    ]
  },
  {
    id: "hi1m3",
    title: "Module 3: Learning How to Learn Effectively",
    summary: "Build core learning habits and information literacy skills that enable students to learn any new skill efficiently.",
    actionable: [
      "Teach effective internet search strategies",
      "Guide students in evaluating information sources",
      "Facilitate development of personal learning strategies",
      "Introduce time management and planning methods"
    ]
  },
  {
    id: "hi1m4",
    title: "Module 4: Building Your Skill Set",
    summary: "Guide students in selecting and developing practical skills through mini-projects and continuous learning.",
    actionable: [
      "Facilitate skill selection based on interests and strengths",
      "Guide project-based skill development",
      "Help students create learning plans",
      "Support portfolio documentation of skills and projects"
    ]
  },
  {
    id: "hi1m5",
    title: "Module 5: Working Together & Sharing Ideas",
    summary: "Develop essential communication and collaboration skills that enhance any technical skill set.",
    actionable: [
      "Facilitate group activities to build collaboration skills",
      "Teach effective communication methods",
      "Guide students in giving and receiving constructive feedback",
      "Help students document their teamwork experiences"
    ]
  },
  {
    id: "hi1m6",
    title: "Module 6: Organizing Your Portfolio & Planning Your Ongoing Journey",
    summary: "Help students organize their portfolios, develop future plans, and understand resources for continued growth.",
    actionable: [
      "Guide portfolio organization and enhancement",
      "Facilitate research on future paths and opportunities",
      "Support development of continued learning plans",
      "Connect students with ongoing guidance resources"
    ]
  },
  {
    id: "hi1m7",
    title: "Module 7: Computer & Projector Enhanced Implementation",
    summary: "Advanced implementation strategies for schools with computer and projector access to enhance the learning experience.",
    actionable: [
      "Implement visual demonstrations using technology",
      "Facilitate interactive digital activities",
      "Showcase student work using digital platforms",
      "Provide enhanced access to digital resources and guest speakers"
    ]
  }
];
