
import React from "react";
import { BookOpen, GraduationCap, FileText } from "lucide-react";

const TeacherMaterials: React.FC = () => {
  const materialCategories = [
    {
      id: "lesson-plans",
      title: "Lesson Plans & Activities",
      icon: <BookOpen className="h-6 w-6 text-primary" />,
      description: "Ready-to-use classroom materials for teaching future-ready skills",
      materials: [
        { title: "Critical Thinking Activities (Grades 3-7)", type: "Lesson Pack" },
        { title: "Financial Literacy Curriculum (Elementary)", type: "Unit Plan" },
        { title: "Digital Skills Project Ideas", type: "Activity Guide" },
      ]
    },
    {
      id: "high-income-skills",
      title: "High-Income Skills Guidance",
      icon: <GraduationCap className="h-6 w-6 text-primary" />,
      description: "Resources for delivering career and high-income skills guidance sessions",
      materials: [
        { title: "Career Cluster Discussion Guide", type: "Facilitator Guide" },
        { title: "Portfolio Development Framework", type: "Template" },
        { title: "Industry Expert Connection Toolkit", type: "Resource Guide" },
      ]
    },
    {
      id: "assessment-tools",
      title: "Assessment & Tracking Tools",
      icon: <FileText className="h-6 w-6 text-primary" />,
      description: "Instruments for measuring and tracking student progress in future-ready skills",
      materials: [
        { title: "Future Skills Readiness Assessment", type: "Assessment" },
        { title: "Student Career Interest Inventory", type: "Questionnaire" },
        { title: "Skills Progress Tracking Template", type: "Spreadsheet" },
      ]
    },
  ];

  return (
    <div className="p-4">
      <h2 className="text-2xl font-bold mb-6">Teacher Materials Library</h2>
      <p className="text-gray-600 mb-8">
        Comprehensive resources designed to help teachers implement future-ready skill development and 
        high-income skill guidance in their classrooms. These materials support the implementation of the strategies 
        outlined in the playbooks.
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {materialCategories.map((category) => (
          <div key={category.id} className="bg-white rounded-lg shadow-md overflow-hidden h-full flex flex-col">
            <div className="bg-primary/5 p-5">
              <div className="flex items-center">
                {category.icon}
                <h3 className="text-xl font-semibold ml-3">{category.title}</h3>
              </div>
              <p className="text-gray-600 mt-2">{category.description}</p>
            </div>
            <div className="p-5 flex-1 flex flex-col">
              <ul className="space-y-3 flex-1">
                {category.materials.map((material, index) => (
                  <li key={index} className="flex items-center justify-between">
                    <span>{material.title}</span>
                    <span className="text-xs font-medium bg-gray-100 px-2 py-1 rounded">
                      {material.type}
                    </span>
                  </li>
                ))}
              </ul>
              <div className="mt-4 flex justify-end">
                <button className="text-primary font-medium">
                  Coming Soon
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-xl font-semibold mb-3">Teacher Training Resources</h3>
          <p className="text-gray-600 mb-4">
            Professional development materials to help teachers build their skills in future-ready education.
          </p>
          <ul className="space-y-2 text-gray-700">
            <li className="flex items-center">
              <div className="h-2 w-2 rounded-full bg-primary mr-2"></div>
              <span>Guiding Student Career Exploration Workshop</span>
            </li>
            <li className="flex items-center">
              <div className="h-2 w-2 rounded-full bg-primary mr-2"></div>
              <span>Using Assessment Data Effectively</span>
            </li>
            <li className="flex items-center">
              <div className="h-2 w-2 rounded-full bg-primary mr-2"></div>
              <span>Integrating Future Skills Across Subjects</span>
            </li>
          </ul>
          <div className="mt-4 flex justify-end">
            <button className="text-primary font-medium">Coming Soon</button>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-xl font-semibold mb-3">Request Custom Materials</h3>
          <p className="text-gray-600 mb-4">
            Need specific materials for your school's implementation? Our team can help develop custom resources 
            tailored to your needs.
          </p>
          <div className="flex items-center text-accent mt-4">
            <span className="font-medium">Contact us for custom materials</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TeacherMaterials;
