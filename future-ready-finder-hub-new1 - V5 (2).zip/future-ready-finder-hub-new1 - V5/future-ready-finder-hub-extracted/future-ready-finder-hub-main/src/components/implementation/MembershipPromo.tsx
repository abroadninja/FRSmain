
import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { MessageSquare, Users, Award, Star } from "lucide-react";

const MembershipPromo = () => {
  return (
    <Card className="overflow-hidden border-none shadow-md rounded-2xl bg-white">
      {/* Top section with banner */}
      <div className="relative bg-gradient-to-r from-blue-600 to-blue-700 p-5 text-white">
        <h3 className="text-xl font-bold">Join Our Premium Growth Network</h3>
        <p className="text-sm text-white/90 mt-1">
          Connect with school leaders and get expert guidance while maintaining access to all free resources
        </p>
        
        {/* Feature highlights */}
        <div className="grid grid-cols-3 gap-2 mt-4">
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 flex flex-col items-center text-center">
            <div className="bg-white/20 p-2 rounded-full mb-2">
              <MessageSquare className="h-4 w-4 text-white" />
            </div>
            <p className="font-medium text-xs">Expert Support</p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 flex flex-col items-center text-center">
            <div className="bg-white/20 p-2 rounded-full mb-2">
              <Users className="h-4 w-4 text-white" />
            </div>
            <p className="font-medium text-xs">School Network</p>
          </div>
          
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-3 flex flex-col items-center text-center">
            <div className="bg-white/20 p-2 rounded-full mb-2">
              <Award className="h-4 w-4 text-white" />
            </div>
            <p className="font-medium text-xs">Growth Tools</p>
          </div>
        </div>
      </div>
      
      {/* Benefits list */}
      <CardContent className="p-5">
        <h4 className="font-semibold text-gray-800 mb-3">Premium Network Benefits</h4>
        <ul className="space-y-2.5">
          <li className="flex">
            <span className="inline-flex items-center justify-center bg-green-100 text-green-800 rounded-full w-5 h-5 mr-2.5 flex-shrink-0">
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
              </svg>
            </span>
            <span className="text-sm">Weekly Q&A sessions with education experts</span>
          </li>
          
          <li className="flex">
            <span className="inline-flex items-center justify-center bg-green-100 text-green-800 rounded-full w-5 h-5 mr-2.5 flex-shrink-0">
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
              </svg>
            </span>
            <span className="text-sm">Connect with schools implementing our system</span>
          </li>
          
          <li className="flex">
            <span className="inline-flex items-center justify-center bg-green-100 text-green-800 rounded-full w-5 h-5 mr-2.5 flex-shrink-0">
              <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
              </svg>
            </span>
            <span className="text-sm">Implementation support and coaching</span>
          </li>
        </ul>
        
        {/* Testimonial */}
        <div className="bg-gray-50 rounded-lg p-4 mt-4">
          <div className="flex items-start">
            <Star className="h-4 w-4 text-yellow-500 mt-1 mr-2 flex-shrink-0" />
            <div>
              <p className="text-sm italic text-gray-600">
                "The premium network has been invaluable for our school's transformation journey. The expert guidance and community support make all the difference."
              </p>
              <p className="text-sm font-medium mt-1">- School Principal</p>
            </div>
          </div>
        </div>
      </CardContent>
      
      {/* Call to action */}
      <CardFooter className="px-5 pb-5 pt-0">
        <Button asChild className="w-full bg-blue-600 hover:bg-blue-700">
          <Link to="/membership" className="flex items-center justify-center">
            Learn About Premium Network
          </Link>
        </Button>
        <p className="text-xs text-center text-gray-500 mt-2">
          All implementation resources remain free for everyone
        </p>
      </CardFooter>
    </Card>
  );
};

export default MembershipPromo;
