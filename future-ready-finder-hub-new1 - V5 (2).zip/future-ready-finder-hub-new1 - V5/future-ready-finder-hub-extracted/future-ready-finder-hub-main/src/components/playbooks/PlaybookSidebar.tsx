
import React from "react";
import { BookOpen, ChevronRight } from "lucide-react";

// Sidebar receives playbooks array, selectedPlaybook, setSelectedPlaybook, etc.
const PlaybookSidebar = ({
  playbooks, selectedPlaybook, setSelectedPlaybook, selectedModule, setSelectedModule,
}: {
  playbooks: {id: string, title: string, modules: {id: string, title:string}[]}[];
  selectedPlaybook: string;
  setSelectedPlaybook: (id: string) => void;
  selectedModule: string;
  setSelectedModule: (id: string) => void;
}) => (
  <nav className="p-6">
    <h2 className="text-xl font-bold mb-8 text-primary flex items-center gap-2">
      <BookOpen className="h-6 w-6 text-accent" />
      Playbooks App
    </h2>
    <div className="space-y-6">
      {playbooks.map(pb => (
        <div key={pb.id}>
          <button
            className={`w-full text-left font-semibold transition text-lg py-1 px-2 rounded-md
            ${pb.id === selectedPlaybook ? "bg-accent/10 text-accent" : "hover:bg-gray-50 text-gray-700"}`}
            onClick={() => {
              setSelectedPlaybook(pb.id);
              setSelectedModule(pb.modules[0].id);
            }}
          >
            {pb.title}
          </button>
          <div className="pl-4 mt-2 space-y-1">
            {pb.modules.map(mod => (
              <button
                key={mod.id}
                className={`flex items-center gap-1 px-2 py-1 rounded transition
                ${mod.id === selectedModule ? "bg-brand-100 text-primary font-bold" : "text-gray-600 hover:bg-gray-50"}`}
                onClick={() => setSelectedModule(mod.id)}
              >
                <ChevronRight className="h-4 w-4" />
                <span>{mod.title}</span>
              </button>
            ))}
          </div>
        </div>
      ))}
      <div className="mt-10 text-xs text-gray-500 border-t pt-8 border-accent/20">
        <b className="block text-sm text-primary mb-1">All-in-One Guidance Hub</b>
        <div className="text-gray-500">Discover all implementation strategies and playbooks—<b>exclusive to our partner schools.</b></div>
        <div className="mt-3 italic opacity-80">More playbooks and modules coming soon.</div>
      </div>
    </div>
  </nav>
);

export default PlaybookSidebar;
