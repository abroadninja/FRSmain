import React from "react";
import { Link } from "react-router-dom";
import { BookUser, Search, Briefcase, Brain, Activity } from "lucide-react";
import { 
  HighIncomeSkillsModule1, 
  HighIncomeSkillsModule2, 
  HighIncomeSkillsModule3, 
  HighIncomeSkillsKeywordLibrary 
} from "@/components/implementation";
import HighIncomeSkillsModule6 from "@/components/implementation/playbooks/HighIncomeSkillsModule6";
import HighIncomeSkillsModule4 from "@/components/implementation/playbooks/HighIncomeSkillsModule4";
import HighIncomeSkillsModule5 from "@/components/implementation/playbooks/HighIncomeSkillsModule5";
import HighIncomeSkillsModule7 from "@/components/implementation/playbooks/HighIncomeSkillsModule7";

const renderModuleContent = (playbookId: string, moduleId: string) => {
  // ---- Playbook 1 ----
  if (playbookId === "pb1" && moduleId === "pb1m1") {
    return (
      <section className="bg-white/90 p-10 md:p-12">
        <h1 className="text-3xl font-extrabold text-primary mb-2">Immediate Impact – Quick Wins for a Standout School</h1>
        <h2 className="text-xl mb-8 font-semibold text-accent">Module 1: Powerful Positioning (Immediate Implementation)</h2>
        <p className="mb-3 text-gray-800 text-lg">
          <span className="font-bold text-primary">Objective:</span>  
          <span> Provide schools with ready-to-deploy strategies and "Done-for-You" resources to create immediate impact, establish a distinct brand, and attract parent inquiries.</span>
        </p>
        <ul className="list-disc ml-6 mb-5 text-md text-gray-700 space-y-1">
          <li>Establish a <span className="font-bold">unique, memorable school position</span>—stand out from generic crowd!</li>
          <li>Highlight <span className="font-bold">future-ready education</span> and <span className="font-bold">high-income skill building</span> as your core distinctive edge.</li>
          <li>Cultivate thriving parent + student communities for sustainable growth.</li>
          <li>Utilize "Done-for-You" materials: standout websites, flyers, brand kits—<span className="text-accent font-bold">no need to reinvent the wheel!</span></li>
        </ul>
        <h3 className="text-lg mt-6 font-semibold text-secondary mb-1">Why Unique Positioning?</h3>
        <ul className="list-disc ml-6 mb-3 text-gray-600">
          <li>Attracts the right-fit families who value your future-driven approach</li>
          <li>Builds trust & makes your value easy to understand—no more generic "just another school"</li>
          <li>Lets you justify your fees—<span className="font-bold">parents see what sets you apart</span></li>
        </ul>
        <div className="my-6 p-4 bg-brand-50 border-l-4 border-brand-400 shadow-inner rounded">
          <b>The "New Standard": Holistic Future Readiness & High-Income Skill Guidance</b>
          <div className="text-gray-700 mt-2">
            <ul className="list-disc ml-6">
              <li>Go beyond academics: critical thinking, digital skills, creativity, self-awareness, financial literacy + more.</li>
              <li>Help students (8th-12th) build <b>real-world portfolios</b> leading to high-paying careers.</li>
              <li>Unite your entire community—parents, teachers, students—under one mission.</li>
              <li>Deliver <b>unbeatable value</b> at normal fees. <span className="text-primary">(No other school matches this!)</span></li>
            </ul>
          </div>
        </div>
        <h3 className="font-bold text-primary mt-6 mb-1">Get Started Instantly</h3>
        <ol className="list-decimal ml-6 text-gray-800">
          <li><b>Leverage pre-built positioning:</b> Access <span className="text-accent">website & flyer templates</span>—fully customizable.</li>
          <li><b>Identify your unique strengths:</b> Use internal assessments and our frameworks (USP worksheet, mission guides).</li>
          <li><b>Craft strong messaging:</b> Use ready-made headlines, benefit-packed language, and your "irresistible promise."</li>
        </ol>
        <div className="mt-8 bg-brand-50 p-4 rounded-xl border border-brand-100">
          <b>💡 Pro Tip:</b> Transform your school's brand <b className="text-brand-600">this week</b> using our "Immediate Positioning Updates Checklist". <span className="text-accent">See the Playbooks Hub for all guides, checklists, and templates.</span>
        </div>
      </section>
    );
  }
  if (playbookId === "pb1" && moduleId === "pb1m2") {
    return (
      <section className="bg-white/95 p-10 md:p-12">
        <h2 className="text-xl font-semibold mb-2 text-primary">Module 2: Initial Outreach Blitz (Existing Parents & Local Vicinity)</h2>
        <p className="mb-4 text-lg text-gray-800">
          Maximize impact by focusing outreach where you'll see the best results—existing parents and families within a 2-5km radius of your school.
        </p>
        <ul className="list-disc ml-6 text-md text-gray-700">
          <li>
            <b>Engage existing parents first:</b> Turn them into "insider" advocates—get them excited about your new focus.
          </li>
          <li>
            <b>Go hyper-local:</b> Target parents in your neighborhood through direct interactions, flyers, micro-events, and strategic partnerships.
          </li>
          <li>
            <b>Collect leads & build community:</b> Always offer value: invite to your exclusive parent community, share tips/resources, & gather contact info using our Lead Launchpad.
          </li>
          <li>
            <b>Leverage ready-to-use materials:</b> Use our "Done-for-You" flyers and outreach scripts for instant impact!
          </li>
        </ul>
        <div className="mt-7 p-4 bg-accent/10 border-l-4 border-accent rounded">
          <b>Action Point:</b> Set daily lead goals, run your first "parent meet" or micro-event, and start tracking results. <span className="text-accent font-bold">All templates/checklists are in the Playbooks Hub.</span>
        </div>
      </section>
    );
  }

  // ---- Playbook 2 ----
  if (playbookId === "pb2" && moduleId === "pb2m1") {
    return (
      <section className="bg-white/90 p-10 md:p-12">
        <h1 className="text-3xl font-extrabold text-primary mb-2">
          Engaging Your Parent Community (Your Goldmine)
        </h1>
        <h2 className="text-xl font-semibold mb-7 text-accent">Module 1: High-Value, Trust-Building Touchpoints</h2>
        <p className="mb-3 text-lg text-gray-800">
          Build ironclad trust and loyalty through regular high-value interactions at every touchpoint.
        </p>
        <ul className="list-disc ml-6 mb-5 text-md text-gray-700 space-y-1">
          <li>Make parent visits, PTMs, and school events memorable—always highlight your unique, future-ready approach.</li>
          <li>Prioritize <span className="font-bold text-primary">parent WhatsApp & Telegram communities</span> for regular value sharing and two-way engagement.</li>
          <li>Use plug-&-play content ideas: future readiness, education trends, school success stories, expert Q&As.</li>
          <li>Share <span className="font-bold">"curated resource lists"</span>—make every interaction about adding value.</li>
        </ul>
        <div className="mt-7 p-4 bg-accent/10 border-l-4 border-accent rounded">
          <b>Action Point:</b> Choose just 1–2 easy ways to make parent visits better this week. Start using our ready-made content/curation guides today.
        </div>
      </section>
    );
  }
  if (playbookId === "pb2" && moduleId === "pb2m2") {
    return (
      <section className="bg-white/95 p-10 md:p-12">
        <h2 className="text-xl font-semibold mb-2 text-primary">Module 2: Multiplied Outreach DFY (Zero/Tiny Budget)</h2>
        <ul className="list-disc ml-6 mb-5 text-md text-gray-700 space-y-1">
          <li>Set up WhatsApp & Telegram communities—for both existing and prospective parent groups.</li>
          <li>Craft unique value-driven content calendars for each group, using our easy templates and ready-to-go ideas.</li>
          <li>Send tailored community invites & welcome messages for personalized onboarding.</li>
          <li>Leverage "broadcast" channels for tips, updates, and exclusive offers.</li>
          <li>Scale relationships, trust, and referrals with minimal spend!</li>
        </ul>
        <div className="mt-8 bg-brand-50 p-4 rounded-xl border border-brand-100">
          <b>💡 Pro Tip:</b> Download all tools, templates, onboarding guides, and invite templates from the Playbooks Hub.
        </div>
      </section>
    );
  }

  // ---- High Income Skills Playbook ----
  if (playbookId === "hi1" && moduleId === "hi1m1") {
    return <HighIncomeSkillsModule1 />;
  }
  if (playbookId === "hi1" && moduleId === "hi1m2") {
    return <HighIncomeSkillsModule2 />;
  }
  if (playbookId === "hi1" && moduleId === "hi1m3") {
    return <HighIncomeSkillsModule3 />;
  }
  if (playbookId === "hi1" && moduleId === "hi1m4") {
    return <HighIncomeSkillsModule4 />;
  }
  if (playbookId === "hi1" && moduleId === "hi1m5") {
    return <HighIncomeSkillsModule5 />;
  }
  if (playbookId === "hi1" && moduleId === "hi1m6") {
    return <HighIncomeSkillsModule6 />;
  }
  if (playbookId === "hi1" && moduleId === "hi1m7") {
    return <HighIncomeSkillsModule7 />;
  }
  
  // Special handler for Keyword Library
  if (playbookId === "hi1" && moduleId === "hi1keywords") {
    return <HighIncomeSkillsKeywordLibrary />;
  }

  // Fallback for missing content
  return (
    <section className="p-10">
      <h2 className="text-xl font-bold mb-2 text-secondary">More playbooks coming soon</h2>
      <p className="text-gray-700">Check back later for new implementation modules and guidance.</p>
    </section>
  );
};

const PlaybookContent = ({ playbookId, moduleId }: { playbookId: string; moduleId: string }) => {
  // Check if this is a high income skills playbook to show student guides
  const isHighIncomeSkillsPlaybook = playbookId === "hi1";
  
  return (
    <div>
      {renderModuleContent(playbookId, moduleId)}
      
      {isHighIncomeSkillsPlaybook && moduleId !== "hi1keywords" && (
        <div className="mt-8 p-5 bg-blue-50 rounded-lg border border-blue-100">
          <h3 className="text-lg font-bold text-primary mb-3">Supporting Resources</h3>
          <p className="mb-4 text-gray-700">
            Access these helpful resources to support the High Income Skills program:
          </p>
          <div className="flex flex-wrap gap-3">
            <Link 
              to="/student-guides" 
              className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              <BookUser className="h-4 w-4" /> Access Student Guides
            </Link>
            <a 
              href="https://resource-hub.futurereadyschools.com/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
            >
              <Search className="h-4 w-4" /> Resources Hub
            </a>
            <Link 
              to="/career-explorer/clusters" 
              className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors"
            >
              <Briefcase className="h-4 w-4" /> Career Cluster Explorer
            </Link>
            <Link 
              to="/career-explorer/problem-solving" 
              className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
            >
              <Brain className="h-4 w-4" /> Problem-Based Career Matching
            </Link>
            <Link 
              to="/career-explorer/assessment" 
              className="inline-flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-md hover:bg-orange-700 transition-colors"
            >
              <Activity className="h-4 w-4" /> Psychometric Career Assessment
            </Link>
          </div>
        </div>
      )}
      
      <div className="border-t mt-10 pt-6 text-center text-xs text-gray-400">
        <b>All playbooks & implementation modules are exclusive to verified schools and school management. <br />
        Much more is being added – stay tuned!</b>
      </div>
    </div>
  );
};

export default PlaybookContent;
