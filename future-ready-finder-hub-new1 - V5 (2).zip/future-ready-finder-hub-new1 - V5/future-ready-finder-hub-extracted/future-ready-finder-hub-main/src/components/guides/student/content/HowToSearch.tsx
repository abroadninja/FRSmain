
import React from "react";

const HowToSearch = () => {
  return (
    <div className="prose max-w-none">
      <h2 className="text-2xl font-bold text-primary mb-4">How to Search Smartly on Google</h2>
      
      <div className="bg-blue-50 p-4 rounded-lg mb-6">
        <h3 className="text-lg font-semibold mb-2">Why This Matters</h3>
        <p>
          Google has almost all information, but finding the right information quickly and knowing 
          if it's trustworthy saves you a lot of time and helps you learn correctly.
        </p>
      </div>

      <h3 className="text-xl font-semibold text-primary mt-6 mb-3">Search Techniques</h3>
      
      <div className="space-y-4">
        <div className="bg-white p-4 border-l-4 border-blue-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Be Specific</h4>
          <p>
            Use detailed keywords. Instead of searching "jobs", try "data entry jobs work from home India" 
            or "government jobs for 12th pass near Parvathipuram".
          </p>
        </div>
        
        <div className="bg-white p-4 border-l-4 border-blue-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Use Quotes ""</h4>
          <p>
            For exact phrases. Search "Future Ready Skills Success" to find pages with exactly those words in that order. 
            Great for finding specific names or titles.
          </p>
          <div className="bg-gray-50 p-2 rounded mt-2">
            <span className="font-mono text-sm">Example: "best computer courses in Andhra Pradesh"</span>
          </div>
        </div>
        
        <div className="bg-white p-4 border-l-4 border-blue-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Use Minus -</h4>
          <p>
            To remove unwanted results. Search "mango recipes -juice" if you want recipes but not juice. 
            Search "best free courses -udemy" if you want to exclude Udemy results.
          </p>
          <div className="bg-gray-50 p-2 rounded mt-2">
            <span className="font-mono text-sm">Example: content writing jobs -freelance</span>
          </div>
        </div>
        
        <div className="bg-white p-4 border-l-4 border-blue-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Ask Questions</h4>
          <p>
            Type your question directly, like "What is the capital of Andhra Pradesh?" or "How does photosynthesis work?".
          </p>
        </div>
        
        <div className="bg-white p-4 border-l-4 border-blue-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Search in Your Language</h4>
          <p>
            Don't hesitate to search in Telugu or other regional languages. Google understands!
          </p>
          <div className="bg-gray-50 p-2 rounded mt-2">
            <span className="font-mono text-sm">Example: పార్వతీపురం మన్యం జిల్లాలో వాతావరణం (Climate in Parvathipuram Manyam district)</span>
          </div>
        </div>
      </div>
      
      <div className="bg-orange-50 border-l-4 border-orange-500 p-4 rounded my-6">
        <h3 className="font-bold text-orange-800">Check the Source! (VERY IMPORTANT)</h3>
        <p className="mt-2">
          Look at the website address. Is it official (like .gov.in, .nic.in, .ap.gov.in)? 
          Is it a well-known news source (like The Hindu, BBC)? Is it an educational site (.edu, .ac.in)? 
          Or is it just someone's personal blog or a site full of ads? Be careful – not all websites are reliable.
        </p>
      </div>
      
      <h3 className="text-xl font-semibold text-primary mt-6 mb-3">Additional Tips</h3>
      <ul className="list-disc pl-5 space-y-2">
        <li>
          <strong>Use Tabs:</strong> Below the search bar, use the 'Images', 'News', 'Videos', or 'Maps' 
          tabs to find specific types of information faster.
        </li>
        <li>
          <strong>Don't Believe Everything Instantly:</strong> If you find important information, try to 
          confirm it on 1 or 2 other reliable websites. Sometimes information online can be wrong or outdated.
        </li>
        <li>
          <strong>Filter by Time:</strong> For recent information, click "Tools" after searching, then 
          select a time range (like "Past year" or "Past month").
        </li>
        <li>
          <strong>Use Site-Specific Search:</strong> Add "site:[website]" to only search within a specific website.
          <div className="bg-gray-50 p-2 rounded mt-1">
            <span className="font-mono text-sm">Example: scholarship applications site:nic.in</span>
          </div>
        </li>
      </ul>
      
      <div className="bg-green-50 border border-green-200 p-4 rounded-lg mt-8">
        <h4 className="font-semibold text-green-700 mb-2">Practice Exercise</h4>
        <p>Try these searches and compare the results:</p>
        <ol className="list-decimal ml-5 space-y-2">
          <li>Search simply: "jobs"</li>
          <li>Then search specifically: "entry level data entry jobs in [your city] 2025"</li>
          <li>Notice how many more relevant results you get with the specific search.</li>
        </ol>
      </div>
    </div>
  );
};

export default HowToSearch;
