
import React from "react";

const HowToYoutube = () => {
  return (
    <div className="prose max-w-none">
      <h2 className="text-2xl font-bold text-primary mb-4">How-To Guide 2: Learn Effectively from YouTube</h2>
      
      <div className="bg-blue-50 p-4 rounded-lg mb-6">
        <h3 className="font-semibold text-primary mb-2">Why?</h3>
        <p>
          YouTube is like a giant free school with videos on almost anything! Learning to find good educational videos 
          and watch them actively helps you learn new skills and subjects easily.
        </p>
      </div>

      <div className="space-y-6">
        <section>
          <h3 className="text-xl font-semibold text-primary mb-3">Search Smartly</h3>
          <p>Use specific keywords like:</p>
          <ul className="list-disc ml-6">
            <li>[topic] tutorial for beginners</li>
            <li>[topic] explanation class 10</li>
            <li>learn [skill] step by step</li>
            <li>[topic] in Telugu</li>
          </ul>
        </section>

        <section>
          <h3 className="text-xl font-semibold text-primary mb-3">Choose Videos Wisely</h3>
          <p>Before watching, check:</p>
          <ul className="list-disc ml-6">
            <li><strong>Channel:</strong> Is it focused on education or the skill you want?</li>
            <li><strong>Title/Description:</strong> Is it clear what the video is about?</li>
            <li><strong>Date:</strong> Is it recent (especially for tech topics)?</li>
            <li><strong>Views/Likes:</strong> Can give some idea, but popularity doesn't always mean quality</li>
            <li><strong>Comments:</strong> Read a few - what do other viewers say? Are there corrections?</li>
          </ul>
        </section>

        <section className="bg-green-50 p-4 rounded-lg">
          <h3 className="text-xl font-semibold text-primary mb-3">Watch Actively (Don't Just Stare!)</h3>
          <ul className="list-disc ml-6 space-y-2">
            <li><strong>Pause Frequently:</strong> Stop the video to think or take notes</li>
            <li><strong>Rewatch:</strong> If something is confusing, watch that part again</li>
            <li><strong>Take Notes:</strong> Write down key points, steps, or definitions</li>
            <li><strong>Try It:</strong> If it's a skill tutorial, try doing the steps yourself</li>
            <li><strong>Control the Speed:</strong> Use settings to change playback speed as needed</li>
          </ul>
        </section>

        <div className="bg-yellow-50 p-4 rounded-lg">
          <h4 className="font-semibold text-primary mb-2">Important Reminder</h4>
          <p>
            Just like Google, don't assume everything in a video is 100% correct. If you're learning something critical, 
            check the information with other reliable sources (textbooks, trusted websites).
          </p>
        </div>
      </div>
    </div>
  );
};

export default HowToYoutube;
