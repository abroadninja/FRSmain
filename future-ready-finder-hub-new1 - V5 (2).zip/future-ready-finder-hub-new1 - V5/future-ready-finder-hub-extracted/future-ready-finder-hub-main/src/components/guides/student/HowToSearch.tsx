
import React from "react";

const HowToSearch = () => {
  return (
    <div className="prose max-w-none">
      <h2 className="text-2xl font-bold text-primary mb-4">How-To Guide 1: Search Smartly on Google</h2>
      
      <div className="bg-blue-50 p-4 rounded-lg mb-6">
        <h3 className="font-semibold text-primary mb-2">Why?</h3>
        <p>
          Google has almost all information, but finding the right information quickly and knowing if it's trustworthy saves you a lot of time and helps you learn correctly.
        </p>
      </div>

      <div className="space-y-4">
        <h3 className="text-xl font-semibold text-primary">How?</h3>
        
        <ul className="space-y-3">
          <li className="flex gap-2">
            <span className="font-semibold min-w-[120px]">Be Specific:</span>
            <span>Use detailed keywords. Instead of searching jobs, try "data entry jobs work from home India" or "government jobs for 12th pass near Parvathipuram".</span>
          </li>
          
          <li className="flex gap-2">
            <span className="font-semibold min-w-[120px]">Use Quotes "":</span>
            <span>For exact phrases. Search "Future Ready Skills Success" to find pages with exactly those words in that order. Great for finding specific names or titles.</span>
          </li>
          
          <li className="flex gap-2">
            <span className="font-semibold min-w-[120px]">Use Minus -:</span>
            <span>To remove unwanted results. Search "mango recipes -juice" if you want recipes but not juice. Search "best free courses -udemy" if you want to exclude Udemy results.</span>
          </li>
          
          <li className="flex gap-2">
            <span className="font-semibold min-w-[120px]">Ask Questions:</span>
            <span>Type your question directly, like "What is the capital of Andhra Pradesh?" or "How does photosynthesis work?".</span>
          </li>
          
          <li className="flex gap-2">
            <span className="font-semibold min-w-[120px]">Search in Your Language:</span>
            <span>Don't hesitate to search in Telugu or other regional languages. Google understands!</span>
          </li>
        </ul>

        <div className="bg-yellow-50 p-4 rounded-lg mt-6">
          <h4 className="font-semibold text-primary mb-2">Check the Source! (VERY IMPORTANT)</h4>
          <p>Look at the website address. Is it:</p>
          <ul className="list-disc ml-6 mt-2">
            <li>Official (.gov.in, .nic.in, .ap.gov.in)?</li>
            <li>Well-known news source (The Hindu, BBC)?</li>
            <li>Educational site (.edu, .ac.in)?</li>
            <li>Or just someone's personal blog or a site full of ads?</li>
          </ul>
          <p className="mt-2 text-yellow-800">Be careful – not all websites are reliable.</p>
        </div>

        <div className="space-y-2">
          <h4 className="font-semibold text-primary">Additional Tips:</h4>
          <ul className="list-disc ml-6">
            <li>Use Tabs: Below the search bar, use the 'Images', 'News', 'Videos', or 'Maps' tabs to find specific types of information faster.</li>
            <li>Don't Believe Everything Instantly: If you find important information, try to confirm it on 1 or 2 other reliable websites.</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default HowToSearch;
