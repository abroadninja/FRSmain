
import React from "react";

const HowToYoutube = () => {
  return (
    <div className="prose max-w-none">
      <h2 className="text-2xl font-bold text-primary mb-4">Learn Effectively from YouTube</h2>
      
      <div className="bg-red-50 p-4 rounded-lg mb-6">
        <h3 className="text-lg font-semibold mb-2">Why This Matters</h3>
        <p>
          YouTube is like a giant free school with videos on almost anything! Learning to find good educational 
          videos and watch them actively helps you learn new skills and subjects easily.
        </p>
      </div>

      <h3 className="text-xl font-semibold text-primary mt-6 mb-3">Finding Good Educational Content</h3>
      
      <div className="space-y-4">
        <div className="bg-white p-4 border-l-4 border-red-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Search Smartly</h4>
          <p>Use specific keywords like:</p>
          <ul className="list-disc ml-5">
            <li>[topic] tutorial for beginners</li>
            <li>[topic] explanation class 10</li>
            <li>learn [skill] step by step</li>
            <li>[topic] in Telugu</li>
          </ul>
          <div className="bg-gray-50 p-2 rounded mt-2">
            <span className="font-mono text-sm">Example: "photoshop basics for beginners 2025" or "python programming in Telugu"</span>
          </div>
        </div>
        
        <div className="bg-white p-4 border-l-4 border-red-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Choose Videos Wisely</h4>
          <p>Before watching, check:</p>
          <ul className="list-disc ml-5">
            <li><strong>Channel:</strong> Is it focused on education or the skill you want? Does it seem trustworthy?</li>
            <li><strong>Title/Description:</strong> Is it clear what the video is about?</li>
            <li><strong>Date:</strong> Is it recent (especially for tech topics)?</li>
            <li><strong>Views/Likes:</strong> Can give some idea, but popularity doesn't always mean quality.</li>
            <li><strong>Comments:</strong> Read a few comments – what do other viewers say? Are there corrections?</li>
          </ul>
        </div>
      </div>
      
      <h3 className="text-xl font-semibold text-primary mt-6 mb-3">Watching Actively</h3>
      
      <div className="bg-orange-50 border-l-4 border-orange-500 p-4 rounded my-6">
        <h3 className="font-bold text-orange-800">Don't Just Stare at the Screen!</h3>
        <p className="mt-2">
          Active watching means engaging with the content, not just passively consuming it.
        </p>
      </div>
      
      <div className="space-y-4">
        <div className="bg-white p-4 border-l-4 border-purple-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Pause Frequently</h4>
          <p>
            Stop the video to think or take notes. Don't rush through - give yourself time to process.
          </p>
        </div>
        
        <div className="bg-white p-4 border-l-4 border-purple-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Rewatch Difficult Sections</h4>
          <p>
            If something is confusing, watch that part again. Use the video timeline to jump back to specific points.
          </p>
        </div>
        
        <div className="bg-white p-4 border-l-4 border-purple-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Take Notes</h4>
          <p>
            Write down key points, steps, or definitions. This helps solidify your understanding.
          </p>
        </div>
        
        <div className="bg-white p-4 border-l-4 border-purple-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Try It</h4>
          <p>
            If it's a skill tutorial (like coding or design), try doing the steps yourself as you watch 
            or right after. Practice is essential!
          </p>
        </div>
        
        <div className="bg-white p-4 border-l-4 border-purple-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Control the Speed</h4>
          <p>
            Use the settings (gear icon ⚙️) to change playback speed. Slow down fast talkers or complex parts; 
            speed up slow parts you already understand.
          </p>
        </div>
      </div>
      
      <div className="bg-yellow-50 border-l-4 border-yellow-500 p-4 rounded my-6">
        <h3 className="font-bold text-yellow-800">Verify Important Info</h3>
        <p className="mt-2">
          Just like Google, don't assume everything in a video is 100% correct. If you're learning something critical, 
          check the information with other reliable sources (textbooks, trusted websites).
        </p>
      </div>
      
      <h3 className="text-xl font-semibold text-primary mt-6 mb-3">Using YouTube Features</h3>
      <ul className="list-disc pl-5 space-y-2">
        <li>
          <strong>Save to Playlists:</strong> Create learning playlists for different topics or courses.
        </li>
        <li>
          <strong>Use Timestamps:</strong> Many educational videos have timestamps in the description to jump to specific topics.
        </li>
        <li>
          <strong>Enable Captions:</strong> If the speaker is difficult to understand or uses unfamiliar terms.
        </li>
        <li>
          <strong>Subscribe to Quality Channels:</strong> Follow educational channels that consistently provide good content.
        </li>
      </ul>
      
      <div className="bg-green-50 border border-green-200 p-4 rounded-lg mt-8">
        <h4 className="font-semibold text-green-700 mb-2">Practice Exercise</h4>
        <ol className="list-decimal ml-5 space-y-2">
          <li>Pick a topic you're interested in learning.</li>
          <li>Search for a tutorial using specific keywords.</li>
          <li>Watch actively while taking notes.</li>
          <li>Try to explain what you learned to someone else without looking at your notes.</li>
        </ol>
      </div>
    </div>
  );
};

export default HowToYoutube;
