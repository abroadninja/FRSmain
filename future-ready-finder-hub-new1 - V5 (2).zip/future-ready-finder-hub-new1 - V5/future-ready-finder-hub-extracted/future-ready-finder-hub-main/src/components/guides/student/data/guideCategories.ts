
export interface Guide {
  id: string;
  title: string;
  description: string;
  category: string; 
  difficulty?: 'beginner' | 'intermediate' | 'advanced';
  tags?: string[];
  updated?: string; // ISO date string
}

export interface GuideCategory {
  id: string;
  name: string;
  description: string;
  icon?: string;
  color?: string;
}

// Define categories to organize guides
export const guideCategories: GuideCategory[] = [
  {
    id: 'research-skills',
    name: 'Research Skills',
    description: 'Learn how to find and evaluate information effectively',
    color: 'bg-blue-500',
  },
  {
    id: 'learning-techniques',
    name: 'Learning Techniques',
    description: 'Methods to improve how you learn and retain information',
    color: 'bg-green-500',
  },
  {
    id: 'digital-tools',
    name: 'Digital Tools',
    description: 'How to use technology for learning and productivity',
    color: 'bg-purple-500',
  },
  {
    id: 'communication',
    name: 'Communication',
    description: 'Improve your written and verbal communication skills',
    color: 'bg-orange-500',
  },
  {
    id: 'productivity',
    name: 'Productivity',
    description: 'Time management and organization strategies',
    color: 'bg-rose-500',
  },
  {
    id: 'career-development',
    name: 'Career Development',
    description: 'Build skills for your future career',
    color: 'bg-teal-500',
  }
];

// All guides in the system
export const guides: Guide[] = [
  // Research Skills category
  {
    id: 'how-to-search',
    title: 'Search Smartly on Google',
    description: 'Learn effective techniques to find exactly what you need on Google',
    category: 'research-skills',
    difficulty: 'beginner',
    tags: ['search', 'google', 'research'],
    updated: '2025-04-01'
  },
  {
    id: 'how-to-youtube',
    title: 'Learn Effectively from YouTube',
    description: 'How to find and use educational content on YouTube',
    category: 'research-skills',
    difficulty: 'beginner',
    tags: ['video', 'youtube', 'learning'],
    updated: '2025-04-01'
  },
  {
    id: 'using-ai-tools',
    title: 'Use AI (Gemini/ChatGPT) Smartly for Learning',
    description: 'Harness AI tools to enhance your learning experience',
    category: 'digital-tools',
    difficulty: 'intermediate',
    tags: ['ai', 'chatgpt', 'gemini', 'learning'],
    updated: '2025-04-01'
  },
  {
    id: 'note-taking',
    title: 'Simple Note-Taking Methods',
    description: 'Effective techniques to take and organize notes',
    category: 'learning-techniques',
    difficulty: 'beginner',
    tags: ['notes', 'organization', 'study'],
    updated: '2025-04-01'
  },
  {
    id: 'time-management',
    title: 'Basic Time Management Tips',
    description: 'Manage your time better to reduce stress and increase productivity',
    category: 'productivity',
    difficulty: 'beginner',
    tags: ['time', 'planning', 'productivity'],
    updated: '2025-04-01'
  },
  {
    id: 'group-study',
    title: 'Tips for Good Group Study',
    description: 'How to make group study sessions more effective',
    category: 'learning-techniques',
    difficulty: 'intermediate',
    tags: ['collaboration', 'study', 'groups'],
    updated: '2025-04-01'
  },
  {
    id: 'digital-communication',
    title: 'Tips for Clear Digital Communication',
    description: 'How to communicate clearly and effectively in digital platforms',
    category: 'communication',
    difficulty: 'beginner',
    tags: ['messaging', 'whatsapp', 'email'],
    updated: '2025-04-01'
  },
  {
    id: 'feedback-skills',
    title: 'Give & Receive Constructive Feedback',
    description: 'How to provide and accept feedback to grow and improve',
    category: 'communication',
    difficulty: 'intermediate',
    tags: ['feedback', 'communication', 'growth'],
    updated: '2025-04-01'
  },
  {
    id: 'resume-writing',
    title: 'Write a Simple Text Resume/Profile',
    description: 'Create a basic resume that highlights your skills and experience',
    category: 'career-development',
    difficulty: 'intermediate',
    tags: ['resume', 'career', 'job'],
    updated: '2025-04-01'
  }
];

// Helper function to get guides by category
export const getGuidesByCategory = (categoryId: string): Guide[] => {
  return guides.filter(guide => guide.category === categoryId);
};

// Helper function to get a guide by ID
export const getGuideById = (guideId: string): Guide | undefined => {
  return guides.find(guide => guide.id === guideId);
};

// Helper function to search guides by text
export const searchGuides = (searchText: string): Guide[] => {
  const lowercaseSearch = searchText.toLowerCase();
  return guides.filter(guide => 
    guide.title.toLowerCase().includes(lowercaseSearch) || 
    guide.description.toLowerCase().includes(lowercaseSearch) ||
    guide.tags?.some(tag => tag.toLowerCase().includes(lowercaseSearch))
  );
};
