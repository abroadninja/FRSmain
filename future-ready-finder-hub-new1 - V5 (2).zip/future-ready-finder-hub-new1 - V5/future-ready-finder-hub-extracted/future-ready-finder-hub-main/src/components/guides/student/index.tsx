
import React, { useState, useEffect } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/components/ui/use-toast";
import { 
  Book, BookOpen, Search, ChevronRight, 
  Clock, Filter, Star, BookUser 
} from "lucide-react";
import { 
  guideCategories, 
  guides, 
  getGuideById,
  getGuidesByCategory,
  searchGuides
} from "./data/guideCategories";

// Import all guide content components
import HowToSearch from "./content/HowToSearch";
import HowToYoutube from "./content/HowToYoutube";
import UsingAITools from "./content/UsingAITools";
import NoteTaking from "./content/NoteTaking";

// Helper function to render the correct guide component based on ID
const GuideContent = ({ guideId }: { guideId: string }) => {
  switch(guideId) {
    case 'how-to-search':
      return <HowToSearch />;
    case 'how-to-youtube': 
      return <HowToYoutube />;
    case 'using-ai-tools':
      return <UsingAITools />;
    case 'note-taking':
      return <NoteTaking />;
    default:
      return <div className="p-4">Guide content is coming soon...</div>;
  }
};

// Badge component for difficulty level
const DifficultyBadge = ({ level }: { level: string | undefined }) => {
  if (!level) return null;
  
  const colorMap: Record<string, string> = {
    beginner: "bg-green-100 text-green-800 border-green-200",
    intermediate: "bg-yellow-100 text-yellow-800 border-yellow-200",
    advanced: "bg-red-100 text-red-800 border-red-200"
  };
  
  return (
    <span className={`text-xs px-2 py-1 rounded-full border ${colorMap[level] || "bg-gray-100 text-gray-800"}`}>
      {level.charAt(0).toUpperCase() + level.slice(1)}
    </span>
  );
};

const StudentGuides: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [activeGuide, setActiveGuide] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredGuides, setFilteredGuides] = useState(guides);
  const { toast } = useToast();
  const navigate = useNavigate();
  
  // On initial load, check URL parameters
  useEffect(() => {
    const guideParam = searchParams.get('guide');
    const categoryParam = searchParams.get('category') || 'all';
    
    setActiveCategory(categoryParam);
    
    if (guideParam) {
      const guide = getGuideById(guideParam);
      if (guide) {
        setActiveGuide(guideParam);
      } else {
        toast({
          title: "Guide not found",
          description: `The guide "${guideParam}" could not be found.`,
          variant: "destructive"
        });
      }
    }
  }, [searchParams, toast]);
  
  // Filter guides when category or search changes
  useEffect(() => {
    let result = guides;
    
    // Filter by category first
    if (activeCategory !== 'all') {
      result = getGuidesByCategory(activeCategory);
    }
    
    // Then filter by search if there's a query
    if (searchQuery.trim()) {
      const filtered = searchGuides(searchQuery);
      // Only show guides that match both category and search filters
      result = result.filter(guide => filtered.some(g => g.id === guide.id));
    }
    
    setFilteredGuides(result);
  }, [activeCategory, searchQuery]);
  
  // Update URL when active guide changes
  useEffect(() => {
    if (activeGuide) {
      searchParams.set('guide', activeGuide);
      if (activeCategory !== 'all') {
        searchParams.set('category', activeCategory);
      } else {
        searchParams.delete('category');
      }
      setSearchParams(searchParams);
    } else {
      if (activeCategory !== 'all') {
        searchParams.set('category', activeCategory);
      } else {
        searchParams.delete('category');
      }
      searchParams.delete('guide');
      setSearchParams(searchParams);
    }
  }, [activeGuide, activeCategory, searchParams, setSearchParams]);
  
  const handleSelectGuide = (guideId: string) => {
    setActiveGuide(guideId);
  };
  
  const handleSelectCategory = (categoryId: string) => {
    setActiveCategory(categoryId);
    setActiveGuide(null);
  };
  
  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };
  
  const handleBack = () => {
    setActiveGuide(null);
  };
  
  return (
    <div className="container max-w-7xl mx-auto py-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-primary flex items-center">
          <BookOpen className="mr-2 h-7 w-7" />
          Student Resource Guides
        </h1>
      </div>
      
      {activeGuide ? (
        <div>
          <Button 
            variant="ghost" 
            className="mb-4"
            onClick={handleBack}
          >
            ← Back to guides
          </Button>
          <div className="bg-white rounded-lg shadow-md">
            <div className="p-6">
              <GuideContent guideId={activeGuide} />
            </div>
          </div>
        </div>
      ) : (
        <div>
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative w-full md:w-1/2">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search guides..."
                className="pl-10"
                value={searchQuery}
                onChange={handleSearch}
              />
            </div>
            
            {/* Add filters/sort options here later */}
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            {/* Categories sidebar */}
            <div className="md:col-span-3">
              <div className="bg-white rounded-lg shadow-md p-4">
                <h2 className="font-semibold mb-3 flex items-center">
                  <Filter className="mr-2 h-4 w-4" /> Categories
                </h2>
                <div className="space-y-1">
                  <Button
                    variant={activeCategory === 'all' ? "default" : "ghost"}
                    className="w-full justify-start"
                    onClick={() => handleSelectCategory('all')}
                  >
                    <Book className="mr-2 h-4 w-4" />
                    All Guides
                  </Button>
                  
                  {guideCategories.map(category => (
                    <Button
                      key={category.id}
                      variant={activeCategory === category.id ? "default" : "ghost"}
                      className={`w-full justify-start ${activeCategory === category.id ? '' : 'hover:bg-slate-100'}`}
                      onClick={() => handleSelectCategory(category.id)}
                    >
                      <span className={`h-2 w-2 rounded-full mr-2 ${category.color}`}></span>
                      {category.name}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
            
            {/* Main content area - Guide listing */}
            <div className="md:col-span-9">
              <div className="bg-white rounded-lg shadow-md p-6">
                {filteredGuides.length > 0 ? (
                  <div className="space-y-4">
                    <h2 className="text-xl font-semibold mb-4">
                      {activeCategory === 'all' 
                        ? 'All Guides' 
                        : guideCategories.find(c => c.id === activeCategory)?.name || 'Guides'}
                      <span className="text-gray-500 text-sm ml-2">({filteredGuides.length})</span>
                    </h2>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {filteredGuides.map(guide => (
                        <div 
                          key={guide.id}
                          className="border rounded-lg hover:shadow-md transition-shadow cursor-pointer overflow-hidden bg-white"
                          onClick={() => handleSelectGuide(guide.id)}
                        >
                          <div className={`h-2 w-full ${guideCategories.find(c => c.id === guide.category)?.color || 'bg-gray-300'}`}></div>
                          <div className="p-4">
                            <div className="flex justify-between items-start mb-2">
                              <h3 className="font-medium text-lg line-clamp-2">{guide.title}</h3>
                            </div>
                            <p className="text-gray-600 text-sm mb-3 line-clamp-2">{guide.description}</p>
                            
                            <div className="flex items-center justify-between">
                              <DifficultyBadge level={guide.difficulty} />
                              
                              <div className="flex items-center text-primary text-xs">
                                {guide.updated && (
                                  <span className="flex items-center">
                                    <Clock className="h-3 w-3 mr-1" />
                                    {new Date(guide.updated).toLocaleDateString()}
                                  </span>
                                )}
                              </div>
                            </div>
                            
                            <div className="mt-3 text-xs flex flex-wrap gap-1">
                              {guide.tags?.map(tag => (
                                <span key={tag} className="bg-gray-100 text-gray-700 px-2 py-1 rounded-full">
                                  #{tag}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <BookUser className="h-12 w-12 mx-auto text-gray-400 mb-3" />
                    <h3 className="text-lg font-medium text-gray-800 mb-1">No guides found</h3>
                    <p className="text-gray-600">
                      {searchQuery 
                        ? `No guides match "${searchQuery}"` 
                        : "No guides available in this category yet"}
                    </p>
                    {searchQuery && (
                      <Button 
                        variant="outline" 
                        className="mt-4"
                        onClick={() => setSearchQuery("")}
                      >
                        Clear search
                      </Button>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StudentGuides;
