
import React from "react";

const UsingAITools = () => {
  return (
    <div className="prose max-w-none">
      <h2 className="text-2xl font-bold text-primary mb-4">Use AI (like Gemini/ChatGPT) Smartly for Learning</h2>
      
      <div className="bg-purple-50 p-4 rounded-lg mb-6">
        <h3 className="text-lg font-semibold mb-2">Why This Matters</h3>
        <p>
          AI chat tools can be powerful learning buddies. They can explain things, summarize text, 
          brainstorm ideas, and even help you practice. But you need to use them wisely and carefully.
        </p>
      </div>

      <h3 className="text-xl font-semibold text-primary mt-6 mb-3">Effective AI Prompt Strategies</h3>
      
      <div className="space-y-4">
        <div className="bg-white p-4 border-l-4 border-purple-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Ask Specific, Clear Questions</h4>
          <p>Give context! Instead of "Tell me about India", ask:</p>
          <div className="bg-gray-50 p-2 rounded mt-2">
            <span className="font-mono text-sm">"What are the main agricultural products of Andhra Pradesh?"</span>
          </div>
          <div className="bg-gray-50 p-2 rounded mt-2">
            <span className="font-mono text-sm">"Explain the role of the President of India to a 10th standard student"</span>
          </div>
        </div>
        
        <div className="bg-white p-4 border-l-4 border-purple-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Get Simple Explanations</h4>
          <p>If you find a difficult word or concept, ask AI to explain it simply:</p>
          <div className="bg-gray-50 p-2 rounded mt-2">
            <span className="font-mono text-sm">"Explain 'inflation' in simple terms"</span>
          </div>
          <div className="bg-gray-50 p-2 rounded mt-2">
            <span className="font-mono text-sm">"Explain 'blockchain' like I'm 15 years old"</span>
          </div>
          <div className="bg-gray-50 p-2 rounded mt-2">
            <span className="font-mono text-sm">"Explain [concept] in Telugu"</span>
          </div>
        </div>
        
        <div className="bg-white p-4 border-l-4 border-purple-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Summarize Long Text</h4>
          <p>Copy text from a website or document and ask:</p>
          <div className="bg-gray-50 p-2 rounded mt-2">
            <span className="font-mono text-sm">"Summarize this text in 5 bullet points"</span>
          </div>
          <div className="bg-gray-50 p-2 rounded mt-2">
            <span className="font-mono text-sm">"What are the main ideas in this paragraph?"</span>
          </div>
        </div>
        
        <div className="bg-white p-4 border-l-4 border-purple-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Brainstorm Ideas</h4>
          <p>Feeling stuck? Ask for ideas:</p>
          <div className="bg-gray-50 p-2 rounded mt-2">
            <span className="font-mono text-sm">"Give me 5 topic ideas for a science project about water conservation"</span>
          </div>
          <div className="bg-gray-50 p-2 rounded mt-2">
            <span className="font-mono text-sm">"What are some interesting facts about Parvathipuram?"</span>
          </div>
        </div>
      </div>
      
      <h3 className="text-xl font-semibold text-primary mt-6 mb-3">Learning Skills with AI</h3>
      
      <div className="space-y-4">
        <div className="bg-white p-4 border-l-4 border-indigo-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Practice & Get Feedback</h4>
          <p>Ask AI to test you:</p>
          <div className="bg-gray-50 p-2 rounded mt-2">
            <span className="font-mono text-sm">"Ask me 3 questions about the Mughal Empire"</span>
          </div>
          <p className="mt-2">You can even ask it for basic feedback on your writing:</p>
          <div className="bg-gray-50 p-2 rounded mt-2">
            <span className="font-mono text-sm">"Can you check this paragraph for grammar mistakes? [Paste paragraph]"</span>
          </div>
        </div>
        
        <div className="bg-white p-4 border-l-4 border-indigo-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Translate</h4>
          <p>Use it for quick translations:</p>
          <div className="bg-gray-50 p-2 rounded mt-2">
            <span className="font-mono text-sm">"Translate this English sentence to Telugu: 'Practice makes perfect.'"</span>
          </div>
        </div>
        
        <div className="bg-white p-4 border-l-4 border-indigo-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Check Different Drafts</h4>
          <p>
            Often, AI tools like Gemini offer multiple 'drafts' or versions of an answer. 
            Look at them to see different ways of explaining things.
          </p>
        </div>
      </div>
      
      <div className="bg-red-50 border-l-4 border-red-500 p-4 rounded my-6">
        <h3 className="font-bold text-red-800">CRITICAL WARNING - Use Your Brain!</h3>
        <div className="space-y-3 mt-3">
          <p>
            <strong>AI Makes Mistakes:</strong> AI is not always correct. It can give wrong facts, outdated information, 
            or biased opinions. ALWAYS double-check important information using reliable sources (books, teachers, trusted websites).
          </p>
          <p>
            <strong>Don't Copy-Paste:</strong> Use AI to understand, not just to get answers for homework. 
            Copying directly is cheating and doesn't help you learn.
          </p>
          <p>
            <strong>Think Critically:</strong> Ask yourself if the AI's answer makes sense. Does it match what you know? Is it logical?
          </p>
        </div>
      </div>
      
      <h3 className="text-xl font-semibold text-primary mt-6 mb-3">Practical Applications</h3>
      <ul className="list-disc pl-5 space-y-2">
        <li>
          <strong>Prepare for Exams:</strong> "Create a study plan for my 10th class science exam next week"
        </li>
        <li>
          <strong>Understand Difficult Concepts:</strong> "Explain quadratic equations with a simple example"
        </li>
        <li>
          <strong>Research Guidance:</strong> "What should I include in my research about water pollution in local rivers?"
        </li>
        <li>
          <strong>Career Exploration:</strong> "What skills are needed to become a web developer in India?"
        </li>
      </ul>
      
      <div className="bg-green-50 border border-green-200 p-4 rounded-lg mt-8">
        <h4 className="font-semibold text-green-700 mb-2">Practice Exercise</h4>
        <ol className="list-decimal ml-5 space-y-2">
          <li>Pick a topic you're currently studying.</li>
          <li>Write 2-3 specific questions about aspects you find confusing.</li>
          <li>Ask an AI tool these questions and analyze the responses.</li>
          <li>Verify the information with your textbook or teacher.</li>
        </ol>
      </div>
    </div>
  );
};

export default UsingAITools;
