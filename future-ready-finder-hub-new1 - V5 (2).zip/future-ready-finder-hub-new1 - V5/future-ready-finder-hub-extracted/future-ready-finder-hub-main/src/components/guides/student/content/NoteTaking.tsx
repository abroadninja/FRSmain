
import React from "react";

const NoteTaking = () => {
  return (
    <div className="prose max-w-none">
      <h2 className="text-2xl font-bold text-primary mb-4">Simple Note-Taking Methods</h2>
      
      <div className="bg-green-50 p-4 rounded-lg mb-6">
        <h3 className="text-lg font-semibold mb-2">Why This Matters</h3>
        <p>
          Taking notes helps you pay attention, understand better, and remember information later from 
          lectures, videos, or reading. Good notes are a powerful study tool.
        </p>
      </div>

      <h3 className="text-xl font-semibold text-primary mt-6 mb-3">Effective Note-Taking Methods</h3>
      <p className="italic text-gray-600 mb-4">Choose a method or combine them based on your learning style and the subject</p>
      
      <div className="space-y-6">
        <div className="bg-white p-5 border rounded-lg shadow-sm">
          <h4 className="font-semibold text-lg mb-2">1. The Outline Method</h4>
          <p className="mb-2">Good for structured topics with clear hierarchies.</p>
          
          <ol className="list-decimal ml-5 space-y-1">
            <li>Start with the Main Topic (Heading).</li>
            <li>Indent (move slightly to the right) for Sub-Topics (use bullets • or numbers 1, 2, 3).</li>
            <li>Indent further for details, examples, or definitions under each sub-topic.</li>
          </ol>
          
          <div className="bg-gray-50 p-3 rounded-lg mt-3 border border-gray-200">
            <p className="font-semibold">Example:</p>
            <div className="ml-2 mt-2">
              <p className="font-bold">Photosynthesis</p>
              <div className="ml-4 mt-1">
                <p className="font-medium">What it is: Process plants use to make food.</p>
                <div className="ml-4">
                  <p className="mb-1">Ingredients needed:</p>
                  <ul className="list-disc ml-6">
                    <li>Sunlight</li>
                    <li>Water</li>
                    <li>Carbon Dioxide</li>
                  </ul>
                </div>
                <div className="ml-4 mt-2">
                  <p className="mb-1">Products:</p>
                  <ul className="list-disc ml-6">
                    <li>Glucose (food/sugar)</li>
                    <li>Oxygen</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-5 border rounded-lg shadow-sm">
          <h4 className="font-semibold text-lg mb-2">2. Keywords & Summary Method</h4>
          <p className="mb-2">Good for less structured info or when speed is needed.</p>
          
          <ol className="list-decimal ml-5 space-y-1">
            <li>Listen or read a section first.</li>
            <li>Jot down only the most important Keywords or short phrases.</li>
            <li>After the section (or later), write a brief 1-2 sentence Summary in YOUR OWN WORDS connecting the keywords.</li>
          </ol>
          
          <div className="bg-gray-50 p-3 rounded-lg mt-3 border border-gray-200">
            <p className="font-semibold">Example:</p>
            <div className="mt-2">
              <p className="font-medium">Keywords:</p>
              <p className="ml-4">Photosynthesis, plants, food, sunlight, water, CO2, glucose, oxygen</p>
              
              <p className="font-medium mt-3">Summary:</p>
              <p className="ml-4">Photosynthesis is how plants use sunlight, water, and CO2 to create their food (glucose) and release oxygen.</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white p-5 border rounded-lg shadow-sm">
          <h4 className="font-semibold text-lg mb-2">3. Cornell Method</h4>
          <p className="mb-2">A structured system that organizes notes for easy review and study.</p>
          
          <div className="space-y-2 mb-3">
            <p><strong>How to set up:</strong></p>
            <ol className="list-decimal ml-5 space-y-1">
              <li>Draw a line about 6-7cm from the left edge of your paper (creates a margin)</li>
              <li>Take your regular notes on the right side during class/while reading</li>
              <li>After class, write keywords, questions, or main ideas in the left margin</li>
              <li>Leave space at the bottom to write a summary of the page</li>
            </ol>
          </div>
          
          <div className="bg-gray-50 p-3 rounded-lg border border-gray-200">
            <div className="grid grid-cols-4 gap-3">
              <div className="col-span-1 border-r pr-2 pt-2">
                <p className="font-medium">Key Questions:</p>
                <ul className="mt-1 space-y-2">
                  <li>What is photosynthesis?</li>
                  <li>Inputs?</li>
                  <li>Outputs?</li>
                </ul>
              </div>
              <div className="col-span-3 pl-2 pt-2">
                <p className="font-medium">Notes:</p>
                <p className="mt-1">
                  Photosynthesis - process where plants convert sunlight into energy.
                  Plants take in sunlight, water (from roots), and carbon dioxide (from air).
                  The plant uses these to create glucose (sugar) for energy.
                  Oxygen is released as a byproduct through tiny holes in leaves.
                </p>
              </div>
            </div>
            <div className="border-t mt-3 pt-2">
              <p className="font-medium">Summary:</p>
              <p className="mt-1">
                Plants make their own food through photosynthesis by converting sunlight, water, and CO2 into glucose, while releasing oxygen.
              </p>
            </div>
          </div>
        </div>
      </div>
      
      <h3 className="text-xl font-semibold text-primary mt-8 mb-3">General Tips for Any Method</h3>
      
      <div className="space-y-4">
        <div className="bg-white p-4 border-l-4 border-green-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Don't Write Everything</h4>
          <p>
            Focus on main ideas, new vocabulary, important facts/steps.
          </p>
        </div>
        
        <div className="bg-white p-4 border-l-4 border-green-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Use Your Own Words</h4>
          <p>
            Paraphrasing helps you process and remember.
          </p>
        </div>
        
        <div className="bg-white p-4 border-l-4 border-green-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Use Abbreviations & Symbols</h4>
          <p>
            Save time! (e.g., &=and, w/=with, b/c=because, imp=important, →=leads to, ↑=increase, ↓=decrease). 
            Make a key if needed.
          </p>
        </div>
        
        <div className="bg-white p-4 border-l-4 border-green-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Leave Space</h4>
          <p>
            Leave margins or space between points to add your own thoughts, questions, or connections later.
          </p>
        </div>
        
        <div className="bg-white p-4 border-l-4 border-green-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Highlight/Mark</h4>
          <p>
            Use underlining, stars (*), or simple color later to mark key definitions or important points for review.
          </p>
        </div>
        
        <div className="bg-white p-4 border-l-4 border-green-500 rounded shadow-sm">
          <h4 className="font-semibold mb-1">Review Regularly</h4>
          <p>
            Look over your notes within a day or two to help fix them in your memory.
          </p>
        </div>
      </div>
      
      <div className="bg-yellow-50 border-l-4 border-yellow-500 p-4 rounded my-6">
        <h3 className="font-bold text-yellow-800">Digital vs. Handwritten Notes</h3>
        <div className="grid md:grid-cols-2 gap-4 mt-3">
          <div>
            <p className="font-semibold mb-1">Digital Benefits:</p>
            <ul className="list-disc ml-5">
              <li>Easy to organize and search</li>
              <li>Can include images, links, videos</li>
              <li>Never gets lost</li>
              <li>Can be shared easily</li>
              <li>Typing may be faster</li>
            </ul>
          </div>
          <div>
            <p className="font-semibold mb-1">Handwritten Benefits:</p>
            <ul className="list-disc ml-5">
              <li>Better for memory & understanding</li>
              <li>Freedom to draw & create layouts</li>
              <li>No tech distractions</li>
              <li>No battery/internet required</li>
              <li>Easier for math & diagrams</li>
            </ul>
          </div>
        </div>
        <p className="mt-3">
          <strong>Tip:</strong> Choose whichever works better for you, or combine both methods!
        </p>
      </div>
      
      <div className="bg-green-50 border border-green-200 p-4 rounded-lg mt-8">
        <h4 className="font-semibold text-green-700 mb-2">Practice Exercise</h4>
        <ol className="list-decimal ml-5 space-y-2">
          <li>Try each method (Outline, Keywords, Cornell) on different days or subjects</li>
          <li>At the end of the week, review which felt most comfortable and helpful for you</li>
          <li>Customize your preferred method to work even better for your learning style</li>
        </ol>
      </div>
    </div>
  );
};

export default NoteTaking;
