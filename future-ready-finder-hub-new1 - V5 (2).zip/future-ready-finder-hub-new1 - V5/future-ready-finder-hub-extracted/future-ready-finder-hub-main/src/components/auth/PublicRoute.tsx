
import React, { useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "./AuthProvider";

interface PublicRouteProps {
  children: React.ReactNode;
}

export const PublicRoute: React.FC<PublicRouteProps> = ({ children }) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  
  useEffect(() => {
    // Only redirect from login/signup pages if user is logged in
    // Don't redirect from home page, allow both logged-in and non-logged-in users to access it
    if (user && ["/login", "/signup"].includes(location.pathname)) {
      // Use replace: true to prevent creating history entries that can cause redirect loops
      navigate("/dashboard", { replace: true });
    }
    // Only run when the user state or location pathname changes
  }, [user, location.pathname, navigate]);
  
  return <>{children}</>;
};

export default PublicRoute;
