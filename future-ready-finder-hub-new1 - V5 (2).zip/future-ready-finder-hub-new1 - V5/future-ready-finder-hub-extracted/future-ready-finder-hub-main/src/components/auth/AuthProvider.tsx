
import React, { createContext, useContext, useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { toast } from "sonner";

// Define the shape of our context
interface AuthContextType {
  user: any; // User object when logged in, null when logged out
  loading: boolean; // Whether we're currently checking auth state
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (email: string, password: string, profileData?: any) => Promise<void>;
  signOut: () => Promise<void>;
  resetPassword: (email: string) => Promise<{ success: boolean; message: string }>;
  updatePassword: (currentPassword: string, newPassword: string) => Promise<{ success: boolean; message: string }>;
}

// Create the context with a default value
const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  signIn: async () => {},
  signUp: async () => {},
  signOut: async () => {},
  resetPassword: async () => ({ success: false, message: 'Not implemented' }),
  updatePassword: async () => ({ success: false, message: 'Not implemented' }),
});

export const useAuth = () => useContext(AuthContext);

interface AuthProviderProps {
  children: React.ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const navigate = useNavigate();

  // Check if the user is already logged in when the component mounts
  useEffect(() => {
    const checkLoginStatus = () => {
      const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
      const storedUser = localStorage.getItem("user");
      
      if (isLoggedIn && storedUser) {
        try {
          setUser(JSON.parse(storedUser));
        } catch (error) {
          console.error("Error parsing stored user:", error);
          localStorage.removeItem("user");
          localStorage.setItem("isLoggedIn", "false");
        }
      }
      
      setLoading(false);
    };
    
    checkLoginStatus();
  }, []);

  // Sign in function
  const signIn = async (email: string, password: string) => {
    // Mock authentication call (simulate API delay)
    return new Promise<void>((resolve, reject) => {
      setTimeout(async () => {
        try {
          const isDemoPassword = password === 'demo123';
          const isDemoEmail = email === 'demo@futurereadyschools.com';
          
          // Get registered users from local storage
          const registeredUsers = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
          const userExists = registeredUsers.some((u: any) => u.email === email);
          
          // Special case: Demo email always works with demo password
          if (isDemoEmail && isDemoPassword) {
            // Check if demo user exists, if not create one
            let demoUser = registeredUsers.find((u: any) => u.email === 'demo@futurereadyschools.com');
            if (!demoUser) {
              demoUser = {
                id: 'demo-user-123',
                email: 'demo@futurereadyschools.com',
                name: 'Demo User',
                role: 'school_admin',
                usedDemoPassword: true
              };
              registeredUsers.push(demoUser);
              localStorage.setItem('registeredUsers', JSON.stringify(registeredUsers));
            }
            
            // Set user in state and local storage
            setUser(demoUser);
            localStorage.setItem('user', JSON.stringify(demoUser));
            localStorage.setItem('isLoggedIn', 'true');
            
            // Show success message
            toast.success('Welcome to the demo account!');
            navigate('/dashboard');
            return resolve();
          }
          
          // For non-demo emails, check if user exists when using demo password
          if (isDemoPassword) {
            if (!userExists) {
              throw new Error('No account found with this email. Please sign up first.');
            }
            // Show warning about using demo password
            toast.warning('Using demo password. Please update your password in Account settings.');
          } else {
            // Normal login - check credentials
            if (!userExists) {
              throw new Error('No account found with this email. Please sign up first.');
            }
            // In a real app, verify the password with your backend
            // For demo purposes, we'll just check if it's not empty
            if (!password) {
              throw new Error('Please enter your password');
            }
          }
          
          // Create or get user object
          let userObj = { 
            id: `user-${Date.now()}`,
            email,
            name: email.split('@')[0],
            role: 'school_admin',
            usedDemoPassword: isDemoPassword
          };
          
          // If user exists, get their data
          const existingUser = registeredUsers.find((u: any) => u.email === email);
          if (existingUser) {
            userObj = { ...existingUser, usedDemoPassword: isDemoPassword };
          } else {
            // Add new user to registered users
            registeredUsers.push({
              email,
              name: userObj.name,
              id: userObj.id,
              role: userObj.role
            });
            localStorage.setItem('registeredUsers', JSON.stringify(registeredUsers));
          }
          
          // Set user in state and local storage
          setUser(userObj);
          localStorage.setItem('user', JSON.stringify(userObj));
          localStorage.setItem('isLoggedIn', 'true');
          
          // Show success message
          toast.success(`Welcome back, ${userObj.name || 'User'}!`);
          
          // Redirect to dashboard after successful login
          navigate('/dashboard');
          resolve();
          
        } catch (error: any) {
          console.error('Login error:', error);
          reject(error);
        }
      }, 1000);
    });
  };

  // Sign up function
  const signUp = async (email: string, password: string, profileData?: any) => {
    return new Promise<void>((resolve, reject) => {
      setTimeout(() => {
        try {
          // Get existing users
          const registeredUsers = JSON.parse(localStorage.getItem('registeredUsers') || '[]');
          
          // Check if user already exists
          if (registeredUsers.some((u: any) => u.email === email)) {
            throw new Error('An account with this email already exists');
          }
          
          // Create new user
          const newUser = {
            id: `user-${Date.now()}`,
            email,
            name: profileData?.name || email.split('@')[0],
            role: 'school_admin',
            ...profileData
          };
          
          // Add to registered users
          registeredUsers.push(newUser);
          localStorage.setItem('registeredUsers', JSON.stringify(registeredUsers));
          
          // Show success message
          toast.success("Account created successfully! You can now log in with your credentials.", {
            duration: 5000,
          });
          
          // Navigate to login page after successful registration
          navigate('/login');
          
          resolve();
        } catch (error: any) {
          console.error('Signup error:', error);
          reject(new Error(error.message || 'Registration failed. Please try again.'));
        }
      }, 1000);
    });
  };

  // Sign out function
  const signOut = async () => {
    // Clear user state and local storage
    setUser(null);
    localStorage.removeItem("user");
    localStorage.setItem("isLoggedIn", "false");
    
    // Redirect to home page after sign out
    navigate('/');
  };

  const resetPassword = async (email: string) => {
    try {
      // In a real implementation, this would send a password reset email
      // For now, we'll simulate a successful request
      await new Promise(resolve => setTimeout(resolve, 1000));
      return { 
        success: true, 
        message: 'If an account with that email exists, you will receive a password reset link.' 
      };
    } catch (error: any) {
      return { 
        success: false, 
        message: error.message || 'Failed to send password reset email' 
      };
    }
  };

  const updatePassword = async (currentPassword: string, newPassword: string) => {
    try {
      if (!user) {
        throw new Error('User not authenticated');
      }
      
      // In a real implementation, verify current password and update to new password
      // For now, we'll simulate a successful update
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Update user in local storage
      const updatedUser = { ...user, updatedAt: new Date().toISOString() };
      localStorage.setItem('user', JSON.stringify(updatedUser));
      setUser(updatedUser);
      
      return { 
        success: true, 
        message: 'Password updated successfully' 
      };
    } catch (error: any) {
      return { 
        success: false, 
        message: error.message || 'Failed to update password' 
      };
    }
  };

  const value = {
    user,
    loading,
    signIn,
    signUp,
    signOut,
    resetPassword,
    updatePassword,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthProvider;
