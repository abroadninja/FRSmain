
// Re-export from components/ui/toast
export { useToast, toast } from "@/components/ui/toast";
