import { useEffect } from "react";
import { useLocation } from "react-router-dom";

/**
 * A component that scrolls to the top of the page on route changes.
 * Should be placed inside the Router component but outside of any Routes.
 */
const ScrollToTop = () => {
  const { pathname } = useLocation();

  useEffect(() => {
    // Scroll to the top of the page when the route changes
    window.scrollTo(0, 0);
  }, [pathname]);

  return null;
};

export default ScrollToTop;
